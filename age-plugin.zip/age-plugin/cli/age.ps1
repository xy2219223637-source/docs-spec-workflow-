#Requires -Version 5.1
# age.ps1 — AGE (Attractor-Guided Engineering) CLI 主入口 (PowerShell)
# 等价 cli/age(bash):dot-source cli/lib/*.ps1,按子命令分发。
# 命令签名与退出码严格遵循 CONTRACT.md 第3节。
# Win11 原生支持(不依赖 bash);macOS/Linux pwsh 同样可用。
#
# 用法:pwsh -NoProfile -File age.ps1 <command> [options]
#   或(Windows PowerShell 5.1):powershell -NoProfile -File age.ps1 <command> [options]

#Requires -Version 5.1
$ErrorActionPreference = "Stop"

# ---------------------------------------------------------------------------
# 定位插件根 + dot-source 共享库
# ---------------------------------------------------------------------------
$script:AGE_SELF = $MyInvocation.MyCommand.Path
if (-not $script:AGE_SELF) { $script:AGE_SELF = $PSCommandPath }
$script:AGE_SELF_DIR = Split-Path $script:AGE_SELF -Parent
$script:AGE_PLUGIN_ROOT = (Resolve-Path (Join-Path $script:AGE_SELF_DIR "..")).Path
$env:AGE_PLUGIN_ROOT = $script:AGE_PLUGIN_ROOT

# dot-source 共享库(顺序:common 先,其余可依赖它)
. (Join-Path $script:AGE_SELF_DIR "lib/common.ps1")
. (Join-Path $script:AGE_SELF_DIR "lib/init.ps1")
. (Join-Path $script:AGE_SELF_DIR "lib/sync.ps1")
. (Join-Path $script:AGE_SELF_DIR "lib/check.ps1")
. (Join-Path $script:AGE_SELF_DIR "lib/route.ps1")
. (Join-Path $script:AGE_SELF_DIR "lib/use.ps1")

# ---------------------------------------------------------------------------
# 帮助文本
# ---------------------------------------------------------------------------
function script:age_usage {
    @'
age — AGE (Attractor-Guided Engineering) CLI  v0.1.0

用法:
  age <command> [options]

命令:
  init      初始化 AGE 项目结构 + Day 0 引导
  sync      检测代码-文档漂移 (stale/orphan/missing)
  check     静态一致性校验 (路由死链/基线/引用)
  ci        非交互: check --strict + sync --json
  route     任务路由 → owner 文档 + 技能
  audit     文档与代码一致性审计 (full/plan/closure)
  baseline  快照当前 docs/ 指纹到 .age/baseline.json
  doctor    环境与配置诊断
  use       激活 AGE(检测+自动初始化)
  install   安装 AGE 适配配置到当前客户端(ZCode/Claude/Codex/OpenCode/Multica/Win11)
  help      显示帮助

退出码: 见各命令 --help;CI 类命令 0=通过 1=失败。

环境变量:
  AGE_PLUGIN_ROOT  插件根目录(自动探测,可覆盖)
  AGE_NO_COLOR     设为 1 禁用颜色输出

运行 age <command> --help 查看子命令详情。
'@ | Write-Host
}

# ---------------------------------------------------------------------------
# age ci:非交互 = check --strict + sync --json
# ---------------------------------------------------------------------------
function script:age_ci {
    age_init_runtime
    $rc = 0
    age_info "[ci] step 1/2: age check --strict"
    age_call_cli check --strict
    if ($LASTEXITCODE -ne 0) { $rc = 1 }
    age_info "[ci] step 2/2: age sync --json"
    age_call_cli sync --json
    if ($LASTEXITCODE -ne 0) { $rc = 1 }
    if ($rc -eq 0) {
        age_success "[ci] 全部通过"
    } else {
        age_error "[ci] 存在问题(见上)"
    }
    return $rc
}

# ---------------------------------------------------------------------------
# age baseline:快照当前 docs/ 指纹到 .age/baseline.json
# ---------------------------------------------------------------------------
function script:age_baseline {
    age_init_runtime
    $root = (Get-Location).Path
    $rt = age_runtime_dir
    $out = Join-Path $rt "baseline.json"

    $docsDir = Join-Path $root "docs"
    if (-not (Test-Path $docsDir -PathType Container)) {
        age_warn "docs/ 目录不存在,基线为空。"
        $ts = (Get-Date -Format "yyyy-MM-ddTHH:mm:sszzz")
        $empty = '{"files":[],"generated":"' + $ts + '","note":"docs 目录不存在"}'
        $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
        [System.IO.File]::WriteAllText($out, $empty, $utf8NoBom)
        return 0
    }

    # 遍历 docs/**/*.md,记录 path/mtime/lines/sha
    $files = [System.Collections.Generic.List[hashtable]]::new()
    $mds = Get-ChildItem -Path $docsDir -Recurse -Filter "*.md" -File | Sort-Object FullName
    foreach ($f in $mds) {
        $rel = $f.FullName.Substring($root.Length).TrimStart('\', '/')
        $mtime = [int64]$f.LastWriteTime.ToFileTimeUtc()
        $lines = 0
        try { $lines = @(Get-Content -Path $f.FullName -Encoding UTF8).Count } catch { $lines = 0 }
        # sha256
        $sha = ""
        try {
            $shaBytes = [System.Security.Cryptography.SHA256]::Create().ComputeHash([System.IO.File]::ReadAllBytes($f.FullName))
            $sha = ($shaBytes | ForEach-Object { $_.ToString("x2") }) -join ''
        } catch { $sha = "" }
        $files.Add(@{ path = $rel; mtime = $mtime; lines = $lines; sha = $sha })
    }

    # 生成 JSON
    $ts = (Get-Date -Format "yyyy-MM-ddTHH:mm:sszzz")
    $filesJson = ($files | ForEach-Object {
        '{"path":"' + (age_json_escape $_.path) + '","mtime":' + $_.mtime + ',"lines":' + $_.lines + ',"sha":"' + (age_json_escape $_.sha) + '"}'
    }) -join ','
    $json = '{"generated":"' + $ts + '","root":"' + (age_json_escape $root) + '","count":' + $files.Count + ',"files":[' + $filesJson + ']}'
    $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
    [System.IO.File]::WriteAllText($out, $json, $utf8NoBom)

    age_success "基线已快照: $out ($($files.Count) 个文档)"
    return 0
}

# ---------------------------------------------------------------------------
# age audit:文档与代码一致性审计 (inline,等价 audit.sh)
# ---------------------------------------------------------------------------
$script:AGE_AUDIT_VIOLATIONS = 0

function script:age_audit {
    param([Parameter(ValueFromRemainingArguments)][string[]]$Args)

    age_init_runtime
    $script:AGE_AUDIT_VIOLATIONS = 0

    $scope = "full"
    $i = 0
    while ($i -lt $Args.Length) {
        $a = $Args[$i]
        switch -Regex ($a) {
            '^--scope$'  { if (($i + 1) -lt $Args.Length) { $scope = $Args[$i + 1]; $i += 2 } else { $i++ } }
            '^--scope='  { $scope = $a.Substring(8); $i++ }
            '^(-h|--help)$' { age_audit_help; return 0 }
            default      { age_warn "未知参数: $a"; $i++ }
        }
    }

    if ($scope -notin @("full", "plan", "closure")) {
        age_die "无效 --scope: $scope (允许: full|plan|closure)" 1
    }

    $root = (Get-Location).Path
    find_plugin_root | Out-Null

    Write-Host "$(age_color bold "AGE 审计 (scope=$scope)")"

    switch ($scope) {
        "full"    { age_audit_full $root }
        "plan"    { age_audit_plan $root }
        "closure" { age_audit_closure $root }
    }

    Write-Host ""
    if ($script:AGE_AUDIT_VIOLATIONS -gt 0) {
        Write-Host "  $(age_color red '结果')  发现 $($script:AGE_AUDIT_VIOLATIONS) 处违规" -ForegroundColor Red
        Write-Host "  建议: 调用 doc-auditor 子代理修复,或手动对照 owner 文档更新。"
        return 1
    } else {
        Write-Host "  $(age_color green '结果')  审计通过,无违规" -ForegroundColor Green
        return 0
    }
}

function script:age_audit_violation {
    param([string]$Message)
    $script:AGE_AUDIT_VIOLATIONS++
    age_error "违规: $Message"
}
function script:age_audit_note { param([string]$Message); age_warn "注意: $Message" }
function script:age_audit_pass { param([string]$Message); age_info "通过: $Message" }

function script:age_audit_full {
    param([string]$Root)
    age_info "[1/3] 静态一致性 (age check)..."
    $checkOut = & age_call_cli check --strict 2>&1 | Out-String
    $checkCode = $LASTEXITCODE
    if ($checkCode -ne 0) {
        age_audit_note "age check 报告问题(见下)"
        Write-Host $checkOut
        $script:AGE_AUDIT_VIOLATIONS++
    }

    age_info "[2/3] 代码-文档漂移 (age sync)..."
    $syncOut = & age_call_cli sync --json 2>&1 | Out-String
    $syncCode = $LASTEXITCODE
    if ($syncCode -ne 0) {
        if ($syncOut -match '"stale":\[\]' -and $syncOut -match '"orphan":\[\]' -and $syncOut -match '"missing":\[\]') {
            # 无实质漂移
        } else {
            age_audit_violation "存在代码-文档漂移(age sync)"
            Write-Host $syncOut
        }
    }

    age_info "[3/3] 文档目录完整性..."
    $expected = @("backlog", "requirements", "design", "architecture", "plans", "audits", "logs", "bugs", "testing", "context")
    foreach ($d in $expected) {
        if (-not (Test-Path (Join-Path $Root "docs/$d") -PathType Container)) {
            age_audit_violation "docs/$d/ 目录缺失"
        }
    }
}

function script:age_audit_plan {
    param([string]$Root)
    $plansDir = Join-Path $Root "docs/plans"
    if (-not (Test-Path $plansDir -PathType Container)) {
        age_audit_note "docs/plans/ 不存在,无计划可审"
        return
    }
    $plans = Get-ChildItem -Path $plansDir -Filter "*.md" | Where-Object { $_.Name -ne "README.md" }
    if (-not $plans) { age_audit_note "docs/plans/ 无计划文件"; return }
    $plan = $plans | Select-Object -First 1
    age_info "审查计划: $($plan.Name)"
    $content = Get-Content -Path $plan.FullName -Raw -Encoding UTF8
    if ($content -match '技能|skill|age-route') { age_audit_pass "含技能选择记录" }
    else { age_audit_violation "$($plan.Name): 缺技能选择记录" }
    if ($content -match '收尾|closure|audit|验证|verify') { age_audit_pass "含收尾/验证规则" }
    else { age_audit_violation "$($plan.Name): 缺收尾规则" }
    if ($content -match '验收|标准|criteria|acceptance|测试|test') { age_audit_pass "含验证标准" }
    else { age_audit_violation "$($plan.Name): 缺验证标准" }
}

function script:age_audit_closure {
    param([string]$Root)
    age_info "[1/3] 代码-文档漂移..."
    $syncOut = & age_call_cli sync --json 2>&1 | Out-String
    $syncCode = $LASTEXITCODE
    if ($syncCode -ne 0) {
        age_audit_violation "收尾前存在漂移,需先 sync 修复"
        Write-Host $syncOut
    } else {
        age_audit_pass "无漂移"
    }

    age_info "[2/3] docs/context/ 强制上下文非空..."
    $ctx = Join-Path $Root "docs/context"
    $quintet = @("project-context", "ai-autonomy-policy", "codebase-map", "source-of-truth-and-precedence", "conventions")
    $empty = $false
    foreach ($f in $quintet) {
        $p = Join-Path $ctx "$f.md"
        if (-not (Test-Path $p -PathType Leaf)) {
            age_audit_violation "缺失 $f.md"; $empty = $true; continue
        }
        $body = age_strip_frontmatter $p
        if (-not $body.Trim()) { age_audit_violation "$f.md 内容为空"; $empty = $true }
    }
    if (-not $empty) { age_audit_pass "五件套齐全非空" }

    age_info "[3/3] docs/logs/ 有收尾记录..."
    $logsDir = Join-Path $Root "docs/logs"
    if (Test-Path $logsDir -PathType Container) {
        $nlogs = @(Get-ChildItem -Path $logsDir -Filter "*.md" | Where-Object { $_.Name -ne "README.md" }).Count
        if ($nlogs -gt 0) { age_audit_pass "logs 有 $nlogs 份记录" }
        else { age_audit_note "docs/logs/ 无记录(建议补充任务日志)" }
    } else {
        age_audit_note "docs/logs/ 不存在"
    }
}

function script:age_audit_help {
    @'
age audit — 文档与代码一致性审计

用法:
  age audit [--scope full|plan|closure]

scope:
  full     全量一致性(check + sync + 目录完整性)
  plan     计划审计(实现前):技能记录/收尾规则/验证标准
  closure  收尾审计(完成前):无漂移/五件套非空/logs记录

退出码: 0 通过 / 1 违规
'@ | Write-Host
}

# ---------------------------------------------------------------------------
# age doctor:环境与配置诊断 (inline,等价 doctor.sh)
# ---------------------------------------------------------------------------
function script:age_doctor {
    param([Parameter(ValueFromRemainingArguments)][string[]]$Args)

    age_init_runtime
    foreach ($a in $Args) {
        switch -Regex ($a) {
            '^(-h|--help)$' { age_doctor_help; return 0 }
            default         { age_warn "未知参数: $a" }
        }
    }

    $root = (Get-Location).Path
    find_plugin_root | Out-Null
    $problems = 0

    Write-Host "$(age_color bold 'AGE 环境诊断')"
    Write-Host ""

    # 1. git 可用
    if (age_git_ok) {
        $gv = (& git --version 2>$null | Select-Object -First 1)
        Write-Host "  ✓ git 可用 ($gv)" -ForegroundColor Green
    } else {
        Write-Host "  ✗ git 不可用" -ForegroundColor Red
        Write-Host "    修复: 安装 git,或在 git 仓库内运行 age 命令(无 git 时 sync 降级为空)。"
        $problems++
    }

    # 2. CLI 定位
    if ($script:AGE_PLUGIN_ROOT -and (Test-Path (Join-Path $script:AGE_PLUGIN_ROOT "cli/age.ps1") -PathType Leaf)) {
        Write-Host "  ✓ age.ps1 可定位 ($($script:AGE_PLUGIN_ROOT)/cli/age.ps1)" -ForegroundColor Green
    } elseif ($script:AGE_PLUGIN_ROOT -and (Test-Path (Join-Path $script:AGE_PLUGIN_ROOT "cli/age") -PathType Leaf)) {
        Write-Host "  ⚠ age 命令(bash)可定位,age.ps1 在 $($script:AGE_PLUGIN_ROOT)/cli/" -ForegroundColor Yellow
        $problems++
    } else {
        Write-Host "  ✗ age 命令不可定位" -ForegroundColor Red
        Write-Host "    修复: 确认在 AGE 插件目录内运行,或设置 AGE_PLUGIN_ROOT。"
        $problems++
    }

    # 3. AGENTS.md
    $agents = Join-Path $root "AGENTS.md"
    if (Test-Path $agents -PathType Leaf) {
        $content = Get-Content -Path $agents -Raw -Encoding UTF8
        if ($content) {
            if ($content -match '(?m)^#{1,6} ') {
                Write-Host "  ✓ AGENTS.md 可解析" -ForegroundColor Green
            } else {
                Write-Host "  ⚠ AGENTS.md 缺少标题结构" -ForegroundColor Yellow
                $problems++
            }
        } else {
            Write-Host "  ✗ AGENTS.md 为空" -ForegroundColor Red
            $problems++
        }
    } else {
        Write-Host "  ⚠ AGENTS.md 不存在(非 AGE 仓库?)" -ForegroundColor Yellow
        $problems++
    }

    # 4. docs/index.md 路由表
    $index = age_index_path $root
    if ($index) {
        $routes = age_parse_index_routes $index
        if ($routes.Count -gt 0) {
            Write-Host "  ✓ docs/index.md 路由表有 $($routes.Count) 条记录" -ForegroundColor Green
        } else {
            Write-Host "  ⚠ docs/index.md 路由表无有效记录" -ForegroundColor Yellow
            $problems++
        }
    } else {
        Write-Host "  ⚠ docs/index.md 不存在" -ForegroundColor Yellow
        $problems++
    }

    # 5. hook(检查 .ps1 与 .sh 脚本)
    $hooksJson = Join-Path $script:AGE_PLUGIN_ROOT "hooks/hooks.json"
    if (Test-Path $hooksJson -PathType Leaf) {
        Write-Host "  ✓ hooks/hooks.json 存在" -ForegroundColor Green
    } else {
        Write-Host "  ⚠ hooks/hooks.json 不存在" -ForegroundColor Yellow
    }

    # 6. 插件 manifest
    $manifest = Join-Path $script:AGE_PLUGIN_ROOT ".zcode-plugin/plugin.json"
    if (Test-Path $manifest -PathType Leaf) {
        Write-Host "  ✓ .zcode-plugin/plugin.json 存在" -ForegroundColor Green
    } else {
        Write-Host "  ⚠ .zcode-plugin/plugin.json 不存在" -ForegroundColor Yellow
    }

    # 7. MCP server + python
    $mcpServer = Join-Path $script:AGE_PLUGIN_ROOT "mcp/server.py"
    if (Test-Path $mcpServer -PathType Leaf) {
        $py = age_find_python
        if ($py) {
            Write-Host "  ✓ MCP server.py 存在, $py 可用" -ForegroundColor Green
        } else {
            Write-Host "  ⚠ MCP server.py 存在,但 python 不可用" -ForegroundColor Yellow
            Write-Host "    修复: 安装 python(Win11 上通常是 python,不含 3)。"
            $problems++
        }
    } else {
        Write-Host "  ✗ mcp/server.py 不存在" -ForegroundColor Red
        $problems++
    }

    Write-Host ""
    if ($problems -gt 0) {
        Write-Host "  $(age_color red '结果') 发现 $problems 个问题(见上方修复建议)" -ForegroundColor Red
        return 1
    } else {
        Write-Host "  $(age_color green '结果') 环境健康,所有检查通过" -ForegroundColor Green
        return 0
    }
}

function script:age_doctor_help {
    @'
age doctor — 环境与配置诊断

用法:
  age doctor

检查项:
  - git 可用性
  - age 命令定位
  - AGENTS.md 可解析
  - docs/index.md 路由表格式
  - hook 脚本已装
  - 插件 manifest 存在
  - MCP server + python 可用

退出码: 0 全部健康 / 1 有问题
'@ | Write-Host
}

# ---------------------------------------------------------------------------
# age install:安装 AGE 适配配置到当前客户端
# Win11 分支:拷贝 cli/age.ps1 + cli/lib/*.ps1 + hooks/scripts/*.ps1 +
#   hooks/hooks.win11.json 到目标,并提示把 age.ps1 加入 PATH。
# 其他客户端:优先委托 bash cli/age install(若 bash 可用);否则提示用 bash。
# ---------------------------------------------------------------------------
function script:age_install {
    param([Parameter(ValueFromRemainingArguments)][string[]]$Args)

    age_init_runtime

    $client = ""; $dryRun = $false; $listOnly = $false
    $i = 0
    while ($i -lt $Args.Length) {
        $a = $Args[$i]
        switch -Regex ($a) {
            '^--client$'  { if (($i + 1) -lt $Args.Length) { $client = $Args[$i + 1]; $i += 2 } else { $i++ } }
            '^--client='  { $client = $a.Substring(9); $i++ }
            '^--dry-run$' { $dryRun = $true; $i++ }
            '^--list$'    { $listOnly = $true; $i++ }
            '^(-h|--help)$' { age_install_help; return 0 }
            default       { age_warn "未知参数: $a"; $i++ }
        }
    }

    if ($listOnly) { age_install_list; return 0 }

    if (-not (find_plugin_root)) {
        age_die "无法定位 AGE 插件根(AGE_PLUGIN_ROOT 未设置或无效)。" 1
    }

    # 检测客户端
    if (-not $client) {
        $client = detect_host
        if ($client -eq "unknown") {
            age_error "无法自动检测当前客户端环境。请用 --client <name> 手动指定 (zcode|claude|codex|opencode|multica|win11)。"
            return 1
        }
        age_info "检测到当前客户端: $client"
    } else {
        if ($client -notin @("zcode", "claude", "codex", "opencode", "multica", "win11")) {
            age_die "无效 --client: $client (允许: zcode|claude|codex|opencode|multica|win11)" 1
        }
        age_info "使用手动指定客户端: $client"
    }

    # Win11 分支:PowerShell 原生安装
    if ($client -eq "win11") {
        return (_age_install_win11 $dryRun)
    }

    # 其他客户端:委托 bash cli/age install(bash 实现已含完整多客户端逻辑)
    $bashExe = Get-Command bash -ErrorAction SilentlyContinue
    if ($bashExe) {
        age_info "委托 bash cli/age install --client $client $(if ($dryRun) { '--dry-run' })"
        $bashAge = Join-Path $script:AGE_PLUGIN_ROOT "cli/age"
        $bashArgs = @($bashAge, "install", "--client", $client)
        if ($dryRun) { $bashArgs += "--dry-run" }
        & bash @bashArgs
        return $LASTEXITCODE
    } else {
        age_error "客户端 '$client' 的安装需 bash(Git-Bash/WSL)。当前环境无 bash。"
        age_info "Win11 用户请用: age install --client win11(纯 PowerShell,无需 bash)。"
        return 1
    }
}

# _age_install_win11 <dry_run>:Win11 PowerShell 原生安装
# 拷贝 cli/age.ps1 + cli/lib/*.ps1 + hooks/scripts/*.ps1 + hooks/hooks.win11.json
# 到目标目录(默认 ~/.age-cli/),并提示把 age.ps1 加入 PATH。
function script:_age_install_win11 {
    param([bool]$DryRun)
    $target = Join-Path $HOME ".age-cli"
    $srcRoot = $script:AGE_PLUGIN_ROOT

    age_info "Win11 安装:把 PowerShell CLI 入口拷贝到 $target"
    age_info "  (不覆盖 bash CLI;age.ps1 与 cli/age 并存,bash 走 bash,Win11 走 ps1)"

    if ($DryRun) {
        age_info "(dry-run) 将创建目录: $target"
        age_info "(dry-run) 将拷贝 cli/age.ps1 → $target/age.ps1"
        age_info "(dry-run) 将拷贝 cli/lib/*.ps1 → $target/lib/"
        age_info "(dry-run) 将拷贝 hooks/scripts/*.ps1 → $target/hooks/scripts/(若存在)"
        age_info "(dry-run) 将拷贝 hooks/hooks.win11.json → $target/hooks/hooks.win11.json(若存在)"
        age_info "(dry-run) 将提示把 $target 加入 PATH"
        return 0
    }

    # 创建目标目录
    foreach ($d in @($target, (Join-Path $target "lib"), (Join-Path $target "hooks/scripts"))) {
        if (-not (Test-Path $d -PathType Container)) {
            New-Item -ItemType Directory -Path $d -Force | Out-Null
        }
    }

    $rc = 0
    # 1. cli/age.ps1 → target/age.ps1
    $srcAge = Join-Path $srcRoot "cli/age.ps1"
    if (Test-Path $srcAge -PathType Leaf) {
        Copy-Item -Path $srcAge -Destination (Join-Path $target "age.ps1") -Force
        age_success "已拷贝 age.ps1 → $target/age.ps1"
    } else {
        age_error "cli/age.ps1 不存在(本应在本轮产出)。"
        $rc = 1
    }

    # 2. cli/lib/*.ps1 → target/lib/
    $libPs1 = Get-ChildItem -Path (Join-Path $srcRoot "cli/lib") -Filter "*.ps1" -File -ErrorAction SilentlyContinue
    if ($libPs1) {
        foreach ($f in $libPs1) {
            Copy-Item -Path $f.FullName -Destination (Join-Path $target "lib" $f.Name) -Force
        }
        age_success "已拷贝 $($libPs1.Count) 个 lib/*.ps1 → $target/lib/"
    } else {
        age_warn "cli/lib/*.ps1 未找到(可能尚未全部产出)。"
    }

    # 3. hooks/scripts/*.ps1 → target/hooks/scripts/(若存在)
    $hooksPs1Dir = Join-Path $srcRoot "hooks/scripts"
    if (Test-Path $hooksPs1Dir -PathType Container) {
        $hookPs1 = Get-ChildItem -Path $hooksPs1Dir -Filter "*.ps1" -File -ErrorAction SilentlyContinue
        if ($hookPs1) {
            foreach ($f in $hookPs1) {
                Copy-Item -Path $f.FullName -Destination (Join-Path $target "hooks/scripts" $f.Name) -Force
            }
            age_success "已拷贝 $($hookPs1.Count) 个 hooks/scripts/*.ps1 → $target/hooks/scripts/"
        } else {
            age_info "hooks/scripts/*.ps1 未找到(任务执行 agent 产出中)。跳过。"
        }
    } else {
        age_info "hooks/scripts/ 目录不存在。跳过 hook 脚本拷贝。"
    }

    # 4. hooks/hooks.win11.json → target/hooks/hooks.win11.json(若存在)
    $hooksWin11 = Join-Path $srcRoot "hooks/hooks.win11.json"
    if (Test-Path $hooksWin11 -PathType Leaf) {
        Copy-Item -Path $hooksWin11 -Destination (Join-Path $target "hooks/hooks.win11.json") -Force
        age_success "已拷贝 hooks.win11.json → $target/hooks/hooks.win11.json"
    } else {
        age_info "hooks/hooks.win11.json 未找到(任务执行 agent 产出中)。跳过。"
    }

    # 5. 提示加入 PATH
    age_info "安装完成。请把 $target 加入 PATH 以便在任意目录运行 age:"
    age_info '  PowerShell(当前用户,持久):'
    age_info "    `$current = [Environment]::GetEnvironmentVariable('PATH','User')"
    age_info "    [Environment]::SetEnvironmentVariable('PATH', `$current + ';$target', 'User')"
    age_info "  然后重开终端,运行: age doctor 验证。"
    age_info "  (age.ps1 会自动向上探测 AGE 插件根;若插件目录移动,重跑 age install --client win11)"
    age_warn "Win11 为 full 级兼容(§8.12):PowerShell 原生 CLI(不依赖 bash)+ .ps1 hook 脚本。"
    age_warn "  bash CLI(cli/age)在 Git-Bash/WSL 下仍可直接用(双层策略)。"
    return $rc
}

function script:age_install_list {
    @'
AGE 支持的客户端(兼容等级见 CONTRACT §8.11 + §8.12):

  客户端       兼容等级    配置语言      说明
  ───────────  ──────────  ────────────  ──────────────────────────────────
  zcode        full        JSON          原生插件宿主(plugin.json + marketplace)
  claude       full        JSON          Claude Code(hooks+skills+MCP+CLAUDE.md)
  codex        full        TOML          OpenAI Codex CLI(hooks+skills+MCP+AGENTS.md)
  opencode     partial     JSON/TS       OpenCode CLI(MCP+commands+plugin.ts,无 SessionStart/Stop 事件)
  multica      full        JSON          Multica(skill+MCP+autopilot,无本地 hooks)
  win11        full        PowerShell    Windows 11(PowerShell 原生 CLI + .ps1 hooks,不依赖 bash)

兼容等级说明:
  full     — MCP + 指令文件 + Skills + Slash commands + Hooks 全部支持
             (Win11 的 full:PowerShell 原生 CLI 入口 + .ps1 hook 脚本;
              Multica 的 full:Hooks 用 autopilot 触发器部分替代)
  partial  — MCP + 指令文件 + Commands + plugin 模块支持;无 SessionStart/Stop 事件

注意:
  - Win11 双层策略(§8.12):优先 PowerShell 原生(不要求 Git-Bash),Git-Bash 作为回退。
  - 安装指定客户端:age install --client <zcode|claude|codex|opencode|multica|win11>
  - 检测当前环境:age install(不带 --client,自动检测)
'@ | Write-Host
}

function script:age_install_help {
    @'
age install — 安装 AGE 适配配置到当前客户端

用法:
  age install [--client zcode|claude|codex|opencode|multica|win11] [--dry-run] [--list]

参数:
  --client NAME   手动指定客户端 (zcode|claude|codex|opencode|multica|win11)
                  不指定则自动检测当前环境
  --dry-run       预览将执行的安装操作,不实际写文件
  --list          列出所有支持的客户端及其兼容等级,不执行安装

兼容等级(CONTRACT §8.11 + §8.12):
  zcode    full(原生)    claude   full           codex    full
  opencode partial        multica  full(无本地 hooks)
  win11    full(PowerShell 原生 CLI + .ps1 hooks,不依赖 bash)

Win11 安装(§8.12 双层策略):
  age install --client win11
  - 拷贝 cli/age.ps1 + cli/lib/*.ps1 → ~/.age-cli/
  - 拷贝 hooks/scripts/*.ps1 + hooks/hooks.win11.json(若存在)
  - 提示把 ~/.age-cli 加入 PATH
  - 不覆盖 bash CLI(Git-Bash/WSL 下 cli/age 仍可用)

退出码: 0 成功 / 1 失败
'@ | Write-Host
}

# ---------------------------------------------------------------------------
# 主分发
# ---------------------------------------------------------------------------
function script:main {
    param([Parameter(ValueFromRemainingArguments)][string[]]$CmdArgs)

    if ($CmdArgs -and $CmdArgs.Count -gt 0) {
        $cmd = $CmdArgs[0]
        $rest = @()
        if ($CmdArgs.Count -gt 1) { $rest = $CmdArgs[1..($CmdArgs.Count - 1)] }
    } else {
        $cmd = "help"
        $rest = @()
    }

    # 兼容 $args(脚本顶层调用)
    switch ($cmd) {
        "init"       { return age_init @rest }
        "sync"       { return age_sync @rest }
        "check"      { return age_check @rest }
        "ci"         { return age_ci }
        "route"      { return age_route @rest }
        "audit"      { return age_audit @rest }
        "baseline"   { return age_baseline }
        "doctor"     { return age_doctor @rest }
        "use"        { return age_use @rest }
        "install"    { return age_install @rest }
        { $_ -in @("version", "--version", "-V") } { Write-Host "age $script:AGE_VERSION"; return 0 }
        { $_ -in @("help", "--help", "-h") } {
            if ($rest.Count -gt 0) {
                switch ($rest[0]) {
                    "init"    { age_init_help }
                    "sync"    { age_sync_help }
                    "check"   { age_check_help }
                    "route"   { age_route_help }
                    "audit"   { age_audit_help }
                    "doctor"  { age_doctor_help }
                    "use"     { age_use_help }
                    "install" { age_install_help }
                    default   { age_usage }
                }
            } else { age_usage }
            return 0
        }
        ""           { age_usage; return 0 }
        default      {
            age_error "未知命令: $cmd"
            age_usage
            exit 1
        }
    }
}

# 用 $args(脚本顶层自动变量)调用 main
$allArgs = @()
if ($args) { $allArgs = @($args) }
$exitCode = main $allArgs
if ($exitCode -ne $null) { exit $exitCode }

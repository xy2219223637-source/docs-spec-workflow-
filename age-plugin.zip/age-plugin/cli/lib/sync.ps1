# sync.ps1 — age sync 实现 (PowerShell)
# 等价 cli/lib/sync.sh:读 git diff,按 docs/index.md 路由表映射代码变更到 owner 文档。
# 输出 stale/orphan/missing 三类漂移。--json 输出结构化;否则人类可读。
# 退出码:0 无漂移 / 1 有漂移。无 git 时优雅降级(返回0)。

# ---------------------------------------------------------------------------
# age_sync:主入口
# ---------------------------------------------------------------------------
function script:age_sync {
    param([Parameter(ValueFromRemainingArguments)][string[]]$Args)

    age_init_runtime

    $since = ""; $json = $false
    $i = 0
    while ($i -lt $Args.Length) {
        $a = $Args[$i]
        switch -Regex ($a) {
            '^--since$'  { if (($i + 1) -lt $Args.Length) { $since = $Args[$i + 1]; $i += 2 } else { $i++ } }
            '^--since='  { $since = $a.Substring(8); $i++ }
            '^--json$'   { $json = $true; $i++ }
            '^(-h|--help)$' { age_sync_help; return 0 }
            default      { age_warn "未知参数: $a"; $i++ }
        }
    }

    $root = (Get-Location).Path

    # git 可用性
    if (-not (age_git_ok)) {
        if ($json) {
            '{"stale":[],"orphan":[],"missing":[],"git":"unavailable","note":"git 不可用,无法计算漂移"}' | Write-Output
        } else {
            age_warn "git 不可用,无法计算漂移。请确认已安装 git 且当前在仓库内。"
        }
        return 0
    }

    $gitroot = age_git_root
    if (-not $gitroot) { $gitroot = $root }

    # 确定对比基准
    $ref = $since
    if (-not $ref) {
        & git -C $gitroot rev-parse --verify HEAD 2>$null | Out-Null
        if ($LASTEXITCODE -eq 0) { $ref = "HEAD" } else { $ref = "" }
    }

    # 加载路由表
    $index = age_index_path $root
    if (-not $index) {
        if ($json) {
            '{"stale":[],"orphan":[],"missing":[],"note":"docs/index.md 不存在,无法映射"}' | Write-Output
        } else {
            age_warn "docs/index.md 不存在,无法进行路由映射。请先 age init。"
        }
        return 0
    }
    $routes = age_parse_index_routes $index

    # 取代码变更文件清单(排除 docs/ .age/ .zcode-plugin/ AGENTS.md)
    $excludePattern = '^(docs/|\.age/|\.zcode-plugin/|AGENTS\.md)'
    $changed = [System.Collections.Generic.List[string]]::new()
    if ($ref) {
        $diffOut = & git -C $gitroot diff --name-only $ref 2>$null
        foreach ($f in $diffOut) {
            if ($f -and ($f -notmatch $excludePattern)) { $changed.Add($f) }
        }
        $untracked = & git -C $gitroot ls-files --others --exclude-standard 2>$null
        foreach ($f in $untracked) {
            if ($f -and ($f -notmatch $excludePattern)) { $changed.Add($f) }
        }
    } else {
        $tracked = & git -C $gitroot ls-files 2>$null
        $untracked = & git -C $gitroot ls-files --others --exclude-standard 2>$null
        $all = @($tracked) + @($untracked) | Sort-Object -Unique
        foreach ($f in $all) {
            if ($f -and ($f -notmatch $excludePattern)) { $changed.Add($f) }
        }
    }

    # 取文档变更清单
    $docsChanged = [System.Collections.Generic.List[string]]::new()
    if ($ref) {
        $d1 = & git -C $gitroot diff --name-only $ref -- 'docs/' 2>$null
        foreach ($f in $d1) { if ($f) { $docsChanged.Add($f) } }
        $d2 = & git -C $gitroot ls-files --others --exclude-standard -- 'docs/' 2>$null
        foreach ($f in $d2) { if ($f) { $docsChanged.Add($f) } }
    } else {
        $d1 = & git -C $gitroot ls-files -- 'docs/' 2>$null
        $d2 = & git -C $gitroot ls-files --others --exclude-standard -- 'docs/' 2>$null
        $all = @($d1) + @($d2) | Sort-Object -Unique
        foreach ($f in $all) { if ($f) { $docsChanged.Add($f) } }
    }

    # 计算三类漂移
    $stale = [System.Collections.Generic.List[hashtable]]::new()
    $orphans = [System.Collections.Generic.List[hashtable]]::new()
    $missing = [System.Collections.Generic.List[string]]::new()
    age_sync_compute $gitroot $routes $changed $docsChanged $stale $orphans $missing ([ref]$null)

    # 输出
    if ($json) {
        age_sync_output_json $stale $orphans $missing $ref
    } else {
        age_sync_output_human $stale $orphans $missing $ref
    }

    $drift = 0
    if ($stale.Count -gt 0 -or $orphans.Count -gt 0 -or $missing.Count -gt 0) { $drift = 1 }
    return $drift
}

# ---------------------------------------------------------------------------
# age_sync_compute:核心计算
# 路由表格式自适应:模块式(第一列像代码路径)→ module→owner 映射;
#   意图式 → 目录约定推断。
# ---------------------------------------------------------------------------
function script:age_sync_compute {
    param(
        [string]$Gitroot,
        $Routes,
        $Changed,
        $DocsChanged,
        $StaleOut,
        $OrphansOut,
        $MissingOut,
        [ref]$Dummy
    )
    # 判定路由表是否为模块式:任一行的 intent 像代码路径
    $isModuleFormat = $false
    foreach ($r in $Routes) {
        if (age_looks_like_codepath $r.intent) { $isModuleFormat = $true; break }
    }

    if ($isModuleFormat) {
        age_sync_compute_module $Gitroot $Routes $Changed $DocsChanged $StaleOut $OrphansOut $MissingOut
    } else {
        age_sync_compute_intent $Gitroot $Routes $Changed $DocsChanged $StaleOut $OrphansOut $MissingOut
    }
}

# 模块式计算:Routes 项 intent=模块路径, reads=owner文档, writeback=技能
function script:age_sync_compute_module {
    param($Gitroot, $Routes, $Changed, $DocsChanged, $StaleOut, $OrphansOut, $MissingOut)
    foreach ($r in $Routes) {
        $module = $r.intent; $owner = $r.reads
        if (-not $module) { continue }
        foreach ($cf in $Changed) {
            if (-not $cf) { continue }
            if (age_path_matches $cf $module) {
                if (-not (age_file_in_list $owner $DocsChanged)) {
                    $StaleOut.Add(@{ module = $module; owner = $owner; changed_file = $cf })
                }
            }
        }
        if ($module) {
            $modPath = Join-Path $Gitroot $module
            if (-not (Test-Path $modPath)) {
                $OrphansOut.Add(@{ module = $module; owner = $owner })
            }
        }
    }
    # missing:变更文件未命中任何路由模块
    foreach ($cf in $Changed) {
        if (-not $cf) { continue }
        $hit = $false
        foreach ($r in $Routes) {
            if (-not $r.intent) { continue }
            if (age_path_matches $cf $r.intent) { $hit = $true; break }
        }
        if (-not $hit) { $MissingOut.Add($cf) }
    }
}

# 意图式计算:路由表无代码路径映射,采用目录约定
function script:age_sync_compute_intent {
    param($Gitroot, $Routes, $Changed, $DocsChanged, $StaleOut, $OrphansOut, $MissingOut)
    $nChanged = 0; foreach ($x in $Changed) { if ($x) { $nChanged++ } }
    $nDocsChanged = 0; foreach ($x in $DocsChanged) { if ($x) { $nDocsChanged++ } }

    # 有代码变更但无文档变更 → 全部代码变更为 stale
    if ($nChanged -gt 0 -and $nDocsChanged -eq 0) {
        foreach ($cf in $Changed) {
            if (-not $cf) { continue }
            $ownerDir = age_infer_owner_dir $cf
            $StaleOut.Add(@{ module = $cf; owner = "docs/$ownerDir/"; changed_file = $cf })
        }
    }

    # missing:仅当路由表为空时才报
    $nRoutes = 0; foreach ($x in $Routes) { $nRoutes++ }
    if ($nRoutes -eq 0) {
        foreach ($cf in $Changed) {
            if (-not $cf) { continue }
            $MissingOut.Add($cf)
        }
    }
}

# age_infer_owner_dir <codepath>:按约定推断 owner 文档目录
function script:age_infer_owner_dir {
    param([string]$p)
    if ($p -match 'test|spec') { return "testing" }
    if ($p -match 'bug|fix')   { return "bugs" }
    return "architecture"
}

# age_path_matches <file> <module>:文件是否落在 module 路径下
function script:age_path_matches {
    param([string]$file, [string]$module)
    if (-not $module) { return $false }
    if ($file -eq $module) { return $true }
    # 目录前缀匹配(兼容 / 和 \)
    $normModule = $module -replace '\\', '/'
    $normFile = $file -replace '\\', '/'
    if ($normFile.StartsWith($normModule + "/")) { return $true }
    # 通配匹配
    if ($normModule -match '[*?\[]') {
        if ($normFile -like $normModule) { return $true }
        if ($normFile -like ($normModule + "/*")) { return $true }
    }
    return $false
}

# age_file_in_list <file> <list>:file 是否出现在 list 中
function script:age_file_in_list {
    param([string]$file, $list)
    $base = Split-Path $file -Leaf
    foreach ($x in $list) {
        if (-not $x) { continue }
        if ($x -eq $file) { return $true }
        # 去前缀匹配
        $trimmed = $file -replace '^docs/', ''
        if ($x -eq $trimmed) { return $true }
        if ($x -eq ("docs/" + $file)) { return $true }
        # 文件名结尾匹配
        if ($x -like "*$base*") { return $true }
    }
    return $false
}

# ---------------------------------------------------------------------------
# 输出
# ---------------------------------------------------------------------------
function script:age_sync_output_human {
    param($Stale, $Orphan, $Missing, [string]$Ref)
    $nStale = $Stale.Count; $nOrphan = $Orphan.Count; $nMissing = $Missing.Count
    Write-Host "$(age_color bold 'AGE 漂移报告')  (基准: $(if ($Ref) { $Ref } else { '空仓库' }))"
    Write-Host ""
    if ($nStale -gt 0) {
        Write-Host "$(age_color yellow "⚠ stale ($nStale)"): 代码变更但 owner 文档未更新" -ForegroundColor Yellow
        foreach ($s in $Stale) { Write-Host "   $(age_color gray $s.module) → $($s.owner)  (变更: $($s.changed_file))" }
        Write-Host ""
    } else {
        Write-Host "✓ stale (0): 代码-文档同步" -ForegroundColor Green
    }
    if ($nOrphan -gt 0) {
        Write-Host "⚠ orphan ($nOrphan): 路由指向的代码模块已不存在" -ForegroundColor Yellow
        foreach ($o in $Orphan) { Write-Host "   $(age_color gray $o.module) → $($o.owner)" }
        Write-Host ""
    } else {
        Write-Host "✓ orphan (0): 无悬空路由" -ForegroundColor Green
    }
    if ($nMissing -gt 0) {
        Write-Host "⚠ missing ($nMissing): 新代码模块无路由(owner 文档缺失)" -ForegroundColor Yellow
        foreach ($m in $Missing) { Write-Host "   $(age_color gray $m)" }
        Write-Host ""
    } else {
        Write-Host "✓ missing (0): 所有代码模块已路由" -ForegroundColor Green
    }
    Write-Host ""
    $total = $nStale + $nOrphan + $nMissing
    if ($total -gt 0) {
        Write-Host "合计 $total 处漂移。修复后再次 age sync 验证。" -ForegroundColor Yellow
    } else {
        Write-Host "无漂移。" -ForegroundColor Green
    }
}

function script:age_sync_output_json {
    param($Stale, $Orphan, $Missing, [string]$Ref)
    # 构造 JSON(手拼以保证字段顺序与 bash 一致,供 MCP/hook 消费)
    $staleArr = ($Stale | ForEach-Object {
        '{"module":"' + (age_json_escape $_.module) + '","owner":"' + (age_json_escape $_.owner) + '","changed_file":"' + (age_json_escape $_.changed_file) + '"}'
    }) -join ','
    $orphanArr = ($Orphan | ForEach-Object {
        '{"module":"' + (age_json_escape $_.module) + '","owner":"' + (age_json_escape $_.owner) + '"}'
    }) -join ','
    $missingArr = ($Missing | ForEach-Object {
        '{"file":"' + (age_json_escape $_) + '"}'
    }) -join ','
    if (-not $staleArr)  { $staleArr = "" }
    if (-not $orphanArr) { $orphanArr = "" }
    if (-not $missingArr){ $missingArr = "" }
    $json = '{"since":"' + (age_json_escape $Ref) + '","stale":[' + $staleArr + '],"orphan":[' + $orphanArr + '],"missing":[' + $missingArr + ']}'
    Write-Output $json
}

# ---------------------------------------------------------------------------
function script:age_sync_help {
    @'
age sync — 检测代码与文档的漂移

用法:
  age sync [--since REF] [--json]

参数:
  --since REF  git 对比基准(默认 HEAD)
  --json       输出结构化 JSON(供 MCP/hook 消费)

漂移类别:
  stale   代码变更了,对应 owner 文档没动
  orphan  路由表指向的代码模块已删除
  missing 新代码模块无路由表条目

退出码: 0 无漂移 / 1 有漂移 / (无 git 时 0)
'@ | Write-Host
}

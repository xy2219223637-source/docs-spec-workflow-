# use.ps1 — age use 实现 (PowerShell)
# 等价 cli/lib/use.sh:检测当前项目是否已初始化 → 未初始化则自动 age init → 报告激活状态。
# 用法:age use [--name X] [--kind web|mobile|cli] [--json] [目标目录]

# ---------------------------------------------------------------------------
# age_use:主入口
# ---------------------------------------------------------------------------
function script:age_use {
    param([Parameter(ValueFromRemainingArguments)][string[]]$Args)

    $name = ""; $kind = ""; $jsonMode = $false; $target = "."
    $i = 0
    while ($i -lt $Args.Length) {
        $a = $Args[$i]
        switch -Regex ($a) {
            '^--name$'   { if (($i + 1) -lt $Args.Length) { $name = $Args[$i + 1]; $i += 2 } else { $i++ } }
            '^--name='   { $name = $a.Substring(7); $i++ }
            '^--kind$'   { if (($i + 1) -lt $Args.Length) { $kind = $Args[$i + 1]; $i += 2 } else { $i++ } }
            '^--kind='   { $kind = $a.Substring(7); $i++ }
            '^--json$'   { $jsonMode = $true; $i++ }
            '^(-h|--help)$' { age_use_help; return 0 }
            default      { $target = $a; $i++ }
        }
    }

    # 校验 kind(若提供)
    if ($kind -and $kind -notin @("web", "mobile", "cli")) {
        age_die "无效 --kind: $kind (允许: web|mobile|cli)" 1
    }

    # 目标目录处理(转为绝对路径)
    if (Test-Path $target -PathType Container) {
        $target = (Resolve-Path $target).Path
    } else {
        $target = (Join-Path (Get-Location).Path $target)
        New-Item -ItemType Directory -Path $target -Force | Out-Null
    }
    if (-not (Test-Path $target -PathType Container)) {
        New-Item -ItemType Directory -Path $target -Force | Out-Null
    }

    # 默认值:项目名=当前目录名,kind=web
    $dirName = Split-Path $target -Leaf
    if (-not $name) { $name = $dirName }
    if (-not $kind) { $kind = "web" }

    return (_age_use_run $target $name $kind $jsonMode)
}

# ---------------------------------------------------------------------------
# _age_use_run <target> <name> <kind> <quiet(json)>
# 退出码:0 成功(激活或初始化并激活)。
# ---------------------------------------------------------------------------
function script:_age_use_run {
    param([string]$Target, [string]$Name, [string]$Kind, [bool]$Quiet)
    $root = $Target

    # 1. 检测当前目录是否是 AGE 仓库(有 docs/index.md 或 AGENTS.md 或 .age/)
    $isInitialized = $false
    if ((is_age_repo $root) -or (Test-Path (Join-Path $root ".age") -PathType Container)) {
        $isInitialized = $true
    }

    if ($isInitialized) {
        # 2. 已初始化:报告激活状态 + 输出 context 摘要
        if (-not $Quiet) {
            age_success "AGE 已激活"
            _age_use_print_context_summary $root
        }
        _age_use_emit_json $true $false $Name $Quiet
        return 0
    }

    # 3. 未初始化:检测 git 仓库 + 自动执行 init
    $isGit = $false
    if (Test-Path (Join-Path $root ".git")) {
        $isGit = $true
    } elseif (age_git_ok) {
        $isGit = $true
    }

    if (-not $Quiet) {
        if (-not $isGit) {
            age_warn "当前目录不是 git 仓库,建议先 git init(AGE 不强制 git,仍可初始化)。"
        } else {
            age_info "检测到 AGE 未初始化,自动执行 age init..."
        }
    }

    # 调用 age_init(init.ps1 已 dot-source)
    # quiet 模式下抑制 age_init 的 stdout(进度信息),保留 stderr
    $initCode = 0
    Push-Location $root
    try {
        if ($Quiet) {
            age_init --name $Name --kind $Kind $root 2>&1 | Out-Null
            $initCode = $LASTEXITCODE
            if ($initCode -eq $null) { $initCode = 0 }
        } else {
            age_init --name $Name --kind $Kind $root
            $initCode = $LASTEXITCODE
            if ($initCode -eq $null) { $initCode = 0 }
        }
    } catch {
        $initCode = 1
    } finally {
        Pop-Location
    }

    if ($initCode -ne 0) {
        if (-not $Quiet) {
            age_error "AGE 自动初始化失败 (exit $initCode)。"
        }
        _age_use_emit_json $false $false $Name $Quiet
        return $initCode
    }

    # init 完成后报告
    if (-not $Quiet) {
        age_success "AGE 已自动初始化并激活"
        _age_use_print_context_summary $root
    }
    _age_use_emit_json $true $true $Name $Quiet
    return 0
}

# ---------------------------------------------------------------------------
# _age_use_emit_json <activated> <initialized> <project> <quiet>
# quiet=true 时输出 JSON 到 stdout(供 --json 模式与 MCP 消费)。
# ---------------------------------------------------------------------------
function script:_age_use_emit_json {
    param([bool]$Activated, [bool]$Initialized, [string]$Project, [bool]$Quiet)
    if ($Quiet) {
        $actFlag = if ($Activated) { "true" } else { "false" }
        $initFlag = if ($Initialized) { "true" } else { "false" }
        $json = '{"activated":' + $actFlag + ',"initialized":' + $initFlag + ',"project":"' + (age_json_escape $Project) + '"}'
        Write-Output $json
    }
}

# ---------------------------------------------------------------------------
# _age_use_print_context_summary <root>
# 读取 docs/context/ 摘要输出(人类可读)。
# ---------------------------------------------------------------------------
function script:_age_use_print_context_summary {
    param([string]$Root)
    $ctxDir = Join-Path $Root "docs/context"
    if (-not (Test-Path $ctxDir -PathType Container)) {
        age_info "docs/context/ 目录不存在(初始化未完成?)。"
        return
    }

    # 列出存在的 context 文件
    $files = [System.Collections.Generic.List[string]]::new()
    foreach ($f in @("project-context", "ai-autonomy-policy", "codebase-map",
                     "source-of-truth-and-precedence", "conventions",
                     "requirements", "decisions", "risks", "glossary")) {
        if (Test-Path (Join-Path $ctxDir "$f.md") -PathType Leaf) { $files.Add("$f.md") }
    }

    if ($files.Count -gt 0) {
        age_info "强制上下文 (docs/context/): $($files -join ' ')"
    } else {
        age_warn "docs/context/ 为空。"
    }

    # 输出 project-context.md 首个非空标题段(摘要预览)
    $pc = Join-Path $ctxDir "project-context.md"
    if (Test-Path $pc -PathType Leaf) {
        Write-Host ""
        age_info "项目上下文摘要 (docs/context/project-context.md):"
        $lines = Get-Content -Path $pc -Encoding UTF8
        $preview = [System.Text.StringBuilder]::new()
        $printed = $false
        $count = 0
        foreach ($line in $lines) {
            if ($line -match '^#') {
                if (-not $printed) { [void]$preview.AppendLine($line); $printed = $true }
                continue
            }
            if ($printed -and $line -match '^[^\s]') {
                [void]$preview.AppendLine($line); $count++
            }
            if ($printed -and $count -ge 8) { break }
        }
        $prev = $preview.ToString().Trim()
        if ($prev) {
            foreach ($l in $prev -split "`n") { Write-Host "    $l" }
        } else {
            Write-Host "    (无摘要内容,请编辑 docs/context/project-context.md)"
        }
    }
}

# ---------------------------------------------------------------------------
function script:age_use_help {
    @'
age use — 激活 AGE(检测 + 自动初始化)

用法:
  age use [--name X] [--kind web|mobile|cli] [--json] [目标目录]

参数:
  --name X        项目名称(未初始化时传给 age init;默认=当前目录名)
  --kind K        项目类型:web|mobile|cli(默认 web)
  --json          输出 JSON: {"activated":bool,"initialized":bool,"project":"..."}
  目标目录         默认当前目录

行为:
  1. 检测目标目录是否是 AGE 仓库(有 docs/index.md 或 AGENTS.md 或 .age/)
  2. 已初始化:输出"AGE 已激活"+ docs/context/ 摘要,退出码 0
  3. 未初始化:
     - 检测是否 git 仓库(有 .git/);非 git 则警告但仍可初始化
     - 用默认值自动执行 age init(项目名=当前目录名,kind=web,validate=空)
     - init 完成后输出"AGE 已自动初始化并激活",退出码 0
  4. --json 模式仅输出一行 JSON,供脚本/MCP 消费

退出码: 0 成功(已激活或初始化并激活) / 1 失败

JSON 字段说明:
  activated    true=AGE 已激活
  initialized  true=本次执行了自动初始化;false=此前已初始化
  project      项目名称
'@ | Write-Host
}

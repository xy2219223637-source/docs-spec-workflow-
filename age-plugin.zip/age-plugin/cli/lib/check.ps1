# check.ps1 — age check 实现 (PowerShell)
# 等价 cli/lib/check.sh:静态一致性校验。
#   1. docs/index.md 路由目标(owner 文档)存在
#   2. AGENTS.md 引用的技能可解析
#   3. docs/context/ 五件套齐全且非空
#   4. 需求↔设计↔架构闭环(交叉引用存在性)
# --strict:warning 也算失败。

$script:AGE_CHECK_ERRORS = 0
$script:AGE_CHECK_WARNINGS = 0

function script:age_check {
    param([Parameter(ValueFromRemainingArguments)][string[]]$Args)

    age_init_runtime
    $script:AGE_CHECK_ERRORS = 0
    $script:AGE_CHECK_WARNINGS = 0

    $strict = $false
    foreach ($a in $Args) {
        switch -Regex ($a) {
            '^--strict$'     { $strict = $true }
            '^(-h|--help)$'  { age_check_help; return 0 }
            default          { age_warn "未知参数: $a" }
        }
    }

    $root = (Get-Location).Path
    find_plugin_root | Out-Null

    Write-Host "$(age_color bold 'AGE 一致性检查')"

    age_check_index_routes $root
    age_check_agents_skills $root
    age_check_context_quintet $root
    age_check_traceability $root

    Write-Host ""
    $totalE = $script:AGE_CHECK_ERRORS; $totalW = $script:AGE_CHECK_WARNINGS
    $label = if ($totalE -gt 0) { (age_color red '结果') }
             elseif ($totalW -gt 0) { (age_color yellow '结果') }
             else { (age_color green '结果') }
    Write-Host "  $label  $totalE 错误, $totalW 警告"

    if ($totalE -gt 0) { return 1 }
    if ($strict -and $totalW -gt 0) { return 1 }
    return 0
}

# 计数辅助
function script:age_check_err {
    param([string]$Message)
    $script:AGE_CHECK_ERRORS++
    age_error $Message
}
function script:age_check_warn {
    param([string]$Message)
    $script:AGE_CHECK_WARNINGS++
    age_warn $Message
}

# ---------------------------------------------------------------------------
# 1. 路由目标存在性
# ---------------------------------------------------------------------------
function script:age_check_index_routes {
    param([string]$Root)
    $index = age_index_path $Root
    if (-not $index) {
        age_check_err "docs/index.md 不存在(用 age init 生成)"
        return
    }
    age_info "检查路由目标存在性..."
    $routes = age_parse_index_routes $index

    foreach ($r in $routes) {
        $c1 = $r.intent; $c2 = $r.reads; $c3 = $r.writeback
        if (-not $c1 -and -not $c2) { continue }
        if (age_looks_like_codepath $c1) {
            # 模块式:c2 = owner 文档
            $owner = $c2
            $opath = Join-Path $Root $owner
            if (-not (Test-Path $opath)) { $opath = Join-Path $Root "docs/$owner" }
            if (-not (Test-Path $opath)) { $opath = $owner }
            if (-not (Test-Path $opath) -and $owner -ne "(待补充)" -and $owner) {
                age_check_err "路由死链: '$c1' → '$owner' (文档不存在)"
            }
            if ($c1 -and $c1 -ne "(待补充)") {
                $mpath = Join-Path $Root $c1
                if (-not (Test-Path $mpath)) {
                    age_check_warn "悬空路由: '$c1' 路径不存在(代码已删?)"
                }
            }
        } else {
            # 意图式:c2=READ集 c3=WRITEBACK集,拆分校验每个路径
            $setStr = "$c2 $c3"
            foreach ($p in (age_route_split_set $setStr)) {
                if (-not $p) { continue }
                if ($p -eq "none" -or $p -eq "通常") { continue }
                # 提取末尾路径段
                $clean = $p
                if ($p -match '([a-zA-Z][a-zA-Z0-9_./-]+)$') { $clean = $matches[1] }
                $chkpath = Join-Path $Root "docs/$clean"
                if (-not (Test-Path $chkpath)) { $chkpath = Join-Path $Root $clean }
                if (-not (Test-Path $chkpath)) { continue }  # 非路径跳过
            }
        }
    }
}

# ---------------------------------------------------------------------------
# 2. AGENTS.md 引用技能可解析
# ---------------------------------------------------------------------------
function script:age_check_agents_skills {
    param([string]$Root)
    $agents = Join-Path $Root "AGENTS.md"
    if (-not (Test-Path $agents -PathType Leaf)) {
        age_check_warn "AGENTS.md 不存在(用 age init 生成)"
        return
    }
    age_info "检查 AGENTS.md 技能引用..."
    $content = Get-Content -Path $agents -Raw -Encoding UTF8
    # 抓取 skills/ 开头的路径引用
    $refs = [regex]::Matches($content, 'skills/[A-Za-z0-9_./-]+') | ForEach-Object { $_.Value } | Sort-Object -Unique
    foreach ($r in $refs) {
        # 去行尾标点
        $r = $r -replace '[.,;:)]+$', ''
        $p = Join-Path $Root $r
        if (Test-Path $p) { continue }
        if ($script:AGE_PLUGIN_ROOT -and (Test-Path (Join-Path $script:AGE_PLUGIN_ROOT $r))) { continue }
        age_check_err "AGENTS.md 引用的技能路径不存在: $r"
    }
    # 抓取 skill:xxx 写法
    $refs2 = [regex]::Matches($content, 'skill:[A-Za-z0-9_./-]+') | ForEach-Object { $_.Value } | Sort-Object -Unique
    foreach ($r in $refs2) {
        $name = $r.Substring(6)
        if ((Test-Path (Join-Path $Root "skills/$name") -PathType Container) -or
            (Test-Path (Join-Path $Root "skills/$name.md") -PathType Leaf)) { continue }
        age_check_warn "AGENTS.md 引用的技能未找到: skill:$name"
    }
}

# ---------------------------------------------------------------------------
# 3. docs/context/ 强制上下文齐全且非空
# ---------------------------------------------------------------------------
function script:age_check_context_quintet {
    param([string]$Root)
    $ctx = Join-Path $Root "docs/context"
    age_info "检查 docs/context/ 强制上下文..."
    $required = @("project-context", "ai-autonomy-policy", "codebase-map", "source-of-truth-and-precedence", "conventions")
    $suggested = @("requirements", "decisions", "risks", "glossary")
    if (-not (Test-Path $ctx -PathType Container)) {
        age_check_err "docs/context/ 目录不存在"
        return
    }
    foreach ($f in $required) {
        $path = Join-Path $ctx "$f.md"
        if (-not (Test-Path $path -PathType Leaf)) {
            age_check_err "缺失强制上下文: docs/context/$f.md"
            continue
        }
        $body = age_strip_frontmatter $path
        if (-not $body.Trim()) {
            age_check_err "强制上下文为空(仅标题/注释): docs/context/$f.md"
        }
    }
    foreach ($f in $suggested) {
        $path = Join-Path $ctx "$f.md"
        if (-not (Test-Path $path -PathType Leaf)) { continue }
        $body = age_strip_frontmatter $path
        if (-not $body.Trim()) {
            age_check_warn "建议上下文为空: docs/context/$f.md"
        }
    }
}

# age_strip_frontmatter <path>:去掉标题行(# 开头)与引用行(> 开头)与空行,返回正文
function script:age_strip_frontmatter {
    param([string]$Path)
    $lines = Get-Content -Path $Path -Encoding UTF8
    $sb = [System.Text.StringBuilder]::new()
    foreach ($line in $lines) {
        if ($line -match '^#') { continue }
        if ($line -match '^>') { continue }
        if ($line.Trim() -eq "") { continue }
        [void]$sb.AppendLine($line)
    }
    return $sb.ToString()
}

# ---------------------------------------------------------------------------
# 4. 需求↔设计↔架构闭环
# ---------------------------------------------------------------------------
function script:age_check_traceability {
    param([string]$Root)
    age_info "检查需求↔设计↔架构闭环..."
    $dirs = @("requirements", "design", "architecture")
    $hasReq = $false; $hasDesign = $false; $hasArch = $false
    foreach ($d in $dirs) {
        $dirpath = Join-Path $Root "docs/$d"
        if (-not (Test-Path $dirpath -PathType Container)) {
            age_check_warn "docs/$d/ 目录不存在(闭环缺失)"
            continue
        }
        # 至少1个非 README 的 .md
        $mds = Get-ChildItem -Path $dirpath -Filter "*.md" | Where-Object { $_.Name -ne "README.md" }
        $nmd = if ($mds) { @($mds).Count } else { 0 }
        switch ($d) {
            "requirements"  { if ($nmd -gt 0) { $hasReq = $true } else { age_check_warn "docs/requirements/ 无实质文档(闭环缺需求)" } }
            "design"        { if ($nmd -gt 0) { $hasDesign = $true } else { age_check_warn "docs/design/ 无实质文档(闭环缺设计)" } }
            "architecture"  { if ($nmd -gt 0) { $hasArch = $true } else { age_check_warn "docs/architecture/ 无实质文档(闭环缺架构)" } }
        }
    }
    # 交叉引用
    if ($hasReq -and $hasDesign) {
        $designContent = Get-ChildItem -Path (Join-Path $Root "docs/design") -Filter "*.md" -Recurse | ForEach-Object { Get-Content $_.FullName -Raw } | Out-String
        if ($designContent -notmatch 'requirements?|需求') {
            age_check_warn "design/ 未引用 requirements(闭环断链)"
        }
    }
    if ($hasDesign -and $hasArch) {
        $archContent = Get-ChildItem -Path (Join-Path $Root "docs/architecture") -Filter "*.md" -Recurse | ForEach-Object { Get-Content $_.FullName -Raw } | Out-String
        if ($archContent -notmatch 'design|设计') {
            age_check_warn "architecture/ 未引用 design(闭环断链)"
        }
    }
}

# ---------------------------------------------------------------------------
function script:age_check_help {
    @'
age check — 静态一致性校验

用法:
  age check [--strict]

检查项:
  1. docs/index.md 路由目标(owner 文档)存在
  2. AGENTS.md 引用的技能可解析
  3. docs/context/ 五件套齐全且非空
  4. 需求↔设计↔架构交叉引用闭环

参数:
  --strict  warning 也算失败(默认仅 error 失败)

退出码: 0 通过 / 1 失败
'@ | Write-Host
}

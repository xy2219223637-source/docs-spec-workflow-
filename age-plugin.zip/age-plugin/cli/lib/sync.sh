# sync.sh — age sync 实现
# 读 git diff,按 docs/index.md 路由表映射代码变更到 owner 文档。
# 输出 stale/orphan/missing 三类漂移。--json 输出结构化;否则人类可读。
# 退出码:0 无漂移 / 1 有漂移。无 git 时优雅降级(返回0并提示)。

# ---------------------------------------------------------------------------
# age_sync:主入口
# ---------------------------------------------------------------------------
age_sync() {
  age_init_runtime

  local since="" json=0
  while [ $# -gt 0 ]; do
    case "$1" in
      --since) since="$2"; shift 2;;
      --since=*) since="${1#*=}"; shift;;
      --json) json=1; shift;;
      -h|--help) age_sync_help; return 0;;
      *) age_warn "未知参数: $1"; shift;;
    esac
  done

  local root; root="$(pwd)"

  # git 可用性
  if ! age_git_ok; then
    if [ "$json" = "1" ]; then
      printf '{"stale":[],"orphan":[],"missing":[],"git":"unavailable","note":"git 不可用,无法计算漂移"}\n'
    else
      age_warn "git 不可用,无法计算漂移。请确认已安装 git 且当前在仓库内。"
    fi
    return 0   # 无 git 不算失败(优雅降级)
  fi

  local gitroot; gitroot="$(age_git_root)"
  [ -n "$gitroot" ] || gitroot="$root"

  # 确定对比基准
  local ref="$since"
  if [ -z "$ref" ]; then
    # 默认:与最近一次提交比;若无提交则与空树比
    if git -C "$gitroot" rev-parse --verify HEAD >/dev/null 2>&1; then
      ref="HEAD"
    else
      ref=""  # 无提交,所有文件视为新增
    fi
  fi

  # 加载路由表:输出 "模块<TAB>owner文档<TAB>技能" 到关联结构
  local index; index="$(age_index_path "$root")"
  if [ -z "$index" ]; then
    if [ "$json" = "1" ]; then
      printf '{"stale":[],"orphan":[],"missing":[],"note":"docs/index.md 不存在,无法映射"}\n'
    else
      age_warn "docs/index.md 不存在,无法进行路由映射。请先 age init。"
    fi
    return 0
  fi

  # 读取路由表到并行数组(POSIX sh 无关联数组,用临时文件)
  local routes_tmp; routes_tmp="$(mktemp)"
  age_parse_index_routes "$index" > "$routes_tmp"

  # 取代码变更文件清单(排除 docs/ 与 .age/)
  local changed_tmp; changed_tmp="$(mktemp)"
  if [ -n "$ref" ]; then
    git -C "$gitroot" diff --name-only "$ref" -- 2>/dev/null \
      | grep -vE '^(docs/|\.age/|\.zcode-plugin/|AGENTS\.md)' > "$changed_tmp" || true
    # 也纳入未跟踪的新文件(可能 missing)
    git -C "$gitroot" ls-files --others --exclude-standard 2>/dev/null \
      | grep -vE '^(docs/|\.age/|\.zcode-plugin/|AGENTS\.md)' >> "$changed_tmp" || true
  else
    # 无提交:列出所有已跟踪 + 未跟踪
    { git -C "$gitroot" ls-files 2>/dev/null; git -C "$gitroot" ls-files --others --exclude-standard 2>/dev/null; } \
      | grep -vE '^(docs/|\.age/|\.zcode-plugin/|AGENTS\.md)' | sort -u > "$changed_tmp" || true
  fi

  # 取文档变更清单(用于判断 owner 文档是否随代码一起动)
  local docs_changed_tmp; docs_changed_tmp="$(mktemp)"
  if [ -n "$ref" ]; then
    git -C "$gitroot" diff --name-only "$ref" -- 'docs/' 2>/dev/null > "$docs_changed_tmp" || true
    git -C "$gitroot" ls-files --others --exclude-standard -- 'docs/' 2>/dev/null >> "$docs_changed_tmp" || true
  else
    { git -C "$gitroot" ls-files -- 'docs/' 2>/dev/null; git -C "$gitroot" ls-files --others --exclude-standard -- 'docs/' 2>/dev/null; } \
      | sort -u > "$docs_changed_tmp" || true
  fi

  # 计算三类漂移
  local stale_tmp orphans_tmp missing_tmp
  stale_tmp="$(mktemp)"; orphans_tmp="$(mktemp)"; missing_tmp="$(mktemp)"

  age_sync_compute "$gitroot" "$routes_tmp" "$changed_tmp" "$docs_changed_tmp" \
    "$stale_tmp" "$orphans_tmp" "$missing_tmp"

  # 统计
  local n_stale n_orphan n_missing
  n_stale=$(wc -l < "$stale_tmp" | tr -d ' ')
  n_orphan=$(wc -l < "$orphans_tmp" | tr -d ' ')
  n_missing=$(wc -l < "$missing_tmp" | tr -d ' ')

  # 清理临时文件
  rm -f "$routes_tmp" "$changed_tmp" "$docs_changed_tmp"

  local drift=0
  [ "$n_stale" -gt 0 ] && drift=1
  [ "$n_orphan" -gt 0 ] && drift=1
  [ "$n_missing" -gt 0 ] && drift=1

  # 输出
  if [ "$json" = "1" ]; then
    age_sync_output_json "$stale_tmp" "$orphans_tmp" "$missing_tmp" "$ref"
  else
    age_sync_output_human "$stale_tmp" "$orphans_tmp" "$missing_tmp" "$ref"
  fi

  rm -f "$stale_tmp" "$orphans_tmp" "$missing_tmp"
  return "$drift"
}

# ---------------------------------------------------------------------------
# age_sync_compute:核心计算
# 参数:gitroot routes changed docs_changed stale out orphans out missing out
# 路由表格式自适应:
#   - 模块式(第一列含代码路径,如 src/api):做 module→owner 文档映射
#   - 意图式(第一列是任务描述,无代码路径):无法按路径映射,改用目录约定
# 三类:
#   stale  = 代码变更了,但对应 owner 文档没动
#   orphan = 路由表指向的代码模块已删除(仅模块式有意义)
#   missing= 新增代码模块,路由表里没有对应行
# ---------------------------------------------------------------------------
age_sync_compute() {
  local gitroot="$1" routes="$2" changed="$3" docs_changed="$4"
  local stale_out="$5" orphans_out="$6" missing_out="$7"

  # 判定路由表是否为模块式:任一行的第一列像代码路径(含 / 或带扩展名)
  local is_module_format=0
  local c1
  while IFS=$'\t' read -r c1 _rest; do
    [ -z "$c1" ] && continue
    if age_looks_like_codepath "$c1"; then is_module_format=1; break; fi
  done < "$routes"

  if [ "$is_module_format" = "1" ]; then
    age_sync_compute_module "$gitroot" "$routes" "$changed" "$docs_changed" \
      "$stale_out" "$orphans_out" "$missing_out"
  else
    age_sync_compute_intent "$gitroot" "$routes" "$changed" "$docs_changed" \
      "$stale_out" "$orphans_out" "$missing_out"
  fi
}

# age_looks_like_codepath <s>:是否像代码路径(含 / 且非纯中文,或带文件扩展名)
age_looks_like_codepath() {
  local s="$1"
  [ -z "$s" ] && return 1
  # 含 . 扩展名
  case "$s" in
    *.ts|*.js|*.py|*.go|*.rs|*.java|*.c|*.cpp|*.h|*.sh|*.md) return 0;;
  esac
  # 含 / 且首段像目录名(字母开头)
  case "$s" in
    [a-zA-Z]*/*) return 0;;
  esac
  return 1
}

# 模块式计算(原逻辑)
age_sync_compute_module() {
  local gitroot="$1" routes="$2" changed="$3" docs_changed="$4"
  local stale_out="$5" orphans_out="$6" missing_out="$7"
  local module owner skill
  while IFS=$'\t' read -r module owner skill; do
    [ -z "$module" ] && continue
    while IFS= read -r cf; do
      [ -z "$cf" ] && continue
      if age_path_matches "$cf" "$module"; then
        if age_file_in_list "$owner" "$docs_changed"; then
          : # 文档已动
        else
          printf '%s\t%s\t%s\n' "$module" "$owner" "$cf" >> "$stale_out"
        fi
      fi
    done < "$changed"
    if [ -n "$module" ]; then
      local mod_path="$gitroot/$module"
      if [ ! -e "$mod_path" ]; then
        printf '%s\t%s\n' "$module" "$owner" >> "$orphans_out"
      fi
    fi
  done < "$routes"
  # missing:变更文件未命中任何路由模块
  while IFS= read -r cf; do
    [ -z "$cf" ] && continue
    local hit=0
    while IFS=$'\t' read -r module owner skill; do
      [ -z "$module" ] && continue
      if age_path_matches "$cf" "$module"; then hit=1; break; fi
    done < "$routes"
    [ "$hit" = "0" ] && printf '%s\n' "$cf" >> "$missing_out"
  done < "$changed"
}

# 意图式计算:路由表无代码路径映射,采用目录约定
# 约定:代码变更 → 应有对应文档更新。无法精确映射时:
#   - 若有代码变更但无任何文档变更 → 全部报 stale(提示需 doc-sync)
#   - 新代码文件 → missing(无路由覆盖)
#   - orphan 不适用(意图式无模块路径),不报
age_sync_compute_intent() {
  local gitroot="$1" routes="$2" changed="$3" docs_changed="$4"
  local stale_out="$5" orphans_out="$6" missing_out="$7"

  local n_changed=0 n_docs_changed=0
  n_changed=$(grep -c '.' "$changed" 2>/dev/null); [ -z "$n_changed" ] && n_changed=0
  n_docs_changed=$(grep -c '.' "$docs_changed" 2>/dev/null); [ -z "$n_docs_changed" ] && n_docs_changed=0

  # 有代码变更但无文档变更 → 全部代码变更为 stale(提示需回写)
  if [ "$n_changed" -gt 0 ] 2>/dev/null && [ "$n_docs_changed" -eq 0 ] 2>/dev/null; then
    while IFS= read -r cf; do
      [ -z "$cf" ] && continue
      # 推断 owner 文档目录(按约定:src→architecture, 测试→testing, 等)
      local owner_dir
      owner_dir=$(age_infer_owner_dir "$cf")
      printf '%s\t%s\t%s\n' "$cf" "docs/$owner_dir/" "$cf" >> "$stale_out"
    done < "$changed"
  fi

  # missing:所有代码变更均无路由表覆盖(意图式无法覆盖具体路径 → 全报 missing 提示)
  # 仅当路由表为空时才报;否则意图表已声明任务级覆盖,路径级 missing 无意义
  local n_routes=0
  n_routes=$(grep -c '.' "$routes" 2>/dev/null); [ -z "$n_routes" ] && n_routes=0
  if [ "$n_routes" -eq 0 ] 2>/dev/null; then
    while IFS= read -r cf; do
      [ -z "$cf" ] && continue
      printf '%s\n' "$cf" >> "$missing_out"
    done < "$changed"
  fi
}

# age_infer_owner_dir <codepath>:按约定推断代码文件对应的 owner 文档目录
age_infer_owner_dir() {
  local p="$1"
  case "$p" in
    *test*|*spec*) echo "testing";;
    *bug*|*fix*)   echo "bugs";;
    *)             echo "architecture";;
  esac
}

# age_path_matches <file> <module>:文件是否落在 module 路径下
age_path_matches() {
  local file="$1" module="$2"
  [ -z "$module" ] && return 1
  # 精确文件名匹配
  [ "$file" = "$module" ] && return 0
  # 目录前缀匹配:module 是目录,文件以 module/ 开头
  case "$file" in
    "$module"/*) return 0;;
  esac
  # 通配匹配:module 含 * ? [ ]
  case "$module" in
    *\**|*\?*|\[*)
      # 用 case 模式匹配
      case "$file" in
        $module) return 0;;
        $module/*) return 0;;
      esac
      ;;
  esac
  return 1
}

# age_file_in_list <file> <list_file>:file 是否出现在 list_file 中
age_file_in_list() {
  local file="$1" list="$2"
  [ -f "$list" ] || return 1
  # 相对 gitroot 路径可能带 docs/ 前缀;owner 文档路径也可能带 docs/
  # 做包含匹配 + 精确匹配
  grep -qxF "$file" "$list" && return 0
  # 尝试去前缀匹配
  grep -qxF "${file#docs/}" "$list" && return 0
  grep -qxF "docs/$file" "$list" && return 0
  # 模糊:文件名结尾匹配
  local base="${file##*/}"
  grep -qF "$base" "$list" && return 0
  return 1
}

# ---------------------------------------------------------------------------
# 输出
# ---------------------------------------------------------------------------
age_sync_output_human() {
  local stale="$1" orphan="$2" missing="$3" ref="$4"
  local n_stale n_orphan n_missing
  n_stale=$(wc -l < "$stale" | tr -d ' ')
  n_orphan=$(wc -l < "$orphan" | tr -d ' ')
  n_missing=$(wc -l < "$missing" | tr -d ' ')

  echo "$(age_color bold 'AGE 漂移报告')  (基准: ${ref:-空仓库})"
  echo

  # stale
  if [ "$n_stale" -gt 0 ]; then
    echo "$(age_color yellow "⚠ stale ($n_stale)"): 代码变更但 owner 文档未更新"
    while IFS=$'\t' read -r m o c; do
      [ -z "$m" ] && continue
      printf '   %s → %s  (变更: %s)\n' "$(age_color gray "$m")" "$o" "$c"
    done < "$stale"
    echo
  else
    echo "$(age_color green '✓ stale (0)'): 代码-文档同步"
  fi

  # orphan
  if [ "$n_orphan" -gt 0 ]; then
    echo "$(age_color yellow "⚠ orphan ($n_orphan)"): 路由指向的代码模块已不存在"
    while IFS=$'\t' read -r m o; do
      [ -z "$m" ] && continue
      printf '   %s → %s\n' "$(age_color gray "$m")" "$o"
    done < "$orphan"
    echo
  else
    echo "$(age_color green '✓ orphan (0)'): 无悬空路由"
  fi

  # missing
  if [ "$n_missing" -gt 0 ]; then
    echo "$(age_color yellow "⚠ missing ($n_missing)"): 新代码模块无路由(owner 文档缺失)"
    while IFS= read -r c; do
      [ -z "$c" ] && continue
      printf '   %s\n' "$(age_color gray "$c")"
    done < "$missing"
    echo
  else
    echo "$(age_color green '✓ missing (0)'): 所有代码模块已路由"
  fi

  echo
  local total=$((n_stale + n_orphan + n_missing))
  if [ "$total" -gt 0 ]; then
    echo "$(age_color yellow "合计 $total 处漂移")。修复后再次 age sync 验证。"
  else
    echo "$(age_color green '无漂移。')"
  fi
}

age_sync_output_json() {
  local stale="$1" orphan="$2" missing="$3" ref="$4"

  # 构造 JSON 数组
  local stale_arr orphans_arr missing_arr
  stale_arr=$(age_sync_json_arr_stale "$stale")
  orphans_arr=$(age_sync_json_arr_orphan "$orphan")
  missing_arr=$(age_sync_json_arr_missing "$missing")

  printf '{"since":"%s","stale":%s,"orphan":%s,"missing":%s}\n' \
    "$(age_json_escape "${ref:-}")" "$stale_arr" "$orphans_arr" "$missing_arr"
}

# stale 条目:{module, owner, changed_file}
age_sync_json_arr_stale() {
  local f="$1"
  [ -s "$f" ] || { echo "[]"; return; }
  local first=1
  printf '['
  while IFS=$'\t' read -r m o c; do
    [ -z "$m" ] && continue
    [ "$first" = "1" ] || printf ','
    first=0
    printf '{"module":"%s","owner":"%s","changed_file":"%s"}' \
      "$(age_json_escape "$m")" "$(age_json_escape "$o")" "$(age_json_escape "$c")"
  done < "$f"
  printf ']'
}

age_sync_json_arr_orphan() {
  local f="$1"
  [ -s "$f" ] || { echo "[]"; return; }
  local first=1
  printf '['
  while IFS=$'\t' read -r m o; do
    [ -z "$m" ] && continue
    [ "$first" = "1" ] || printf ','
    first=0
    printf '{"module":"%s","owner":"%s"}' \
      "$(age_json_escape "$m")" "$(age_json_escape "$o")"
  done < "$f"
  printf ']'
}

age_sync_json_arr_missing() {
  local f="$1"
  [ -s "$f" ] || { echo "[]"; return; }
  local first=1
  printf '['
  while IFS= read -r c; do
    [ -z "$c" ] && continue
    [ "$first" = "1" ] || printf ','
    first=0
    printf '{"file":"%s"}' "$(age_json_escape "$c")"
  done < "$f"
  printf ']'
}

# ---------------------------------------------------------------------------
age_sync_help() {
  cat <<'EOF'
age sync — 检测代码与文档的漂移

用法:
  age sync [--since REF] [--json]

参数:
  --since REF  git 对比基准(默认 HEAD)
  --json       输出结构化 JSON(供 MCP/hook 消费)

漂移类别:
  stale   代码变更了,对应 owner 文档没动
  orphan  路由表指向的代码模块已删除
  missing 新代码模块无路由表条目

退出码: 0 无漂移 / 1 有漂移 / (无 git 时 0)
EOF
}

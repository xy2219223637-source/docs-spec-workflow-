# use.sh — age use 实现
# 检测当前项目是否已初始化 → 未初始化则自动 age init → 报告激活状态。
# 用法:age use [--name X] [--kind web|mobile|cli] [--json] [目标目录]

# ---------------------------------------------------------------------------
# age_use:主入口
# ---------------------------------------------------------------------------
age_use() {
  local name="" kind="" json_mode=0 target="."
  # 解析参数
  while [ $# -gt 0 ]; do
    case "$1" in
      --name) name="$2"; shift 2;;
      --name=*) name="${1#*=}"; shift;;
      --kind) kind="$2"; shift 2;;
      --kind=*) kind="${1#*=}"; shift;;
      --json) json_mode=1; shift;;
      -h|--help) age_use_help; return 0;;
      *) target="$1"; shift;;
    esac
  done

  # 校验 kind(若提供)
  case "$kind" in
    web|mobile|cli|"") ;;
    *) age_die "无效 --kind: $kind (允许: web|mobile|cli)" 1;;
  esac

  # 目标目录处理
  target="$(cd "$target" 2>/dev/null && pwd)" || target="$(pwd)/$target"
  [ -d "$target" ] || mkdir -p "$target" || age_die "无法创建目标目录: $target" 1

  # 默认值:项目名=当前目录名,kind=web,validate=空
  local dir_name
  dir_name="$(basename "$target")"
  [ -n "$name" ] || name="$dir_name"
  [ -n "$kind" ] || kind="web"

  # JSON 模式:静默执行,最后只输出一行 JSON
  if [ "$json_mode" = "1" ]; then
    _age_use_run "$target" "$name" "$kind" 1
    return $?
  fi

  _age_use_run "$target" "$name" "$kind" 0
  return $?
}

# ---------------------------------------------------------------------------
# _age_use_run <target> <name> <kind> <quiet>
# 核心逻辑。quiet=1 时只输出 JSON,不输出人类可读信息。
# 退出码:0 成功(激活或初始化并激活)。
# ---------------------------------------------------------------------------
_age_use_run() {
  local target="$1" name="$2" kind="$3" quiet="${4:-0}"
  local root="$target"

  # 1. 检测当前目录是否是 AGE 仓库
  #    (有 docs/index.md 或 AGENTS.md 或 .age/)
  local is_initialized=0
  if is_age_repo "$root" || [ -d "$root/.age" ]; then
    is_initialized=1
  fi

  if [ "$is_initialized" = "1" ]; then
    # 2. 已初始化:报告激活状态 + 输出 context 摘要
    if [ "$quiet" = "0" ]; then
      age_success "AGE 已激活"
      _age_use_print_context_summary "$root"
    fi
    _age_use_emit_json 1 0 "$name" "$quiet"
    return 0
  fi

  # 3. 未初始化:检测 git 仓库 + 自动执行 init
  local is_git=0
  if [ -d "$root/.git" ]; then
    is_git=1
  elif age_git_ok 2>/dev/null; then
    # git rev-parse 在 cwd 判定;target 可能等于 cwd
    is_git=1
  fi

  if [ "$quiet" = "0" ]; then
    if [ "$is_git" = "0" ]; then
      age_warn "当前目录不是 git 仓库,建议先 git init(AGE 不强制 git,仍可初始化)。"
    else
      age_info "检测到 AGE 未初始化,自动执行 age init..."
    fi
  fi

  # 调用 age_init 函数(init.sh 已 source)
  # init 内部完成:拷贝模板 → 渲染 → check → baseline
  # quiet 模式下抑制 age_init 的 stdout(进度信息),保留 stderr(warn/error),
  # 保证 --json 输出仅一行 JSON,不与 init 日志混杂。
  local init_code=0
  if [ "$quiet" = "1" ]; then
    ( cd "$root" && age_init --name "$name" --kind "$kind" "$root" ) >/dev/null || init_code=$?
  else
    ( cd "$root" && age_init --name "$name" --kind "$kind" "$root" ) || init_code=$?
  fi

  if [ "$init_code" -ne 0 ]; then
    if [ "$quiet" = "0" ]; then
      age_error "AGE 自动初始化失败 (exit $init_code)。"
    fi
    _age_use_emit_json 0 0 "$name" "$quiet"
    return "$init_code"
  fi

  # init 完成后报告
  if [ "$quiet" = "0" ]; then
    age_success "AGE 已自动初始化并激活"
    _age_use_print_context_summary "$root"
  fi
  _age_use_emit_json 1 1 "$name" "$quiet"
  return 0
}

# ---------------------------------------------------------------------------
# _age_use_emit_json <activated> <initialized> <project> <quiet>
# quiet=1 时输出 JSON 到 stdout(供 --json 模式与 MCP 消费)。
# quiet=0 时仅在末尾追加一行 JSON 标记(便于脚本解析),不干扰人类阅读。
# 实际策略:quiet=1 → 只输出 JSON;quiet=0 → 不输出 JSON(人类模式)。
# ---------------------------------------------------------------------------
_age_use_emit_json() {
  local activated="$1" initialized="$2" project="$3" quiet="$4"
  # JSON 模式:initialized 字段语义 = 本次是否执行了 init
  #   activated=1,initialized=0 → 已激活(此前已初始化)
  #   activated=1,initialized=1 → 已激活(本次自动初始化)
  local init_flag
  if [ "$initialized" = "1" ]; then init_flag="true"; else init_flag="false"; fi
  local act_flag
  if [ "$activated" = "1" ]; then act_flag="true"; else act_flag="false"; fi
  if [ "$quiet" = "1" ]; then
    printf '{"activated":%s,"initialized":%s,"project":"%s"}\n' \
      "$act_flag" "$init_flag" "$(age_json_escape "$project")"
  fi
}

# ---------------------------------------------------------------------------
# _age_use_print_context_summary <root>
# 读取 docs/context/ 摘要输出(人类可读)。
# 列出存在的 context 文件 + project-context.md 首段(若有)。
# ---------------------------------------------------------------------------
_age_use_print_context_summary() {
  local root="$1"
  local ctx_dir="$root/docs/context"
  if [ ! -d "$ctx_dir" ]; then
    age_info "docs/context/ 目录不存在(初始化未完成?)。"
    return 0
  fi

  # 列出存在的 context 文件
  local files=()
  local f
  for f in "project-context" "ai-autonomy-policy" "codebase-map" \
           "source-of-truth-and-precedence" "conventions" \
           "requirements" "decisions" "risks" "glossary"; do
    [ -f "$ctx_dir/$f.md" ] && files+=("$f.md")
  done

  if [ "${#files[@]}" -gt 0 ]; then
    age_info "强制上下文 (docs/context/): ${files[*]}"
  else
    age_warn "docs/context/ 为空。"
  fi

  # 输出 project-context.md 首个非空标题段(摘要预览)
  local pc="$ctx_dir/project-context.md"
  if [ -f "$pc" ]; then
    echo
    age_info "项目上下文摘要 (docs/context/project-context.md):"
    # 取首个标题行及其后第一个段落(最多 8 行预览)
    local preview
    preview=$(awk '
      BEGIN { printed=0 }
      /^#/ { if (printed==0) { print; printed=1 } next }
      printed==1 && /^[^[:space:]]/ { print; c++ }
      printed==1 && c>=8 { exit }
    ' "$pc" 2>/dev/null | head -8)
    if [ -n "$preview" ]; then
      printf '%s\n' "$preview" | sed 's/^/    /'
    else
      printf '    (无摘要内容,请编辑 docs/context/project-context.md)\n'
    fi
  fi
}

# ---------------------------------------------------------------------------
age_use_help() {
  cat <<'EOF'
age use — 激活 AGE(检测 + 自动初始化)

用法:
  age use [--name X] [--kind web|mobile|cli] [--json] [目标目录]

参数:
  --name X        项目名称(未初始化时传给 age init;默认=当前目录名)
  --kind K        项目类型:web|mobile|cli(默认 web)
  --json          输出 JSON: {"activated":bool,"initialized":bool,"project":"..."}
  目标目录         默认当前目录

行为:
  1. 检测目标目录是否是 AGE 仓库(有 docs/index.md 或 AGENTS.md 或 .age/)
  2. 已初始化:输出"AGE 已激活"+ docs/context/ 摘要,退出码 0
  3. 未初始化:
     - 检测是否 git 仓库(有 .git/);非 git 则警告但仍可初始化
     - 用默认值自动执行 age init(项目名=当前目录名,kind=web,validate=空)
     - init 完成后输出"AGE 已自动初始化并激活",退出码 0
  4. --json 模式仅输出一行 JSON,供脚本/MCP 消费

退出码: 0 成功(已激活或初始化并激活) / 1 失败

JSON 字段说明:
  activated    true=AGE 已激活
  initialized  true=本次执行了自动初始化;false=此前已初始化
  project      项目名称
EOF
}

# route.sh — age route 实现
# 解析 docs/index.md 路由表(意图式:你要做的事→READ集/WRITEBACK集)
#       + 技能路由表(任务类型→项目技能)
#       + skills/age/references/routing-rules.md 决策表
# 输入任务描述,输出应读哪些 owner 文档、选哪个技能。
# --explain 输出决策路径。退出码:0 命中 / 1 未命中。

age_route() {
  age_init_runtime

  local explain=0 task=""
  while [ $# -gt 0 ]; do
    case "$1" in
      --explain) explain=1; shift;;
      -h|--help) age_route_help; return 0;;
      *) task="${task}${task:+ }$1"; shift;;
    esac
  done

  if [ -z "$task" ]; then
    age_die "缺少任务描述。用法: age route <task> [--explain]" 1
  fi

  local root; root="$(pwd)"
  find_plugin_root 2>/dev/null || true

  local index; index="$(age_index_path "$root")"
  if [ -z "$index" ]; then
    age_error "docs/index.md 不存在,无法路由。请先 age init。"
    return 1
  fi

  # 加载意图路由表:意图<TAB>READ集<TAB>WRITEBACK集
  local routes_tmp; routes_tmp="$(mktemp)"
  age_parse_index_routes "$index" > "$routes_tmp"

  # 加载技能路由表:任务类型<TAB>技能
  local skills_tmp; skills_tmp="$(mktemp)"
  age_parse_index_skills "$index" > "$skills_tmp"

  # 加载 routing-rules.md 决策表(若存在)
  local rules="$AGE_PLUGIN_ROOT/skills/age/references/routing-rules.md"
  [ -f "$rules" ] || rules="$root/skills/age/references/routing-rules.md"
  [ -f "$rules" ] || rules=""

  # 路由匹配:遍历意图行,关键词命中 → 收集 READ 集
  local matched_read="" matched_writeback="" matched_intent="" any_hit=0
  local intent readset wbset
  while IFS=$'\t' read -r intent readset wbset; do
    [ -z "$intent" ] && continue
    if age_route_match_intent "$task" "$intent"; then
      any_hit=1
      matched_intent="$intent"
      # READ 集:多个文档用 、 或 , 分隔
      local d
      for d in $(age_route_split_set "$readset"); do
        [ -z "$d" ] && continue
        age_route_add matched_read "$d"
      done
      for d in $(age_route_split_set "$wbset"); do
        [ -z "$d" ] && continue
        age_route_add matched_writeback "$d"
      done
      break   # 命中首个意图即可(意图表通常互斥)
    fi
  done < "$routes_tmp"

  # 技能匹配:从技能表按任务类型关键词查
  local matched_skill=""
  if [ -s "$skills_tmp" ]; then
    local ttype skill
    while IFS=$'\t' read -r ttype skill; do
      [ -z "$ttype" ] && continue
      if age_route_match_intent "$task" "$ttype"; then
        matched_skill="$skill"
        break
      fi
    done < "$skills_tmp"
  fi

  # 决策表补充:若未命中,查 routing-rules 关键词→技能/文档
  if [ "$any_hit" = "0" ] && [ -n "$rules" ]; then
    local rule_result
    rule_result=$(age_route_rules_lookup "$rules" "$task")
    if [ -n "$rule_result" ]; then
      any_hit=1
      matched_skill="$rule_result"
      matched_intent="决策表匹配(默认路由)"
    fi
  fi

  rm -f "$routes_tmp" "$skills_tmp"

  if [ "$any_hit" = "0" ]; then
    echo "$(age_color yellow '未命中路由')。"
    echo "任务: $task"
    echo "建议: 在 docs/index.md 补充该任务类型的路由条目,或手动选择技能。"
    [ "$explain" = "1" ] && age_route_explain "$task" "$index" "$rules" "" "" "未命中"
    return 1
  fi

  # 输出
  echo "$(age_color bold '路由结果')"
  echo "  任务: $(age_color cyan "$task")"
  echo "  匹配意图: $(age_color cyan "$matched_intent")"
  echo "  $(age_color green '应读 (READ 集)'):"
  local d
  for d in $matched_read; do
    [ -z "$d" ] && continue
    echo "    - $d"
  done
  echo "  $(age_color green '可能回写 (WRITEBACK 集)'):"
  local w
  for w in $matched_writeback; do
    [ -z "$w" ] && continue
    echo "    - $w"
  done
  echo "  $(age_color green '建议技能'):"
  if [ -n "$matched_skill" ]; then
    echo "    - $matched_skill"
  else
    echo "    - none(无项目技能,走 owner 文档)"
  fi

  if [ "$explain" = "1" ]; then
    age_route_explain "$task" "$index" "$rules" "$matched_read" "$matched_skill" "$matched_intent"
  fi

  return 0
}

# age_route_add <varname> <value>:向空格分隔列表追加(去重)
age_route_add() {
  local varname="$1" val="$2"
  local cur="${!varname}"
  case " $cur " in
    *" $val "*) ;;         # 已存在
    *) if [ -z "$cur" ]; then eval "$varname=\"\$val\""; else eval "$varname=\"\$cur \$val\""; fi;;
  esac
}

# age_route_split_set <set_string>:把 "context/a.md、backlog/、requirements/" 拆成路径列表
# 处理中文顿号、逗号、空格分隔;去掉反引号、说明括号
age_route_split_set() {
  echo "$1" \
    | sed -e 's/`//g' \
          -e 's/、/ /g' -e 's/,/ /g' \
          -e 's/([^)]*)//g' -e 's/（[^）]*）//g' \
    | tr ' ' '\n' \
    | sed -e 's/^[[:space:]]*//' -e 's/[[:space:]]*$//' \
    | grep -v '^$'
}

# age_route_match_intent:task 是否命中意图行(关键词匹配)
age_route_match_intent() {
  local task="$1" intent="$2"
  local t i
  t=$(echo "$task" | tr '[:upper:]' '[:lower:]')
  i=$(echo "$intent" | tr '[:upper:]' '[:lower:]')
  # 切分意图为关键词(中文按字、英文按词)
  # 简化:对意图中长度≥2的 token 做包含匹配;任一命中即匹配
  local kw
  for kw in $(echo "$i" | tr -c '[:alnum:]' ' ' | tr ' ' '\n' | grep -E '.{2,}'); do
    case "$t" in
      *"$kw"*) return 0;;
    esac
  done
  # 中文关键词:取连续中文字符段
  for kw in $(echo "$i" | grep -oE '[一-龥]{2,}' 2>/dev/null); do
    case "$t" in
      *"$kw"*) return 0;;
    esac
  done
  return 1
}

# age_route_rules_lookup:在 routing-rules.md 中按关键词查技能/文档
# 决策表约定:| 关键词 | 技能 | 或 | 关键词 | READ | 技能 |
age_route_rules_lookup() {
  local rules="$1" task="$2"
  [ -f "$rules" ] || return
  local t; t=$(echo "$task" | tr '[:upper:]' '[:lower:]')
  awk -F'|' -v t="$t" '
    function trim(s){ gsub(/^[[:space:]]+|[[:space:]]+$/,"",s); return s }
    /^[[:space:]]*\|/ {
      line=$0
      if (line ~ /^\|[-: |]+$/) next
      kw=trim($3); sk=trim($4)
      if (kw=="" || sk=="") next
      if (kw ~ /关键词|keyword/i) next
      gsub(/[,，、]/, " ", kw)
      n=split(kw, parts, " ")
      for (i=1; i<=n; i++) {
        p=tolower(trim(parts[i]))
        if (p == "") continue
        if (index(t, p) > 0) { print sk; exit }
      }
      # 中文关键词
      cmd = "echo \"" kw "\" | grep -oE \"[一-龥]{2,}\""
      while ((cmd | getline zh) > 0) {
        if (index(t, tolower(zh)) > 0) { print sk; close(cmd); exit }
      }
      close(cmd)
    }
  ' "$rules" 2>/dev/null
}

# age_route_explain:输出决策路径
age_route_explain() {
  local task="$1" index="$2" rules="$3" readset="$4" skill="$5" intent="$6"
  echo
  echo "$(age_color bold '决策路径'):"
  echo "  1. 读取路由器: $index"
  echo "  2. 解析意图路由表(你要做的事→READ/WRITEBACK) + 技能路由表(任务类型→技能)"
  echo "  3. 任务关键词切分: $(echo "$task" | tr '[:upper:]' '[:lower:]')"
  echo "  4. 遍历意图行,关键词包含匹配"
  if [ -n "$intent" ]; then
    echo "  5. 命中意图: $intent"
  else
    echo "  5. 意图表未命中"
  fi
  if [ -n "$rules" ]; then
    echo "  6. 补充查决策表: $rules"
  else
    echo "  6. 决策表 routing-rules.md 未找到(跳过)"
  fi
  echo "  7. 结果 → READ: [$readset] skill: [${skill:-none}]"
}

age_route_help() {
  cat <<'EOF'
age route — 任务路由

用法:
  age route <task> [--explain]

参数:
  <task>     任务描述(自然语言,如"新增需求"、"设计接口"、"修bug")
  --explain  输出决策路径

输出:
  - 匹配的意图行
  - 应读的 owner 文档(READ 集)
  - 可能回写的文档(WRITEBACK 集)
  - 建议技能(来自技能路由表或决策表)

退出码: 0 命中 / 1 未命中
EOF
}

# check.sh — age check 实现
# 静态一致性校验:
#   1. docs/index.md 路由目标(owner 文档)存在
#   2. AGENTS.md 引用的技能可解析(skills/ 下有对应)
#   3. docs/context/ 五件套齐全且非空
#   4. 需求↔设计↔架构闭环(交叉引用存在性)
# --strict:warning 也算失败。

AGE_CHECK_ERRORS=0
AGE_CHECK_WARNINGS=0

age_check() {
  age_init_runtime
  AGE_CHECK_ERRORS=0
  AGE_CHECK_WARNINGS=0

  local strict=0
  while [ $# -gt 0 ]; do
    case "$1" in
      --strict) strict=1; shift;;
      -h|--help) age_check_help; return 0;;
      *) age_warn "未知参数: $1"; shift;;
    esac
  done

  local root; root="$(pwd)"
  find_plugin_root 2>/dev/null || true

  echo "$(age_color bold 'AGE 一致性检查')"

  age_check_index_routes "$root"
  age_check_agents_skills "$root"
  age_check_context_quintet "$root"
  age_check_traceability "$root"

  echo
  local total_e=$AGE_CHECK_ERRORS total_w=$AGE_CHECK_WARNINGS
  printf '  %s  %s错误, %s警告\n' \
    "$( [ "$total_e" -gt 0 ] && age_color red '结果' || ([ "$total_w" -gt 0 ] && age_color yellow '结果' || age_color green '结果'))" \
    "$total_e" "$total_w"

  if [ "$total_e" -gt 0 ]; then return 1; fi
  if [ "$strict" = "1" ] && [ "$total_w" -gt 0 ]; then return 1; fi
  return 0
}

# 计数辅助
age_check_err() { AGE_CHECK_ERRORS=$((AGE_CHECK_ERRORS + 1)); age_error "$*"; }
age_check_warn() { AGE_CHECK_WARNINGS=$((AGE_CHECK_WARNINGS + 1)); age_warn "$*"; }

# ---------------------------------------------------------------------------
# 1. 路由目标存在性:docs/index.md 路由表每行引用的 owner 文档/目录是否存在
# 意图式:READ 集 / WRITEBACK 集含多个路径(相对 docs/),逐一校验。
# 模块式:第一列为代码路径,第二列为 owner 文档。
# ---------------------------------------------------------------------------
age_check_index_routes() {
  local root="$1"
  local index; index="$(age_index_path "$root")"
  if [ -z "$index" ]; then
    age_check_err "docs/index.md 不存在(用 age init 生成)"
    return
  fi
  age_info "检查路由目标存在性..."
  local routes_tmp; routes_tmp="$(mktemp)"
  age_parse_index_routes "$index" > "$routes_tmp"

  local c1 c2 c3
  while IFS=$'\t' read -r c1 c2 c3; do
    [ -z "$c1" ] && [ -z "$c2" ] && continue
    # 判定格式:第一列像代码路径 → 模块式;否则意图式(校验 c2/c3 中的路径)
    if age_looks_like_codepath "$c1" 2>/dev/null; then
      # 模块式:c2 = owner 文档
      local owner="$c2"
      local opath="$root/$owner"
      [ -f "$opath" ] || opath="$root/docs/$owner"
      [ -f "$opath" ] || opath="$owner"
      if [ ! -f "$opath" ] && [ "$owner" != "(待补充)" ] && [ -n "$owner" ]; then
        age_check_err "路由死链: '$c1' → '$owner' (文档不存在)"
      fi
      if [ -n "$c1" ] && [ "$c1" != "(待补充)" ]; then
        local mpath="$root/$c1"
        if [ ! -e "$mpath" ]; then
          age_check_warn "悬空路由: '$c1' 路径不存在(代码已删?)"
        fi
      fi
    else
      # 意图式:c2=READ集 c3=WRITEBACK集,拆分校验每个路径
      local set_str="$c2 $c3"
      local p
      for p in $(age_route_split_set "$set_str" 2>/dev/null); do
        [ -z "$p" ] && continue
        [ "$p" = "none" ] && continue
        [ "$p" = "通常" ] && continue
        # 路径中可能含中文前缀(如"相关 requirements/"),提取末尾路径段
        local clean
        clean=$(printf '%s' "$p" | sed -E 's/.*([a-zA-Z][a-zA-Z0-9_./-]*)$/\1/')
        [ -n "$clean" ] && p="$clean"
        # 路径相对 docs/:context/xxx → docs/context/xxx;也接受带 docs/ 前缀
        local chkpath="$root/docs/$p"
        [ -e "$chkpath" ] || chkpath="$root/$p"
        [ -e "$chkpath" ] || continue   # 无法定位的纯描述词跳过(非路径)
        if [ ! -e "$chkpath" ]; then
          age_check_err "路由死链: '$c1' 引用 '$p' 不存在"
        fi
      done
    fi
  done < "$routes_tmp"
  rm -f "$routes_tmp"
}

# ---------------------------------------------------------------------------
# 2. AGENTS.md 引用技能可解析
# 扫描 AGENTS.md 中形如 skills/age/... 或 skill:xxx 的引用,检查文件存在。
# ---------------------------------------------------------------------------
age_check_agents_skills() {
  local root="$1"
  local agents="$root/AGENTS.md"
  if [ ! -f "$agents" ]; then
    age_check_warn "AGENTS.md 不存在(用 age init 生成)"
    return
  fi
  age_info "检查 AGENTS.md 技能引用..."
  # 抓取 skills/ 开头的路径引用(常见写法:`skills/age/xxx`)
  local refs
  refs=$(grep -oE 'skills/[A-Za-z0-9_./-]+' "$agents" 2>/dev/null | sort -u || true)
  local r
  for r in $refs; do
    # 仅去掉行尾的标点(如句末的 . , ; : )),保留路径内的点(.md)
    r="$(printf '%s' "$r" | sed -e 's/[.,;:)]*$//')"
    # 技能可能在项目内,也可能引用 AGE 插件自身的 skills/(在 AGE_PLUGIN_ROOT)。
    # 先查项目根,再回退到插件根。
    local p="$root/$r"
    [ -e "$p" ] && continue
    if [ -n "${AGE_PLUGIN_ROOT:-}" ] && [ -e "$AGE_PLUGIN_ROOT/$r" ]; then
      continue
    fi
    age_check_err "AGENTS.md 引用的技能路径不存在: $r"
  done
  # 抓取 skill:xxx 写法
  refs=$(grep -oE 'skill:[A-Za-z0-9_./-]+' "$agents" 2>/dev/null | sort -u || true)
  for r in $refs; do
    local name="${r#skill:}"
    [ -d "$root/skills/$name" ] || [ -f "$root/skills/$name.md" ] || \
      age_check_warn "AGENTS.md 引用的技能未找到: skill:$name"
  done
}

# ---------------------------------------------------------------------------
# 3. docs/context/ 强制上下文齐全且非空
# 强制五件套(AGENTS.md 声明):project-context / ai-autonomy-policy /
#   codebase-map / source-of-truth-and-precedence / conventions
# 附加建议文件(空则 warning):requirements / decisions / risks / glossary
# ---------------------------------------------------------------------------
age_check_context_quintet() {
  local root="$1"
  local ctx="$root/docs/context"
  age_info "检查 docs/context/ 强制上下文..."
  # 强制五件套:缺失或空 = error
  local -a required=("project-context" "ai-autonomy-policy" "codebase-map" "source-of-truth-and-precedence" "conventions")
  # 附加建议:缺失或空 = warning(不阻断)
  local -a suggested=("requirements" "decisions" "risks" "glossary")
  if [ ! -d "$ctx" ]; then
    age_check_err "docs/context/ 目录不存在"
    return
  fi
  local f
  for f in "${required[@]}"; do
    local path="$ctx/$f.md"
    if [ ! -f "$path" ]; then
      age_check_err "缺失强制上下文: docs/context/$f.md"
      continue
    fi
    local body
    body=$(sed -e 's/^#.*//' -e 's/^>.*//' -e 's/^[[:space:]]*$//' "$path" 2>/dev/null)
    if [ -z "$body" ]; then
      age_check_err "强制上下文为空(仅标题/注释): docs/context/$f.md"
    fi
  done
  for f in "${suggested[@]}"; do
    local path="$ctx/$f.md"
    [ -f "$path" ] || continue   # 缺失不报(模板可选)
    local body
    body=$(sed -e 's/^#.*//' -e 's/^>.*//' -e 's/^[[:space:]]*$//' "$path" 2>/dev/null)
    if [ -z "$body" ]; then
      age_check_warn "建议上下文为空: docs/context/$f.md"
    fi
  done
}

# ---------------------------------------------------------------------------
# 4. 需求↔设计↔架构闭环
# 检查:requirements/design/architecture 目录各有至少1份文档,
# 且相互交叉引用(互提文件名)。
# ---------------------------------------------------------------------------
age_check_traceability() {
  local root="$1"
  age_info "检查需求↔设计↔架构闭环..."
  local -a dirs=("requirements" "design" "architecture")
  local d
  local has_req=0 has_design=0 has_arch=0
  for d in "${dirs[@]}"; do
    local dirpath="$root/docs/$d"
    if [ ! -d "$dirpath" ]; then
      age_check_warn "docs/$d/ 目录不存在(闭环缺失)"
      continue
    fi
    # 至少1个非 README 的 .md
    local nmd
    nmd=$(find "$dirpath" -maxdepth 1 -name '*.md' ! -name 'README.md' 2>/dev/null | wc -l | tr -d ' ')
    case "$d" in
      requirements) [ "$nmd" -gt 0 ] && has_req=1 || age_check_warn "docs/requirements/ 无实质文档(闭环缺需求)";;
      design)       [ "$nmd" -gt 0 ] && has_design=1 || age_check_warn "docs/design/ 无实质文档(闭环缺设计)";;
      architecture) [ "$nmd" -gt 0 ] && has_arch=1 || age_check_warn "docs/architecture/ 无实质文档(闭环缺架构)";;
    esac
  done

  # 交叉引用:design 应引用 requirements;architecture 应引用 design
  if [ "$has_req" = "1" ] && [ "$has_design" = "1" ]; then
    if ! grep -rliE 'requirements?|需求' "$root/docs/design/" >/dev/null 2>&1; then
      age_check_warn "design/ 未引用 requirements(闭环断链)"
    fi
  fi
  if [ "$has_design" = "1" ] && [ "$has_arch" = "1" ]; then
    if ! grep -rliE 'design|设计' "$root/docs/architecture/" >/dev/null 2>&1; then
      age_check_warn "architecture/ 未引用 design(闭环断链)"
    fi
  fi
}

# ---------------------------------------------------------------------------
age_check_help() {
  cat <<'EOF'
age check — 静态一致性校验

用法:
  age check [--strict]

检查项:
  1. docs/index.md 路由目标(owner 文档)存在
  2. AGENTS.md 引用的技能可解析
  3. docs/context/ 五件套齐全且非空
  4. 需求↔设计↔架构交叉引用闭环

参数:
  --strict  warning 也算失败(默认仅 error 失败)

退出码: 0 通过 / 1 失败
EOF
}

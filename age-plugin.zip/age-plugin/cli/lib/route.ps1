# route.ps1 — age route 实现 (PowerShell)
# 等价 cli/lib/route.sh:解析 docs/index.md 路由表(意图式:你要做的事→READ集/WRITEBACK集)
#       + 技能路由表(任务类型→项目技能)
#       + skills/age/references/routing-rules.md 决策表
# 输入任务描述,输出应读哪些 owner 文档、选哪个技能。
# --explain 输出决策路径。退出码:0 命中 / 1 未命中。

function script:age_route {
    param([Parameter(ValueFromRemainingArguments)][string[]]$Args)

    age_init_runtime

    $explain = $false
    $taskParts = [System.Collections.Generic.List[string]]::new()
    foreach ($a in $Args) {
        switch -Regex ($a) {
            '^--explain$'   { $explain = $true }
            '^(-h|--help)$' { age_route_help; return 0 }
            default         { $taskParts.Add($a) }
        }
    }
    $task = $taskParts -join " "

    if (-not $task) {
        age_die "缺少任务描述。用法: age route <task> [--explain]" 1
    }

    $root = (Get-Location).Path
    find_plugin_root | Out-Null

    $index = age_index_path $root
    if (-not $index) {
        age_error "docs/index.md 不存在,无法路由。请先 age init。"
        return 1
    }

    # 加载意图路由表
    $routes = age_parse_index_routes $index
    # 加载技能路由表
    $skills = age_parse_index_skills $index
    # 加载 routing-rules.md(若存在)
    $rules = ""
    $rulesPath = Join-Path $script:AGE_PLUGIN_ROOT "skills/age/references/routing-rules.md"
    if ($rulesPath -and (Test-Path $rulesPath -PathType Leaf)) {
        $rules = $rulesPath
    } else {
        $altRules = Join-Path $root "skills/age/references/routing-rules.md"
        if (Test-Path $altRules -PathType Leaf) { $rules = $altRules }
    }

    # 路由匹配:遍历意图行,关键词命中 → 收集 READ 集
    $matchedRead = [System.Collections.Generic.List[string]]::new()
    $matchedWriteback = [System.Collections.Generic.List[string]]::new()
    $matchedIntent = ""
    $anyHit = $false
    foreach ($r in $routes) {
        if (-not $r.intent) { continue }
        if (age_route_match_intent $task $r.intent) {
            $anyHit = $true
            $matchedIntent = $r.intent
            foreach ($d in (age_route_split_set $r.reads)) {
                if ($d) { age_route_add_list $matchedRead $d }
            }
            foreach ($d in (age_route_split_set $r.writeback)) {
                if ($d) { age_route_add_list $matchedWriteback $d }
            }
            break   # 命中首个意图即可
        }
    }

    # 技能匹配:从技能表按任务类型关键词查
    $matchedSkill = ""
    foreach ($s in $skills) {
        if (-not $s.ttype) { continue }
        if (age_route_match_intent $task $s.ttype) {
            $matchedSkill = $s.skill
            break
        }
    }

    # 决策表补充:若未命中,查 routing-rules
    if (-not $anyHit -and $rules) {
        $ruleResult = age_route_rules_lookup $rules $task
        if ($ruleResult) {
            $anyHit = $true
            $matchedSkill = $ruleResult
            $matchedIntent = "决策表匹配(默认路由)"
        }
    }

    if (-not $anyHit) {
        Write-Host "$(age_color yellow '未命中路由')。" -ForegroundColor Yellow
        Write-Host "任务: $task"
        Write-Host "建议: 在 docs/index.md 补充该任务类型的路由条目,或手动选择技能。"
        if ($explain) { age_route_explain $task $index $rules "" "" "未命中" }
        return 1
    }

    # 输出
    Write-Host "$(age_color bold '路由结果')"
    Write-Host "  任务: $(age_color cyan $task)"
    Write-Host "  匹配意图: $(age_color cyan $matchedIntent)"
    Write-Host "  $(age_color green '应读 (READ 集)'):"
    foreach ($d in $matchedRead) { if ($d) { Write-Host "    - $d" } }
    Write-Host "  $(age_color green '可能回写 (WRITEBACK 集)'):"
    foreach ($w in $matchedWriteback) { if ($w) { Write-Host "    - $w" } }
    Write-Host "  $(age_color green '建议技能'):"
    if ($matchedSkill) {
        Write-Host "    - $matchedSkill"
    } else {
        Write-Host "    - none(无项目技能,走 owner 文档)"
    }

    if ($explain) {
        age_route_explain $task $index $rules ($matchedRead -join " ") $matchedSkill $matchedIntent
    }
    return 0
}

# age_route_add_list <list> <value>:向列表追加(去重)
function script:age_route_add_list {
    param($List, [string]$Val)
    if ($List -contains $Val) { return }
    $List.Add($Val)
}

# age_route_split_set <set_string>:把 "context/a.md、backlog/、requirements/" 拆成路径列表
# 处理中文顿号、逗号、空格分隔;去掉反引号、说明括号
function script:age_route_split_set {
    param([string]$SetStr)
    if (-not $SetStr) { return @() }
    $s = $SetStr -replace '`', ''
    $s = $s -replace '、', ' ' -replace ',', ' '
    # 去掉括号说明(中英文)
    $s = [regex]::Replace($s, '\([^)]*\)', '')
    $s = [regex]::Replace($s, '（[^）]*）', '')
    $parts = $s -split '\s+' | ForEach-Object { $_.Trim() } | Where-Object { $_ }
    return $parts
}

# age_route_match_intent:task 是否命中意图行(关键词匹配)
function script:age_route_match_intent {
    param([string]$task, [string]$intent)
    $t = $task.ToLower()
    $i = $intent.ToLower()
    # 英文 token(长度>=2)包含匹配
    $tokens = [regex]::Matches($i, '[a-z0-9]{2,}') | ForEach-Object { $_.Value }
    foreach ($kw in $tokens) {
        if ($t.Contains($kw)) { return $true }
    }
    # 中文关键词(连续中文>=2字)
    $zhTokens = [regex]::Matches($intent, '[\u4e00-\u9fff]{2,}') | ForEach-Object { $_.Value }
    foreach ($kw in $zhTokens) {
        if ($t.Contains($kw.ToLower())) { return $true }
    }
    return $false
}

# age_route_rules_lookup:在 routing-rules.md 中按关键词查技能/文档
# 决策表约定:| 关键词 | 技能 | 或 | 关键词 | READ | 技能 |
function script:age_route_rules_lookup {
    param([string]$Rules, [string]$Task)
    if (-not (Test-Path $Rules -PathType Leaf)) { return "" }
    $t = $Task.ToLower()
    $lines = Get-Content -Path $Rules -Encoding UTF8
    foreach ($line in $lines) {
        if ($line -notmatch '^\s*\|') { continue }
        if ($line -match '^\|[-: |]+\]+$') { continue }
        $cols = $line.TrimStart('|').Split('|')
        # 取第3、4列(关键词、技能);兼容列数差异
        $kw = if ($cols.Length -ge 3) { $cols[2].Trim() } else { "" }
        $sk = if ($cols.Length -ge 4) { $cols[3].Trim() } else { "" }
        if (-not $kw -or -not $sk) { continue }
        if ($kw -match '关键词|keyword') { continue }
        # 关键词按 , ， 、 空格切分
        $kwParts = $kw -split '[,，、\s]+' | ForEach-Object { $_.Trim().ToLower() } | Where-Object { $_ }
        foreach ($p in $kwParts) {
            if ($t.Contains($p)) { return $sk }
        }
        # 中文关键词
        $zhTokens = [regex]::Matches($kw, '[\u4e00-\u9fff]{2,}') | ForEach-Object { $_.Value }
        foreach ($zh in $zhTokens) {
            if ($t.Contains($zh.ToLower())) { return $sk }
        }
    }
    return ""
}

# age_route_explain:输出决策路径
function script:age_route_explain {
    param([string]$Task, [string]$Index, [string]$Rules, [string]$Readset, [string]$Skill, [string]$Intent)
    Write-Host ""
    Write-Host "$(age_color bold '决策路径'):"
    Write-Host "  1. 读取路由器: $Index"
    Write-Host "  2. 解析意图路由表(你要做的事→READ/WRITEBACK) + 技能路由表(任务类型→技能)"
    Write-Host "  3. 任务关键词切分: $($Task.ToLower())"
    Write-Host "  4. 遍历意图行,关键词包含匹配"
    if ($Intent) { Write-Host "  5. 命中意图: $Intent" }
    else { Write-Host "  5. 意图表未命中" }
    if ($Rules) { Write-Host "  6. 补充查决策表: $Rules" }
    else { Write-Host "  6. 决策表 routing-rules.md 未找到(跳过)" }
    $skillDisplay = if ($Skill) { $Skill } else { "none" }
    Write-Host "  7. 结果 → READ: [$Readset] skill: [$skillDisplay]"
}

function script:age_route_help {
    @'
age route — 任务路由

用法:
  age route <task> [--explain]

参数:
  <task>     任务描述(自然语言,如"新增需求"、"设计接口"、"修bug")
  --explain  输出决策路径

输出:
  - 匹配的意图行
  - 应读的 owner 文档(READ 集)
  - 可能回写的文档(WRITEBACK 集)
  - 建议技能(来自技能路由表或决策表)

退出码: 0 命中 / 1 未命中
'@ | Write-Host
}

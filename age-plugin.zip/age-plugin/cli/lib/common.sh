# common.sh — AGE CLI 共享函数库
# 被 cli/age 主入口 source;所有 cli/lib/*.sh 可调用此处函数。
# 仅依赖标准工具:git/sed/grep/find/awk/cat/mkdir/printf。

# ---------------------------------------------------------------------------
# 常量
# ---------------------------------------------------------------------------
# .age 目录(运行态数据):日志、基线快照、缓存
AGE_DIR_NAME=".age"
AGE_LOG_FILE=""        # 由 age_init_runtime 在首次日志时确定
# AGE_PLUGIN_ROOT 可能在 cli/age 主入口已设置(基于自解析路径);
# 仅在未设置时清空,由 find_plugin_root 按需填充。
: "${AGE_PLUGIN_ROOT=}"

# 退出码(与 CONTRACT.md 第3节一致)
AGE_OK=0
AGE_FAIL=1

# ---------------------------------------------------------------------------
# 颜色输出(无 tty 时自动降级为无色)
# ---------------------------------------------------------------------------
age_color_init() {
  if [ -t 1 ] && [ -z "${AGE_NO_COLOR:-}" ]; then
    AGE_C_RESET=$'\033[0m'
    AGE_C_BOLD=$'\033[1m'
    AGE_C_RED=$'\033[31m'
    AGE_C_GREEN=$'\033[32m'
    AGE_C_YELLOW=$'\033[33m'
    AGE_C_BLUE=$'\033[34m'
    AGE_C_CYAN=$'\033[36m'
    AGE_C_GRAY=$'\033[90m'
  else
    AGE_C_RESET=""
    AGE_C_BOLD=""
    AGE_C_RED=""
    AGE_C_GREEN=""
    AGE_C_YELLOW=""
    AGE_C_BLUE=""
    AGE_C_CYAN=""
    AGE_C_GRAY=""
  fi
}

# 文本着色:age_color red "msg"
age_color() {
  local color="$1"; shift
  local var="AGE_C_$(echo "$color" | tr '[:lower:]' '[:upper:]')"
  printf '%s%s%s' "${!var}" "$*" "$AGE_C_RESET"
}

# ---------------------------------------------------------------------------
# 插件根定位与运行态初始化
# ---------------------------------------------------------------------------

# find_plugin_root:向上查找含 cli/age 的目录,设置 AGE_PLUGIN_ROOT。
# 返回 0 找到,1 未找到。
find_plugin_root() {
  local dir="${AGE_PLUGIN_ROOT:-}"
  # 已缓存则直接返回
  if [ -n "$dir" ] && [ -f "$dir/cli/age" ]; then return 0; fi
  dir="$(pwd)"
  while [ "$dir" != "/" ]; do
    if [ -f "$dir/cli/age" ]; then
      AGE_PLUGIN_ROOT="$dir"
      return 0
    fi
    dir="$(dirname "$dir")"
  done
  # 最后检查一次根目录
  if [ -f "/cli/age" ]; then AGE_PLUGIN_ROOT="/"; return 0; fi
  return 1
}

# age_runtime_dir:返回当前项目(=cwd)的 .age 目录。
# 运行态数据(日志 .age/age.log、基线 .age/baseline.json)属于被操作的项目,
# 不属于 AGE 插件本身。AGE_PLUGIN_ROOT 仅用于定位插件代码(templates/skills/cli)。
age_runtime_dir() {
  echo "$(pwd)/$AGE_DIR_NAME"
}

# age_init_runtime:确保 .age 目录存在,设置日志路径。幂等。
age_init_runtime() {
  local rt; rt="$(age_runtime_dir)"
  [ -d "$rt" ] || mkdir -p "$rt"
  AGE_LOG_FILE="$rt/age.log"
}

# ---------------------------------------------------------------------------
# 日志(追加写 .age/age.log,带时间戳与级别)
# ---------------------------------------------------------------------------
age_log() {
  local level="$1"; shift
  age_init_runtime
  local ts
  ts="$(date '+%Y-%m-%dT%H:%M:%S%z' 2>/dev/null || date '+%Y-%m-%dT%H:%M:%S')"
  printf '%s [%s] %s\n' "$ts" "$level" "$*" >> "$AGE_LOG_FILE" 2>/dev/null
}

# ---------------------------------------------------------------------------
# 用户面输出(区分 info/warn/error/success)
# ---------------------------------------------------------------------------
age_info()    { printf '%s\n' "$(age_color cyan 'ℹ') $*"; age_log INFO "$*"; }
age_success() { printf '%s\n' "$(age_color green '✓') $*"; age_log INFO "$*"; }
age_warn()    { printf '%s\n' "$(age_color yellow '⚠') $*" >&2; age_log WARN "$*"; }
age_error()   { printf '%s\n' "$(age_color red '✗') $*" >&2; age_log ERROR "$*"; }

# age_die <msg> [exit_code]:打印错误并以码退出(默认1)
age_die() {
  local code="${2:-$AGE_FAIL}"
  age_error "$1"
  exit "$code"
}

# ---------------------------------------------------------------------------
# git 可用性(优雅降级)
# ---------------------------------------------------------------------------
# age_git_ok:git 可用且当前在仓库内 → 0;否则 1(不报错,仅判断)
age_git_ok() {
  command -v git >/dev/null 2>&1 || return 1
  git rev-parse --git-dir >/dev/null 2>&1 || return 1
  return 0
}

# age_git_root:输出 git 仓库根目录;无 git 时输出空串。
age_git_root() {
  age_git_ok || { echo ""; return 1; }
  git rev-parse --show-toplevel 2>/dev/null
}

# ---------------------------------------------------------------------------
# AGE 仓库判定
# ---------------------------------------------------------------------------
# is_age_repo:存在 docs/index.md(AGE 路由器)或 AGENTS.md 视为已初始化。
is_age_repo() {
  local root="${1:-$(pwd)}"
  [ -f "$root/docs/index.md" ] && return 0
  [ -f "$root/AGENTS.md" ] && return 0
  return 1
}

# ---------------------------------------------------------------------------
# 宿主客户端检测(多客户端兼容,CONTRACT §8.11,CP-1 校验后)
# ---------------------------------------------------------------------------
# detect_host:检测当前宿主客户端环境,输出 zcode|claude|codex|opencode|multica|win11|unknown。
#
# 检测策略(CP-1 校验后修订 + Multica 恢复 + Win11 兼容,2026-07-11):
#   第一优先级:环境变量(最可靠,多客户端共存时运行中的客户端会设置自己的 env)。
#     - ZCODE_PLUGIN_ROOT / ZCODE_PROJECT_DIR → zcode
#     - CLAUDE_PLUGIN_ROOT / CLAUDE_PROJECT_DIR → claude
#     - CODEX_HOME(且 config.toml 存在)→ codex
#     - OPENCODE_CONFIG → opencode
#     - AGE_MULTICA_WORKSPACE(Multica agent 注入)→ multica
#   第二优先级:配置文件/目录特征(单客户端或无 env 时的回退)。
#     - ZCode:.zcode/ 目录
#     - Claude:.claude/ 目录,~/.claude/
#     - Codex:~/.codex/config.toml(优先检测是否含 [hooks] 段,确认是 full 级 AGE 配置)
#     - OpenCode:opencode.json,~/.config/opencode/
#     - Multica:/Applications/Multica.app 存在 或 multica 在 PATH 或 ~/.multica/config.json 存在
#     - Win11(§8.12):$OS=Windows_NT 或 uname 含 MINGW/MSYS/CYGWIN/Windows(bash on Win)
#
# Codex 检测信号增强(CP-4):除 CODEX_HOME/~/.codex 外,还检测
#   ~/.codex/config.toml 是否含 [hooks] 段(确认 Codex full 级兼容已安装)。
#
# Multica 检测(§8.11 恢复):本机验证 v0.3.43,云 workspace 模式,full 级(skill+MCP+
#   autopilot)。无 AGE 专用 env 注入时,用 multica CLI 在 PATH 或 Multica.app 存在或
#   ~/.multica/config.json 存在作回退信号。优先级低于客户端 env/特征(避免误判)。
#
# Win11 检测(§8.12):bash 在 Win11 上运行时(Git-Bash/WSL/MSYS),$OS=Windows_NT 或
#   uname 输出含 MINGW/MSYS/CYGWIN/Windows。优先级最低(在所有客户端信号之后),
#   仅当上面所有更明确的客户端信号都不命中时,才判定为 win11。注意:bash 在 WSL
#   (真 Linux 内核)下 uname 输出含 "Linux" 而非 Windows/MINGW,故 WSL 不会命中
#   win11 分支(WSL 是完整 Linux,走标准 bash 路径,不算 Win11 原生场景)。
#
# 返回码:0 始终(unknown 也是合法结果,调用方决定如何处理)。
detect_host() {
  # === 第一优先级:环境变量(多客户端共存时据此判定运行中的客户端)===

  # 1a. ZCode:有 ZCODE_PLUGIN_ROOT 环境变量(插件 hook 运行时设置)
  if [ -n "${ZCODE_PLUGIN_ROOT:-}" ] && [ -d "${ZCODE_PLUGIN_ROOT:-}" ]; then
    echo "zcode"; return 0
  fi
  # ZCODE_PROJECT_DIR 由 ZCode 宿主注入(即使无 PLUGIN_ROOT 也判定为 zcode)
  if [ -n "${ZCODE_PROJECT_DIR:-}" ] && [ -d "${ZCODE_PROJECT_DIR:-}" ]; then
    echo "zcode"; return 0
  fi

  # 1b. Claude Code:有 CLAUDE_PLUGIN_ROOT 环境变量
  if [ -n "${CLAUDE_PLUGIN_ROOT:-}" ] && [ -d "${CLAUDE_PLUGIN_ROOT:-}" ]; then
    echo "claude"; return 0
  fi
  # CLAUDE_PROJECT_DIR 由 Claude Code 宿主注入
  if [ -n "${CLAUDE_PROJECT_DIR:-}" ] && [ -d "${CLAUDE_PROJECT_DIR:-}" ]; then
    echo "claude"; return 0
  fi

  # 1c. Codex:有 CODEX_HOME 环境变量(指向配置目录)
  if [ -n "${CODEX_HOME:-}" ] && [ -d "${CODEX_HOME:-}" ]; then
    echo "codex"; return 0
  fi

  # 1d. OpenCode:有 OPENCODE_CONFIG 环境变量
  if [ -n "${OPENCODE_CONFIG:-}" ]; then
    echo "opencode"; return 0
  fi

  # 1e. Multica:有 AGE_MULTICA_WORKSPACE 环境变量(install.sh 或 agent custom-env 注入)
  #   Multica agent 运行时由 install.sh 经 agent env set 注入此变量,作为最强信号。
  if [ -n "${AGE_MULTICA_WORKSPACE:-}" ]; then
    echo "multica"; return 0
  fi

  # === 第二优先级:配置文件/目录特征(无 env 时的回退)===

  # 2a. ZCode:cwd 下 .zcode/ 目录(ZCode 工作区特征)
  if [ -d "$(pwd)/.zcode" ]; then
    echo "zcode"; return 0
  fi
  if [ -d "${ZCODE_PROJECT_DIR:-}/.zcode" ] 2>/dev/null; then
    echo "zcode"; return 0
  fi

  # 2b. Claude Code:.claude/ 目录 或 ~/.claude/
  if [ -d "$(pwd)/.claude" ]; then
    echo "claude"; return 0
  fi
  if [ -d "$HOME/.claude" ]; then
    echo "claude"; return 0
  fi

  # 2c. Codex:~/.codex/ 目录(CP-4 增强:检测 config.toml 含 [hooks] 段)
  #   有 [hooks] 段 → 确认 Codex full 级 AGE 配置已安装(优先匹配)
  #   无 [hooks] 段但目录存在 → 仍判定为 codex(可能未安装 AGE hooks)
  local codex_home="${CODEX_HOME:-$HOME/.codex}"
  if [ -d "$codex_home" ]; then
    # 检测 config.toml 是否含 [hooks] 段(CP-1:Codex 有完整 PascalCase hooks)
    if [ -f "$codex_home/config.toml" ] && \
       grep -qE '^[[:space:]]*\[hooks' "$codex_home/config.toml" 2>/dev/null; then
      echo "codex"; return 0
    fi
    # 目录存在但无 hooks 段也判定为 codex(基础检测)
    if [ -d "$HOME/.codex" ]; then
      echo "codex"; return 0
    fi
  fi
  # 兜底:无 CODEX_HOME 但有 ~/.codex
  if [ -d "$HOME/.codex" ]; then
    echo "codex"; return 0
  fi

  # 2d. OpenCode:cwd 下 opencode.json 存在,或 ~/.config/opencode/
  if [ -f "$(pwd)/opencode.json" ]; then
    echo "opencode"; return 0
  fi
  if [ -d "$HOME/.config/opencode" ]; then
    echo "opencode"; return 0
  fi

  # 2e. Multica(§8.11 恢复,本机 v0.3.43 验证):云 workspace 模式,full 级。
  #   信号优先级:multica CLI 在 PATH > /Applications/Multica.app 存在 > ~/.multica/config.json。
  #   注:Multica 检测放在最后(OpenCode 之后),因为本机常与其它客户端共存,
  #   仅当上面所有更明确的客户端信号都不命中时,才判定为 multica。
  if command -v multica >/dev/null 2>&1; then
    # 确认是 Multica 的 multica(非同名其它工具):检查 ~/.multica/config.json
    if [ -f "$HOME/.multica/config.json" ]; then
      echo "multica"; return 0
    fi
  fi
  if [ -d "/Applications/Multica.app" ] && [ -f "$HOME/.multica/config.json" ]; then
    echo "multica"; return 0
  fi
  # 仅 ~/.multica/config.json(无 CLI/无 app,可能仅认证残留)——仍判 multica
  if [ -f "$HOME/.multica/config.json" ]; then
    echo "multica"; return 0
  fi

  # 2f. Win11 检测(§8.12):bash on Windows。
  #   信号:$OS=Windows_NT(cmd/PowerShell 注入,Git-Bash/MSYS 继承)或
  #         uname 输出含 MINGW/MSYS/CYGWIN/Windows。
  #   优先级最低(所有客户端 env/特征之后),仅当无更明确的客户端信号时才判 win11。
  #   注:WSL(真 Linux 内核)uname 含 "Linux",不命中此分支(WSL 走标准 bash,非 Win11 原生)。
  if [ -n "${OS:-}" ] && [ "$OS" = "Windows_NT" ]; then
    echo "win11"; return 0
  fi
  if command -v uname >/dev/null 2>&1; then
    local uname_out
    uname_out="$(uname 2>/dev/null)"
    case "$uname_out" in
      *MINGW*|*MSYS*|*CYGWIN*|*Windows*) echo "win11"; return 0;;
    esac
  fi

  # 3. 无法判定
  echo "unknown"; return 0
}

# ---------------------------------------------------------------------------
# JSON 工具:纯 sed/awk 的极简 JSON 字符串转义与拼接。
# 不引入 jq 依赖;只做够用的字符串转义。
# ---------------------------------------------------------------------------
# age_json_escape <string>:转义 JSON 字符串内容(反斜杠/引号/控制字符)
age_json_escape() {
  # 先处理反斜杠,再处理引号,再处理换行/制表/回车
  printf '%s' "$1" \
    | sed -e 's/\\/\\\\/g' \
          -e 's/"/\\"/g' \
          -e 's/\t/\\t/g' \
    | awk -v RS='\0' '{
        gsub(/\r/, "\\r", $0);
        gsub(/\n/, "\\n", $0);
        printf "%s", $0
      }'
}

# age_json_kv <key> <value> [quote]:输出 "key":"value" 或 "key":value(quote=0)
age_json_kv() {
  local key="$1" val="$2" quote="${3:-1}"
  if [ "$quote" = "1" ]; then
    printf '"%s":"%s"' "$(age_json_escape "$key")" "$(age_json_escape "$val")"
  else
    printf '"%s":%s' "$(age_json_escape "$key")" "$val"
  fi
}

# ---------------------------------------------------------------------------
# 模板渲染:render_template <template_file> <output_file> <key1=val1> [key2=val2 ...]
# 替换 {{key}} → val。支持多层嵌套占位符(如 {{user.name}} 通过转点号为下划线)。
# 用 sed 实现;占位符格式 {{ key }} / {{key}} 均可(去空格)。
# ---------------------------------------------------------------------------
render_template() {
  local tpl="$1" out="$2"; shift 2
  [ -f "$tpl" ] || { age_die "模板不存在: $tpl" 1; }

  local tmp; tmp="$(mktemp)"
  cp "$tpl" "$tmp"

  # 去重 key(保留每个 key 的最后一条值)。
  # 背景:调用方(如 age init)常先填默认值再追加命令行覆盖,导致同一 key 出现多次。
  # sed 替换是消耗式的——首次替换后占位符已消失,后续同 key 的覆盖值无法生效。
  # 这里先把 kvs 折叠成"每 key 仅最后值",保证覆盖语义正确。
  # 策略:逆序遍历(tac),首次见到的 key 即原序中最后定义者;收集后还原为原顺序。
  local dedup_tmp; dedup_tmp="$(mktemp)"
  local kv
  for kv in "$@"; do
    printf '%s\n' "$kv" >> "$dedup_tmp"
  done
  local -a final_kvs=()
  local key_seen=""
  local -a rev=()
  # tac 逆序读 BSD/GNU 通用:tail -r(macOS)回退到 tac
  local tac_bin=""
  if command -v tac >/dev/null 2>&1; then tac_bin="tac"; else tac_bin="tail -r"; fi
  while IFS= read -r kv; do
    [ -z "$kv" ] && continue
    local k="${kv%%=*}"
    # 逆序下首次见到 = 原序最后定义,保留;后续重复丢弃
    case " $key_seen " in
      *" $k "*) continue;;
    esac
    key_seen="$key_seen $k"
    rev=( "$kv" ${rev[@]+"${rev[@]}"} )   # 前插,使最终顺序恢复原序
  done < <($tac_bin "$dedup_tmp")
  final_kvs=( ${rev[@]+"${rev[@]}"} )
  rm -f "$dedup_tmp"

  # 逐个参数 key=value 替换
  for kv in "${final_kvs[@]}"; do
    local key="${kv%%=*}"
    local val="${kv#*=}"
    [ "$key" = "$kv" ] && continue   # 无 = 跳过
    # key 归一化:去空格,点号→下划线(便于 {{user.name}} 写法)
    key="$(echo "$key" | sed -e 's/^[[:space:]]*//' -e 's/[[:space:]]*$//' -e 's/\./_/g')"
    # val 转义 sed 替换串特殊字符:反斜杠、&、/ (分隔符)、换行。
    # 用 | 作 sed 分隔符避免值中的 / 冲突,但仍需转义 | 和 & 和 \。
    local esc_val
    if printf '%s' "$val" | grep -q $'\n'; then
      # 多行:换行先转 \n 字面
      esc_val="$(printf '%s' "$val" | sed -e 's/[\\&|]/\\&/g' -e 's/\n/\\n/g')"
    else
      esc_val="$(printf '%s' "$val" | sed -e 's/[\\&|]/\\&/g')"
    fi
    # 匹配 {{ key }} 与 {{key}}。用 | 作分隔符(值中 / 不需转义)。
    local tmp2; tmp2="$(mktemp)"
    if ! sed -e "s|{{[[:space:]]*${key}[[:space:]]*}}|${esc_val}|g" "$tmp" > "$tmp2" 2>/dev/null; then
      # sed 失败:保留原 tmp,丢弃空 tmp2,不覆盖
      rm -f "$tmp2"
      continue
    fi
    # 仅在 tmp2 非空时才替换(防止 sed 静默失败写空文件)
    if [ -s "$tmp2" ]; then
      mv "$tmp2" "$tmp"
    else
      rm -f "$tmp2"
    fi
  done

  # 把渲染结果写到目标
  mkdir -p "$(dirname "$out")" 2>/dev/null
  mv "$tmp" "$out"
}

# ---------------------------------------------------------------------------
# docs/index.md 路由表解析
# ---------------------------------------------------------------------------
# age_index_path:输出 docs/index.md 路径(项目根下);不存在输出空。
age_index_path() {
  local root="${1:-$(pwd)}"
  [ -f "$root/docs/index.md" ] && { echo "$root/docs/index.md"; return 0; }
  echo ""; return 1
}

# age_parse_index_routes <index.md>:解析路由表,输出 TSV: 意图<TAB>READ集<TAB>WRITEBACK集
# 支持两种格式:
#   (A) 意图式(优先):| 你要做的事 | READ 集 | WRITEBACK 集 |
#   (B) 模块式(兼容):| 模块/路径 | owner 文档 | 技能 |
# 章节感知:仅解析"路由表"章节(到下一个 ## 标题止),避免误抓技能表/目录索引。
# 跳过表头与分隔行。
age_parse_index_routes() {
  local index="$1"
  [ -f "$index" ] || return 1
  # 列约定:| 意图 | READ集 | WRITEBACK集 |  →  $2=意图 $3=READ $4=WRITEBACK
  awk -F'|' '
    function trim(s){ gsub(/^[[:space:]]+|[[:space:]]+$/,"",s); return s }
    BEGIN { inroute=0 }
    # 进入路由表章节:标题含"路由表"但不含"技能"(排除"技能路由表")
    /^##[^#].*路由表/ && !/技能/ { inroute=1; next }
    # 遇到任意 ## 标题则退出
    inroute && /^##[^#]/ { inroute=0 }
    inroute && /^[[:space:]]*\|/ {
      line=$0
      gsub(/^[[:space:]]+/, "", line)
      if (line == "") next
      if (line ~ /^\|[-: |]+$/) next       # 分隔行
      intent=trim($2); reads=trim($3); wbs=trim($4)
      if (intent=="" && reads=="") next
      # 表头识别:仅匹配确切表头标记(避免误杀含"模块"的意图行)
      if (intent ~ /^你要做的事$/) next
      if (reads ~ /^先读|READ 集/) next
      printf "%s\t%s\t%s\n", intent, reads, wbs
    }
  ' "$index"
}

# age_parse_index_skills <index.md>:解析技能路由表,输出 TSV: 任务类型<TAB>技能
# 章节感知:仅解析"技能路由表"章节。表格形如:| 任务类型 | 项目技能 | 备注 |
age_parse_index_skills() {
  local index="$1"
  [ -f "$index" ] || return 1
  awk -F'|' '
    function trim(s){ gsub(/^[[:space:]]+|[[:space:]]+$/,"",s); return s }
    BEGIN { inskill=0 }
    /^##[^#].*技能路由/ { inskill=1; next }
    inskill && /^##[^#]/ { inskill=0 }
    inskill && /^[[:space:]]*\|/ {
      line=$0
      gsub(/^[[:space:]]+/, "", line)
      if (line ~ /^\|[-: |]+$/) next
      ttype=trim($2); skill=trim($3)
      if (ttype=="" && skill=="") next
      if (ttype ~ /任务类型|task/i) next
      printf "%s\t%s\n", ttype, skill
    }
  ' "$index"
}

# ---------------------------------------------------------------------------
# 调用核心函数(subprocess 自身复用):统一入口
# age_call_cli <subcommand> [args...]:以子进程调用 cli/age,返回其退出码。
# 用于 MCP server / hook 脚本复用 CLI 核心逻辑。
# ---------------------------------------------------------------------------
age_call_cli() {
  find_plugin_root 2>/dev/null || true
  [ -n "$AGE_PLUGIN_ROOT" ] || return 1
  "$AGE_PLUGIN_ROOT/cli/age" "$@"
}

# ---------------------------------------------------------------------------
# 参数解析辅助
# ---------------------------------------------------------------------------
# age_has_flag <flag> "$@":参数列表中是否含某 flag。返回 0/1。
age_has_flag() {
  local flag="$1"; shift
  local a
  for a in "$@"; do [ "$a" = "$flag" ] && return 0; done
  return 1
}

# age_get_opt <flag> <default> "$@":取 --flag value 形式参数值,缺省返回 default。
age_get_opt() {
  local flag="$1" default="$2"; shift 2
  local a prev=""
  for a in "$@"; do
    if [ "$prev" = "$flag" ]; then printf '%s' "$a"; return 0; fi
    prev="$a"
  done
  printf '%s' "$default"
}

# age_get_opt_flag <flag> "$@":取 --flag=value 形式或 --flag value;返回值或空。
age_get_opt_eq() {
  local flag="$1"; shift
  local a
  for a in "$@"; do
    case "$a" in
      "$flag"=*) printf '%s' "${a#*=}"; return 0;;
    esac
  done
  return 1
}

# ---------------------------------------------------------------------------
# 在 source 时执行一次性初始化
# ---------------------------------------------------------------------------
age_color_init

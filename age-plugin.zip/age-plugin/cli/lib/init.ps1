# init.ps1 — age init 实现 (PowerShell)
# 等价 cli/lib/init.sh:拷贝 templates/repo/ → 渲染占位符 → 生成骨架 → check + baseline。
# 用法:age init [--name X] [--kind web|mobile|cli] [--validate CMD] [目标目录]

# ---------------------------------------------------------------------------
# 读取 userConfig-schema.json 默认值
# PowerShell 用 ConvertFrom-Json 解析(内置,无 jq 依赖)。
# 返回 hashtable:字段名→默认值。schema 不存在时返回内置默认值。
# ---------------------------------------------------------------------------
function script:age_load_userconfig_defaults {
    $kvs = [ordered]@{
        project_name    = "My Project"
        project_kind    = "web"
        doc_language    = "zh"
        require_backlog = "true"
        validate_cmd    = ""
        owner_name      = ""
    }
    if (-not (find_plugin_root)) { return $kvs }
    $schema = Join-Path $script:AGE_PLUGIN_ROOT ".zcode-plugin/userConfig-schema.json"
    if (Test-Path $schema -PathType Leaf) {
        try {
            $json = Get-Content -Path $schema -Raw -Encoding UTF8 | ConvertFrom-Json
            if ($json.properties) {
                foreach ($prop in $json.properties.PSObject.Properties) {
                    if ($null -ne $prop.Value.default) {
                        $kvs[$prop.Name] = [string]$prop.Value.default
                    }
                }
            }
        } catch {
            # 解析失败:保留内置默认
        }
    }
    return $kvs
}

# ---------------------------------------------------------------------------
# age_init:主入口
# ---------------------------------------------------------------------------
function script:age_init {
    param([Parameter(ValueFromRemainingArguments)][string[]]$Args)

    age_init_runtime

    $name = ""; $kind = ""; $validate = ""; $target = "."
    # 解析参数
    $i = 0
    while ($i -lt $Args.Length) {
        $a = $Args[$i]
        switch -Regex ($a) {
            '^--name$'      { if (($i + 1) -lt $Args.Length) { $name = $Args[$i + 1]; $i += 2 } else { $i++ } }
            '^--name='      { $name = $a.Substring(7); $i++ }
            '^--kind$'      { if (($i + 1) -lt $Args.Length) { $kind = $Args[$i + 1]; $i += 2 } else { $i++ } }
            '^--kind='      { $kind = $a.Substring(7); $i++ }
            '^--validate$'  { if (($i + 1) -lt $Args.Length) { $validate = $Args[$i + 1]; $i += 2 } else { $i++ } }
            '^--validate='  { $validate = $a.Substring(11); $i++ }
            '^(-h|--help)$' { age_init_help; return 0 }
            default         { $target = $a; $i++ }
        }
    }

    # 校验 kind
    if ($kind -and $kind -notin @("web", "mobile", "cli")) {
        age_die "无效 --kind: $kind (允许: web|mobile|cli)" 1
    }

    # 目标目录处理(转为绝对路径)
    if (Test-Path $target -PathType Container) {
        $target = (Resolve-Path $target).Path
    } else {
        $target = (Join-Path (Get-Location).Path $target)
        New-Item -ItemType Directory -Path $target -Force | Out-Null
    }
    if (-not (Test-Path $target -PathType Container)) {
        New-Item -ItemType Directory -Path $target -Force | Out-Null
    }

    # 定位插件根 + 模板目录
    if (-not (find_plugin_root)) {
        age_die "无法定位 AGE 插件根(未找到 cli/age 或 cli/age.ps1)。请在插件目录内运行,或设置 AGE_PLUGIN_ROOT。" 1
    }
    $tplRoot = Join-Path $script:AGE_PLUGIN_ROOT "templates/repo"
    if (-not (Test-Path $tplRoot -PathType Container)) {
        age_warn "模板目录不存在: $tplRoot(可能其他 agent 尚未产出模板)。将生成最小骨架。"
        $tplRoot = ""
    }

    # 加载 userConfig 默认值
    $kvs = age_load_userconfig_defaults

    # 命令行参数覆盖默认值
    if ($name)     { $kvs["project_name"] = $name }
    if ($kind)     { $kvs["project_kind"] = $kind }
    if ($validate) { $kvs["validate_cmd"] = $validate }

    # 派生字段:project_slug(小写 + 空格转横线 + 仅保留字母数字横线)
    $safeName = if ($name) { $name } else { "My Project" }
    $safeName = $safeName.ToLower() -replace ' ', '-' -replace '[^a-z0-9-]', ''
    $kvs["project_slug"] = $safeName

    # 技能占位符默认 none
    foreach ($sk in @("skill_requirements", "skill_design", "skill_architecture", "skill_testing", "skill_build")) {
        $kvs[$sk] = "none"
    }
    # owner / 语言 / backlog
    $kvs["owner_name"] = if ($name) { $name } else { "" }
    $kvs["doc_language"] = "zh-CN"
    $kvs["require_backlog"] = "true"

    # project-context.md 的 Day 0 手填字段:渲染为醒目待填写标记
    $TBD = "「待填写:见下方填写指引」"
    $kvs["project_name"] = if ($name) { $name } else { "My Project" }
    $kvs["project_description"] = $TBD
    $kvs["target_users"] = $TBD
    $kvs["current_phase"] = $TBD
    $kvs["tech_stack"] = $TBD

    # ai-autonomy-policy.md
    $kvs["autonomy_scope"] = $TBD
    $kvs["needs_confirmation"] = $TBD

    # codebase-map.md:按 project_kind 给模块骨架占位
    $mod1Name = "module-1"; $mod1Path = "src/";   $mod1Role = "核心逻辑"
    $mod1Entry = "src/main"; $mod1Deps = "无"
    $mod2Name = "module-2"; $mod2Path = "src/";   $mod2Role = "辅助"
    $mod2Entry = "src/lib"; $mod2Deps = "module-1"
    switch ($kind) {
        "web" {
            $mod1Name = "frontend"; $mod1Path = "src/";      $mod1Role = "前端 UI"
            $mod1Entry = "src/main.ts"; $mod1Deps = "无"
            $mod2Name = "backend";  $mod2Path = "server/";   $mod2Role = "后端 API"
            $mod2Entry = "server/index.ts"; $mod2Deps = "frontend"
        }
        "mobile" {
            $mod1Name = "app"; $mod1Path = "app/";           $mod1Role = "移动端"
            $mod1Entry = "app/index"; $mod1Deps = "无"
            $mod2Name = "api"; $mod2Path = "api/";           $mod2Role = "后端服务"
            $mod2Entry = "api/index"; $mod2Deps = "app"
        }
        "cli" {
            $mod1Name = "core";     $mod1Path = "src/";      $mod1Role = "CLI 核心"
            $mod1Entry = "src/main"; $mod1Deps = "无"
            $mod2Name = "commands"; $mod2Path = "src/cmd/";  $mod2Role = "命令实现"
            $mod2Entry = "src/cmd"; $mod2Deps = "core"
        }
    }
    $kvs["module_1_name"] = $mod1Name; $kvs["module_1_path"] = $mod1Path
    $kvs["module_1_responsibility"] = $mod1Role; $kvs["module_1_entry"] = $mod1Entry; $kvs["module_1_deps"] = $mod1Deps
    $kvs["module_2_name"] = $mod2Name; $kvs["module_2_path"] = $mod2Path
    $kvs["module_2_responsibility"] = $mod2Role; $kvs["module_2_entry"] = $mod2Entry; $kvs["module_2_deps"] = $mod2Deps
    # 兼容旧键名
    $kvs["module_1_role"] = $mod1Role; $kvs["module_2_role"] = $mod2Role
    $kvs["dependency_rules"] = $TBD; $kvs["main_entry"] = $TBD; $kvs["test_entry"] = $TBD; $kvs["build_entry"] = $TBD

    # conventions.md 键名
    $kvs["naming_conventions"] = $TBD; $kvs["commit_conventions"] = $TBD; $kvs["branch_conventions"] = $TBD
    $kvs["testing_conventions"] = $TBD; $kvs["doc_conventions"] = $TBD
    $kvs["convention_exceptions"] = $TBD
    # 兼容旧键名
    $kvs["naming"] = $TBD; $kvs["commit"] = $TBD; $kvs["branch"] = $TBD; $kvs["testing"] = $TBD

    age_info "初始化 AGE 项目结构到: $target"

    # 1) 拷贝模板(若存在)—— 排除 .age/
    if ($tplRoot -and (Test-Path $tplRoot -PathType Container)) {
        age_info "拷贝模板 templates/repo/ → $target"
        # 递归拷贝,排除 .age/
        $items = Get-ChildItem -Path $tplRoot -Recurse -Force | Where-Object { $_.FullName -notmatch '[\\/]\.age([\\/]|$)' }
        foreach ($item in $items) {
            $rel = $item.FullName.Substring($tplRoot.Length).TrimStart('\', '/')
            $dst = Join-Path $target $rel
            if ($item.PSIsContainer) {
                if (-not (Test-Path $dst -PathType Container)) {
                    New-Item -ItemType Directory -Path $dst -Force | Out-Null
                }
            } else {
                $dstDir = Split-Path $dst -Parent
                if (-not (Test-Path $dstDir -PathType Container)) {
                    New-Item -ItemType Directory -Path $dstDir -Force | Out-Null
                }
                Copy-Item -Path $item.FullName -Destination $dst -Force
            }
        }
    }

    # 2) 确保核心目录存在
    age_init_ensure_skeleton $target

    # 3) 生成/渲染 AGENTS.md
    if (Test-Path (Join-Path $target "AGENTS.md") -PathType Leaf) {
        render_template (Join-Path $target "AGENTS.md") (Join-Path $target "AGENTS.md") $kvs
    } else {
        age_init_write_agents $target $name $kind $validate
    }

    # 4) 生成/渲染 docs/index.md
    if (Test-Path (Join-Path $target "docs/index.md") -PathType Leaf) {
        render_template (Join-Path $target "docs/index.md") (Join-Path $target "docs/index.md") $kvs
    } else {
        age_init_write_index $target $name
    }

    # 5) 渲染 docs/context/ 五件套
    age_init_render_context $target $kvs

    # 6) 渲染 START-HERE 清单(若存在)
    $startHere = Join-Path $target "START-HERE-after-copy.md"
    if (Test-Path $startHere -PathType Leaf) {
        render_template $startHere $startHere $kvs
    }

    age_success "AGE 骨架已生成。"
    age_info "  - AGENTS.md: 代理操作契约"
    age_info "  - docs/index.md: 文档路由器"
    age_info "  - docs/context/: 强制上下文五件套"

    # 7) 自动 age check 自检
    age_info "运行自检 age check..."
    $checkCode = 0
    Push-Location $target
    try {
        age_call_cli check
        $checkCode = $LASTEXITCODE
        if ($checkCode -eq $null) { $checkCode = 0 }
    } catch {
        $checkCode = 1
    } finally {
        Pop-Location
    }
    if ($checkCode -ne 0) {
        age_warn "自检发现 warning(骨架初始状态常见,补充内容后即可消除)。"
    } else {
        age_success "自检通过。"
    }

    # 8) 自动 age baseline 快照
    age_info "生成基线快照 age baseline..."
    Push-Location $target
    try {
        age_call_cli baseline
        if ($LASTEXITCODE -ne 0) { age_warn "基线生成失败(可稍后手动 age baseline)。" }
    } catch {
        age_warn "基线生成失败(可稍后手动 age baseline)。"
    } finally {
        Pop-Location
    }

    age_success "AGE 初始化完成。下一步:编辑 docs/context/project-context.md 描述你的项目。"
    return 0
}

# ---------------------------------------------------------------------------
# age_init_ensure_skeleton:确保目录结构齐全
# ---------------------------------------------------------------------------
function script:age_init_ensure_skeleton {
    param([string]$Target)
    $dirs = @(
        "docs", "docs/context", "docs/backlog", "docs/requirements",
        "docs/design", "docs/architecture", "docs/plans", "docs/audits",
        "docs/logs", "docs/bugs", "docs/testing", ".age"
    )
    foreach ($d in $dirs) {
        $p = Join-Path $Target $d
        if (-not (Test-Path $p -PathType Container)) {
            New-Item -ItemType Directory -Path $p -Force | Out-Null
        }
    }
}

# ---------------------------------------------------------------------------
# 最小 AGENTS.md 占位(模板缺失时)
# ---------------------------------------------------------------------------
function script:age_init_write_agents {
    param([string]$Target, [string]$Name = "My Project", [string]$Kind = "web", [string]$Validate = "")
    $sb = [System.Text.StringBuilder]::new()
    [void]$sb.AppendLine("# AGENTS.md — $Name 代理操作契约")
    [void]$sb.AppendLine("")
    [void]$sb.AppendLine("> 由 age init 生成。本文件是所有 AI 代理在本仓库工作的强制契约。")
    [void]$sb.AppendLine("")
    [void]$sb.AppendLine("## 项目身份")
    [void]$sb.AppendLine("- 名称: $Name")
    [void]$sb.AppendLine("- 类型: $Kind")
    if ($Validate) { [void]$sb.AppendLine("- 验证命令: ``$Validate``") }
    [void]$sb.AppendLine("")
    [void]$sb.AppendLine("## 强制上下文")
    [void]$sb.AppendLine("开工前必读 `docs/context/` 五件套;每个任务前用 `age route <task>` 确定要读的 owner 文档。")
    [void]$sb.AppendLine("")
    [void]$sb.AppendLine("## 文档路由")
    [void]$sb.AppendLine("见 `docs/index.md`。代码变更须回写到对应 owner 文档,用 `age sync` 检测漂移。")
    [void]$sb.AppendLine("")
    [void]$sb.AppendLine("## 收尾规则")
    [void]$sb.AppendLine("任务完成前 `age audit --scope closure`;提交前 `age check --strict`。")
    $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
    [System.IO.File]::WriteAllText((Join-Path $Target "AGENTS.md"), $sb.ToString(), $utf8NoBom)
}

# ---------------------------------------------------------------------------
# 最小 docs/index.md 路由器(模板缺失时)
# ---------------------------------------------------------------------------
function script:age_init_write_index {
    param([string]$Target, [string]$Name = "My Project")
    $content = @"
# 文档路由器 — $Name

> 由 age init 生成。本文件是代码模块到 owner 文档的路由表。
> 代码变更 → 用 ``age sync`` 检测对应 owner 文档是否需更新。

## 路由表

| 模块/路径 | owner 文档 | 技能 |
|---|---|---|
| src/ | docs/architecture/overview.md | age-route |
| (待补充) | (待补充) | (待补充) |

## 说明
- 每行声明一个代码区域由哪个文档负责。
- ``age route <task>`` 依据此表 + ``skills/age/references/routing-rules.md`` 决策。
- 新增模块时务必同步更新本表,否则 ``age sync`` 会报 missing。
"@
    $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
    [System.IO.File]::WriteAllText((Join-Path $Target "docs/index.md"), $content, $utf8NoBom)
}

# ---------------------------------------------------------------------------
# 渲染 docs/context/ 强制上下文
# ---------------------------------------------------------------------------
function script:age_init_render_context {
    param([string]$Target, [hashtable]$Kvs)
    $ctx = Join-Path $Target "docs/context"
    $required = @("project-context", "ai-autonomy-policy", "codebase-map", "source-of-truth-and-precedence", "conventions")
    $suggested = @("requirements", "decisions", "risks", "glossary")
    foreach ($f in ($required + $suggested)) {
        $path = Join-Path $ctx "$f.md"
        if (Test-Path $path -PathType Leaf) {
            render_template $path $path $Kvs
        } else {
            age_init_write_context_stub $path $f
        }
    }
    # 渲染 context/README.md(若已拷贝)
    $readme = Join-Path $ctx "README.md"
    if (Test-Path $readme -PathType Leaf) {
        render_template $readme $readme $Kvs
    }
}

function script:age_init_write_context_stub {
    param([string]$Path, [string]$Kind)
    $titles = @{
        "project-context"                = "项目上下文"
        "ai-autonomy-policy"             = "AI 自主权策略"
        "codebase-map"                   = "代码库地图"
        "source-of-truth-and-precedence" = "事实来源与优先级"
        "conventions"                    = "约定"
        "requirements"                   = "需求基线"
        "decisions"                      = "关键决策(ADR 索引)"
        "risks"                          = "风险登记"
        "glossary"                       = "术语表"
    }
    $title = if ($titles.ContainsKey($Kind)) { $titles[$Kind] } else { $Kind }
    $content = @"
# $title

> 由 age init 生成。此文件为 docs/context/ 上下文之一,开工前必读。
> 内容待补充(空内容会被 age check 标记)。
"@
    $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
    [System.IO.File]::WriteAllText($Path, $content, $utf8NoBom)
}

# ---------------------------------------------------------------------------
function script:age_init_help {
    @'
age init — 初始化 AGE 项目结构

用法:
  age init [--name X] [--kind web|mobile|cli] [--validate CMD] [目标目录]

参数:
  --name X        项目名称(渲染到 AGENTS.md / docs)
  --kind K        项目类型:web|mobile|cli
  --validate CMD  验证命令(如 "npm test")
  目标目录         默认当前目录

行为:
  1. 拷贝 templates/repo/ 到目标
  2. 用 userConfig 默认值 + 命令行参数渲染占位符
  3. 生成 AGENTS.md / docs/index.md / docs/context/ 五件套骨架
  4. 自动 age check 自检
  5. 自动 age baseline 快照

退出码: 0 成功 / 1 失败
'@ | Write-Host
}

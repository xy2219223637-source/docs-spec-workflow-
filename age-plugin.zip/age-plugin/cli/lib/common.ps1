# common.ps1 — AGE CLI 共享函数库 (PowerShell)
# 等价 cli/lib/common.sh,供 cli/age.ps1 dot-source。
# 仅依赖 PowerShell 内置 cmdlet + git(可选)+ python(可选)。
# Win11 原生支持(不依赖 bash),跨平台(macOS/Linux pwsh 同样可用)。

# ---------------------------------------------------------------------------
# 常量(等价 common.sh)
# ---------------------------------------------------------------------------
$script:AGE_DIR_NAME = ".age"
$script:AGE_LOG_FILE = ""        # 由 age_init_runtime 在首次日志时确定
$script:AGE_OK = 0
$script:AGE_FAIL = 1
$script:AGE_VERSION = "0.1.0"

# AGE_PLUGIN_ROOT 可由 cli/age.ps1 主入口基于自解析路径预先设置;
# 未设置时由 find_plugin_root 按需填充。
if (-not (Test-Path variable:AGE_PLUGIN_ROOT)) {
    $script:AGE_PLUGIN_ROOT = ""
}

# ---------------------------------------------------------------------------
# 颜色输出(无 tty 或 $AGE_NO_COLOR 时降级为无色)
# ---------------------------------------------------------------------------
function script:age_color_init {
    # PowerShell 用 Write-Host -ForegroundColor,无需 ANSI 码;
    # 但保留一个全局开关供 age_color 文本着色函数判断是否降级。
    if ($host.UI -and $host.UI.RawUI -and -not $env:AGE_NO_COLOR) {
        $script:AGE_USE_COLOR = $true
    } else {
        $script:AGE_USE_COLOR = $false
    }
}

# age_color <color> <text>:返回带色的字符串(用于嵌入 printf 风格输出)。
# PowerShell 里更推荐直接 Write-Host -ForegroundColor;此函数供需要字符串拼接处用。
function script:age_color {
    param([string]$Color, [string]$Text)
    if (-not $script:AGE_USE_COLOR) { return $Text }
    $map = @{
        red    = "Red"; green = "Green"; yellow = "Yellow"
        blue   = "Blue"; cyan = "Cyan"; gray = "DarkGray"; bold = "White"
    }
    $c = $map[$Color.ToLower()]
    if (-not $c) { return $Text }
    # 返回带 ANSI 码的字符串(Write-Host 之外的场景)
    $code = @{
        Red = 31; Green = 32; Yellow = 33; Blue = 34; Cyan = 36; DarkGray = 90; White = 1
    }[$c]
    return "`e[${code}m$Text`e[0m"
}

# ---------------------------------------------------------------------------
# 插件根定位与运行态初始化
# ---------------------------------------------------------------------------

# find_plugin_root:向上查找含 cli/age(或 cli/age.ps1)的目录,设置 $AGE_PLUGIN_ROOT。
# 返回 $true 找到 / $false 未找到。
function script:find_plugin_root {
    # 已缓存则直接返回
    if ($script:AGE_PLUGIN_ROOT -and (Test-Path (Join-Path $script:AGE_PLUGIN_ROOT "cli/age") -PathType Leaf)) {
        return $true
    }
    if ($script:AGE_PLUGIN_ROOT -and (Test-Path (Join-Path $script:AGE_PLUGIN_ROOT "cli/age.ps1") -PathType Leaf)) {
        return $true
    }
    $dir = (Get-Location).Path
    while ($dir) {
        if ((Test-Path (Join-Path $dir "cli/age") -PathType Leaf) -or
            (Test-Path (Join-Path $dir "cli/age.ps1") -PathType Leaf)) {
            $script:AGE_PLUGIN_ROOT = $dir
            return $true
        }
        $parent = (Split-Path $dir -Parent)
        if (-not $parent -or $parent -eq $dir) { break }
        $dir = $parent
    }
    return $false
}

# age_runtime_dir:返回当前项目(=cwd)的 .age 目录路径。
function script:age_runtime_dir {
    return (Join-Path (Get-Location).Path $script:AGE_DIR_NAME)
}

# age_init_runtime:确保 .age 目录存在,设置日志路径。幂等。
function script:age_init_runtime {
    $rt = age_runtime_dir
    if (-not (Test-Path $rt -PathType Container)) {
        New-Item -ItemType Directory -Path $rt -Force | Out-Null
    }
    $script:AGE_LOG_FILE = Join-Path $rt "age.log"
}

# ---------------------------------------------------------------------------
# 日志(追加写 .age/age.log,带时间戳与级别)
# ---------------------------------------------------------------------------
function script:age_log {
    param([string]$Level, [string]$Message)
    age_init_runtime
    $ts = (Get-Date -Format "yyyy-MM-ddTHH:mm:sszzz")
    try {
        Add-Content -Path $script:AGE_LOG_FILE -Value "$ts [$Level] $Message" -Encoding UTF8
    } catch {
        # 日志写入失败不阻断主流程
    }
}

# ---------------------------------------------------------------------------
# 用户面输出(区分 info/warn/error/success)
# PowerShell 用 Write-Host -ForegroundColor;info/success 走 stdout(Information 流),
# warn/error 走 stderr。
# ---------------------------------------------------------------------------
function script:age_info {
    param([string]$Message)
    Write-Host "ℹ $Message" -ForegroundColor Cyan
    age_log INFO $Message
}
function script:age_success {
    param([string]$Message)
    Write-Host "✓ $Message" -ForegroundColor Green
    age_log INFO $Message
}
function script:age_warn {
    param([string]$Message)
    Write-Host "⚠ $Message" -ForegroundColor Yellow
    age_log WARN $Message
}
function script:age_error {
    param([string]$Message)
    # stderr:Write-Host 无法直接写 stderr,用 [Console]::Error.WriteLine
    [Console]::Error.WriteLine("✗ $Message")
    age_log ERROR $Message
}

# age_die <msg> [exit_code]:打印错误并以码退出(默认1)
function script:age_die {
    param([string]$Message, [int]$Code = $script:AGE_FAIL)
    age_error $Message
    exit $Code
}

# ---------------------------------------------------------------------------
# git 可用性(优雅降级)
# ---------------------------------------------------------------------------
# age_git_ok:git 可用且当前在仓库内 → $true;否则 $false(不报错,仅判断)
function script:age_git_ok {
    $g = Get-Command git -ErrorAction SilentlyContinue
    if (-not $g) { return $false }
    $r = & git rev-parse --git-dir 2>$null
    return ($LASTEXITCODE -eq 0)
}

# age_git_root:输出 git 仓库根目录;无 git 时输出空串。
function script:age_git_root {
    if (-not (age_git_ok)) { return "" }
    $root = & git rev-parse --show-toplevel 2>$null
    if ($LASTEXITCODE -eq 0) { return $root.Trim() }
    return ""
}

# ---------------------------------------------------------------------------
# AGE 仓库判定
# ---------------------------------------------------------------------------
# is_age_repo:存在 docs/index.md(AGE 路由器)或 AGENTS.md 视为已初始化。
function script:is_age_repo {
    param([string]$Root = (Get-Location).Path)
    if (Test-Path (Join-Path $Root "docs/index.md") -PathType Leaf) { return $true }
    if (Test-Path (Join-Path $Root "AGENTS.md") -PathType Leaf) { return $true }
    return $false
}

# ---------------------------------------------------------------------------
# 宿主客户端检测(多客户端兼容,CONTRACT §8.11 + §8.12 Win11)
# ---------------------------------------------------------------------------
# detect_host:检测当前宿主客户端环境,输出
#   zcode|claude|codex|opencode|multica|win11|unknown
#
# Win11 检测(§8.12):Win11 原生 PowerShell 运行时,$OS / uname 含
#   Windows/MINGW/MSYS → win11(bash on Win 也归此类,因 AGE 在 Win11 上走 PS1 入口)。
#   优先级:ZCode → Claude → Codex → OpenCode → Multica → Win11 → unknown。
function script:detect_host {
    # === 第一优先级:环境变量(多客户端共存时据此判定运行中的客户端)===
    if ($env:ZCODE_PLUGIN_ROOT -and (Test-Path $env:ZCODE_PLUGIN_ROOT -PathType Container)) { return "zcode" }
    if ($env:ZCODE_PROJECT_DIR -and (Test-Path $env:ZCODE_PROJECT_DIR -PathType Container)) { return "zcode" }
    if ($env:CLAUDE_PLUGIN_ROOT -and (Test-Path $env:CLAUDE_PLUGIN_ROOT -PathType Container)) { return "claude" }
    if ($env:CLAUDE_PROJECT_DIR -and (Test-Path $env:CLAUDE_PROJECT_DIR -PathType Container)) { return "claude" }
    if ($env:CODEX_HOME -and (Test-Path $env:CODEX_HOME -PathType Container)) { return "codex" }
    if ($env:OPENCODE_CONFIG) { return "opencode" }
    if ($env:AGE_MULTICA_WORKSPACE) { return "multica" }

    # === 第二优先级:配置文件/目录特征 ===
    if (Test-Path (Join-Path (Get-Location).Path ".zcode") -PathType Container) { return "zcode" }
    if (Test-Path (Join-Path $HOME ".zcode") -PathType Container) { return "zcode" }
    if (Test-Path (Join-Path (Get-Location).Path ".claude") -PathType Container) { return "claude" }
    if (Test-Path (Join-Path $HOME ".claude") -PathType Container) { return "claude" }

    $codexHome = if ($env:CODEX_HOME) { $env:CODEX_HOME } else { Join-Path $HOME ".codex" }
    if (Test-Path $codexHome -PathType Container) { return "codex" }

    if (Test-Path (Join-Path (Get-Location).Path "opencode.json") -PathType Leaf) { return "opencode" }
    if (Test-Path (Join-Path $HOME ".config/opencode") -PathType Container) { return "opencode" }

    # Multica(§8.11 恢复)
    if (Get-Command multica -ErrorAction SilentlyContinue) {
        if (Test-Path (Join-Path $HOME ".multica/config.json") -PathType Leaf) { return "multica" }
    }
    if ($IsWindows -or $env:OS -eq "Windows_NT") {
        if ((Test-Path "/Applications/Multica.app" -PathType Container) -and
            (Test-Path (Join-Path $HOME ".multica/config.json") -PathType Leaf)) { return "multica" }
    }
    if (Test-Path (Join-Path $HOME ".multica/config.json") -PathType Leaf) { return "multica" }

    # === Win11 检测(§8.12)===
    # PowerShell 原生运行 + Windows 环境标志 → win11(bash on Win / Git-Bash / WSL 不在此分支,
    # 因 WSL/Git-Bash 下走 bash CLI;此分支仅 PowerShell on Windows 命中)。
    if ($IsWindows) { return "win11" }
    # 兼容 Windows PowerShell 5.1(无 $IsWindows 自动变量):用 $env:OS
    if ($env:OS -eq "Windows_NT") { return "win11" }
    # uname 检测(Git-Bash/MSYS 下 PowerShell 罕见,但兜底)
    $uname = Get-Command uname -ErrorAction SilentlyContinue
    if ($uname) {
        $u = & uname 2>$null
        if ($u -match "MINGW|MSYS|CYGWIN|Windows") { return "win11" }
    }

    return "unknown"
}

# ---------------------------------------------------------------------------
# JSON 工具:PowerShell 用 ConvertTo-Json/ConvertFrom-Json(内置,无 jq 依赖)。
# ---------------------------------------------------------------------------

# age_json_escape <string>:返回 JSON 字符串安全的字面值(不含外层引号)。
# PowerShell 里通常直接用 ConvertTo-Json;此函数供手拼 JSON 时用。
function script:age_json_escape {
    param([string]$Str)
    $s = $Str -replace '\\', '\\' -replace '"', '\"' -replace "`t", '\t'
    $s = $s -replace "`r", '\r' -replace "`n", '\n'
    return $s
}

# ---------------------------------------------------------------------------
# 模板渲染:render_template <template_file> <output_file> <kvs hashtable>
# 替换 {{key}} → val。支持 {{ key }} / {{key}} 两种写法(去空格)。
# PowerShell 用 -replace(正则)实现;键名归一化:点号→下划线。
# ---------------------------------------------------------------------------
function script:render_template {
    param(
        [Parameter(Mandatory)][string]$TemplateFile,
        [Parameter(Mandatory)][string]$OutputFile,
        [hashtable]$Kvs
    )
    if (-not (Test-Path $TemplateFile -PathType Leaf)) {
        age_die "模板不存在: $TemplateFile" 1
    }
    $content = Get-Content -Path $TemplateFile -Raw -Encoding UTF8

    if ($Kvs) {
        foreach ($key in $Kvs.Keys) {
            $val = [string]$Kvs[$key]
            # 键名归一化:去空格,点号→下划线
            $normKey = $key.Trim() -replace '\.', '_'
            # 构造正则:匹配 {{ key }} 或 {{key}},允许键名前后空格
            $pattern = '\{\{\s*' + [regex]::Escape($normKey) + '\s*\}\}'
            # -replace 用替换串;val 中的 $ 需转义($ 在替换串是特殊字符)
            $safeVal = $val -replace '\$', '$$$$'
            $content = [regex]::Replace($content, $pattern, $safeVal)
        }
    }

    # 确保输出目录存在
    $outDir = Split-Path $OutputFile -Parent
    if ($outDir -and -not (Test-Path $outDir -PathType Container)) {
        New-Item -ItemType Directory -Path $outDir -Force | Out-Null
    }
    # 写入(UTF8 不带 BOM,避免 markdown 工具误读)
    # 用全路径(Resolve-Path 对已存在父目录可靠;回退用 Unresolved)避免硬编码路径分隔符
    $fullOut = $OutputFile
    try {
        $fullOut = (Resolve-Path -LiteralPath $OutputFile).Path
    } catch {
        # 文件可能尚不存在(Resolve-Path 对不存在文件报错);改解析父目录再拼接
        $parentFull = (Get-Item -LiteralPath $outDir).FullName
        $fullOut = Join-Path $parentFull (Split-Path $OutputFile -Leaf)
    }
    $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
    [System.IO.File]::WriteAllText($fullOut, $content, $utf8NoBom)
}

# ---------------------------------------------------------------------------
# docs/index.md 路由表解析
# ---------------------------------------------------------------------------
# age_index_path:输出 docs/index.md 路径(项目根下);不存在输出空。
function script:age_index_path {
    param([string]$Root = (Get-Location).Path)
    $p = Join-Path $Root "docs/index.md"
    if (Test-Path $p -PathType Leaf) { return $p }
    return ""
}

# age_parse_index_routes <index.md>:解析路由表,返回数组对象列表
#   每项:@{ intent=<string>; reads=<string>; writeback=<string> }
# 支持两种格式:
#   (A) 意图式(优先):| 你要做的事 | READ 集 | WRITEBACK 集 |
#   (B) 模块式(兼容):| 模块/路径 | owner 文档 | 技能 |
# 章节感知:仅解析"路由表"章节(到下一个 ## 标题止)。
function script:age_parse_index_routes {
    param([Parameter(Mandatory)][string]$Index)
    if (-not (Test-Path $Index -PathType Leaf)) { return @() }
    $lines = Get-Content -Path $Index -Encoding UTF8
    $result = [System.Collections.Generic.List[hashtable]]::new()
    $inRoute = $false
    foreach ($line in $lines) {
        # 进入路由表章节:标题含"路由表"但不含"技能"
        if ($line -match '^##[^#].*路由表' -and $line -notmatch '技能') {
            $inRoute = $true; continue
        }
        # 遇到任意 ## 标题则退出
        if ($inRoute -and ($line -match '^##[^#]')) { $inRoute = $false; continue }
        if ($inRoute -and ($line -match '^\s*\|')) {
            $trimmed = $line.Trim()
            if ($trimmed -eq "") { continue }
            if ($trimmed -match '^\|[-: |]+\]+$') { continue }
            $cols = $trimmed.TrimStart('|').Split('|')
            # 末列因末尾 | 会产生空尾元素,取前3列
            $intent = if ($cols.Length -ge 1) { $cols[0].Trim() } else { "" }
            $reads = if ($cols.Length -ge 2) { $cols[1].Trim() } else { "" }
            $wb = if ($cols.Length -ge 3) { $cols[2].Trim() } else { "" }
            if ($intent -eq "" -and $reads -eq "") { continue }
            # 表头识别:仅匹配确切表头标记
            if ($intent -match '^你要做的事$') { continue }
            if ($reads -match '^(先读|READ 集)') { continue }
            $result.Add(@{ intent = $intent; reads = $reads; writeback = $wb })
        }
    }
    return ,$result
}

# age_parse_index_skills <index.md>:解析技能路由表,返回数组 @{ ttype=<string>; skill=<string> }
function script:age_parse_index_skills {
    param([Parameter(Mandatory)][string]$Index)
    if (-not (Test-Path $Index -PathType Leaf)) { return @() }
    $lines = Get-Content -Path $Index -Encoding UTF8
    $result = [System.Collections.Generic.List[hashtable]]::new()
    $inSkill = $false
    foreach ($line in $lines) {
        if ($line -match '^##[^#].*技能路由') { $inSkill = $true; continue }
        if ($inSkill -and ($line -match '^##[^#]')) { $inSkill = $false; continue }
        if ($inSkill -and ($line -match '^\s*\|')) {
            $trimmed = $line.Trim()
            if ($trimmed -match '^\|[-: |]+\]+$') { continue }
            $cols = $trimmed.TrimStart('|').Split('|')
            $ttype = if ($cols.Length -ge 1) { $cols[0].Trim() } else { "" }
            $skill = if ($cols.Length -ge 2) { $cols[1].Trim() } else { "" }
            if ($ttype -eq "" -and $skill -eq "") { continue }
            if ($ttype -match '任务类型|task') { continue }
            $result.Add(@{ ttype = $ttype; skill = $skill })
        }
    }
    return ,$result
}

# ---------------------------------------------------------------------------
# 调用核心函数(subprocess 自身复用):统一入口
# age_call_cli <subcommand> [args...]:以子进程调用 cli/age(优先 .ps1),返回其退出码。
# Win11 上优先调 age.ps1;若 bash 可用且 age.ps1 不可用,回退 bash age。
# ---------------------------------------------------------------------------
function script:age_call_cli {
    param([Parameter(ValueFromRemainingArguments)][string[]]$Args)
    if (-not (find_plugin_root)) { return 1 }
    $root = $script:AGE_PLUGIN_ROOT
    if (-not $root) { return 1 }
    # 优先 PowerShell 入口(同进程函数调用更高效,但为保持与 bash age_call_cli
    # 一致的子进程语义 + 避免变量污染,这里用子进程)。
    $ps1 = Join-Path $root "cli/age.ps1"
    if (Test-Path $ps1 -PathType Leaf) {
        # 选 PowerShell 可执行文件:pwsh(7)优先,powershell(5.1)回退
        $psExe = $null
        foreach ($cand in @("pwsh", "powershell")) {
            $psExe = Get-Command $cand -ErrorAction SilentlyContinue
            if ($psExe) { break }
        }
        if ($psExe) {
            & $psExe.Name -NoProfile -File $ps1 @Args
            $code = $LASTEXITCODE
            if ($code -eq $null) { $code = 0 }
            return $code
        }
        # 无 PowerShell 可用:回退 bash(若可用)
        $bashAge = Join-Path $root "cli/age"
        $bashExe = Get-Command bash -ErrorAction SilentlyContinue
        if ($bashExe -and (Test-Path $bashAge -PathType Leaf)) {
            & bash $bashAge @Args
            return $LASTEXITCODE
        }
        return 1
    }
    # 回退 bash 入口
    $bashAge = Join-Path $root "cli/age"
    if (Test-Path $bashAge -PathType Leaf) {
        $bashExe = Get-Command bash -ErrorAction SilentlyContinue
        if ($bashExe) {
            & bash $bashAge @Args
            return $LASTEXITCODE
        }
    }
    return 1
}

# ---------------------------------------------------------------------------
# Python 检测(Win11 上 python 而非 python3,§8.12)
# ---------------------------------------------------------------------------
# age_find_python:返回可用的 python 可执行名;无则空串。
# 检测顺序:python → python3 → py -3
function script:age_find_python {
    foreach ($exe in @("python", "python3")) {
        if (Get-Command $exe -ErrorAction SilentlyContinue) { return $exe }
    }
    $py = Get-Command py -ErrorAction SilentlyContinue
    if ($py) {
        # 验证 py -3 可用
        & py -3 --version 2>$null | Out-Null
        if ($LASTEXITCODE -eq 0) { return "py -3" }
    }
    return ""
}

# ---------------------------------------------------------------------------
# 参数解析辅助
# ---------------------------------------------------------------------------
# age_has_flag <flag> <args[]>:参数列表中是否含某 flag。
function script:age_has_flag {
    param([string]$Flag, [string[]]$Args)
    foreach ($a in $Args) { if ($a -eq $Flag) { return $true } }
    return $false
}

# age_get_opt <flag> <default> <args[]>:取 --flag value 形式参数值。
function script:age_get_opt {
    param([string]$Flag, [string]$Default, [string[]]$Args)
    for ($i = 0; $i -lt $Args.Length; $i++) {
        if ($Args[$i] -eq $Flag -and ($i + 1) -lt $Args.Length) {
            return $Args[$i + 1]
        }
    }
    return $Default
}

# age_get_opt_eq <flag> <args[]>:取 --flag=value 形式;返回值或 $null。
function script:age_get_opt_eq {
    param([string]$Flag, [string[]]$Args)
    $prefix = $Flag + "="
    foreach ($a in $Args) {
        if ($a.StartsWith($prefix)) { return $a.Substring($prefix.Length) }
    }
    return $null
}

# ---------------------------------------------------------------------------
# age_looks_like_codepath <s>:是否像代码路径(含 / 或带扩展名,或字母开头的目录路径)
# ---------------------------------------------------------------------------
function script:age_looks_like_codepath {
    param([string]$s)
    if (-not $s) { return $false }
    # 含文件扩展名
    if ($s -match '\.(ts|js|py|go|rs|java|c|cpp|h|sh|md)$') { return $true }
    # 含 / 或 \ 且首段像目录名(字母开头)
    if ($s -match '^[a-zA-Z][a-zA-Z0-9_-]*[/\\]') { return $true }
    return $false
}

# ---------------------------------------------------------------------------
# 在 source 时执行一次性初始化
# ---------------------------------------------------------------------------
age_color_init

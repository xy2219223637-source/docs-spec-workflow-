# audit.sh — age audit 实现
# full=全量文档代码一致性;plan=计划审计(实现前);closure=收尾审计(完成前)。
# 输出违规列表,可调 doc-auditor 子代理。退出码:0 通过 / 1 违规。

AGE_AUDIT_VIOLATIONS=0

age_audit() {
  age_init_runtime
  AGE_AUDIT_VIOLATIONS=0

  local scope="full"
  while [ $# -gt 0 ]; do
    case "$1" in
      --scope) scope="$2"; shift 2;;
      --scope=*) scope="${1#*=}"; shift;;
      -h|--help) age_audit_help; return 0;;
      *) age_warn "未知参数: $1"; shift;;
    esac
  done

  case "$scope" in
    full|plan|closure) ;;
    *) age_die "无效 --scope: $scope (允许: full|plan|closure)" 1;;
  esac

  local root; root="$(pwd)"
  find_plugin_root 2>/dev/null || true

  echo "$(age_color bold "AGE 审计 (scope=$scope)")"

  case "$scope" in
    full)     age_audit_full "$root";;
    plan)     age_audit_plan "$root";;
    closure)  age_audit_closure "$root";;
  esac

  echo
  if [ "$AGE_AUDIT_VIOLATIONS" -gt 0 ]; then
    printf '  %s  发现 %s 处违规\n' "$(age_color red '结果')" "$AGE_AUDIT_VIOLATIONS"
    echo "  建议: 调用 doc-auditor 子代理修复,或手动对照 owner 文档更新。"
    return 1
  else
    printf '  %s  审计通过,无违规\n' "$(age_color green '结果')"
    return 0
  fi
}

age_audit_violation() {
  AGE_AUDIT_VIOLATIONS=$((AGE_AUDIT_VIOLATIONS + 1))
  age_error "违规: $*"
}
age_audit_note() { age_warn "注意: $*"; }
age_audit_pass() { age_info "通过: $*"; }

# ---------------------------------------------------------------------------
# full:全量文档代码一致性
# 综合 check + sync + 各文档目录非空检查
# ---------------------------------------------------------------------------
age_audit_full() {
  local root="$1"
  age_info "[1/3] 静态一致性 (age check)..."
  age_call_cli check --strict >/tmp/age_audit_check.$$ 2>&1 || {
    age_audit_note "age check 报告问题(见下)"
    cat /tmp/age_audit_check.$$ | sed 's/^/    /'
    AGE_AUDIT_VIOLATIONS=$((AGE_AUDIT_VIOLATIONS + 1))
  }
  rm -f /tmp/age_audit_check.$$

  age_info "[2/3] 代码-文档漂移 (age sync)..."
  age_call_cli sync --json >/tmp/age_audit_sync.$$ 2>&1 || {
    local sync_code=$?
    # sync 退出码1=有漂移
    if grep -q '"stale":\[\]' /tmp/age_audit_sync.$$ 2>/dev/null && \
       grep -q '"orphan":\[\]' /tmp/age_audit_sync.$$ 2>/dev/null && \
       grep -q '"missing":\[\]' /tmp/age_audit_sync.$$ 2>/dev/null; then
      :
    else
      age_audit_violation "存在代码-文档漂移(age sync)"
      cat /tmp/age_audit_sync.$$ | sed 's/^/    /'
    fi
  }
  rm -f /tmp/age_audit_sync.$$

  age_info "[3/3] 文档目录完整性..."
  age_audit_doc_dirs "$root"
}

# ---------------------------------------------------------------------------
# plan:计划审计(实现前)
# 审查 docs/plans/ 下计划是否含:技能选择记录、收尾规则、验证标准
# ---------------------------------------------------------------------------
age_audit_plan() {
  local root="$1"
  local plans_dir="$root/docs/plans"
  if [ ! -d "$plans_dir" ]; then
    age_audit_note "docs/plans/ 不存在,无计划可审"
    return
  fi
  local plan found=0
  # 找最近的 .md 计划文件(排除 README)
  for plan in "$plans_dir"/*.md; do
    [ -f "$plan" ] || continue
    [ "$(basename "$plan")" = "README.md" ] && continue
    found=1
    age_info "审查计划: $(basename "$plan")"
    local content; content=$(cat "$plan" 2>/dev/null)
    # 技能选择记录
    if echo "$content" | grep -qiE '技能|skill|age-route|age-route'; then
      age_audit_pass "含技能选择记录"
    else
      age_audit_violation "$plan: 缺技能选择记录"
    fi
    # 收尾规则
    if echo "$content" | grep -qiE '收尾|closure|audit|验证|verify'; then
      age_audit_pass "含收尾/验证规则"
    else
      age_audit_violation "$plan: 缺收尾规则"
    fi
    # 验证标准
    if echo "$content" | grep -qiE '验收|标准|criteria|acceptance|测试|test'; then
      age_audit_pass "含验证标准"
    else
      age_audit_violation "$plan: 缺验证标准"
    fi
    break   # 审最近一份
  done
  [ "$found" = "0" ] && age_audit_note "docs/plans/ 无计划文件"
}

# ---------------------------------------------------------------------------
# closure:收尾审计(完成前)
# 检查:sync 无漂移 + context 五件套已更新 + logs 有记录
# ---------------------------------------------------------------------------
age_audit_closure() {
  local root="$1"
  age_info "[1/3] 代码-文档漂移..."
  age_call_cli sync --json >/tmp/age_audit_csync.$$ 2>&1
  local sync_code=$?
  if [ "$sync_code" -ne 0 ]; then
    age_audit_violation "收尾前存在漂移,需先 sync 修复"
    cat /tmp/age_audit_csync.$$ | sed 's/^/    /'
  else
    age_audit_pass "无漂移"
  fi
  rm -f /tmp/age_audit_csync.$$

  age_info "[2/3] docs/context/ 强制上下文非空..."
  local ctx="$root/docs/context"
  # 强制五件套(与 AGENTS.md 声明一致)
  local -a quintet=("project-context" "ai-autonomy-policy" "codebase-map" "source-of-truth-and-precedence" "conventions")
  local f empty=0
  for f in "${quintet[@]}"; do
    local p="$ctx/$f.md"
    if [ ! -f "$p" ]; then
      age_audit_violation "缺失 $f.md"
      empty=1; continue
    fi
    local body
    body=$(sed -e 's/^#.*//' -e 's/^>.*//' -e 's/^[[:space:]]*$//' "$p" 2>/dev/null)
    if [ -z "$body" ]; then
      age_audit_violation "$f.md 内容为空"
      empty=1
    fi
  done
  [ "$empty" = "0" ] && age_audit_pass "五件套齐全非空"

  age_info "[3/3] docs/logs/ 有收尾记录..."
  local logs_dir="$root/docs/logs"
  if [ -d "$logs_dir" ]; then
    local nlogs
    nlogs=$(find "$logs_dir" -name '*.md' ! -name 'README.md' 2>/dev/null | wc -l | tr -d ' ')
    if [ "$nlogs" -gt 0 ]; then
      age_audit_pass "logs 有 $nlogs 份记录"
    else
      age_audit_note "docs/logs/ 无记录(建议补充任务日志)"
    fi
  else
    age_audit_note "docs/logs/ 不存在"
  fi
}

# ---------------------------------------------------------------------------
# 文档目录完整性检查
# ---------------------------------------------------------------------------
age_audit_doc_dirs() {
  local root="$1"
  local -a expected=("backlog" "requirements" "design" "architecture" "plans" "audits" "logs" "bugs" "testing" "context")
  local d
  for d in "${expected[@]}"; do
    local p="$root/docs/$d"
    if [ ! -d "$p" ]; then
      age_audit_violation "docs/$d/ 目录缺失"
    fi
  done
}

age_audit_help() {
  cat <<'EOF'
age audit — 文档与代码一致性审计

用法:
  age audit [--scope full|plan|closure]

scope:
  full     全量一致性(check + sync + 目录完整性)
  plan     计划审计(实现前):技能记录/收尾规则/验证标准
  closure  收尾审计(完成前):无漂移/五件套非空/logs记录

退出码: 0 通过 / 1 违规
EOF
}

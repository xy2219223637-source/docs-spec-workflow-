# init.sh — age init 实现
# 拷贝 templates/repo/ → 目标,渲染占位符,生成骨架,完成后自动 check + baseline。
# 用法:age init [--name X] [--kind web|mobile|cli] [--validate CMD] [目标目录]

# ---------------------------------------------------------------------------
# 读取 userConfig-schema.json 默认值(纯文本解析,避免 jq 依赖)
# 输出 key=value 行到 stdout,供 init 渲染使用。
# schema 不存在时返回内置默认值。
# ---------------------------------------------------------------------------
age_load_userconfig_defaults() {
  local schema
  find_plugin_root 2>/dev/null || true
  schema="${AGE_PLUGIN_ROOT:-$(pwd)}/.zcode-plugin/userConfig-schema.json"

  # 内置兜底默认值(schema 缺失或字段未声明 default 时用)
  cat <<EOF
project_name=My Project
project_kind=web
doc_language=zh
require_backlog=true
validate_cmd=
owner_name=
EOF

  if [ -f "$schema" ]; then
    # 解析 JSON schema:跟踪当前 property 名,遇其 "default" 输出 key=value
    # schema 结构: "properties": { "owner_name": { "default": "...", ... }, ... }
    # boolean default 为 true/false(无引号),字符串 default 带引号
    # 用可移植 awk(BSD/GNU 通用),不依赖 gawk 的 match(s, re, arr)
    awk '
      BEGIN { in_props=0; curkey="" }
      /"properties"[[:space:]]*:/ { in_props=1 }
      in_props && /^}/ { in_props=0 }
      # 捕获 property 名:找 "xxx": { 模式
      in_props && match($0, /"[a-zA-Z_][a-zA-Z0-9_]*"[[:space:]]*:[[:space:]]*\{/) {
        s=substr($0, RSTART, RLENGTH)
        sub(/^"/, "", s)
        sub(/"[[:space:]]*:[[:space:]]*\{.*/, "", s)
        curkey=s
      }
      # 捕获 default 值(字符串或布尔/数字)
      in_props && curkey != "" && /"default"[[:space:]]*:/ {
        line=$0
        sub(/.*"default"[[:space:]]*:[[:space:]]*/, "", line)
        if (substr(line,1,1) == "\"") {
          sub(/^"/, "", line)
          sub(/".*/, "", line)
          printf "%s=%s\n", curkey, line
        } else {
          sub(/[,}].*/, "", line)
          gsub(/[[:space:]]/, "", line)
          printf "%s=%s\n", curkey, line
        }
      }
    ' "$schema" 2>/dev/null
  fi
}

# ---------------------------------------------------------------------------
# age_init:主入口
# ---------------------------------------------------------------------------
age_init() {
  age_init_runtime

  local name="" kind="" validate="" target="."
  # 解析参数
  while [ $# -gt 0 ]; do
    case "$1" in
      --name) name="$2"; shift 2;;
      --name=*) name="${1#*=}"; shift;;
      --kind) kind="$2"; shift 2;;
      --kind=*) kind="${1#*=}"; shift;;
      --validate) validate="$2"; shift 2;;
      --validate=*) validate="${1#*=}"; shift;;
      -h|--help) age_init_help; return 0;;
      *) target="$1"; shift;;
    esac
  done

  # 校验 kind
  case "$kind" in
    web|mobile|cli|"") ;;
    *) age_die "无效 --kind: $kind (允许: web|mobile|cli)" 1;;
  esac

  # 目标目录处理
  target="$(cd "$target" 2>/dev/null && pwd)" || target="$(pwd)/$target"
  [ -d "$target" ] || mkdir -p "$target" || age_die "无法创建目标目录: $target" 1

  # 定位插件根 + 模板目录
  find_plugin_root 2>/dev/null || age_die "无法定位 AGE 插件根(未找到 cli/age)。请在插件目录内运行,或设置 AGE_PLUGIN_ROOT。" 1
  local tpl_root="$AGE_PLUGIN_ROOT/templates/repo"
  if [ ! -d "$tpl_root" ]; then
    age_warn "模板目录不存在: $tpl_root(可能其他 agent 尚未产出模板)。将生成最小骨架。"
    tpl_root=""
  fi

  # 加载 userConfig 默认值
  local -a kvs=()
  local kv
  while IFS= read -r kv; do
    [ -n "$kv" ] && kvs+=("$kv")
  done < <(age_load_userconfig_defaults)

  # 命令行参数覆盖默认值
  [ -n "$name" ]     && kvs+=("project_name=$name")
  [ -n "$kind" ]     && kvs+=("project_kind=$kind")
  [ -n "$validate" ] && kvs+=("validate_cmd=$validate")
  # 派生字段
  local safe_name="${name:-My Project}"
  safe_name="$(echo "$safe_name" | tr '[:upper:]' '[:lower:]' | tr ' ' '-' | tr -cd '[:alnum:]-')"
  kvs+=("project_slug=$safe_name")
  # 技能占位符默认 none(项目未接入专属技能);可由 userConfig 覆盖
  local sk
  for sk in skill_requirements skill_design skill_architecture skill_testing skill_build; do
    kvs+=("$sk=none")
  done
  # owner 占位符(AGENTS.md 模板用)
  kvs+=("owner_name=$name")
  kvs+=("doc_language=zh-CN")
  kvs+=("require_backlog=true")

  # project-context.md 的 Day 0 手填字段:渲染为醒目的待填写标记。
  # 这些字段不由 --name/--kind 推导,需用户在 Day 0 填入真实内容。
  # 用 「待填写」 标记,age check 会把它当作"未填写"警告(非空但可识别)。
  local TBD="「待填写:见下方填写指引」"
  kvs+=("project_name=${name:-My Project}")
  kvs+=("project_description=$TBD")
  kvs+=("target_users=$TBD")
  kvs+=("current_phase=$TBD")
  kvs+=("tech_stack=$TBD")

  # ai-autonomy-policy.md
  kvs+=("autonomy_scope=$TBD")
  kvs+=("needs_confirmation=$TBD")

  # codebase-map.md:按 project_kind 给模块骨架占位。
  # 注意:键名必须与模板占位符一致(见 templates/repo/docs/context/codebase-map.md):
  #   {{module_1_path}} {{module_1_responsibility}} {{module_1_entry}} {{module_1_deps}}
  #   {{module_2_path}} {{module_2_responsibility}} {{module_2_entry}} {{module_2_deps}}
  local mod1_name="module-1" mod1_path="src/" mod1_role="核心逻辑"
  local mod1_entry="src/main" mod1_deps="无"
  local mod2_name="module-2" mod2_path="src/" mod2_role="辅助"
  local mod2_entry="src/lib" mod2_deps="module-1"
  case "$kind" in
    web)
      mod1_name="frontend"; mod1_path="src/";    mod1_role="前端 UI"
      mod1_entry="src/main.ts"; mod1_deps="无"
      mod2_name="backend";  mod2_path="server/";  mod2_role="后端 API"
      mod2_entry="server/index.ts"; mod2_deps="frontend"
      ;;
    mobile)
      mod1_name="app";      mod1_path="app/";     mod1_role="移动端"
      mod1_entry="app/index"; mod1_deps="无"
      mod2_name="api";      mod2_path="api/";     mod2_role="后端服务"
      mod2_entry="api/index"; mod2_deps="app"
      ;;
    cli)
      mod1_name="core";     mod1_path="src/";     mod1_role="CLI 核心"
      mod1_entry="src/main"; mod1_deps="无"
      mod2_name="commands"; mod2_path="src/cmd/"; mod2_role="命令实现"
      mod2_entry="src/cmd"; mod2_deps="core"
      ;;
  esac
  # 模块地图键名与模板占位符严格对齐
  kvs+=("module_1_name=$mod1_name" "module_1_path=$mod1_path")
  kvs+=("module_1_responsibility=$mod1_role" "module_1_entry=$mod1_entry" "module_1_deps=$mod1_deps")
  kvs+=("module_2_name=$mod2_name" "module_2_path=$mod2_path")
  kvs+=("module_2_responsibility=$mod2_role" "module_2_entry=$mod2_entry" "module_2_deps=$mod2_deps")
  # 兼容旧键名(module_1_role 等),防其他模板/脚本引用
  kvs+=("module_1_role=$mod1_role" "module_2_role=$mod2_role")
  kvs+=("dependency_rules=$TBD" "main_entry=$TBD" "test_entry=$TBD" "build_entry=$TBD")

  # conventions.md:键名必须与模板占位符一致
  # {{naming_conventions}} {{commit_conventions}} {{branch_conventions}}
  # {{testing_conventions}} {{doc_conventions}} {{convention_exceptions}}
  kvs+=("naming_conventions=$TBD" "commit_conventions=$TBD" "branch_conventions=$TBD")
  kvs+=("testing_conventions=$TBD" "doc_conventions=$TBD")
  kvs+=("convention_exceptions=$TBD")
  # 兼容旧键名
  kvs+=("naming=$TBD" "commit=$TBD" "branch=$TBD" "testing=$TBD")

  age_info "初始化 AGE 项目结构到: $target"

  # 1) 拷贝模板(若存在)
  local ctx_dir="$target/docs/context"
  if [ -n "$tpl_root" ] && [ -d "$tpl_root" ]; then
    age_info "拷贝模板 templates/repo/ → $target"
    # 用 cp -R 递归拷贝;目标已存在目录则合并。
    # 排除 .age/:模板里的 .age/age.log 是开发期残留,不应带进新项目;
    # 新项目的 .age/ 由 age_init_runtime 按需创建,日志从零开始。
    local cp_tmp_list; cp_tmp_list="$(mktemp)"
    ( cd "$tpl_root" && find . -mindepth 1 -not -path './.age/*' -not -name '.age' -print ) > "$cp_tmp_list" 2>/dev/null
    while IFS= read -r ent; do
      [ -z "$ent" ] && continue
      # ent 形如 ./docs/...;去掉前导 ./
      local rel="${ent#./}"
      local src="$tpl_root/$rel" dst="$target/$rel"
      if [ -d "$src" ]; then
        mkdir -p "$dst"
      elif [ -f "$src" ]; then
        mkdir -p "$(dirname "$dst")"
        cp -p "$src" "$dst" 2>/dev/null
      fi
    done < "$cp_tmp_list"
    rm -f "$cp_tmp_list"
  fi

  # 2) 确保核心目录存在(docs/context 五件套 + 各文档目录)
  age_init_ensure_skeleton "$target"

  # 3) 生成/渲染 AGENTS.md(若模板存在则渲染,否则最小占位)
  if [ -f "$target/AGENTS.md" ]; then
    render_template "$target/AGENTS.md" "$target/AGENTS.md" "${kvs[@]}"
  else
    age_init_write_agents "$target" "$name" "$kind" "$validate"
  fi

  # 4) 生成/渲染 docs/index.md(路由器)
  if [ -f "$target/docs/index.md" ]; then
    render_template "$target/docs/index.md" "$target/docs/index.md" "${kvs[@]}"
  else
    age_init_write_index "$target" "$name"
  fi

  # 5) 渲染 docs/context/ 五件套(若模板已拷贝则渲染占位符)
  age_init_render_context "$target" "${kvs[@]}"

  # 6) 渲染 START-HERE 清单(若存在)
  if [ -f "$target/START-HERE-after-copy.md" ]; then
    render_template "$target/START-HERE-after-copy.md" "$target/START-HERE-after-copy.md" "${kvs[@]}"
  fi

  age_success "AGE 骨架已生成。"
  age_info "  - AGENTS.md: 代理操作契约"
  age_info "  - docs/index.md: 文档路由器"
  age_info "  - docs/context/: 强制上下文五件套"

  # 7) 自动 age check 自检
  age_info "运行自检 age check..."
  local check_code=0
  ( cd "$target" && age_call_cli check ) || check_code=$?
  if [ "$check_code" -ne 0 ]; then
    age_warn "自检发现 warning(骨架初始状态常见,补充内容后即可消除)。"
  else
    age_success "自检通过。"
  fi

  # 8) 自动 age baseline 快照
  age_info "生成基线快照 age baseline..."
  ( cd "$target" && age_call_cli baseline ) || age_warn "基线生成失败(可稍后手动 age baseline)。"

  age_success "AGE 初始化完成。下一步:编辑 docs/context/project-context.md 描述你的项目。"
  return 0
}

# ---------------------------------------------------------------------------
# age_init_ensure_skeleton:确保目录结构齐全
# docs/context/ 五件套目录:project-context / requirements / decisions / risks / glossary
# 各文档子目录:backlog requirements design architecture plans audits logs bugs testing
# ---------------------------------------------------------------------------
age_init_ensure_skeleton() {
  local target="$1"
  local dirs=(
    "docs" "docs/context" "docs/backlog" "docs/requirements"
    "docs/design" "docs/architecture" "docs/plans" "docs/audits"
    "docs/logs" "docs/bugs" "docs/testing"
    ".age"
  )
  local d
  for d in "${dirs[@]}"; do
    [ -d "$target/$d" ] || mkdir -p "$target/$d"
  done
}

# ---------------------------------------------------------------------------
# 最小 AGENTS.md 占位(模板缺失时)
# ---------------------------------------------------------------------------
age_init_write_agents() {
  local target="$1" name="${2:-My Project}" kind="${3:-web}" validate="${4:-}"
  cat > "$target/AGENTS.md" <<EOF
# AGENTS.md — $name 代理操作契约

> 由 age init 生成。本文件是所有 AI 代理在本仓库工作的强制契约。

## 项目身份
- 名称: $name
- 类型: $kind
EOF
  if [ -n "$validate" ]; then
    echo "- 验证命令: \`$validate\`" >> "$target/AGENTS.md"
  fi
  cat >> "$target/AGENTS.md" <<'EOF'

## 强制上下文
开工前必读 `docs/context/` 五件套;每个任务前用 `age route <task>` 确定要读的 owner 文档。

## 文档路由
见 `docs/index.md`。代码变更须回写到对应 owner 文档,用 `age sync` 检测漂移。

## 收尾规则
任务完成前 `age audit --scope closure`;提交前 `age check --strict`。
EOF
}

# ---------------------------------------------------------------------------
# 最小 docs/index.md 路由器(模板缺失时)
# ---------------------------------------------------------------------------
age_init_write_index() {
  local target="$1" name="${2:-My Project}"
  cat > "$target/docs/index.md" <<EOF
# 文档路由器 — $name

> 由 age init 生成。本文件是代码模块到 owner 文档的路由表。
> 代码变更 → 用 \`age sync\` 检测对应 owner 文档是否需更新。

## 路由表

| 模块/路径 | owner 文档 | 技能 |
|---|---|---|
| src/ | docs/architecture/overview.md | age-route |
| (待补充) | (待补充) | (待补充) |

## 说明
- 每行声明一个代码区域由哪个文档负责。
- \`age route <task>\` 依据此表 + \`skills/age/references/routing-rules.md\` 决策。
- 新增模块时务必同步更新本表,否则 \`age sync\` 会报 missing。
EOF
}

# ---------------------------------------------------------------------------
# 渲染 docs/context/ 强制上下文:若已拷贝模板则渲染占位符;缺失则生成最小占位。
# 强制五件套(与 AGENTS.md 声明一致):
#   project-context / ai-autonomy-policy / codebase-map /
#   source-of-truth-and-precedence / conventions
# 附加建议:requirements / decisions / risks / glossary
# ---------------------------------------------------------------------------
age_init_render_context() {
  local target="$1"; shift
  local kvs=("$@")
  local ctx="$target/docs/context"
  local -a required=("project-context" "ai-autonomy-policy" "codebase-map" "source-of-truth-and-precedence" "conventions")
  local -a suggested=("requirements" "decisions" "risks" "glossary")
  local f
  for f in "${required[@]}" "${suggested[@]}"; do
    local path="$ctx/$f.md"
    if [ -f "$path" ]; then
      render_template "$path" "$path" "${kvs[@]}"
    else
      age_init_write_context_stub "$path" "$f"
    fi
  done
  # 渲染 context/README.md(若模板已拷贝)
  local readme="$ctx/README.md"
  [ -f "$readme" ] && render_template "$readme" "$readme" "${kvs[@]}"
}

age_init_write_context_stub() {
  local path="$1" kind="$2"
  local title
  case "$kind" in
    project-context)              title="项目上下文";;
    ai-autonomy-policy)           title="AI 自主权策略";;
    codebase-map)                 title="代码库地图";;
    source-of-truth-and-precedence) title="事实来源与优先级";;
    conventions)                  title="约定";;
    requirements)                 title="需求基线";;
    decisions)                    title="关键决策(ADR 索引)";;
    risks)                        title="风险登记";;
    glossary)                     title="术语表";;
    *)                            title="$kind";;
  esac
  cat > "$path" <<EOF
# $title

> 由 age init 生成。此文件为 docs/context/ 上下文之一,开工前必读。
> 内容待补充(空内容会被 age check 标记)。
EOF
}

# ---------------------------------------------------------------------------
age_init_help() {
  cat <<'EOF'
age init — 初始化 AGE 项目结构

用法:
  age init [--name X] [--kind web|mobile|cli] [--validate CMD] [目标目录]

参数:
  --name X        项目名称(渲染到 AGENTS.md / docs)
  --kind K        项目类型:web|mobile|cli
  --validate CMD  验证命令(如 "npm test")
  目标目录         默认当前目录

行为:
  1. 拷贝 templates/repo/ 到目标
  2. 用 userConfig 默认值 + 命令行参数渲染占位符
  3. 生成 AGENTS.md / docs/index.md / docs/context/ 五件套骨架
  4. 自动 age check 自检
  5. 自动 age baseline 快照

退出码: 0 成功 / 1 失败
EOF
}

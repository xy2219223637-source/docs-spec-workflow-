# doctor.sh — age doctor 实现
# 诊断:AGENTS.md 可解析?docs/index.md 路由表格式?git 可用?hook 已装?
# CLI 在 PATH?给修复建议。退出码:0 全部健康 / 1 有问题。

age_doctor() {
  age_init_runtime

  while [ $# -gt 0 ]; do
    case "$1" in
      -h|--help) age_doctor_help; return 0;;
      *) age_warn "未知参数: $1"; shift;;
    esac
  done

  local root; root="$(pwd)"
  find_plugin_root 2>/dev/null || true

  local problems=0
  echo "$(age_color bold 'AGE 环境诊断')"
  echo

  # 1. git 可用
  if age_git_ok; then
    printf '  %s git 可用 (%s)\n' "$(age_color green '✓')" "$(git --version 2>/dev/null | head -1)"
  else
    printf '  %s git 不可用\n' "$(age_color red '✗')"
    echo '    修复: 安装 git,或在 git 仓库内运行 age 命令(无 git 时 sync 降级为空)。'
    problems=$((problems + 1))
  fi

  # 2. CLI 在 PATH / 可定位
  local age_bin=""
  if command -v age >/dev/null 2>&1; then
    age_bin="$(command -v age)"
    printf '  %s age 命令在 PATH (%s)\n' "$(age_color green '✓')" "$age_bin"
  elif [ -n "$AGE_PLUGIN_ROOT" ] && [ -f "$AGE_PLUGIN_ROOT/cli/age" ]; then
    printf '  %s age 命令未在 PATH,但可定位 (%s/cli/age)\n' "$(age_color yellow '⚠')" "$AGE_PLUGIN_ROOT"
    echo "    修复: 加到 PATH: export PATH=\"$AGE_PLUGIN_ROOT/cli:\$PATH\" 或创建软链。"
  else
    printf '  %s age 命令不可定位\n' "$(age_color red '✗')"
    echo '    修复: 确认在 AGE 插件目录内运行,或设置 AGE_PLUGIN_ROOT。'
    problems=$((problems + 1))
  fi

  # 3. AGENTS.md 可解析(存在且非空)
  local agents="$root/AGENTS.md"
  if [ -f "$agents" ]; then
    if [ -s "$agents" ]; then
      # 检查是否含至少一个标题
      if grep -qE '^#{1,6} ' "$agents" 2>/dev/null; then
        printf '  %s AGENTS.md 可解析\n' "$(age_color green '✓')"
      else
        printf '  %s AGENTS.md 缺少标题结构\n' "$(age_color yellow '⚠')"
        echo '    修复: 补充 markdown 标题(# 开头)结构。'
        problems=$((problems + 1))
      fi
    else
      printf '  %s AGENTS.md 为空\n' "$(age_color red '✗')"
      echo '    修复: 运行 age init 生成,或手动填写代理契约。'
      problems=$((problems + 1))
    fi
  else
    printf '  %s AGENTS.md 不存在(非 AGE 仓库?)\n' "$(age_color yellow '⚠')"
    echo '    修复: 运行 age init 初始化。'
    problems=$((problems + 1))
  fi

  # 4. docs/index.md 路由表格式
  local index; index="$(age_index_path "$root")"
  if [ -n "$index" ]; then
    # 检查是否含至少一条有效路由行(非表头/非分隔)
    local nrows
    nrows=$(age_parse_index_routes "$index" | grep -c '.' || true)
    if [ "$nrows" -gt 0 ]; then
      printf '  %s docs/index.md 路由表有 %s 条记录\n' "$(age_color green '✓')" "$nrows"
    else
      printf '  %s docs/index.md 路由表无有效记录\n' "$(age_color yellow '⚠')"
      echo '    修复: 补充 | 模块 | owner 文档 | 技能 | 格式的路由行。'
      problems=$((problems + 1))
    fi
  else
    printf '  %s docs/index.md 不存在\n' "$(age_color yellow '⚠')"
    echo '    修复: 运行 age init 生成路由器。'
    problems=$((problems + 1))
  fi

  # 5. hook 已装
  local hooks_json=""
  [ -n "$AGE_PLUGIN_ROOT" ] && hooks_json="$AGE_PLUGIN_ROOT/hooks/hooks.json"
  if [ -n "$hooks_json" ] && [ -f "$hooks_json" ]; then
    # 检查 hook 脚本是否存在且可执行
    local scripts_ok=1
    local scripts_dir="$AGE_PLUGIN_ROOT/hooks/scripts"
    if [ -d "$scripts_dir" ]; then
      local sh
      for sh in "$scripts_dir"/*.sh; do
        [ -f "$sh" ] || continue
        if [ ! -x "$sh" ]; then
          scripts_ok=0
          printf '  %s hook 脚本不可执行: %s\n' "$(age_color yellow '⚠')" "$(basename "$sh")"
          echo "    修复: chmod +x $sh"
          problems=$((problems + 1))
        fi
      done
    fi
    if [ "$scripts_ok" = "1" ]; then
      printf '  %s hooks/hooks.json 存在,脚本可执行\n' "$(age_color green '✓')"
    fi
  else
    printf '  %s hooks/hooks.json 不存在\n' "$(age_color yellow '⚠')"
    echo '    修复: 由任务执行 agent 产出 hooks 配置;不影响 CLI 核心功能。'
  fi

  # 6. 插件 manifest
  local manifest=""
  [ -n "$AGE_PLUGIN_ROOT" ] && manifest="$AGE_PLUGIN_ROOT/.zcode-plugin/plugin.json"
  if [ -n "$manifest" ] && [ -f "$manifest" ]; then
    printf '  %s .zcode-plugin/plugin.json 存在\n' "$(age_color green '✓')"
  else
    printf '  %s .zcode-plugin/plugin.json 不存在\n' "$(age_color yellow '⚠')"
    echo '    修复: 由事实设计 agent 产出 manifest。'
  fi

  # 7. MCP server
  local mcp_server=""
  [ -n "$AGE_PLUGIN_ROOT" ] && mcp_server="$AGE_PLUGIN_ROOT/mcp/server.py"
  if [ -n "$mcp_server" ] && [ -f "$mcp_server" ]; then
    if command -v python3 >/dev/null 2>&1; then
      printf '  %s MCP server.py 存在, python3 可用\n' "$(age_color green '✓')"
    else
      printf '  %s MCP server.py 存在,但 python3 不可用\n' "$(age_color yellow '⚠')"
      echo '    修复: 安装 python3 以运行 MCP server。'
      problems=$((problems + 1))
    fi
  else
    printf '  %s mcp/server.py 不存在\n' "$(age_color red '✗')"
    problems=$((problems + 1))
  fi

  echo
  if [ "$problems" -gt 0 ]; then
    printf '  %s 发现 %s 个问题(见上方修复建议)\n' "$(age_color red '结果')" "$problems"
    return 1
  else
    printf '  %s 环境健康,所有检查通过\n' "$(age_color green '结果')"
    return 0
  fi
}

age_doctor_help() {
  cat <<'EOF'
age doctor — 环境与配置诊断

用法:
  age doctor

检查项:
  - git 可用性
  - age 命令定位
  - AGENTS.md 可解析
  - docs/index.md 路由表格式
  - hook 脚本已装且可执行
  - 插件 manifest 存在
  - MCP server + python3 可用

退出码: 0 全部健康 / 1 有问题
EOF
}

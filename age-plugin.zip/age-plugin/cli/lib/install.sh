# install.sh — age install 实现
# 自动检测当前宿主客户端(ZCode/Claude Code/Codex/OpenCode/Multica/Win11),
# 从 compat/<客户端>/ 拷贝适配配置到正确位置(合并而非覆盖)。
# 用法:age install [--client zcode|claude|codex|opencode|multica|win11] [--dry-run] [--list] [--help]
#
# 兼容等级(CONTRACT §8.11 + §8.12 Win11,2026-07-11):
#   zcode    — full(原生插件宿主)
#   claude   — full(hooks+skills+MCP+CLAUDE.md)
#   codex    — full(hooks+skills+MCP+AGENTS.md,Codex 有完整 PascalCase hooks)
#   opencode — partial(MCP+commands+plugin.ts(Hooks 接口)+AGENTS.md,无 SessionStart/Stop 事件)
#   multica  — full(skill+MCP+autopilot,本机 v0.3.43 验证;无本地 hooks,autopilot 部分替代)
#   win11    — full(PowerShell 原生 CLI cli/age.ps1 + .ps1 hook 脚本,不依赖 bash)

# ---------------------------------------------------------------------------
# age_install:主入口
# ---------------------------------------------------------------------------
age_install() {
  age_init_runtime

  local client="" dry_run=0 list_only=0
  # 解析参数
  while [ $# -gt 0 ]; do
    case "$1" in
      --client) client="$2"; shift 2;;
      --client=*) client="${1#*=}"; shift;;
      --dry-run) dry_run=1; shift;;
      --list) list_only=1; shift;;
      -h|--help) age_install_help; return 0;;
      *) age_warn "未知参数: $1"; shift;;
    esac
  done

  # --list:列出所有支持的客户端及其兼容等级,直接返回
  if [ "$list_only" = "1" ]; then
    age_install_list
    return 0
  fi

  # 定位插件根(compat/ 目录在其下)
  find_plugin_root 2>/dev/null || true
  if [ -z "$AGE_PLUGIN_ROOT" ] || [ ! -d "$AGE_PLUGIN_ROOT" ]; then
    age_die "无法定位 AGE 插件根(AGE_PLUGIN_ROOT 未设置或无效)。" 1
  fi
  local compat_dir="$AGE_PLUGIN_ROOT/compat"

  # 1. 检测客户端(或用手动指定)
  if [ -z "$client" ]; then
    client="$(detect_host)"
    if [ "$client" = "unknown" ]; then
      age_error "无法自动检测当前客户端环境。请用 --client <name> 手动指定 (zcode|claude|codex|opencode|multica|win11)。"
      return 1
    fi
    age_info "检测到当前客户端: $client"
  else
    # 校验手动指定的客户端名
    case "$client" in
      zcode|claude|codex|opencode|multica|win11) ;;
      *) age_die "无效 --client: $client (允许: zcode|claude|codex|opencode|multica|win11)" 1;;
    esac
    age_info "使用手动指定客户端: $client"
  fi

  # 2. 多客户端共存检测(CONTRACT §8.11):安装某客户端时若发现已有其他
  #    客户端的配置痕迹,提示用户保持指令文件(AGENTS.md/CLAUDE.md)同步。
  _age_install_coexistence_warn "$client"

  # 3. 按客户端分发
  case "$client" in
    zcode)
      _age_install_zcode "$compat_dir" "$dry_run"
      ;;
    claude)
      _age_install_claude "$compat_dir" "$dry_run"
      ;;
    codex)
      _age_install_codex "$compat_dir" "$dry_run"
      ;;
    opencode)
      _age_install_opencode "$compat_dir" "$dry_run"
      ;;
    multica)
      _age_install_multica "$compat_dir" "$dry_run"
      ;;
    win11)
      _age_install_win11 "$compat_dir" "$dry_run"
      ;;
    *)
      age_die "未支持的客户端: $client" 1
      ;;
  esac
  return $?
}

# ---------------------------------------------------------------------------
# 各客户端安装逻辑
# ---------------------------------------------------------------------------

# _age_install_zcode:ZCode 是原生插件宿主,无需额外安装
_age_install_zcode() {
  local compat_dir="$1" dry_run="$2"
  age_success "ZCode 是 AGE 的原生插件宿主,无需额外安装。"
  age_info "AGE 插件已通过 ZCode 插件机制加载(plugin.json + marketplace)。"
  age_info "如需在项目中初始化 AGE 文档骨架,请运行: age use"
  if [ "$dry_run" = "1" ]; then
    age_info "(dry-run) 无文件操作。"
  fi
  return 0
}

# _age_install_claude:Claude Code 适配
#   compat/claude-code/settings.json → .claude/settings.json
#   compat/claude-code/.mcp.json      → 项目根/.mcp.json
#   compat/claude-code/CLAUDE.md      → 项目根/CLAUDE.md
_age_install_claude() {
  local compat_dir="$1" dry_run="$2"
  local src_dir="$compat_dir/claude-code"
  local proj; proj="$(pwd)"

  if [ ! -d "$src_dir" ]; then
    age_error "Claude Code 适配配置目录不存在: $src_dir"
    age_info "请确认 compat/claude-code/ 已由事实设计 agent 产出。"
    return 1
  fi

  local rc=0

  # settings.json → .claude/settings.json(合并)
  _age_install_merge_json \
    "$src_dir/settings.json" "$proj/.claude/settings.json" "$dry_run" || rc=$?

  # .mcp.json → 项目根/.mcp.json(合并)
  _age_install_merge_json \
    "$src_dir/.mcp.json" "$proj/.mcp.json" "$dry_run" || rc=$?

  # CLAUDE.md → 项目根/CLAUDE.md(存在则跳过,不覆盖已有指令)
  if [ -f "$src_dir/CLAUDE.md" ]; then
    local dest="$proj/CLAUDE.md"
    if [ "$dry_run" = "1" ]; then
      age_info "(dry-run) 将拷贝 CLAUDE.md → $dest (已存在则跳过)"
    elif [ -f "$dest" ]; then
      age_warn "已存在 $dest,跳过(不覆盖已有指令文件)。"
    else
      cp "$src_dir/CLAUDE.md" "$dest" 2>/dev/null && \
        age_success "已拷贝 CLAUDE.md → $dest" || \
        { age_error "拷贝失败: CLAUDE.md"; rc=1; }
    fi
  fi

  if [ "$rc" -eq 0 ]; then
    age_success "Claude Code 适配配置安装完成。"
    age_info "已写入: .claude/settings.json, .mcp.json, CLAUDE.md"
    age_info "重启 Claude Code 会话以加载 MCP server 与 hooks。"
  fi
  return "$rc"
}

# _age_install_codex:Codex CLI 适配(CP-1 校验后:Codex 为 full 级,含 hooks)
#   compat/codex/config.toml → ~/.codex/config.toml(合并而非覆盖)
#   config.toml 含 [mcp_servers.age-mcp] 段(MCP)+ [hooks.SessionStart|PostToolUse|Stop] 段
#   (CONTRACT §8.11:Codex 有完整 PascalCase hooks,与 Claude Code 事件名一致)
_age_install_codex() {
  local compat_dir="$1" dry_run="$2"
  local src="$compat_dir/codex/config.toml"
  local proj; proj="$(pwd)"

  if [ ! -f "$src" ]; then
    age_error "Codex 适配配置文件不存在: $src"
    age_info "请确认 compat/codex/ 已由事实设计 agent 产出。"
    return 1
  fi

  # Codex 配置目录:CODEX_HOME 或 ~/.codex
  local codex_home="${CODEX_HOME:-$HOME/.codex}"
  local dest="$codex_home/config.toml"

  if [ "$dry_run" = "1" ]; then
    age_info "(dry-run) 将合并 $src → $dest"
    age_info "(dry-run) 含 MCP servers + hooks 配置(SessionStart/PostToolUse/Stop)"
    return 0
  fi

  mkdir -p "$codex_home" 2>/dev/null || { age_error "无法创建目录: $codex_home"; return 1; }

  local rc=0
  # 合并 TOML:无 jq/python toml 库可用的通用方案
  # 策略:若 dest 不存在 → 直接拷贝;若存在 → 追加 AGE 段(去重)
  if [ ! -f "$dest" ]; then
    cp "$src" "$dest" 2>/dev/null && \
      age_success "已拷贝 config.toml → $dest" || \
      { age_error "拷贝失败: $dest"; return 1; }
  else
    # TOML 合并:用 _age_install_merge_toml
    _age_install_merge_toml "$src" "$dest" || rc=$?
  fi

  age_success "Codex 适配配置安装完成: $dest"
  # 确认安装的内容(MCP + hooks)
  age_info "已安装:MCP server(age-mcp)+ hooks(SessionStart/PostToolUse/Stop)"
  age_info "Codex 为 full 级兼容(§8.11):hooks 事件名 PascalCase,与 Claude Code 一致。"
  age_info "Codex CLI 的 AGENTS.md 指令文件请用 age use 在项目中初始化。"
  return "$rc"
}

# _age_install_opencode:OpenCode CLI 适配(CP-4 plugin-based 重写)
#   本机验证(@opencode-ai/plugin SDK 1.17.18):OpenCode hooks 是 plugin 机制,
#   不是配置文件式钩子 —— opencode.json 不能配 hooks 键,必须写 plugin 模块
#   (实现 Hooks 接口)并在 plugin 数组引用。
#   安装内容:
#     - opencode.json → 项目根/opencode.json(合并 mcp/commands/plugin 段,无 hooks 键)
#     - plugin.ts    → 项目根/plugin.ts(若已存在则跳过)
#     - package.json → 项目根/package.json(若已存在则跳过)
#   PARTIAL 降级(§8.11):无 SessionStart/Stop 事件。
#     - chat.message plugin hook 部分替代 SessionStart(每会话首条消息注入 context)
#     - tool.execute.after plugin hook 真实对应 PostToolUse(漂移检测)
#     - Stop 无对应,降级为手动 /age-audit
_age_install_opencode() {
  local compat_dir="$1" dry_run="$2"
  local src_dir="$compat_dir/opencode"
  local proj; proj="$(pwd)"

  if [ ! -d "$src_dir" ] || [ ! -f "$src_dir/opencode.json" ]; then
    age_error "OpenCode 适配配置目录不存在或缺少 opencode.json: $src_dir"
    age_info "请确认 compat/opencode/ 已由事实设计 agent 产出。"
    return 1
  fi

  local rc=0

  # opencode.json → 项目根/opencode.json(合并,无 hooks 键)
  _age_install_merge_json \
    "$src_dir/opencode.json" "$proj/opencode.json" "$dry_run" || rc=$?

  # plugin.ts → 项目根/plugin.ts(存在则跳过,不覆盖)
  if [ -f "$src_dir/plugin.ts" ]; then
    local dest_ts="$proj/plugin.ts"
    if [ "$dry_run" = "1" ]; then
      age_info "(dry-run) 将拷贝 plugin.ts → $dest_ts (已存在则跳过)"
    elif [ -f "$dest_ts" ]; then
      age_warn "已存在 $dest_ts,跳过(不覆盖已有 plugin 模块)。"
    else
      cp "$src_dir/plugin.ts" "$dest_ts" 2>/dev/null && \
        age_success "已拷贝 plugin.ts → $dest_ts" || \
        { age_error "拷贝失败: plugin.ts"; rc=1; }
    fi
  else
    age_warn "compat/opencode/plugin.ts 不存在,跳过 plugin 模块拷贝。"
  fi

  # package.json → 项目根/package.json(存在则跳过)
  if [ -f "$src_dir/package.json" ]; then
    local dest_pkg="$proj/package.json"
    if [ "$dry_run" = "1" ]; then
      age_info "(dry-run) 将拷贝 package.json → $dest_pkg (已存在则跳过)"
    elif [ -f "$dest_pkg" ]; then
      age_warn "已存在 $dest_pkg,跳过(不覆盖已有 package.json)。"
    else
      cp "$src_dir/package.json" "$dest_pkg" 2>/dev/null && \
        age_success "已拷贝 package.json → $dest_pkg" || \
        { age_error "拷贝失败: package.json"; rc=1; }
    fi
  fi

  if [ "$rc" -eq 0 ]; then
    age_success "OpenCode 适配配置安装完成: $proj/opencode.json (+ plugin.ts + package.json)"
    age_warn "OpenCode 为 partial 级兼容(§8.11):无 SessionStart/Stop 事件。"
    age_info "已安装:MCP server(age-mcp)+ commands(use-age/route/sync/audit)+ plugin 引用。"
    age_info "plugin 机制:opencode.json 的 \"plugin\": [\"./plugin.ts\"] 引用 AGE plugin 模块。"
    age_info "plugin 模块实现 Hooks 接口:chat.message(部分替代 SessionStart)、tool.execute.after(PostToolUse 对应)。"
    age_info "可选:跑 \`opencode plugin ./plugin.ts\` 显式安装 plugin(opencode 启动时也会经 plugin 数组自动加载)。"
    age_info "降级:Stop 无对应事件,任务收尾请手动跑 /age-audit(触发 age audit --scope closure)。"
    age_info "OpenCode 的 AGENTS.md 指令文件请用 age use 在项目中初始化。"
  fi
  return "$rc"
}

# _age_install_multica:Multica 适配(§8.11 恢复,本机 v0.3.43 验证,full 级)
#   Multica 是云 workspace 模式客户端,扩展机制:skill(create/import)+ MCP(agent
#   --mcp-config,标准 mcpServers JSON)+ agent instructions(--instructions,等价
#   AGENTS.md)+ autopilot(schedule/webhook,部分替代 hooks)。无本地 hooks。
#
#   安装不是拷贝配置文件,而是调 multica CLI 注册到 workspace:
#     1. 渲染 compat/multica/mcp-config.json 占位符(AGE_PLUGIN_ROOT / PROJECT_DIR)
#     2. multica skill create 注册 use-AGE 技能(同名已存在则 update)
#     3. (可选,需 --agent)multica agent update --mcp-config-file + agent skills add
#        + agent env set(AGE_PLUGIN_ROOT / AGE_PROJECT_ROOT)
#     4. (可选,需 --agent 且未 --no-autopilot)autopilot 定时漂移检测
#
#   age install --client multica 调用 compat/multica/install.sh 完成;
#   dry-run 透传。不支持 --agent(age install 无此参数),仅注册技能 + 提示绑定命令。
_age_install_multica() {
  local compat_dir="$1" dry_run="$2"
  local src_dir="$compat_dir/multica"
  local installer="$src_dir/install.sh"

  if [ ! -d "$src_dir" ] || [ ! -f "$installer" ]; then
    age_error "Multica 适配目录不存在或缺少 install.sh: $src_dir"
    age_info "请确认 compat/multica/ 已产出(use-AGE.skill.md + mcp-config.json + install.sh)。"
    return 1
  fi

  # 确保可执行
  [ -x "$installer" ] || chmod +x "$installer" 2>/dev/null

  age_info "Multica 为 full 级兼容(§8.11,本机 v0.3.43 验证):skill + MCP + autopilot。"
  age_info "安装方式:调 multica CLI 注册技能到 workspace(非拷贝配置文件)。"

  # 调用 compat/multica/install.sh(dry-run 透传;不传 --agent,仅注册技能)
  local dry_flag=""
  [ "$dry_run" = "1" ] && dry_flag="--dry-run"

  age_info "执行: $installer $dry_flag"
  if [ "$dry_run" = "1" ]; then
    # dry-run 下仍执行 install.sh --dry-run(它内部只预览 multica 命令,不实际注册)
    if bash "$installer" --dry-run --no-autopilot; then
      age_success "Multica 适配安装预览完成(dry-run)。"
    else
      age_error "install.sh --dry-run 失败。"
      return 1
    fi
  else
    if bash "$installer" --no-autopilot; then
      age_success "Multica use-AGE 技能已注册到 workspace。"
    else
      age_error "compat/multica/install.sh 执行失败。"
      return 1
    fi
  fi

  age_info "已注册:use-AGE 技能(注册到 Multica workspace,所有 agent 可共享)。"
  age_warn "Multica 无本地 hooks(§8.11):SessionStart/Stop 由 use-AGE 技能(显式激活)+"
  age_warn "  autopilot(定时漂移检测)部分替代。完整 closure audit 需在对话中触发。"
  age_info "绑定 MCP + 技能到 agent(需手动,因 age install 不带 --agent):"
  age_info "  bash $installer --agent <agent-name-or-id>"
  age_info "  (会配置 agent --mcp-config + --skill-ids + --custom-env + 可选 autopilot)"
  age_info "Multica agent 的 AGENTS.md 指令:把 templates/repo/AGENTS.md 内容作为"
  age_info "  multica agent create --instructions 的值,或在工作区跑 age use 生成 AGENTS.md。"
  return 0
}

# ---------------------------------------------------------------------------
# _age_install_win11:Windows 11 适配(§8.12 双层策略,full 级)
#   Win11 原生 shell 是 PowerShell,无 bash。本函数把 PowerShell CLI 入口拷贝到
#   目标目录(默认 ~/.age-cli/),并提示把 age.ps1 加入 PATH。
#   双层策略:不覆盖 bash CLI(cli/age);Git-Bash/WSL 下 cli/age 仍可用。
#
#   安装内容(从插件根拷贝,非 compat/win11/,因 PS1 入口由总调度产出在 cli/):
#     - cli/age.ps1              → ~/.age-cli/age.ps1
#     - cli/lib/*.ps1            → ~/.age-cli/lib/
#     - hooks/scripts/*.ps1      → ~/.age-cli/hooks/scripts/(若存在,任务执行 agent 产出)
#     - hooks/hooks.win11.json   → ~/.age-cli/hooks/hooks.win11.json(若存在)
#   然后提示用户把 ~/.age-cli 加入 PATH(PowerShell 持久化命令)。
_age_install_win11() {
  local compat_dir="$1" dry_run="$2"
  local src_root="$AGE_PLUGIN_ROOT"
  local target="$HOME/.age-cli"

  if [ -z "$src_root" ] || [ ! -d "$src_root" ]; then
    age_error "无法定位 AGE 插件根(AGE_PLUGIN_ROOT 未设置或无效)。"
    return 1
  fi

  age_info "Win11 安装(§8.12 双层策略):把 PowerShell CLI 入口拷贝到 $target"
  age_info "  (不覆盖 bash CLI;age.ps1 与 cli/age 并存,bash 走 bash,Win11 走 ps1)"

  if [ "$dry_run" = "1" ]; then
    age_info "(dry-run) 将创建目录: $target, $target/lib, $target/hooks/scripts"
    age_info "(dry-run) 将拷贝 cli/age.ps1 → $target/age.ps1"
    age_info "(dry-run) 将拷贝 cli/lib/*.ps1 → $target/lib/"
    age_info "(dry-run) 将拷贝 hooks/scripts/*.ps1 → $target/hooks/scripts/(若存在)"
    age_info "(dry-run) 将拷贝 hooks/hooks.win11.json → $target/hooks/hooks.win11.json(若存在)"
    age_info "(dry-run) 将提示把 $target 加入 PATH"
    return 0
  fi

  # 创建目标目录
  mkdir -p "$target/lib" "$target/hooks/scripts" 2>/dev/null || {
    age_error "无法创建目标目录: $target"
    return 1
  }

  local rc=0

  # 1. cli/age.ps1 → target/age.ps1
  if [ -f "$src_root/cli/age.ps1" ]; then
    cp "$src_root/cli/age.ps1" "$target/age.ps1" 2>/dev/null && \
      age_success "已拷贝 age.ps1 → $target/age.ps1" || \
      { age_error "拷贝失败: age.ps1"; rc=1; }
  else
    age_error "cli/age.ps1 不存在(本应在本轮产出)。"
    rc=1
  fi

  # 2. cli/lib/*.ps1 → target/lib/
  local n_lib=0
  if [ -d "$src_root/cli/lib" ]; then
    local f
    for f in "$src_root/cli/lib"/*.ps1; do
      [ -f "$f" ] || continue
      if cp "$f" "$target/lib/" 2>/dev/null; then
        n_lib=$((n_lib + 1))
      else
        age_warn "拷贝失败: $(basename "$f")"
      fi
    done
    if [ "$n_lib" -gt 0 ]; then
      age_success "已拷贝 $n_lib 个 lib/*.ps1 → $target/lib/"
    else
      age_warn "cli/lib/*.ps1 未找到(可能尚未全部产出)。"
    fi
  else
    age_warn "cli/lib/ 目录不存在。跳过 lib 拷贝。"
  fi

  # 3. hooks/scripts/*.ps1 → target/hooks/scripts/(若存在)
  local n_hook=0
  if [ -d "$src_root/hooks/scripts" ]; then
    local f
    for f in "$src_root/hooks/scripts"/*.ps1; do
      [ -f "$f" ] || continue
      if cp "$f" "$target/hooks/scripts/" 2>/dev/null; then
        n_hook=$((n_hook + 1))
      else
        age_warn "拷贝失败: $(basename "$f")"
      fi
    done
    if [ "$n_hook" -gt 0 ]; then
      age_success "已拷贝 $n_hook 个 hooks/scripts/*.ps1 → $target/hooks/scripts/"
    else
      age_info "hooks/scripts/*.ps1 未找到(任务执行 agent 产出中)。跳过。"
    fi
  else
    age_info "hooks/scripts/ 目录不存在。跳过 hook 脚本拷贝。"
  fi

  # 4. hooks/hooks.win11.json → target/hooks/hooks.win11.json(若存在)
  if [ -f "$src_root/hooks/hooks.win11.json" ]; then
    cp "$src_root/hooks/hooks.win11.json" "$target/hooks/hooks.win11.json" 2>/dev/null && \
      age_success "已拷贝 hooks.win11.json → $target/hooks/hooks.win11.json" || \
      age_warn "拷贝失败: hooks.win11.json"
  else
    age_info "hooks/hooks.win11.json 未找到(任务执行 agent 产出中)。跳过。"
  fi

  # 5. 提示加入 PATH
  age_info "安装完成。请把 $target 加入 PATH 以便在任意目录运行 age:"
  age_info "  PowerShell(当前用户,持久):"
  age_info '    $current = [Environment]::GetEnvironmentVariable("PATH","User")'
  age_info '    [Environment]::SetEnvironmentVariable("PATH", $current + ";'"$target"'", "User")'
  age_info "  然后重开终端,运行: age doctor 验证。"
  age_info "  (age.ps1 会自动向上探测 AGE 插件根;若插件目录移动,重跑 age install --client win11)"
  age_warn "Win11 为 full 级兼容(§8.12):PowerShell 原生 CLI(不依赖 bash)+ .ps1 hook 脚本。"
  age_warn "  bash CLI(cli/age)在 Git-Bash/WSL 下仍可直接用(双层策略)。"

  # 6. hooks.json 覆盖提示(W-7 修复):ZCode 只加载 hooks/hooks.json,
  #    Win11 上 .sh hook 脚本无 bash 无法执行。提示用户用 hooks.win11.json 覆盖。
  if [ -f "$src_root/hooks/hooks.win11.json" ]; then
    age_warn "Win11 + ZCode 用户:ZCode 只加载 hooks/hooks.json(指向 .sh 脚本),Win11 原生无 bash 时 hook 会失效。"
    age_warn "  解决:把 hooks.win11.json 覆盖到 ZCode 插件目录的 hooks/hooks.json:"
    age_warn "    Copy-Item '$src_root/hooks/hooks.win11.json' '$src_root/hooks/hooks.json' -Force"
    age_warn "  (或手动编辑 hooks.json 把 .sh 路径改为 .ps1 + pwsh 前缀)"
  fi
  return "$rc"
}

# ---------------------------------------------------------------------------
# --list 与多客户端共存检测
# ---------------------------------------------------------------------------

# age_install_list:列出所有支持的客户端及其兼容等级(CONTRACT §8.11)
age_install_list() {
  cat <<'EOF'
AGE 支持的客户端(兼容等级见 CONTRACT §8.11 + §8.12):

  客户端       兼容等级    配置语言      说明
  ───────────  ──────────  ────────────  ──────────────────────────────────
  zcode        full        JSON          原生插件宿主(plugin.json + marketplace)
  claude       full        JSON          Claude Code(hooks+skills+MCP+CLAUDE.md)
  codex        full        TOML          OpenAI Codex CLI(hooks+skills+MCP+AGENTS.md)
  opencode     partial     JSON/TS       OpenCode CLI(MCP+commands+plugin.ts,无 SessionStart/Stop 事件)
  multica      full        JSON          Multica(skill+MCP+autopilot,本机 v0.3.43 验证;无本地 hooks)
  win11        full        PowerShell    Windows 11(PowerShell 原生 CLI + .ps1 hooks,不依赖 bash)

兼容等级说明:
  full     — MCP + 指令文件 + Skills + Slash commands + Hooks(全事件) 全部支持
             (Win11 的 full:PowerShell 原生 CLI 入口 + .ps1 hook 脚本;
              Multica 的 full 略有差异:Hooks 用 autopilot 触发器部分替代,非本地 hooks)
  partial  — MCP + 指令文件 + Commands + plugin 模块(Hooks 接口)支持;
             Hooks 走 plugin 模块(tool.execute.after=PostToolUse 对应、chat.message=部分 SessionStart),
             无 SessionStart/Stop 事件(客户端无此事件,不可行,降级处理)

注意:
  - Multica 已恢复到客户端列表(2026-07-11 本机验证:真实存在,AI 原生团队工作区客户端,
    v0.3.43 Go 实现,云 workspace 模式;之前因拼写误作 "Mutica" 被误判为实验性语言而移除,已纠正)。
  - Win11 双层策略(§8.12):优先 PowerShell 原生(不要求 Git-Bash),Git-Bash 作为回退。
  - 安装指定客户端:age install --client <zcode|claude|codex|opencode|multica|win11>
  - 检测当前环境:age install(不带 --client,自动检测)
EOF
}

# _age_install_coexistence_warn <current_client>:多客户端共存检测
# 安装某客户端时,若检测到已有其他客户端的配置痕迹,提示用户保持指令文件同步。
# 不阻断安装,仅提示(CONTRACT §8.11)。
_age_install_coexistence_warn() {
  local current="$1"
  local proj; proj="$(pwd)"
  local found_others=""

  # 各客户端的配置痕迹特征(项目内 + 用户目录)
  # ZCode:.zcode/ 目录
  # Claude:.claude/ 目录 或 CLAUDE.md
  # Codex:~/.codex/config.toml 含 AGE 配置(或 .codex/ 目录)
  # OpenCode:opencode.json 存在

  case "$current" in
    zcode)
      # 装的是 zcode,检查其他客户端
      [ -d "$proj/.claude" ] && found_others="$found_others claude"
      [ -f "$proj/CLAUDE.md" ] && found_others="$found_others claude(CLAUDE.md)"
      [ -f "$proj/opencode.json" ] && found_others="$found_others opencode"
      [ -f "${CODEX_HOME:-$HOME/.codex}/config.toml" ] && found_others="$found_others codex"
      [ -f "$HOME/.multica/config.json" ] && found_others="$found_others multica"
      ;;
    claude)
      [ -d "$proj/.zcode" ] && found_others="$found_others zcode"
      [ -f "$proj/opencode.json" ] && found_others="$found_others opencode"
      [ -f "${CODEX_HOME:-$HOME/.codex}/config.toml" ] && found_others="$found_others codex"
      [ -f "$HOME/.multica/config.json" ] && found_others="$found_others multica"
      ;;
    codex)
      [ -d "$proj/.zcode" ] && found_others="$found_others zcode"
      [ -d "$proj/.claude" ] && found_others="$found_others claude"
      [ -f "$proj/CLAUDE.md" ] && found_others="$found_others claude(CLAUDE.md)"
      [ -f "$proj/opencode.json" ] && found_others="$found_others opencode"
      [ -f "$HOME/.multica/config.json" ] && found_others="$found_others multica"
      ;;
    opencode)
      [ -d "$proj/.zcode" ] && found_others="$found_others zcode"
      [ -d "$proj/.claude" ] && found_others="$found_others claude"
      [ -f "$proj/CLAUDE.md" ] && found_others="$found_others claude(CLAUDE.md)"
      [ -f "${CODEX_HOME:-$HOME/.codex}/config.toml" ] && found_others="$found_others codex"
      [ -f "$HOME/.multica/config.json" ] && found_others="$found_others multica"
      ;;
    multica)
      [ -d "$proj/.zcode" ] && found_others="$found_others zcode"
      [ -d "$proj/.claude" ] && found_others="$found_others claude"
      [ -f "$proj/CLAUDE.md" ] && found_others="$found_others claude(CLAUDE.md)"
      [ -f "$proj/opencode.json" ] && found_others="$found_others opencode"
      [ -f "${CODEX_HOME:-$HOME/.codex}/config.toml" ] && found_others="$found_others codex"
      ;;
    win11)
      # Win11 不与其他客户端配置冲突(PS1 入口独立),仅检测其他客户端痕迹提示
      [ -d "$proj/.zcode" ] && found_others="$found_others zcode"
      [ -d "$proj/.claude" ] && found_others="$found_others claude"
      [ -f "$proj/CLAUDE.md" ] && found_others="$found_others claude(CLAUDE.md)"
      [ -f "$proj/opencode.json" ] && found_others="$found_others opencode"
      [ -f "${CODEX_HOME:-$HOME/.codex}/config.toml" ] && found_others="$found_others codex"
      [ -f "$HOME/.multica/config.json" ] && found_others="$found_others multica"
      ;;
  esac

  if [ -n "$found_others" ]; then
    age_warn "检测到多客户端共存,已有其他客户端配置:$(echo "$found_others" | sed 's/^ *//')"
    age_info "多客户端共存时,AGENTS.md / CLAUDE.md 指令文件需保持同步(CLAUDE.md 是 AGENTS.md 的生成副本)。"
    age_info "建议用 age use 在项目中初始化 AGENTS.md,再同步到 CLAUDE.md。"
  fi
}

# ---------------------------------------------------------------------------
# 合并工具(合并而非覆盖)
# ---------------------------------------------------------------------------

# _age_install_merge_json <src> <dest> <dry_run>
# 合并两个 JSON 文件:用 python3(若可用)做深合并;否则 dest 不存在则拷贝,
# 存在则保留 dest 不覆盖并警告(避免破坏已有配置)。
# 退出码:0 成功 / 1 失败
_age_install_merge_json() {
  local src="$1" dest="$2" dry_run="${3:-0}"

  if [ ! -f "$src" ]; then
    age_warn "源文件不存在,跳过: $src"
    return 0
  fi

  if [ "$dry_run" = "1" ]; then
    if [ -f "$dest" ]; then
      age_info "(dry-run) 将合并 $src → $dest (深合并)"
    else
      age_info "(dry-run) 将拷贝 $src → $dest"
    fi
    return 0
  fi

  # dest 不存在:直接拷贝
  if [ ! -f "$dest" ]; then
    mkdir -p "$(dirname "$dest")" 2>/dev/null
    cp "$src" "$dest" 2>/dev/null && \
      age_success "已拷贝 $(basename "$src") → $dest" || \
      { age_error "拷贝失败: $dest"; return 1; }
    return 0
  fi

  # dest 存在:优先用 python3 深合并
  if command -v python3 >/dev/null 2>&1; then
    # python3 脚本:深合并两个 JSON,顶层 dict 键合并(后者补充前者),
    # 同名键若均为 dict 则递归合并,否则 dest 优先(保留用户已有值)。
    if python3 - "$src" "$dest" <<'PYEOF' 2>/dev/null
import json, sys
src_path, dest_path = sys.argv[1], sys.argv[2]
with open(src_path, "r", encoding="utf-8") as f:
    src = json.load(f)
with open(dest_path, "r", encoding="utf-8") as f:
    dest = json.load(f)

def deep_merge(base, extra):
    """extra 补充 base:base 已有的键保留,extra 独有的键加入。"""
    if not isinstance(base, dict) or not isinstance(extra, dict):
        return base
    result = dict(base)
    for k, v in extra.items():
        if k in result:
            if isinstance(result[k], dict) and isinstance(v, dict):
                result[k] = deep_merge(result[k], v)
            # 否则保留 result[k](dest 优先)
        else:
            result[k] = v
    return result

merged = deep_merge(dest, src)
with open(dest_path, "w", encoding="utf-8") as f:
    json.dump(merged, f, ensure_ascii=False, indent=2)
    f.write("\n")
PYEOF
    then
      age_success "已深合并 $(basename "$src") → $dest"
      return 0
    else
      age_warn "python3 合并失败,回退为保留已有文件(不覆盖)。"
      return 0
    fi
  else
    # 无 python3:保守策略,保留 dest 不覆盖
    age_warn "已存在 $dest,无 python3 无法自动合并,保留已有文件不覆盖。"
    age_info "如需强制覆盖,请先备份并删除 $dest 后重跑 age install。"
    return 0
  fi
}

# _age_install_merge_toml <src> <dest>
# 合并两个 TOML 文件:TOML 无标准库可移植解析,采用"追加 AGE 段 + 去重"策略。
# 读取 src 中 [section] 段,若 dest 已有同名 section 则跳过,否则追加。
# 退出码:0 成功 / 1 失败
_age_install_merge_toml() {
  local src="$1" dest="$2"

  if [ ! -f "$src" ]; then
    age_warn "源 TOML 不存在: $src"
    return 0
  fi
  if [ ! -f "$dest" ]; then
    cp "$src" "$dest" 2>/dev/null && \
      age_success "已拷贝 config.toml → $dest" || \
      { age_error "拷贝失败: $dest"; return 1; }
    return 0
  fi

  # 提取 dest 已有的 section 名(形如 [xxx] 或 [xxx.yyy])
  # 用 grep 过滤再 strip,避免 awk 复杂转义
  local existing_sections
  existing_sections=$(grep -E '^[[:space:]]*\[[^]]+\]' "$dest" 2>/dev/null \
    | sed 's/[[:space:]]*//g' | sort -u)

  # 遍历 src,按 section 分块,dest 未有的 section 整块追加
  local tmp; tmp="$(mktemp)"
  local current_section=""
  local block_buf=""
  local src_section
  local added=0

  # 逐行读 src
  while IFS= read -r line || [ -n "$line" ]; do
    # 检测 section 头
    if echo "$line" | grep -qE '^[[:space:]]*\[[^]]+\]'; then
      # 先把上一个 block flush
      if [ -n "$current_section" ] && [ -n "$block_buf" ]; then
        src_section="$(echo "$current_section" | sed 's/[[:space:]]*//g')"
        if ! echo "$existing_sections" | grep -qxF "$src_section"; then
          printf '%s\n' "$block_buf" >> "$tmp"
          added=$((added + 1))
        fi
      fi
      current_section="$line"
      block_buf="$line"
    else
      if [ -n "$current_section" ]; then
        block_buf="$block_buf"$'\n'"$line"
      else
        # section 头之前的顶层键值对,直接追加(罕见)
        printf '%s\n' "$line" >> "$tmp"
      fi
    fi
  done < "$src"

  # flush 最后一个 block
  if [ -n "$current_section" ] && [ -n "$block_buf" ]; then
    src_section="$(echo "$current_section" | sed 's/[[:space:]]*//g')"
    if ! echo "$existing_sections" | grep -qxF "$src_section"; then
      printf '%s\n' "$block_buf" >> "$tmp"
      added=$((added + 1))
    fi
  fi

  if [ "$added" -gt 0 ]; then
    # 追加到 dest(加空行分隔)
    printf '\n# --- AGE plugin (merged by age install) ---\n' >> "$dest"
    cat "$tmp" >> "$dest"
    age_success "已合并 $added 个新配置段 → $dest (已有段保留)"
  else
    age_info "$dest 已包含所有 src 的配置段,无需合并。"
  fi
  rm -f "$tmp"
  return 0
}

# ---------------------------------------------------------------------------
age_install_help() {
  cat <<'EOF'
age install — 安装 AGE 适配配置到当前客户端

用法:
  age install [--client zcode|claude|codex|opencode|multica|win11] [--dry-run] [--list]

参数:
  --client NAME   手动指定客户端 (zcode|claude|codex|opencode|multica|win11)
                  不指定则自动检测当前环境
  --dry-run       预览将执行的安装操作,不实际写文件
  --list          列出所有支持的客户端及其兼容等级,不执行安装

兼容等级(CONTRACT §8.11 + §8.12 Win11):
  zcode    full(原生)    claude   full           codex    full
  opencode partial        multica  full(skill+MCP+autopilot,无本地 hooks)
  win11    full(PowerShell 原生 CLI + .ps1 hooks,不依赖 bash)

行为:
  自动检测当前宿主客户端(检查环境变量与配置目录特征):
    - ZCode:       ZCODE_PLUGIN_ROOT 或 .zcode/ 目录
    - Claude Code: CLAUDE_PLUGIN_ROOT 或 .claude/ 目录 或 ~/.claude/
    - Codex:       CODEX_HOME 或 ~/.codex/config.toml(含 [hooks] 段)
    - OpenCode:    OPENCODE_CONFIG 或 opencode.json 存在
    - Multica:     AGE_MULTICA_WORKSPACE 或 multica CLI 在 PATH 或
                   /Applications/Multica.app 或 ~/.multica/config.json
    - Win11:       $OS=Windows_NT 或 uname 含 MINGW/MSYS/CYGWIN/Windows

  按检测结果从 compat/<客户端>/ 拷贝适配配置:
    - zcode:    报告"原生插件,无需额外安装"
    - claude:   settings.json → .claude/settings.json
                .mcp.json → 项目根/.mcp.json
                CLAUDE.md → 项目根/CLAUDE.md
    - codex:    config.toml → ~/.codex/config.toml (合并)
                含 [mcp_servers] + [hooks] 段(SessionStart/PostToolUse/Stop)
    - opencode: opencode.json → 项目根/opencode.json (合并,无 hooks 键)
                plugin.ts → 项目根/plugin.ts (AGE plugin 模块,实现 Hooks 接口)
                package.json → 项目根/package.json (plugin 依赖)
                PARTIAL:plugin 模块含 chat.message(部分 SessionStart)、tool.execute.after(PostToolUse 对应);
                无 SessionStart/Stop 事件(不可行)
    - multica:  调 compat/multica/install.sh 注册 use-AGE 技能到 workspace
                (multica skill create,非拷贝配置文件);MCP/skill 绑定需额外
                跑 install.sh --agent <id>(age install 不带 --agent 仅注册技能)
                FULL 但无本地 hooks:SessionStart/Stop 由 use-AGE 技能 + autopilot 替代
    - win11:    拷贝 cli/age.ps1 + cli/lib/*.ps1 → ~/.age-cli/
                拷贝 hooks/scripts/*.ps1 + hooks/hooks.win11.json(若存在)
                提示把 ~/.age-cli 加入 PATH(§8.12 双层策略,不覆盖 bash CLI)
                FULL:PowerShell 原生 CLI + .ps1 hook 脚本,不依赖 bash

  多客户端共存检测:安装某客户端时若发现已有其他客户端配置,提示保持
  AGENTS.md/CLAUDE.md 同步。

  所有配置文件采用"合并而非覆盖"策略:已有文件深合并,保留用户已有值。
  (Multica 例外:它不是拷贝配置,而是 CLI 注册到云 workspace。
   Win11 例外:它拷贝 PS1 入口到独立目录,不修改项目配置。)

注意: Multica 已恢复(2026-07-11 本机验证 v0.3.43,真实 AI 客户端;
      之前拼写误作 "Mutica" 被误判为实验性语言而移除,已纠正)。
      Win11 双层策略(§8.12):优先 PowerShell 原生(不要求 Git-Bash),Git-Bash 作为回退。

退出码: 0 成功 / 1 失败
EOF
}

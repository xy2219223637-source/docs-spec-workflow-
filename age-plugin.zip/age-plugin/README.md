# AGE — Attractor-Guided Engineering

> 一句话定位:AGE 是**吸引子引导工程**插件,让仓库在 AI 辅助迭代中持续回归稳定的产品 / 设计 / 架构结构。

AI 辅助开发的最大风险不是单次代码质量,而是**结构漂移**——文档与代码脱节、决策失去依据、任务无人收尾。AGE 不试图"管住" AI,而是为仓库铺设一个**吸引子基线**(owner 文档:项目上下文、技术栈、约定、决策来源)。只要基线存在,**计划 / 测试 / 审计 / 日志**这些"支架"就能把每次迭代拉回稳定结构。

**核心理念:基线是吸引子,支架只有在吸引子存在后才有意义。** 先有 owner 文档基线,再谈计划与审计;否则支架无处附着。

- **吸引子** = `docs/context/`(项目上下文五件套)+ `AGENTS.md`(代理操作契约)+ `docs/index.md`(文档路由器)。它们定义"仓库应该长什么样"。
- **支架** = `hooks/`(事件触发)+ `skills/`(编排判断)+ `cli/`(确定性内核)+ `mcp/`(agent 感知)。它们把每次迭代拉回基线。

---

## 四层架构

AGE 是**分层系统**(非四选一)。四种形态各有不可替代的职责,组合而非择一——辩论结论见 `CONTRACT.md` §1。

| 层 | 形态 | 职责 | 不可替代之处 |
|---|---|---|---|
| 投递外壳 | **插件(plugin)** | 组件容器 + 事件触发器 | ZCode 扩展单元,把一切装进可分发的包 |
| 编排大脑 | **元 skill** | 判断层:路由 / 选技能 / 触发审计 | 需要语义判断,纯 CLI 做不到 |
| 确定性内核 | **CLI** | 覆盖 CI / headless / git 提交边界 | 必须可脱离会话运行,纯 skill 做不到 |
| 感知层 | **MCP server** | resources + tools,会话态可见 | agent 需要稳定 URI 读写仓库状态 |

四层缺一,AGE 要么无法分发,要么无法在 CI 跑,要么无法被 agent 调用。四层协作覆盖**四个时段**(编辑 / 会话 / 提交 / CI):

```
                  AGE 插件架构 · 四层 × 四时段

  ┌──────────────────────────────────────────────────────────────────────┐
  │  时段 →      编辑(edit)     会话(session)    提交(commit)      CI     │
  │  层 ↓                                                                │
  ├──────────────────────────────────────────────────────────────────────┤
  │  插件外壳    注册组件           装载 skill /         —            —     │
  │  (plugin)   声明 hooks         command / agent                    │
  │                                                                      │
  │  元 skill      —             route / doc-sync      —            —     │
  │  (编排大脑)                   / audit 编排                          │
  │              ┌────────── 语义判断层,被 hook / command 调用 ──────┐ │
  │              │                                                     │ │
  │  CLI          —             age route            age check      age ci │
  │  (确定性内核)                age sync             age audit    (strict │
  │                                                   --scope full) +sync)│
  │              └──────────── 确定性,CI / headless 可跑 ────────────┘ │
  │                                                                      │
  │  MCP server   —           resources / tools        —            —     │
  │  (感知层)     (会话态)    docs://index             (会话态可见)        │
  │                            docs://status                              │
  │                            age_route / age_check_drift               │
  └──────────────────────────────────────────────────────────────────────┘
        ▲                                                                  ▲
        │                                                                  │
   吸引子基线(docs/context + AGENTS.md + docs/index.md) ─────────────────┘
   计划 / 测试 / 审计 / 日志 = 支架,只在基线存在后才有意义
```

**数据流:**

- **编辑时段** — `PostToolUse` hook → `on-edit.sh` → `age sync --json`,实时提醒漂移(stale / orphan / missing)。
- **会话时段** — `SessionStart` hook 注入 `docs/context/` 摘要;元 skill 在任务前 `route`、任务后 `doc-sync`;MCP 让 agent 读写 `docs://status`。
- **提交时段** — pre-commit 调 `age check --strict`;`age audit --scope closure` 收尾。
- **CI 时段** — `age ci` = `check --strict` + `sync --json`,非交互、确定性,按退出码阻断 pipeline。

---

## 快速开始

三步进入 AGE 循环:**install → use → route**。

```bash
# 1. 安装 AGE 适配到当前客户端(自动检测;ZCode 原生则跳过)
age install

# 2. 在项目里激活 AGE(未初始化时自动 age init,生成 docs/ + AGENTS.md + 基线)
age use

# 3. 开发任务前路由:读哪些 owner 文档、标记回写集
age route implement-login
# ... 写代码 / 让 AI 写代码 ...
# 任务后:age sync 报漂移;收尾:age audit --scope closure
```

**零门槛入口**:不想记命令,直接对 AI 说「启动 AGE」「开启 AGE」「enable AGE」「use AGE」等相同语义的话,`use-AGE` 技能会自动激活并完成上述流程(详见 [use-AGE 功能](#use-age-功能))。

**手动四步(逐步控制):**

```bash
age init --name myproj --kind web    # 1. 初始化骨架 + Day 0 引导
$EDITOR START-HERE-after-copy.md     # 2. 填 Day 0:docs/context/ 五件套
age baseline                         # 3. 生成基线快照(漂移的参照系)
age route <task>                     # 4. 进入开发循环:前路由 → 后同步 → 周期审计
age sync
age audit --scope closure
```

> 前置依赖:`git`、`bash`、`python3`(MCP server)、`jq`(`age sync --json` 解析)。运行 `age doctor` 检查环境。

---

## CLI 命令参考

`cli/age` 是确定性内核,10 个子命令,覆盖 CI / headless / git 提交边界。所有判断层的最终落点。

| 命令 | 作用 | 退出码 | 典型调用方 |
|---|---|---|---|
| `age init` | 初始化 AGE 项目结构 + Day 0 引导(渲染模板、生成基线) | 0 / 1 | `/age-init`、SessionStart(首次) |
| `age use` | 激活 AGE:检测 + 未初始化则自动 init + 报告状态 | 0 / 1 | `/use-age`、自然语言触发 |
| `age install` | 安装 AGE 适配配置到当前客户端(自动检测 / `--client` 指定) | 0 / 1 | 手动、CI 引导 |
| `age check` | 静态一致性校验:路由死链 / 基线齐全 / AGENTS 引用可解析(`--strict` warning 也算失败) | 0 / 1 | pre-commit、CI、`/age-audit` |
| `age sync` | 检测代码-文档漂移(stale / orphan / missing),`--json` 输出结构化 | 0 无漂移 / 1 有漂移 | `PostToolUse` hook、`/age-sync` |
| `age route <task>` | 按 `docs/index.md` 路由到 owner 文档 + 技能(`--explain` 给理由) | 0 命中 / 1 未命中 | MCP `age_route`、`/age-route` |
| `age audit` | 文档与代码一致性审计(`--scope full` / `plan` / `closure`) | 0 通过 / 1 违规 | `Stop` hook、`/age-audit` |
| `age doctor` | 环境与配置诊断(git / python3 / jq / 基线 / 路由) | 0 健康 / 1 有问题 | `age init` 前、SessionStart |
| `age ci` | 非交互 = `check --strict` + `sync --json`,CI 流水线按退出码阻断 | 0 / 1 | CI 流水线 |
| `age baseline` | 快照当前 `docs/` 指纹到 `.age/baseline.json` | 0 / 1 | `age init` 后 |

退出码约定:CI 类命令 `0` = 通过、`1` = 失败。运行 `age <command> --help` 查看子命令详情;`AGE_NO_COLOR=1` 禁用颜色输出。

---

## 多客户端兼容

AGE 以 ZCode 为一等宿主(完整插件),同时通过 `compat/` 适配层让 Claude Code / Codex CLI / OpenCode CLI / Multica 复用同一套**公共核心**(`cli/age` + `AGENTS.md` + `mcp/server.py`)。各客户端差异仅在 hooks 事件名、MCP 配置键、skills / commands 存放格式,由适配层桥接。

**5 客户端兼容矩阵:**

| 客户端 | 等级 | 机制 | 适配目录 |
|---|---|---|---|
| ZCode | full(原生) | `plugin.json` + skills + commands + hooks + MCP | `.zcode-plugin/`(无需适配) |
| Claude Code | full | `.claude/` + `settings.json` + `.mcp.json` + `CLAUDE.md` | `compat/claude-code/` |
| Codex CLI | full | `config.toml`(MCP + hooks + skills) | `compat/codex/` |
| OpenCode CLI | partial | `opencode.json` + `plugin.ts`(MCP + commands,无 SessionStart/Stop) | `compat/opencode/` |
| Multica | full | `multica skill create` + `agent --mcp-config` + autopilot | `compat/multica/` |

**平台兼容矩阵(操作系统层):**

| 平台 | 原生 shell | 兼容等级 | 入口 |
|---|---|---|---|
| macOS / Linux | bash | full | `cli/age`(POSIX shell) |
| Windows 11 | PowerShell 5.1+ | full(PowerShell 原生 + Git-Bash 回退) | `cli/age.ps1`(PowerShell) / `cli/age`(Git-Bash) |

> **Windows 11 双层兼容策略**(详见 [`compat/win11/README.md`](compat/win11/README.md)):
> 1. **PowerShell 原生层**(首选)—— `cli/age.ps1` + `hooks/scripts/*.ps1` + `hooks/hooks.win11.json`,不依赖 bash。
> 2. **Git-Bash 回退层**—— 现有 bash 脚本在 Git-Bash(随 Git for Windows 安装)下直接可用。
>
> 优先 PowerShell 原生(不要求用户装 Git-Bash),Git-Bash 作为回退。Win11 上 Python 通常是 `python`(不含 3),CLI 会按 `python` → `python3` → `py -3` 顺序检测。

**功能降级矩阵:**

| 功能 | ZCode | Claude Code | Codex CLI | OpenCode CLI | Multica |
|---|---|---|---|---|---|
| MCP(resources + tools) | 有 | 有 | 有 | 有 | 有(`agent --mcp-config`) |
| 指令文件 | AGENTS.md | CLAUDE.md | AGENTS.md | AGENTS.md | `agent --instructions`(=AGENTS.md) |
| Skills(use-AGE / age 等) | 有 | 有 | 有(`.codex/skills/`) | 无(用 commands 替代) | 有(`skill create` 注册到 workspace) |
| Slash commands | 有 | 有 | 无(用 AGENTS.md 引导) | 有(内联 prompt) | 无(用 skill + autopilot 替代) |
| SessionStart hook | 有 | 有 | 有 | 无(`chat.message` 部分替代) | 无(use-AGE 技能显式激活替代) |
| PostToolUse hook | 有 | 有 | 有 | 有(`tool.execute.after`,plugin hook) | 无(autopilot 定时 `age sync` 部分替代) |
| Stop hook | 有 | 有 | 有 | 无 | 无(autopilot 定时 + 对话中触发) |

> **Multica 的 full 级**与 ZCode / Claude Code / Codex 略有差异:它没有本地 hooks,但用 **use-AGE 技能**(用户显式激活,替代 SessionStart 的一次性上下文注入)+ **autopilot**(定时 schedule 触发 `age sync`,部分替代 Stop 的 closure audit)补齐了等价能力,故仍为 full 级而非 partial。
>
> **OpenCode CLI 的 partial 级**:hooks 是 plugin 模块机制(须实现 `Hooks` 接口写成 `plugin.ts`,不能在 `opencode.json` 配置),仅有 `tool.execute.after`(PostToolUse 对应)、`tool.execute.before`(PreToolUse 对应)、`chat.message`(部分替代 SessionStart),**无 SessionStart / Stop**。漂移检测与收尾审计靠 `/age-sync`、`/age-audit` 命令手动触发。
>
> 兼容事实以 `CONTRACT.md` §8.11 的 CP-1 校验结论(2026-07-11,源码验证)+ Multica 恢复(2026-07-11,本机验证 v0.3.43)为准。

---

## use-AGE 功能

`use-AGE` 是 AGE 的零门槛入口:用户用**自然语言**说"启动 AGE"即可自动激活;若当前项目未初始化,自动执行 `age init` 完成初始化,无需手动跑脚手架。

**触发方式(三种等价):**

| 方式 | 入口 | 适用场景 |
|---|---|---|
| 自然语言 | 对 AI 说「启动 AGE」「开启 AGE」「enable AGE」「use AGE」等 | 交互式会话(最自然) |
| Slash command | `/use-age` | 显式触发 |
| CLI | `age use` | CI / headless / 确定性 |

**触发词覆盖(中英文 + 语义变体):**

- 中文:开启AGE、启动AGE、用AGE、使用AGE、激活AGE、启用吸引子工程、开始AGE
- 英文:enable AGE、start AGE、use AGE、activate AGE、turn on AGE、init AGE
- 语义变体:"帮我设置AGE"、"这个项目用AGE吧"、"装一下AGE"

**`age use` 行为:** 检测当前项目是否已初始化 → 未初始化则用默认值自动执行 `age init`(生成 `docs/`、`AGENTS.md`、`.age/baseline.json`)→ 报告激活状态。已初始化的项目只报告"AGE 已激活",不重复 init。非 git 目录会优雅降级(警告但仍可初始化)。

---

## 目录结构

```
age-plugin/
├── .zcode-plugin/              # ZCode 插件清单
│   ├── plugin.json             #   manifest:声明 skills/commands/hooks/agents/mcpServers/userConfig
│   └── userConfig-schema.json  #   Day 0 个性化字段 schema
├── skills/
│   ├── age/                    # 元 skill(编排大脑)
│   │   ├── SKILL.md            #   主文件:编排四子流程(age-init/route/doc-sync/audit)
│   │   └── references/         #   路由表 / 基线 schema / 同步清单
│   └── use-AGE/                # 入口技能(自然语言触发,中英文触发词)
├── commands/                   # slash commands:/age-init /age-route /age-sync /age-audit /use-age 等
├── hooks/
│   ├── hooks.json              # 事件触发配置(SessionStart / PostToolUse / Stop)
│   ├── hooks.win11.json        # Win11 事件触发配置(指向 .ps1 脚本)
│   └── scripts/                # on-session-start / on-edit / on-stop + lib(.sh + .ps1 各一套)
├── agents/                     # 子代理
│   ├── doc-auditor.md          #   扫 backlog/requirements 与代码一致性
│   ├── bug-tracker.md          #   归档复杂回归
│   ├── plan-reviewer.md        #   审查 docs/plans 的收尾规则
│   └── age-activator.md        #   激活子代理(use-AGE)
├── cli/                        # CLI 确定性内核
│   ├── age                     #   主入口(路由分发,POSIX shell)
│   ├── age.ps1                 #   PowerShell 入口(Win11 原生层,等价 cli/age)
│   └── lib/                    #   9 个核心函数库(init/sync/check/ci/route/audit/doctor/use/install + common)
├── mcp/
│   ├── server.py               # MCP server(感知层:resources + tools,纯 stdlib)
│   └── requirements.txt        # 依赖清单(无第三方依赖)
├── compat/                     # 多客户端 / 跨平台兼容层
│   ├── claude-code/            #   Claude Code 适配(.claude/ + .mcp.json + CLAUDE.md)
│   ├── codex/                  #   Codex CLI 适配(config.toml: MCP + hooks + skills)
│   ├── opencode/               #   OpenCode CLI 适配(opencode.json + plugin.ts)
│   ├── multica/                #   Multica 适配(skill create + agent --mcp-config + autopilot)
│   └── win11/                  #   Windows 11 适配(PowerShell 原生层:path-utils.ps1 + env-template.ps1)
├── templates/repo/             # Day 0 骨架模板(44 文件,age init 渲染到目标仓库)
│   ├── AGENTS.md               #   代理操作契约模板
│   ├── START-HERE-after-copy.md#   Day 0 清单
│   └── docs/
│       ├── index.md            #   文档路由器模板(意图式路由表)
│       ├── context/            #   五件套强制上下文(project-context/codebase-map/conventions/ai-autonomy-policy/source-of-truth)
│       ├── {backlog,requirements,design,architecture,plans,audits,logs,bugs,testing,...}/
│       ├── examples/           #   完整示例(feature-plan/requirement/closure-audit + small-app-walkthrough)
│       ├── process/            #   工作流(application-development-workflow)
│       └── articles/           #   方法论(attractor-before-harness.md)
├── tests/                      # bats 测试套件(契约驱动)
│   ├── helpers/test_helper.bash
│   ├── test_cli.bats           #   CLI 子命令
│   ├── test_compat.bats        #   多客户端兼容
│   ├── test_install.bats       #   age install
│   ├── test_hooks.bats         #   hook 事件
│   ├── test_mcp.bats           #   MCP server
│   ├── test_templates.bats     #   模板渲染
│   ├── test_use_age.bats       #   use-AGE 功能
│   └── test_win11.bats         #   Windows 11 兼容(PowerShell 原生层)
└── docs/                       # 插件自身的设计 / 审批 / 风险文档
```

---

## 安装方式

三种安装方式,按宿主客户端选择。

### 方式一:ZCode 原生(推荐)

AGE 是 ZCode 插件。在 ZCode 客户端 **Settings → Plugin Management → Discover**,添加本插件所在 marketplace(本地目录或 Git 仓库),然后安装 `age`。安装后插件自动启用其 skills / commands / hooks / MCP server / agents。

```bash
# 本地开发安装(软链到插件目录)
ln -s /path/to/age-plugin ~/.zcode/plugins/age
# 让 age CLI 可被发现(可选,用于 CI / headless)
ln -s /path/to/age-plugin/cli/age /usr/local/bin/age
# 验证
age doctor
```

安装后,ZCode 会在会话开始时自动连接插件提供的 MCP server(`age`),并注册三个 hook(SessionStart / PostToolUse / Stop)。MCP server 是 workspace 信任、自动连接的,无需手动授权。

### 方式二:`age install` 自动适配

`age install` 自动检测当前宿主客户端,并把对应适配配置写入正确位置:

```bash
age install --list                 # 列出所有支持的客户端
age install                        # 自动检测客户端并安装
age install --client claude        # Claude Code
age install --client codex         # Codex CLI
age install --client opencode      # OpenCode CLI
age install --client multica       # Multica(调 compat/multica/install.sh 注册技能到 workspace)
age install --client win11         # Windows 11(安装 PowerShell 原生入口 cli/age.ps1 + .ps1 hooks)
age install --client zcode         # ZCode(报告:已是原生插件,无需适配)
```

在无法检测到任何客户端的环境下,命令会优雅报告(不崩溃)。

> Multica 的安装与其他客户端不同:它不是拷贝配置文件,而是调用 `multica` CLI 把 use-AGE 技能注册到云 workspace。`age install --client multica` 仅注册技能;绑定 MCP + 技能到 agent 需额外跑 `compat/multica/install.sh --agent <agent-name-or-id>`(配置 `agent --mcp-config` + `--skill-ids` + `--custom-env` + 可选 autopilot)。

### Windows 11 安装

Windows 11 原生无 bash,AGE 采用**双层兼容策略**:

1. **PowerShell 原生层(首选)** —— `cli/age.ps1`(PowerShell CLI 入口)+ `hooks/scripts/*.ps1`(PowerShell hook 脚本)+ `hooks/hooks.win11.json`(指向 .ps1 脚本)。不依赖 bash。
2. **Git-Bash 回退层** —— 现有 bash 脚本(`cli/age` + `hooks/scripts/*.sh`)在 Git-Bash(随 [Git for Windows](https://git-scm.com/download/win) 安装)下直接可用。

**前置依赖:**

- **PowerShell 5.1+**(Win11 预装 PowerShell 5.1;可选装 PowerShell 7)
- **Python**(MCP server 依赖;Win11 上通常是 `python` 而非 `python3`,CLI 按 `python` → `python3` → `py -3` 顺序自动检测)
- **Git**(可选,用于 `age sync` 漂移检测;装 Git for Windows 即同时获得 Git-Bash 回退层)

**安装:**

```powershell
# PowerShell 原生安装:安装 PowerShell CLI 入口 + .ps1 hooks 配置
age install --client win11

# 验证环境(git / python / jq / 基线 / 路由)
age doctor

# 在项目里激活 AGE(未初始化时自动 age init)
age use
```

> 路径与环境变量:Win11 上 AGE 用 `$env:AGE_PLUGIN_ROOT`(PowerShell)/ `%AGE_PLUGIN_ROOT%`(CMD)定位插件根,而非 bash 的 `$AGE_PLUGIN_ROOT`。`compat/win11/path-utils.ps1` 提供 `Convert-ToWinPath`(POSIX↔Win 路径转换)与 `Find-PluginRoot`(插件根自动探测)工具函数;`compat/win11/env-template.ps1` 是环境变量模板。详见 [`compat/win11/README.md`](compat/win11/README.md)。
>
> 行结束符:仓库建议配置 `.gitattributes`(`* text=auto eol=lf`),避免 CRLF/LF 混入导致 `age check`/`age sync` 路径解析偏差。

### 方式三:手动拷贝

若不想用 `age install`,可直接拷贝 `compat/<客户端>/` 下的配置到对应位置:

```bash
# Claude Code:settings.json 放 .claude/,.mcp.json 放工作区根,CLAUDE.md 放工作区根
mkdir -p .claude
cp compat/claude-code/settings.json .claude/settings.json
cp compat/claude-code/.mcp.json       .mcp.json
cp compat/claude-code/CLAUDE.md       ./CLAUDE.md

# Codex CLI:config.toml(含 [mcp_servers] + [hooks] 段)放到 ~/.codex/
cp compat/codex/config.toml ~/.codex/config.toml

# OpenCode CLI:opencode.json 放工作区根,再 opencode plugin 安装 plugin.ts
cp compat/opencode/opencode.json opencode.json

# Multica:调 install.sh 注册 use-AGE 技能到云 workspace(非拷贝配置文件)
compat/multica/install.sh --dry-run                    # 预览
compat/multica/install.sh                              # 仅注册技能
compat/multica/install.sh --agent <agent-name-or-id>   # 注册技能 + 绑定 MCP/skill/env + 可选 autopilot
```

各客户端的详细适配说明见对应 `compat/<客户端>/README.md`。MCP server 复用同一个 `mcp/server.py`,各适配配置只是以不同格式指向它。

> 跨客户端复用的公共层是 CLI(`cli/age`)、指令文件(`AGENTS.md`)、MCP server(`mcp/server.py`)——它们与具体客户端无关。

---

## 配置:userConfig

AGE 在 `.zcode-plugin/userConfig-schema.json` 声明 Day 0 个性化字段。安装时 ZCode 会引导填写,值用于渲染 `templates/repo/` 中的 `{{...}}` 占位符(统一 `{{}}` 风格)。

**五个 Day 0 核心字段**(决定 `AGENTS.md` 与 `docs/context/` 的骨架):

| 字段 | 作用 | 示例 |
|---|---|---|
| `owner_name` | owner 身份,写入 AGENTS.md | `张三` |
| `project_kind` | 仓库类型(web / mobile / cli),影响脚手架与 codebase-map 骨架 | `web` |
| `doc_language` | 文档 / 交互语言,写入 AGENTS.md 与 conventions.md | `中文` |
| `require_backlog` | 是否强制 backlog(`false` 时不强制生成 docs/backlog/ 内容) | `true` |
| `validate_cmd` | 验证命令(测试 / 构建),空则收尾审计跳过验证步骤 | `npm test` |

项目上下文字段(`project_name`、`project_description`、`target_users`、`current_phase`、`tech_stack` 等)写入 `docs/context/project-context.md` 等,详见 schema 的 `_age_render_targets` 注解。字段最终定义以 `.zcode-plugin/userConfig-schema.json` 为准。

---

## 测试

```bash
# 运行全部 bats 测试(契约驱动,覆盖 CLI / hook / MCP / template / 兼容层 / install / use-age)
bats tests/

# 单个套件
bats tests/test_cli.bats          # 27 测试:CLI 子命令
bats tests/test_compat.bats       # 47 测试:多客户端兼容
bats tests/test_install.bats      # 14 测试:age install
bats tests/test_hooks.bats        # 12 测试:hook 事件
bats tests/test_mcp.bats          # 12 测试:MCP server
bats tests/test_templates.bats    # 17 测试:模板渲染
bats tests/test_use_age.bats      # 12 测试:use-AGE 功能
bats tests/test_win11.bats        # 36 测试:Windows 11 兼容(PowerShell 原生层)
```

全套 **177 个测试**,针对 `CONTRACT.md` 的契约(§3 / §4 / §5 / §8.12)编写,不依赖任何 agent 的实现细节——**契约先行**。测试是契约的守卫,不是实现的附庸:若实现 agent 调整行为偏离契约,测试将失败,此时应优先修实现或更新契约,而非改测试。

> 运行测试需 [bats-core](https://github.com/bats-core/bats-core)。安装:`git clone https://github.com/bats-core/bats-core && cd bats-core && ./install.sh /tmp/bats-prefix`,然后用 `/tmp/bats-prefix/bin/bats tests/` 运行。部分测试在 macOS BSD awk 下因路由解析器边界问题会 skip(详见 `CONTRACT.md` §8.9 [CR-1])。

---

## AGE 插件与 AGE 模板的关系

AGE 最早是一份**纯模板**(一组 docs 目录约定 + 文章方法论)。模板回答了"仓库应该长什么样",但不回答"怎么在 AI 迭代中保持这样"——它只是静态文件,没有触发器、没有判断、没有 CI。

**本插件是 AGE 模板的可执行形态:**

- **模板** = 吸引子(owner 文档基线),定义目标结构。
- **插件** = 支架(计划 / 测试 / 审计 / 日志的执行机制),把每次迭代拉回目标结构。

`templates/repo/` 就是模板本身,被 `age init` 复制进新仓库;而 `hooks/` `skills/` `cli/` `mcp/` 是让模板"活起来"的支架。没有模板,插件无从初始化;没有插件,模板在 AI 迭代下会迅速漂移。两者是吸引子与支架的关系——详见 `templates/repo/docs/articles/attractor-before-harness.md`。

---

## 设计文档索引

`docs/` 是插件自身的设计 / 审批 / 风险文档(非渲染到目标仓库的模板)。以下文档记录了 AGE 插件的形态辩论、方案审批、风险登记与改进建议。

| 文档 | 内容 |
|---|---|
| `docs/index.md` | 插件自身的文档路由器(内部导航,与 `CONTRACT.md` 同源) |
| `docs/design-review.md` | 形态裁决与方案审批的详细论证( CONDITIONALLY APPROVED ) |
| `docs/approval.md` | 方案审批结论(条件通过,含阻断级缺陷清单) |
| `docs/risk-register.md` | 风险登记(形态辩论期的风险与缓解) |
| `docs/improvement-proposals.md` | 改进建议(v1.1 路线图) |
| `docs/use-age-design.md` | use-AGE 功能设计审查与审批(自然语言触发 + 自动初始化) |
| `docs/compat-design-review.md` | 多客户端兼容设计审查(CP-1 源码校验后,Codex 升级 / OpenCode 降级 / Multica 恢复) |
| `docs/compat-risk-register.md` | 多客户端兼容风险登记 |

> `CONTRACT.md`(项目根)是所有 agent 间的共享契约,事实层基线,与 `docs/index.md` 同源。新 agent 接手 AGE 插件的推荐阅读顺序:`CONTRACT.md` → `docs/index.md` → `skills/age/SKILL.md` → `skills/age/references/*.md` → 对应所有权的目录。

---

## 设计来源

- 形态裁决、目录所有权、CLI / MCP / Hook 契约:`CONTRACT.md`(§1-§8)
- 文档路由器:`docs/index.md`(插件自身)
- 方法论:"吸引子先于支架"——见 `templates/repo/docs/articles/attractor-before-harness.md`
- 插件版本号:`.zcode-plugin/plugin.json` 的 `version` 字段

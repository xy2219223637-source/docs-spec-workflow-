# AGE Plugin 方案审查报告

> 审查对象:`CONTRACT.md`(共享契约 v1)
> 审查角色:方案审批与建议 agent
> 审查日期:2026-07-11
> 审查基线:`/Users/ale/ZCodeProject/age-plugin/CONTRACT.md`(94 行,8 节)
> 审查状态:基于契约原文,未引用尚未产出的实现代码(并发构建中)

---

## 0. 审查范围与方法

本报告审查 `CONTRACT.md` 所定义的 AGE 插件分层架构方案,覆盖:

1. 分层架构合理性(第 1 节)
2. 接口自洽性:CLI(第 3 节)↔ MCP(第 4 节)↔ Hook(第 5 节)↔ 元 skill(第 6 节)
3. 文件所有权划分(第 2 节)
4. 子代理契约(第 7 节)
5. 并发构建集成风险
6. 审查结论

审查方法:逐节比对契约内部一致性,识别断点、命名歧义、状态缺口、跨层语义错配。每条发现标注**严重度**(阻断/重要/次要)与**契约定位**(节号)。

---

## 1. 架构审查:分层是否合理

### 1.1 四层模型(第 1 节)

契约第 1 节定义四层:

| 层 | 职责 | 性质 |
|---|---|---|
| 插件(plugin) | 投递外壳 + 事件触发器 | 扩展单元 |
| 元 skill | 编排大脑(路由/选技能/触发审计) | 判断层 |
| CLI | 确定性内核(CI/headless,git/提交边界) | 确定性 |
| MCP server | agent 感知层(resources + tools) | 会话态可见 |

**结论:分层合理。** 四层按"投递 → 判断 → 确定性 → 感知"正交分解,每层有独立的存在理由:插件层解决分发,skill 层解决路由智能,CLI 层解决可复现/CI,MCP 层解决 agent 运行时可见性。这是比"四选一"更稳健的裁决。

### 1.2 四层 ↔ 四态覆盖

任务背景要求四层覆盖"编辑态/会话态/提交态/CI态"。逐态核对:

| 态 | 覆盖层 | 契约依据 | 评估 |
|---|---|---|---|
| 编辑态 | Hook PostToolUse(`Edit\|Write\|MultiEdit`)→ `age sync` | 第 5 节 | 充分 |
| 会话态 | MCP resources/tools(会话态可见)+ 元 skill route | 第 1、4、6 节 | 充分 |
| 提交态 | CLI `age check`(pre-commit)+ `age baseline` | 第 3 节 | 充分 |
| CI 态 | CLI `age ci` = `check --strict` + `sync --json` | 第 3 节 | 充分 |

**结论:四态覆盖充分。** 但**契约未显式声明"层→态"映射表**(第 1 节只给层,不给态)。这导致实现者需自行推断,存在推断偏差风险。

> **发现 D-1(重要):第 1 节缺少"层→态"显式映射。** 建议在第 1 节补一张层/态覆盖矩阵,使"四层覆盖四态"从隐含变为契约级断言,便于后续 `age check` 校验。

### 1.3 确定性边界

CLI 被定位为"确定性内核",覆盖 CI/headless。但第 3 节所有命令实现于 `cli/age`(shell)+ `cli/lib/*.sh`(shell 库),依赖 POSIX shell。

> **发现 D-2(重要):CLI 确定性依赖 POSIX shell,未声明跨平台策略。** `hooks/scripts/*.sh` 同样为 shell。Windows 原生环境(无 bash)下 CLI 与 hook 均无法运行,"CI 态覆盖"在 Windows CI 上失效。契约应声明目标平台矩阵(macOS/Linux/WSL/Git-Bash/原生 Windows)及最低 shell 要求。

---

## 2. 接口自洽性审查

### 2.1 CLI ↔ MCP 工具对齐(第 3 节 ↔ 第 4 节)

逐条核对 MCP tools 与 CLI 命令的对应关系:

| MCP tool | 对应 CLI 命令 | 一致性 |
|---|---|---|
| `age_route(task)` | `age route <task>` | 一致 |
| `age_check_drift(scope?)` | `age sync [--since REF] [--json]` | **命名错配** |
| `age_propose_doc_update(change)` | 无直接对应 | **缺 CLI 后端** |
| `age_evolve(task_id)` | 无直接对应 | **缺 CLI 后端** |

> **发现 D-3(阻断):MCP 工具 `age_propose_doc_update` 与 `age_evolve` 无 CLI 后端。** 契约第 1 节明确"CLI = 确定性内核,覆盖 CI/headless"。MCP 是会话态感知层,其可变操作(propose/evolve)若没有 CLI 等价物,则 CI/headless 路径无法复现这两类操作,违反"确定性内核"原则。需补 `age propose` 与 `age evolve` CLI 子命令,或在契约中显式声明这两个 MCP 工具为"仅会话态、无 CI 镜像"并说明理由。

> **发现 D-4(重要):`age_check_drift` ↔ `age sync` 命名错配。** 同一概念(漂移检测)在 MCP 层叫 `age_check_drift`,在 CLI 层叫 `sync`,在元 skill 层(第 6 节)叫 `doc-sync`。三处三个名字,实现者需自行建立映射,易引入隐性 bug。建议统一语义根名(如 `drift`),各层用一致前缀/后缀。

### 2.2 Hook ↔ CLI 对齐(第 5 节 ↔ 第 3 节)

| Hook 事件 | 调用 | CLI 契约匹配 |
|---|---|---|
| SessionStart | `age route` 判定 + 读 context | **语义错配** |
| PostToolUse | `on-edit.sh` → `age sync --json` | 匹配 |
| Stop | `on-stop.sh` → `age audit --scope closure` | 匹配 |

> **发现 D-5(阻断):SessionStart 调用 `age route` 存在语义错配。** `age route <task>`(第 3 节)要求 `<task>` 参数,语义是"给定任务,路由到 owner 文档"。但 SessionStart 在会话开始时触发,**此时尚无任务**。契约写"`age route` 判定",但 `route` 无任务可路由。需澄清:SessionStart 实际应调用 `age doctor`(诊断)或 `age baseline`/读 `docs://context`,而非 `age route`。当前描述会导致 hook 在每次会话启动时因缺参数而失败。

### 2.3 元 skill 子流程 ↔ CLI 对齐(第 6 节 ↔ 第 3 节)

第 6 节四个子流程:

| 子流程 | 触发边界 | 对应 CLI | 一致性 |
|---|---|---|---|
| `age-init` | 新仓库/套模板 | `age init` | 一致 |
| `route` | 任务开始前 | `age route` | 一致 |
| `doc-sync` | 任务结束后 | `age sync` | 命名错配(D-4) |
| `audit` | 周期/显式 | `age audit` | 一致 |

第 6 节 `route` 子流程"标记回写集",`doc-sync` 子流程"对照回写集更新文档"。

> **发现 D-6(重要):回写集(writeback set)存储位置未定义。** `route` 标记的回写集由谁写、写到哪里(`.age/`?会话内存?)、`doc-sync` 如何读取,契约未规定。`age baseline` 写 `.age/baseline.json` 有明示,但回写集无对应状态文件契约。这是 route→doc-sync 闭环的关键状态,缺失将导致 doc-sync 无据可依。

### 2.4 退出码语义

第 3 节退出码多为 0/1,但语义不统一:

- `age sync`:0 无漂移 / 1 有漂移(漂移是"预期状态",非错误)
- `age check`:0 / 1
- `age ci` = `check --strict` + `sync --json`:组合后退出码未定义(check 过但 sync 有漂移时,`age ci` 返回 0 还是 1?)
- `age baseline`:仅 0(无失败码)

> **发现 D-7(次要):`age ci` 组合退出码与 `age baseline` 缺失败码未定义。** 建议明确:多命令组合时取"最严重"退出码;`age baseline` 补 0/1。

### 2.5 MCP 返回形状与 CLI 退出码的不对称

`age route` CLI 返回 0命中/1未命中(布尔语义),MCP `age_route` 返回 `{doc, skill, reason}`(结构语义)。未命中时 MCP 返回什么?空 doc?error?契约未规定。

> **发现 D-8(次要):MCP `age_route` 未命中时返回形状未定义。** 建议规定:未命中时返回 `{doc: null, skill: null, reason: "no-match"}` 且 tool 不抛错,保持与 CLI 退出码对称的可观测性。

---

## 3. 所有权划分审查(第 2 节)

### 3.1 所有权表完整性

第 2 节列出 19 条路径,归属 5 个 owner agent:事实设计、过程计划、任务执行、总调度、代码审查。

> **发现 D-9(阻断):第 2 节所有权表缺失"方案审批 agent"及其 9 个文件。** 任务背景明确存在第 6 个 agent(方案审批),其所有权文件包括 `docs/design-review.md`、`docs/approval.md`、`docs/risk-register.md`、`docs/improvement-proposals.md`、`templates/repo/docs/examples/README.md` 及 4 个 examples 文件。这些路径在所有权表中**全部缺席**。后果:
> - `docs/` 目录下除 `docs/index.md`(事实设计)外,其余 docs 文件所有权悬空,任何 agent 都可能误写,引发并发冲突。
> - `templates/repo/docs/examples/` 是否归属"过程计划"(因 `{backlog,...,testing,...}/README.md` 的 `...` 省略号)还是"方案审批",语义歧义。
>
> **修复:在第 2 节补"方案审批"agent 列,显式登记其 9 个文件。**

### 3.2 `.age/` 运行时状态目录所有权

`age baseline` 写 `.age/baseline.json`(第 3 节),回写集预期也落 `.age/`(D-6)。但 `.age/` 目录的格式定义、schema 文档所有权未在表中分配。

> **发现 D-10(重要):`.age/` 运行时状态文件(baseline.json、回写集、漂移缓存)的 schema 所有权未分配。** 建议归属"总调度"(CLI 实现者)并补 schema 文档路径(如 `cli/lib/.age-schema.md` 或 `docs/index.md` 引用)。

### 3.3 MCP 依赖与测试归属

`mcp/server.py` 归总调度,但 `mcp/` 下的依赖清单(`requirements.txt`/`pyproject.toml`)与 MCP 单元测试未在表中。

> **发现 D-11(重要):MCP server 依赖清单与测试无 owner。** `tests/*.bats`(代码审查)仅覆盖 CLI/hook(bats 是 bash 测试框架),Python MCP server 无测试 owner。建议:总调度补 `mcp/requirements.txt` 与 `tests/test_mcp.py`(或归代码审查扩展测试范围)。

### 3.4 跨平台 CLI 入口

`cli/age` 为 POSIX 入口,Windows 包装(`cli/age.cmd`/`cli/age.bat`)未在表中。

> **发现 D-12(次要):Windows CLI 入口无 owner。** 若决定支持原生 Windows(D-2),需补 `cli/age.cmd` 所有权(归总调度)。

---

## 4. 子代理契约审查(第 7 节)

第 7 节三个子代理:doc-auditor、bug-tracker、plan-reviewer。

> **发现 D-13(阻断):`plan-reviewer` 触发条件"方案审批 agent 调用"存在角色混淆。** 任务背景将"方案审批 agent"定义为**构建期**角色(产出审批文档),而 `plan-reviewer` 是**运行期**子代理(在 `agents/plan-reviewer.md`,会话中触发)。构建期 agent 无法"调用"运行期子代理——两者生命周期不同。契约将两个角色混用"方案审批"一词。需澄清:
> - 若 `plan-reviewer` 是运行期审计子代理,其触发应为运行期事件(如 `/age-audit --scope plan` 或 plan 收尾命令),而非"方案审批 agent 调用"。
> - "方案审批 agent"(构建期)与"plan-reviewer 子代理"(运行期)应使用不同名称,避免歧义。

> **发现 D-14(次要):doc-auditor 触发"/age-audit"未规定 `--scope`。** `age audit` 有 `full|plan|closure` 三档,doc-auditor 默认档未声明。建议补默认 `--scope full`。

---

## 5. 并发构建集成风险(6 agent 并行)

6 个 agent 并发构建,集成风险来源:

1. **接口实现漂移**:总调度实现 CLI/MCP,任务执行实现 hook,双方都依赖第 3-5 节契约。若任一方对契约解读不同(如 D-4 命名错配、D-5 SessionStart 语义),集成时 hook 调用 CLI 会失败。
2. **模板路径冲突**:`templates/repo/docs/` 下,事实设计(AGENTS.md、index.md、context/)与过程计划(各目录 README.md)与方案审批(examples/)三方写入,边界靠目录划分,但 D-9 显示 examples/ 归属歧义。
3. **SKILL.md ↔ references ↔ commands 三角**:事实设计写 SKILL.md/references,任务执行写 commands,二者通过元 skill 编排耦合。若 SKILL.md 引用的 command 名与 commands/ 实际文件名不符,触发断裂。
4. **测试滞后**:代码审查 agent 写 `tests/*.bats`,但其测试对象(CLI/hook)由总调度/任务执行产出。并发下测试可能在被测对象未就绪时编写,基于契约猜测行为,集成后暴露偏差。
5. **第 8 节缺口协调串行化**:第 8 节"缺口由总调度协调"是串行瓶颈——6 agent 并发发现缺口都写第 8 节,总调度需串行裁决,可能成为关键路径。

> **发现 D-15(重要):并发构建缺少"集成契约冻结点"。** 建议在构建流程中设置契约冻结里程碑:6 agent 先按 CONTRACT v1 实现,在集成前由总调度汇总第 8 节缺口、发布 CONTRACT v1.1,再进入集成。否则各 agent 基于不同版本契约的产出无法拼装。

---

## 6. 审查结论

### 6.1 总体评估

| 维度 | 评级 | 说明 |
|---|---|---|
| 分层架构合理性 | 通过 | 四层正交分解稳健,四态覆盖充分 |
| 接口自洽性 | **需返工** | D-3/D-5 两处阻断级断点 |
| 所有权划分 | **需返工** | D-9 阻断(审批 agent 缺席) |
| 子代理契约 | **需返工** | D-13 阻断(角色混淆) |
| 并发集成可行性 | 有条件通过 | 需补集成冻结点(D-15) |

### 6.2 结论:**有条件通过(CONDITIONALLY APPROVED)**

架构方向正确,分层与四态覆盖成立。但存在 3 项阻断级契约缺陷(D-3、D-5、D-9、D-13),必须在实现进入集成阶段前修复,否则并发产出无法拼装。详见 `docs/approval.md`。

### 6.3 阻断项清单(必须在集成前修复)

| ID | 缺陷 | 修复动作 | 责任 |
|---|---|---|---|
| D-3 | MCP propose/evolve 无 CLI 后端 | 补 CLI 命令或显式声明仅会话态 | 总调度 |
| D-5 | SessionStart 调 `age route` 语义错配 | 改为 `age doctor`/读 context | 任务执行 + 总调度 |
| D-9 | 审批 agent 及 9 文件未入所有权表 | 补第 2 节 | 总调度协调 |
| D-13 | plan-reviewer 触发角色混淆 | 改为运行期事件触发 | 总调度 |

### 6.4 重要项清单(应在 v1.1 修复)

D-1(层→态映射)、D-2(跨平台策略)、D-4(命名统一)、D-6(回写集存储)、D-10(.age schema 所有权)、D-11(MCP 测试归属)、D-15(集成冻结点)。

### 6.5 次要项清单(可在后续迭代)

D-7(ci 退出码)、D-8(route 未命中形状)、D-12(Windows 入口)、D-14(doc-auditor scope)。

---

> 本报告所列阻断项已同步写入 `CONTRACT.md` 第 8 节(缺口与协调),供总调度 agent 裁决并发布 CONTRACT v1.1。

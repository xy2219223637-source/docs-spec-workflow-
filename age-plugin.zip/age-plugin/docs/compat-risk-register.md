# AGE Plugin 多客户端兼容风险登记册

> 维护方:方案审批与建议 agent
> 创建日期:2026-07-11
> 关联:`docs/compat-design-review.md`(兼容方案审查报告,发现 C-*)、`docs/approval.md`(第一轮前置条件)、`docs/risk-register.md`(第一轮风险 R1-R10)
> 概率/影响评级:H=高 / M=中 / L=低
> 风险等级 = 概率 × 影响(粗筛;H/H 与 H/M 视为需立即处理)
> 本登记册聚焦**多客户端兼容**特有风险;通用风险(并发集成、跨平台、hook 性能等)见 `docs/risk-register.md`,本文仅在多客户端场景放大时引用。

---

## 风险总览

| ID | 风险 | 概率 | 影响 | 等级 | 状态 | 关联发现 |
|---|---|---|---|---|---|---|
| RC-1 | 客户端版本差异导致配置失效 | H | M | 高 | 待缓解 | C-19, C-21 |
| RC-2 | MCP 协议版本不一致 | M | H | 高 | 待缓解 | C-19 |
| RC-3 | hooks 事件名/语义差异导致触发不准 | H | H | 极高 | 待缓解 | C-20, C-21 |
| RC-4 | AGENTS.md/CLAUDE.md 不同步 | M | M | 中 | 待缓解 | C-14, C-15 |
| RC-5 | age install 误检客户端 | M | H | 高 | 待缓解 | C-10, C-11 |
| RC-6 | 多客户端共存冲突 | M | H | 高 | 待缓解 | C-12 |
| RC-7 | Codex 无 hooks/skills 导致功能降级 | H | H | 极高 | 待缓解 | C-4, C-5 |
| RC-8 | OpenCode 命令格式差异 | M | M | 中 | 待缓解 | C-7 |
| RC-9 | 路径/环境变量跨平台问题 | H | M | 高 | 待缓解 | C-2, C-18 |
| RC-10 | Mutica 信息缺失 | L | L | 低 | 观察 | C-22 |
| RC-11 | MCP server 项目根检测不准 | M | H | 高 | 待缓解 | C-18 |
| RC-12 | age install 覆盖用户既有配置 | M | H | 高 | 待缓解 | C-13 |

---

## 风险详情

### RC-1 — 客户端版本差异导致配置失效
- **描述**:Claude Code / Codex / OpenCode 处于活跃迭代期,各客户端的配置文件格式(settings.json / config.toml / opencode.json 的字段名、嵌套结构、hooks 事件名、MCP 配置键)可能随版本变更。AGE 适配配置基于 §8.11 事实表的某一时间点调研,客户端升级后配置字段名变化(如 hooks 从 `hooks` 改 `hookHandlers`、MCP 从 `mcpServers` 改 `mcp.servers`),导致已装配置失效,客户端加载报错或静默忽略。
- **概率**:H — 客户端均在快速演进,配置格式调整先例常见。
- **影响**:M — 单客户端配置失效影响该客户端用户,不波及其他客户端;但失效常表现为"静默不触发"(hook 不触发、MCP 不连接),用户难自查。
- **缓解**:
  1. 各 `compat/<client>/README.md` 标注"目标客户端版本 = X",并维护版本兼容矩阵。
  2. `age doctor` 增加客户端版本检测:读取客户端版本号,与适配配置的目标版本比对,不匹配时告警"客户端版本 X 已知不兼容,适配配置可能失效,请升级 AGE 或回退客户端"。
  3. `tests/test_compat.bats` 增加配置文件 schema 校验(各客户端配置的必填字段存在性)。
  4. 适配配置采用"最小字段集"策略——只用客户端稳定文档明确支持的字段,避免用实验性字段。
- **负责人**:总调度(age doctor 检测)+ 事实设计(README 版本标注)+ 代码审查(测试)

### RC-2 — MCP 协议版本不一致
- **描述**:`mcp/server.py` 实现 MCP stdio JSON-RPC 2.0(§8.8 Y),支持 initialize/resources/list/resources/read/tools/list/tools/call/ping。但各客户端实现的 MCP 协议版本可能不同(2024-2025 协议演进中):initialize 握手的 protocolVersion 字段值不同、resources/read 与 tools/call 的语义边界差异(某些客户端把 resources 也暴露为 tools)、streamable HTTP vs stdio 传输差异。版本不匹配时,server 可能握手失败或工具不可见。
- **概率**:M — MCP 协议核心(stdio JSON-RPC)稳定,但版本字段与边缘语义在演进。
- **影响**:H — MCP 是非 ZCode 客户端的核心会话态能力,失效则 age_route/age_check_drift 等 tool 不可用,AGE 退化为纯 CLI。
- **缓解**:
  1. server.py 在 initialize 握手时记录客户端声明的 protocolVersion,输出到 `.age/mcp-handshake.log` 供诊断。
  2. server.py 声明最低支持协议版本,低于则告警(但不拒绝,尽力服务);对未知版本字段做容错(忽略而非崩溃)。
  3. `compat/<client>/README.md` 标注"目标 MCP 协议版本 = X"。
  4. `age doctor` 启动 server 后调 `tools/list` 验证 4 个工具(age_route/age_check_drift/age_propose_doc_update/age_evolve)+ age_activate 全部可见,不可见则告警。
  5. server.py 保持纯 stdlib、最小协议依赖(只用 MCP 核心方法),降低协议版本耦合。
- **负责人**:总调度(server.py)

### RC-3 — hooks 事件名/语义差异导致触发不准
- **描述**:§8.11 事实表:ZCode hooks 事件名 PascalCase(7事件);Claude Code PascalCase(settings.json);OpenCode camelCase;Codex 无 hooks。AGE 用 SessionStart/PostToolUse/Stop 三个事件。风险有二:(1) OpenCode 的 camelCase 事件名(如 sessionStart/postToolUse/stop)是**推断**而非实测,若 OpenCode 实际事件名不同(如 onSessionStart、afterToolUse、onStop),映射表错误导致 hook 不触发;(2) 即便事件名对,各客户端的 matcher 语法(ZCode 正则 `Edit|Write|MultiEdit` vs 其他客户端的 glob/前缀匹配)、触发时机(同步阻塞 vs 异步)、输出契约(stdout JSON `{"additionalContext":...}` vs 其他格式)可能不同,导致 hook 触发了但行为不对(如注入上下文格式错误被客户端丢弃,静默失败)。
- **概率**:H — §8.11 未给 OpenCode 实测事件名,映射表基于推断;matcher/输出契约跨客户端未验证。
- **影响**:H — hook 是编辑态(PostToolUse 漂移检测)与收尾态(Stop 审计)的核心,触发不准等于编辑态/收尾态覆盖断裂,漂移积累,用户无感。
- **缓解**:
  1. **CP-3(阻断前置)**:总调度 + 事实设计基于 OpenCode 实测文档/实测验证重写 hooks 事件名映射表,写入 `compat/opencode/opencode.json` 与 `compat/opencode/README.md`。若 OpenCode 不支持所需 3 事件,按 Codex 降级(C-4)处理。
  2. 各客户端适配配置的 hooks 段基于**实测**的 matcher 语法与输出契约,非复制 ZCode hooks.json。
  3. `hooks/scripts/lib.sh` 检测当前客户端(经 env 变量),按客户端分支输出 emit_context 格式。
  4. `age doctor` 注入测试 hook(写一个无害的 PostToolUse hook 验证是否触发),报告 hooks 实际触发情况。
  5. `tests/test_compat.bats` 校验各客户端 hook 配置的 JSON/TOML 语法与必填字段。
  6. hook 脚本在触发时写 `.age/hooks.log`(§8.6 K 已有),用户可查 hook 是否触发过。
- **负责人**:总调度(detect_host + lib.sh 分支)+ 事实设计(适配配置)+ 任务执行(hook 脚本)+ 代码审查(测试)

### RC-4 — AGENTS.md/CLAUDE.md 不同步
- **描述**:Claude Code 用 CLAUDE.md,其他客户端用 AGENTS.md。若采用拷贝副本策略(C-14),两份文件独立存在。用户(或 age init 渲染)编辑了 AGENTS.md 但未重跑 `age install --client claude` 生成 CLAUDE.md,导致 Claude Code 读到的 CLAUDE.md 过时。反之若用户直接编辑 CLAUDE.md,AGENTS.md(源)未更新,下次重生成会覆盖用户对 CLAUDE.md 的修改。双向编辑失同步使两个客户端看到不同的操作契约。
- **概率**:M — 副本策略天然有失同步风险,除非每次变更都重生成。
- **影响**:M — 不同步导致 Claude Code 与其他客户端行为不一致,但不崩溃(两份文件各自可用,只是内容有差)。
- **缓解**:
  1. **AGENTS.md 为源、CLAUDE.md 为生成副本**(C-14/C-15),CLAUDE.md 首行标注"由 AGENTS.md 自动生成,请勿直接编辑"。
  2. `age check` 增加 CLAUDE.md ↔ AGENTS.md 内容一致性校验(若两者都存在),不一致则告警"CLAUDE.md 与 AGENTS.md 不同步,请重跑 age install --client claude"。
  3. `age install --client claude` 每次从 AGENTS.md 重新生成 CLAUDE.md(幂等覆盖)。
  4. 若 Claude Code 实际也读 AGENTS.md(C-16 待确认),则可省略 CLAUDE.md,直接复用 AGENTS.md,消除同步问题。
  5. 文档明确:修改操作契约只改 AGENTS.md,改后重跑 install 同步 CLAUDE.md。
- **负责人**:事实设计(模板 + compat/claude-code/CLAUDE.md)+ 总调度(age check 校验 + age install 生成)

### RC-5 — age install 误检客户端
- **描述**:`age install` 的 `detect_host()`(§8.11 总调度)自动检测当前客户端环境。§8.11 未给检测算法,推断靠 env 变量(`ZCODE_*`/`CLAUDE_*`/`CODEX_*`/`OPENCODE_*`)与配置文件存在性。误检场景:(1) 用户装了多个客户端,检测全命中,detect_host 猜错当前客户端,把 Claude 配置装到 Codex 目录;(2) env 变量不存在(§8.11 标 Claude/Codex/OpenCode "无标准"env),只能靠配置文件存在性,但配置文件存在≠当前运行在该客户端;(3) 用户用非标准路径安装客户端(如便携版),配置文件不在默认路径,检测漏判。误检导致装错配置,客户端加载失败或 AGE 不触发。
- **概率**:M — 多客户端共存普遍,env 变量缺失使检测信号弱。
- **影响**:H — 装错配置轻则 AGE 不工作(静默),重则破坏用户既有客户端配置(若 install 覆盖写)。
- **缓解**:
  1. **CP-4**:detect_host 用优先级链(env 变量 > 配置文件 > 提示),env 命中即定;env 全无时不自动猜。
  2. 多客户端检测命中时,`age install` 进入交互模式列出检测结果让用户选,不自动猜;非交互须 `--client <name>` 显式指定。
  3. `age install --list` 列出所有客户端及检测结果(✓ 检测到 / ✗ 未检测到 / ? 不确定)。
  4. `age install --dry-run` 预览将写入的配置路径与内容,用户确认后再实际写。
  5. 检测结果写 `.age/installed-clients.json`,记录已装客户端,供 age doctor 引用与重复安装时跳过。
  6. 检测失败(全无信号)时明确提示"未检测到已知客户端,请用 age install --client <name> 显式指定",绝不静默猜一个。
- **负责人**:总调度(detect_host + age install)

### RC-6 — 多客户端共存冲突
- **描述**:用户同时用多个客户端(如 Claude Code + Codex)开发同一项目。冲突点:(1) 指令文件——Claude 读 CLAUDE.md,Codex 读 AGENTS.md,内容须同步(RC-4);(2) `.age/` 状态文件——两客户端操作同一项目的 baseline.json、writeback.json,若同时写(如 Claude PostToolUse 触发 age sync 写缓存,Codex 用户手动跑 age route 写 writeback)可能并发写冲突,文件损坏;(3) MCP 配置——两客户端各自有 MCP 配置(不同位置),指向同一 server.py,server 同时被两个客户端启动两个进程,若都写 `.age/` 状态,竞态;(4) 安装覆盖——`age install --client codex` 是否会覆盖之前 `--client claude` 装的配置(若两者写同一文件,如工作区 .mcp.json 被 codex 误改)。
- **概率**:M — 多客户端开发同一项目是高级用户常见模式。
- **影响**:H — 状态文件损坏导致 route/doc-sync 闭环断裂(R9 放大);配置覆盖导致某客户端配置丢失。
- **缓解**:
  1. `age install` 支持多客户端分别安装,各写各配置路径,不覆盖其他客户端配置(Claude 写 .mcp.json/.claude/,Codex 写 ~/.codex/config.toml,路径不交叉)。
  2. `.age/` 状态文件并发写风险:writeback.json 改为**追加模式**(任务数组)而非单任务覆盖,降低覆盖概率;或加文件锁(flock)串行化写。
  3. MCP server 多实例:server.py 对 `.age/` 的写操作(baseline/writeback)用原子写(写临时文件 + rename),避免半写损坏。
  4. `compat/README.md` 明确多客户端共存规则:各客户端配置独立、`.age/` 共享但原子写、指令文件 AGENTS.md 为源 CLAUDE.md 为副本。
  5. `age doctor` 检测多客户端共存场景,提示"检测到多客户端操作同一项目,`.age/` 状态共享,避免同时触发写操作"。
- **负责人**:总调度(age install 隔离 + server.py 原子写)+ 事实设计(共存规则文档)

### RC-7 — Codex 无 hooks/skills/commands 导致功能降级
- **描述**:§8.11 事实表:Codex 无 hooks、无 skills、无 slash commands。AGE 在 Codex 上仅剩 CLI + AGENTS.md + MCP。后果:(1) 编辑后不会自动触发 `age sync`——漂移检测断裂,代码与文档漂移积累无感;(2) 任务结束不会自动触发 `age audit --scope closure`——收尾审计断裂,文档不更新;(3) 会话开始不注入 context(SessionStart 断裂,MCP resources 部分替代);(4) 元 skill 编排失效(无 skills),用户须手动用 CLI;(5) 无 slash commands,用户须手敲完整 CLI 命令。这不是 bug 而是客户端能力限制,但若用户误以为"Codex 兼容=全功能",实际体验是大打折扣的"重度降级"。
- **概率**:H — Codex 确实无此能力(§8.11 事实表),只要用户在 Codex 用 AGE 就必然发生。
- **影响**:H — 编辑态/收尾态/编排态三态断裂,AGE 核心价值(自动漂移检测、自动收尾)在 Codex 上失效,只剩手动 CLI。
- **缓解**:
  1. **CP-2**:定义功能降级矩阵,Codex 标 minimal 级,`compat/codex/README.md` 与 `compat/README.md` 显式声明"Codex 无 hooks/skills/commands,以下功能不可用,以下操作须手动"。
  2. 列出手动操作清单:编辑后 `age sync`;任务结束 `age audit --scope closure`;任务开始 `age route <task>`;初始化 `age init`。
  3. 列出 skill→CLI 映射表:age-init→`age init`;route→`age route`;doc-sync→`age sync`;audit→`age audit`。
  4. AGENTS.md(模板)增加"Codex 降级指引"段,利用 AGENTS.md 作为 Codex agent 的指令文件,引导 agent 自觉在编辑后提醒跑 sync(指令兜底,非强制但优于无兜底)。
  5. `age doctor` 检测客户端无 hooks 能力时,提示"编辑态漂移检测已禁用,请手动 age sync"。
  6. MCP resources(docs://context/project-context)部分替代 SessionStart 的上下文注入——Codex 有 MCP,agent 可主动读 resources 获取 context。
- **负责人**:事实设计(compat/codex/README.md + AGENTS.md 降级段)+ 总调度(age doctor 检测)

### RC-8 — OpenCode 命令格式差异
- **描述**:§8.11 事实表:OpenCode commands 为 `opencode.json` 内联格式,与 ZCode 的 `.md+frontmatter` 格式迥异。AGE 现有 5 个 commands(`commands/*.md`:age-init/age-sync/age-route/age-audit/use-age),每个是 .md 文件含 frontmatter(name/description)+ 正文。适配到 OpenCode 须把每个 .md 转换为 opencode.json 的 commands 数组项(name/description/body 字段)。转换风险:(1) frontmatter 字段映射不一致(如 ZCode 的 description 对应 OpenCode 的哪个字段);(2) 正文 Markdown 在 JSON 字符串中须转义(换行、引号);(3) AGE 新增 command 后 OpenCode 适配须同步,手动维护易漏。
- **概率**:M — 格式转换本身可行,但手动维护易失同步。
- **影响**:M — 转换错误导致 OpenCode commands 不可用或描述错乱,不影响其他客户端。
- **缓解**:
  1. `compat/opencode/opencode.json` 提供 5 个 command 的完整转换样例(含正确 JSON 转义)。
  2. `age install --client opencode` 自动从 `commands/*.md` 提取 frontmatter + 正文,渲染到 opencode.json 的 commands 段(每次重生成,非手动维护)。
  3. 转换脚本处理 Markdown→JSON 字符串转义(换行 `\n`、引号 `\"`、反斜杠 `\\`)。
  4. `tests/test_compat.bats` 校验 opencode.json 的 commands 段与 `commands/*.md` 数量一致、字段齐全。
  5. AGE 新增 command 时,age install 重生成保证同步;文档提醒"新增 command 后须重跑 age install --client opencode"。
- **负责人**:总调度(age install 转换)+ 事实设计(opencode.json 样例)+ 代码审查(测试)

### RC-9 — 路径/环境变量跨平台问题
- **描述**:AGE 的 MCP server 与 hook 脚本依赖环境变量定位项目根与插件根。§8.11 事实表:ZCode 有 `${ZCODE_PROJECT_DIR}`/`${ZCODE_PLUGIN_ROOT}`;Claude Code/Codex/OpenCode "无标准"或待确认。§8.11 总调度改动:lib.sh 兼容 `CLAUDE_PROJECT_DIR`/`CODEX_HOME`/`OPENCODE_CONFIG`;server.py 兼容 `AGE_PROJECT_ROOT` → `AGE_PROJECT_DIR` → `os.getcwd()`。风险:(1) 这些变量名是否实际存在未验证(§8.11 标"无标准",总调度改动提及兼容——矛盾);(2) 即便存在,变量值可能是用户家目录而非项目目录(如 CODEX_HOME 指向 ~/.codex 而非项目);(3) Windows 路径分隔符(`\` vs `/`)与空格路径处理;(4) 各客户端启动 MCP/hook 的工作目录(cwd)不一致,os.getcwd() 兜底可能返回家目录或临时目录。
- **概率**:H — 非 ZCode 客户端的 env 变量缺失或不准是大概率。
- **影响**:M — 项目根定位不准导致 server.py 找不到 docs/、hook 脚本找不到 CLI,AGE 静默失效(不崩但不工作)。
- **缓解**:
  1. **CP-7**:各客户端适配配置的 env 段尽量注入 `AGE_PROJECT_ROOT`(用客户端支持的变量替换,如 Claude Code 的 `${workspaceFolder}` 若支持);不支持时文档说明手动设。
  2. server.py 的 cwd 兜底加校验:cwd 下无 docs/ 或 AGENTS.md 时输出 warning"项目根检测可能不准,cwd=<...>,请设 AGE_PROJECT_ROOT"。
  3. `hooks/scripts/lib.sh` 的 `age_resolve_cli()`(§8.6 K)已有多级回退(`${ZCODE_PLUGIN_ROOT}` → `${CLAUDE_PLUGIN_ROOT}` → PATH),扩展支持其他客户端的插件根变量;CLI 缺失时静默 exit 0 + 日志。
  4. 跨平台路径:CLI 已声明支持 macOS/Linux/WSL/Git-Bash(§8.8 AB),路径处理用 POSIX 工具;Windows 原生需 Git-Bash。
  5. `age doctor` 检测 server.py 项目根解析:启动 server 调 age_route 验证返回非空(非空说明根定位正确)。
  6. `compat/<client>/README.md` 各自说明该客户端的 env 变量注入方式与项目根定位策略。
- **负责人**:总调度(server.py + lib.sh + age doctor)+ 事实设计(README)

### RC-10 — Mutica 信息缺失
- **描述**:§8.11:"Mutica 无可验证公开信息,在 compat/ 下预留 `compat/mutica/README.md` 标注'待确认',不实现。"风险:若 Mutica 实际有公开扩展机制但调研未覆盖,或 Mutica 后续发布扩展文档,AGE 未及时适配,用户反馈"支持 Mutica"时无现成方案。反之,若 Mutica 无扩展机制,预留的占位永久闲置,增加维护噪音。
- **概率**:L — Mutica 信息缺失是已知状态,短期内无变化概率低。
- **影响**:L — 不影响现有四客户端;仅影响潜在的 Mutica 用户(若存在)。
- **缓解**:
  1. `compat/mutica/README.md`(事实设计)标注"待确认"+ 复查触发条件(Mutica 发布公开扩展文档 / 用户反馈需支持)。
  2. `age install --client mutica` 返回明确错误"Mutica 适配尚未实现(无公开扩展信息)",不静默跳过。
  3. `compat/README.md` 客户端对照表标 Mutica 为"待确认(预留)"。
  4. 每次契约大版本升级(v1.4+)复查 Mutica 是否有新公开信息。
  5. 本登记册定期复查(每轮契约升级时)。
- **负责人**:事实设计(compat/mutica/README.md)

### RC-11 — MCP server 项目根检测不准
- **描述**:`mcp/server.py` 项目根检测链:`AGE_PROJECT_ROOT` → `AGE_PROJECT_DIR` → `os.getcwd()`(§8.8 Y)。ZCode 下 env 由 plugin.json 注入,可靠。非 ZCode 客户端:env 变量缺失(§8.11 标"无标准"),回退 cwd——但 MCP server 的 cwd 取决于客户端启动工作目录,可能不是项目根(如客户端在家目录启动 MCP,或用临时目录)。项目根检测不准导致 server.py 找不到 `docs/index.md`、`AGENTS.md`,age_route 返回未命中,age_check_drift 报全量漂移(找不到任何 owner 文档),MCP 工具全部失效。
- **概率**:M — 非 ZCode 客户端 env 缺失是大概率,cwd 兜底不准是常见。
- **影响**:H — MCP 是非 ZCode 客户端的核心会话态能力,项目根不准等于 MCP 工具全失效,AGE 退化为纯 CLI。
- **缓解**:
  1. 各客户端 `.mcp.json`/config.toml/opencode.json 的 env 段显式注入 `AGE_PROJECT_ROOT`(用客户端变量替换或文档说明手动设)。
  2. server.py 启动时检测项目根:若无 docs/ 且无 AGENTS.md,输出 warning 到 stderr(客户端 MCP 日志可见)。
  3. server.py 支持 `--project-root` 命令行参数(客户端 args 配置中传入),作为 env 之外的显式指定方式。
  4. `age doctor` 启动 server 后调 age_route 验证返回非空,空则告警"MCP 项目根检测失败"。
  5. 文档建议:非 ZCode 客户端用户在适配配置中手动设 `AGE_PROJECT_ROOT` 为项目绝对路径。
- **负责人**:总调度(server.py + age doctor)

### RC-12 — age install 覆盖用户既有配置
- **描述**:`age install` 往用户家目录或工作区写适配配置(如 `~/.claude/settings.json`、`~/.codex/config.toml`)。这些文件用户可能已有非 AGE 配置(其他 hooks、其他 MCP servers、其他 skills)。若 `age install` 简单覆盖写,会毁掉用户既有配置。即便合并写,JSON 深合并/TOML 段级合并实现复杂,合并错误(如 hooks 数组被替换而非追加、MCP servers 字段被覆盖)同样破坏用户配置。用户配置丢失是严重体验事故。
- **概率**:M — 用户已有客户端配置是常见(用 Claude Code 的人多半已有 settings.json)。
- **影响**:H — 覆盖用户既有 hooks/MCP/skills 配置是不可逆事故(除非用户有备份),直接损害 AGE 信誉。
- **缓解**:
  1. `age install` 写入前检测目标文件是否已有 AGE 配置(含 `age-mcp` server 名),有则跳过提示"已安装";无则**合并**而非覆盖。
  2. JSON 配置用深合并(保留用户既有键,AGE 键追加);TOML 用段级追加(`[mcp_servers.age-mcp]` 追加,不动其他段);hooks 数组追加(不替换)。
  3. 写入前备份:`age install` 把目标文件备份为 `<file>.age-backup`(或 `.age/install-backup/<file>`),便于回滚。
  4. `age install --dry-run` 预览将写入的完整内容(含合并结果),用户确认后再写。
  5. `age uninstall --client <name>` 移除 AGE 配置(只删 AGE 相关键,不动用户其他配置),支持回滚。
  6. `tests/test_install.bats` 覆盖"目标文件已有非 AGE 配置"场景,验证合并不破坏。
- **负责人**:总调度(age install 合并 + 备份 + uninstall)+ 代码审查(测试)

---

## 风险处置追踪

| ID | 等级 | 缓解状态 | 复查日期 | 关联前置条件 |
|---|---|---|---|---|
| RC-1 | 高 | 待 age doctor 版本检测 | CP-1 事实表校验后 | CP-1 |
| RC-2 | 高 | 待 server.py 协议版本容错 | MCP 实现评审时 | CP-7 |
| RC-3 | 极高 | 待 OpenCode hooks 实测(P0) | 集成前 | CP-3 |
| RC-4 | 中 | 待 AGENTS.md 为源策略 + age check 校验 | CONTRACT v1.3 | CP-5 |
| RC-5 | 高 | 待 detect_host 优先级链 + 交互选择 | age install 实现评审时 | CP-4 |
| RC-6 | 高 | 待多客户端共存规则 + 原子写 | CONTRACT v1.3 | CP-6 |
| RC-7 | 极高 | 待降级矩阵 + 手动操作清单(P0) | 集成前 | CP-2 |
| RC-8 | 中 | 待 age install 命令转换 | age install 实现评审时 | CP-4 |
| RC-9 | 高 | 待 env 注入 + cwd 校验 | server.py/hook 评审时 | CP-7 |
| RC-10 | 低 | 观察(预留占位) | 每轮契约升级 | — |
| RC-11 | 高 | 待 server.py 项目根强化 | MCP 实现评审时 | CP-7 |
| RC-12 | 高 | 待 age install 合并 + 备份 + uninstall | age install 实现评审时 | CP-4 |

---

## 与第一轮风险登记册的关系

本登记册聚焦多客户端兼容特有风险(RC-*)。以下第一轮风险(R*,见 `docs/risk-register.md`)在多客户端场景下被放大,此处仅引用,不重复登记:

| 第一轮风险 | 多客户端场景放大 | 关联 RC |
|---|---|---|
| R1(协议成熟度) | 多客户端 = 多套协议(ZCode 插件 + MCP + 各客户端 hooks),协议变动面更广 | RC-1, RC-2 |
| R3(CLI 跨平台) | 多客户端用户可能在不同 OS 用不同客户端,跨平台面更广 | RC-9 |
| R4(hook 性能) | 各客户端 hook 触发机制不同(同步/异步),性能影响不一 | RC-3 |
| R9(回写集状态丢失) | 多客户端并发写 `.age/writeback.json`,状态丢失概率升高 | RC-6 |

---

> 本登记册为活文档,方案审批 agent 在每次契约变更(CONTRACT vN)或多客户端适配实现评审后复查并更新。阻断级风险(RC-3、RC-7)须在集成前关闭。

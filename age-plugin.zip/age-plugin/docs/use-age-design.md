# use-AGE 功能设计审查与审批

> 审查对象:use-AGE 功能(CONTRACT.md §8.10 第二轮任务)
> 审查角色:方案审批与建议 agent
> 审查日期:2026-07-11
> 审查基线:`CONTRACT.md` §8.10 + 现有实现代码(`skills/age/SKILL.md`、`cli/age`、`cli/lib/*.sh`、`hooks/scripts/on-session-start.sh`、`hooks/scripts/lib.sh`、`mcp/server.py`、`commands/age-init.md`、`templates/repo/docs/context/ai-autonomy-policy.md`)
> 审查状态:基于契约 §8.10 与现有代码实际内容,本轮 use-AGE 功能尚未实现(skills/use-AGE/ 不存在、commands/use-age.md 不存在、cli/lib/use.sh 不存在),属构建前设计审批

---

## 0. 审查范围与方法

本报告审查 §8.10 定义的 use-AGE 功能:用户用自然语言"开启/启动 AGE"时自动激活;未初始化时自动 init。审查覆盖:

1. 功能定义清晰度(入口技能职责边界)
2. 触发词覆盖充分性(§8.10 触发词清单 vs 自然语言变体)
3. 自动初始化策略安全性(何时 init 安全 / 太激进)
4. 技能层级清晰度(use-AGE → age → 子技能,有无职责重叠)
5. 与 SessionStart hook 的协作与冲突优先级
6. 风险识别(误触发、非预期初始化、多项目混淆)
7. 审批结论与可执行前置条件

审查方法:以 §8.10 文件所有权表与现有代码为事实基线,逐项核验设计自洽性与实现可行性。每条发现标注**严重度**(阻断/重要/次要)与**定位**。

> **关键事实核对(基于实际代码,非契约文字):**
> - `hooks/scripts/lib.sh::is_age_repo()`(行 103-108):严格按 §5,**仅认 `docs/index.md`**(`[ -f "${proj}/docs/index.md" ]`)。这是 hook 层判定。
> - `cli/lib/common.sh::is_age_repo()`(行 134-139):**宽松判定**,`docs/index.md` 或 `AGENTS.md` 任一存在即视为 AGE 仓库。
> - `hooks/scripts/on-session-start.sh`(行 21-33):非 AGE 仓库 + 是 git 仓库时,**仅提示** `/age-init`,不自动执行;非 git 仓库时**静默**。
> - `cli/lib/init.sh::age_init()`:init 会拷贝 `templates/repo/` 全树、渲染占位符、生成 AGENTS.md + docs/index.md + docs/context/ 五件套、跑 `age check` + `age baseline`。**有副作用、写大量文件**。
> - §8.10 要求将 `on-session-start.sh` 从"提示"改为"自动 init"——这是**从只读提示到写操作的语义跃迁**,是本审查的核心风险点。

---

## 1. 功能定义:use-AGE 是什么

### 1.1 定位

use-AGE 是 **AGE 插件的入口技能(entry-point skill)**,职责收敛为三件事:

1. **自然语言触发**:用户说"开启 AGE / 启动 AGE / enable AGE / 用 AGE"等语义时,被 ZCode 技能发现机制激活(靠 description 中的触发词匹配)。
2. **状态检测**:判断当前项目是否已 AGE 初始化(是否为 AGE 仓库)。
3. **自动初始化 + 激活**:未初始化则自动跑 `age init`;已初始化则直接激活(注入 AGENTS.md + docs/index.md 路由上下文,提示用 `/age-route` 开始任务)。

### 1.2 use-AGE 与 age 元 skill 的职责边界

| 维度 | use-AGE(入口技能) | age(元 skill) |
|---|---|---|
| 触发方式 | 自然语言"用 AGE"类短语 | 任务开始/结束、审计、init 等**语义事件** |
| 职责 | 检测 + 初始化 + 激活(一次性引导) | 编排四个子流程(route/doc-sync/audit/age-init) |
| 状态 | 无状态(每次触发都重新检测) | 有状态(route 标记 WRITEBACK 集) |
| 是否写文件 | 仅在未初始化时写(经 `age init`) | 经 CLI/MCP 写 owner 文档 |

**结论:边界清晰。** use-AGE 是"开关",age 是"运行时引擎"。use-AGE 不重复 age 的编排逻辑,只做"把 age 装上并点亮"。

> **发现 U-1(重要):use-AGE 与 age 元 skill 的 `age-init` 子流程存在职责重叠风险。** age SKILL.md 第 16 行已定义 `age-init` 子流程(触发:新仓库/套模板/SessionStart 首次/`/age-init`),其机械层就是 `age init` + `age baseline` + `age doctor`。use-AGE 的"自动初始化"也是调 `age init`。两者都指向同一 CLI 后端,但触发路径不同(use-AGE = 自然语言;age-init 子流程 = `/age-init` 命令 / SessionStart)。
> **要求**:use-AGE 的 SKILL.md 正文须**显式声明**"未初始化时委托 age 的 `age-init` 子流程执行 `age init`,不自行重写 init 逻辑",避免两个技能各写一套 init 引导步骤导致行为分叉。事实设计 agent 在编辑 `skills/age/SKILL.md` description 增加"被 use-AGE 激活"语义时,应在正文补一句交叉引用。

---

## 2. 触发词覆盖审查

### 2.1 §8.10 触发词清单核对

§8.10 列出的触发词:

- 中文:开启AGE、启动AGE、用AGE、使用AGE、激活AGE、启用吸引子工程、开始AGE
- 英文:enable AGE、start AGE、use AGE、activate AGE、turn on AGE、init AGE
- 语义变体:"帮我设置AGE"、"这个项目用AGE吧"、"装一下AGE"

### 2.2 覆盖充分性评估

上述清单覆盖了"动词 + AGE"的主流模式,但**遗漏了若干高频说法**。根据 skill-creator SKILL.md 的指导——"Models tend to *under*-trigger skills, so write descriptions a little bit pushy"——description 应尽量穷举常见说法,宁可多触发再由正文判断,也不要漏触发。

> **发现 U-2(重要):触发词遗漏常见说法。** 以下说法在中文开发者语境中高频,建议事实设计 agent 在 `skills/use-AGE/SKILL.md` 的 description 中补充:
>
> 中文遗漏:
> - "给这个项目加上 AGE" / "给项目加个 AGE"(加字句式)
> - "AGE 搞起来" / "AGE 弄一下" / "AGE 配一下"(口语化动词)
> - "把这个项目接入 AGE" / "接入吸引子工程"(接入句式)
> - "初始化 AGE" / "AGE 初始化"(init 语义,与英文 init AGE 对应的中文)
> - "AGE 设置一下" / "设置 AGE 吧"(设置句式,§8.10 仅列"帮我设置AGE"一种)
> - "这个仓库用 AGE"(仓库代换项目)
> - "用吸引子工程" / "吸引子工程开起来"(全称变体,§8.10 仅"启用吸引子工程"一种)
>
> 英文遗漏:
> - "set up AGE" / "setup AGE"(setup 是高频词,§8.10 未列)
> - "get AGE going" / "get AGE running"
> - "bootstrap AGE"
> - "add AGE to this project" / "add AGE here"
> - "turn AGE on"(§8.10 有 turn on AGE,但 turn AGE on 语序变体)
>
> **可执行要求**:description 须以"动词短语清单"形式列出,而非散文。参考写法(事实设计 agent 据此实现):
> ```
> description: Entry-point skill for activating AGE (Attractor-Guided Engineering) in the current project via natural language. Trigger whenever the user says any of: 开启AGE/启动AGE/用AGE/使用AGE/激活AGE/开始AGE/启用吸引子工程/给项目加AGE/接入AGE/AGE搞起来/AGE配一下/设置AGE/初始化AGE (Chinese); enable/start/use/activate/turn on/init/set up/setup/bootstrap/get going/add AGE (English); or semantic variants like "帮我设置AGE"、"这个项目用AGE吧"、"装一下AGE"、"给这个项目加上AGE". On trigger: detect whether the project is AGE-initialized; if not, run age init automatically; if yes, activate by surfacing AGENTS.md + docs/index.md routing context. Use aggressively — when in doubt about whether the user wants AGE, trigger and let the skill body decide.
> ```

### 2.3 误触发风险与隔离

补充触发词会提高召回率,但也增加误触发风险(用户说"这个项目用 Git 吧"被误匹配"用 AGE")。缓解措施:

> **发现 U-3(次要):description 须明确"AGE"标记词的边界,降低误召回。** 建议在 description 中强调"必须出现 AGE / 吸引子工程 标记词才触发",而非泛泛的"设置项目"。同时 use-AGE 正文第一步做**语义复核**:若实际意图非 AGE(如用户只是想"设置项目"),则不执行 init,改为澄清询问。这是"先触发后复核"的两段式策略,兼顾召回率与精度。

---

## 3. 自动初始化策略审查

这是本功能的**核心风险区**。§8.10 要求:`on-session-start.sh` 从"提示"改为"自动 init"。现有 `on-session-start.sh` 行 21-33 是**只读提示**(emit_context 一句话),改为"自动 init"是**写操作语义跃迁**——会在用户项目里创建 AGENTS.md、docs/ 全树、.age/ 目录等数十个文件。

### 3.1 何时自动 init 是安全的?

自动 init 安全的**必要条件**(全部满足):

1. **用户明确表达意图**:用户说了"启动 AGE / 用 AGE"类触发词(主动激活),而非被动 SessionStart。
2. **目标目录是 git 仓库**:init 的产物应纳入版本控制,非 git 目录自动 init 会留下无人管理的文件流。
3. **目标目录未被 AGE 化**:`is_age_repo()` 返回 false(无 docs/index.md,无 AGENTS.md)。
4. **不覆盖已有文件**:`age init` 拷贝模板时,现有 `age_init()` 用 `cp -p`(行 203)会覆盖同名文件——自动 init 前须检测冲突。

### 3.2 何时自动 init 太激进?

> **发现 U-4(阻断):§8.10 要求 SessionStart hook 自动 init,过于激进,违反"只读 hook 不阻塞/不写"原则。** 现有 `on-session-start.sh` 全文以 `# Must NEVER block: always exit 0` 开头(行 7),hook 设计哲学是"注入上下文,绝不写文件"。SessionStart 在**每次会话开始**触发,无用户意图信号——用户可能只是打开一个不想用 AGE 的项目。若 SessionStart 自动跑 `age init`,会在用户毫不知情时往项目里灌入 docs/ 全树 + AGENTS.md,这是不可逆的副作用(hook 不删文件),且用户未必想要。
>
> **要求(总调度 + 任务执行)**:`age use` 子命令(`cli/lib/use.sh`)承担自动 init;**SessionStart hook 不自动 init,维持"提示"行为**。理由:
> - SessionStart = 无意图信号的被动触发,只读。
> - `age use` / `/use-age` / use-AGE 技能 = 用户主动表达意图,可写。
> - §8.10 把 on-session-start.sh 改动列入任务执行所有权,但**应改为"提示措辞增强"而非"自动 init"**:在非 AGE 仓库 + git 仓库时,提示从"run /age-init"升级为"run /use-age 或说'启动 AGE'来自动初始化",引导用户用主动入口,而非 hook 擅自执行。
>
> 若总调度坚持 SessionStart 须自动 init,则**必须加门控**(见 3.3),否则本项阻断不予放行。

### 3.3 门控条件(若任何路径自动 init,必须满足)

> **发现 U-5(阻断):`age use` 自动 init 须加四道门控,否则不可放行。** `cli/lib/use.sh` 实现时须在调 `age init` 前依次检查:
>
> 1. **意图门**:由 use-AGE 技能或 `/use-age` 命令触发(主动入口),不接受 hook 直调。`age use` 须能区分"用户主动"vs"被 hook 调用"——建议 `age use` 只从技能/命令调用,SessionStart 不调 `age use`。
> 2. **git 门**:目标目录是 git 仓库(`git rev-parse --git-dir` 成功),否则只提示"请在 git 仓库内使用 AGE",不 init。
> 3. **未初始化门**:`is_age_repo()` 返回 false。已初始化则跳过 init,直接激活。
> 4. **冲突门**:目标目录已有 AGENTS.md 或 docs/ 时,**不覆盖**,改为提示"检测到已有 AGENTS.md/docs/,可能已有文档体系。是否强制初始化?需用 `/age-init` 显式确认。"——即自动 init 仅在"干净 git 仓库"执行;有任何疑似文档痕迹则降级为提示。
>
> 门控不满足时,`age use` 退出码 0(不报错,只提示),绝不 exit 1 阻断。

### 3.4 边界情况

> **发现 U-6(重要):边界情况未在 §8.10 定义,须补充策略。**
>
> | 边界情况 | 建议策略 |
> |---|---|
> | 非 git 目录说"启动 AGE" | `age use` 提示"AGE 建议 git 仓库内使用;当前非 git 仓库。是否 `git init` 后再启用?需确认。"不自动 init。 |
> | 已有 docs/ 目录的项目(非 AGE) | 冲突门触发:提示"已有 docs/,AGE init 可能与现有文档结构冲突。建议先备份,用 `/age-init` 显式确认。"不自动覆盖。 |
> | 已有 AGENTS.md(非 AGE 生成) | 冲突门触发:同上。`is_age_repo` CLI 版宽松判定会误认为已 AGE 化——此处须用**严格判定**(仅 docs/index.md)决定是否 init,避免误跳过。 |
> | monorepo 子目录 | `age use` 须在**仓库根**执行(git rev-parse --show-toplevel),而非当前子目录。否则 docs/ 落在子目录,与 git 根的 AGENTS.md 脱节。建议:检测到子目录时,提示"将在仓库根 <root> 初始化 AGE",并 cd 到根执行。 |
> | 用户在 AGE 插件自身仓库说"启动 AGE" | 插件仓库已有 docs/index.md,is_age_repo=true,直接激活,不 init。正确。 |
> | 用户在别人已有的 AGE 项目说"启动 AGE" | 已初始化,直接激活。正确。 |
>
> **可执行要求**:总调度在 `cli/lib/use.sh` 实现上述边界策略;任务执行在 `/use-age` command 与 use-AGE SKILL.md 正文引用相同策略,保持一致。

### 3.5 is_age_repo 判定不一致的放大效应

> **发现 U-7(重要):use-AGE 放大了 §8.6 [J] / §8.8 [X] 的 is_age_repo 判定不一致问题。** 当前三方判定:
> - hook `lib.sh::is_age_repo()` = 严格(仅 docs/index.md)
> - CLI `common.sh::is_age_repo()` = 宽松(docs/index.md 或 AGENTS.md)
> - §8.10 未指定 use-AGE 用哪个
>
> use-AGE 的"检测 + 决定是否 init"对判定语义**极敏感**:若用宽松判定,一个仅有 AGENTS.md(非 AGE 生成,如其他工具的 agent 约定)的项目会被误判为"已 AGE 化",从而跳过 init,用户说"启动 AGE"却没反应;若用严格判定,AGE 初始化中途(AGENTS.md 已生成、docs/index.md 尚未)会被误判为"未初始化"重复 init。
>
> **要求(总调度,v1.1)**:统一 is_age_repo 权威定义为**严格判定(仅 docs/index.md)**,理由:(1) docs/index.md 是 AGE 路由器的唯一标志,AGENTS.md 是通用约定非 AGE 专属;(2) hook 已用严格判定,改 CLI 一行即可;(3) `age init` 流程中 docs/index.md 在 AGENTS.md 之后生成(见 init.sh 行 219-224),宽松判定的"避免初始化中途误判"理由可由 init 流程内部标志位(如 `.age/.initing`)解决,而非放宽判定。本项与 §8.6 [J] / §8.8 [X] 联动,建议本轮一并裁定。

---

## 4. 技能层级审查

### 4.1 层级结构

§8.10 隐含的层级:

```
use-AGE(入口技能,自然语言触发)
  → age(元 skill,编排)
    → age-init / route / doc-sync / audit(四个子流程)
      → CLI(age init/route/sync/audit/check/ci/baseline/doctor)
      → MCP(age_route/age_check_drift/age_propose_doc_update/age_evolve + age_activate[新增])
```

### 4.2 层级清晰度评估

**结论:层级清晰,但 use-AGE 与 age 的 age-init 子流程需显式去重(见 U-1)。**

> **发现 U-8(重要):use-AGE 正文须明确"激活已初始化项目时做什么",避免与 age 的 route 子流程重叠。** use-AGE 在"已初始化"分支不应执行 route(那是任务开始时 age 的事),而应:注入 AGENTS.md + docs/index.md 摘要 + 提示"用 /age-route 开始任务"。即 use-AGE 的"激活"是"点亮上下文",不是"开始路由"。两者边界:
> - use-AGE 激活 = 一次性,把 AGE 装进会话视野。
> - age route = 每个任务开始,把任务路由到 owner 文档。
>
> **要求**:use-AGE SKILL.md 正文区分两个分支:(A) 未初始化 → 委托 age-init 子流程;(B) 已初始化 → 注入上下文 + 提示下一步用 route,不自行 route。

### 4.3 /use-age command 与 use-AGE 技能的关系

§8.10 同时定义了 `skills/use-AGE/SKILL.md`(技能)与 `commands/use-age.md`(slash 命令)。两者关系须明确:

> **发现 U-9(次要):/use-age 命令与 use-AGE 技能须共享同一后端,避免行为分叉。** 建议:`/use-age` 命令体调用 `age use` CLI 子命令(总调度实现),use-AGE 技能正文也指向 `age use`。两者是同一逻辑的两个入口(显式 slash vs 自然语言触发),后端唯一。`commands/use-age.md` 不重复 init 检测逻辑,只调 `age use` 并报告结果。这与 §8.5 C(commands 引用 SKILL.md 子流程语义、不重复定义)的模式一致。

---

## 5. 与 SessionStart hook 的关系

### 5.1 两条激活路径

use-AGE 功能引入后,AGE 有两条"激活"路径:

| 路径 | 触发 | 意图信号 | 行为 |
|---|---|---|---|
| **主动**:use-AGE 技能 / `/use-age` | 用户说"启动 AGE"或敲命令 | 强(用户明确要) | 可自动 init |
| **被动**:SessionStart hook | 每次会话开始 | 无(用户可能无感) | 只读提示(现状) |

### 5.2 协作模型

> **发现 U-10(阻断):须明确"hook 只提示、技能/命令才 init"的分工,禁止 hook 自动 init。** 协作模型应为:
>
> 1. **SessionStart hook**(被动,无意图):维持现状——非 AGE 仓库 + git 仓库时**提示**"说'启动 AGE'或运行 /use-age 来启用";AGE 仓库时注入上下文。**绝不自动 init。**
> 2. **use-AGE 技能 / `/use-age`**(主动,有意图):检测 + 必要时自动 init + 激活。
> 3. **`age use` CLI**(后端):被技能/命令调用,执行检测+init+激活逻辑。hook 不直调 `age use`。
>
> 理由:hook 在每次会话开始无差别触发,无用户意图信号;自动 init 是写操作,必须由用户主动入口触发。这与现有 on-session-start.sh 行 7 "Must NEVER block" 的设计哲学一致——延伸为"Must NEVER write/modify",hook 只注入上下文。
>
> **冲突时谁优先**:若 SessionStart 提示了"启用 AGE",用户随即说"启动 AGE",use-AGE 技能触发并执行 init——这是"提示 → 主动确认 → 执行"的正常流程,无冲突。若用户忽略提示,不执行任何操作,AGE 不被启用——正确。不存在"hook 与技能同时 init"的冲突,因为 hook 不 init。

### 5.3 §8.10 对 on-session-start.sh 改动的重新定性

> **发现 U-11(重要):§8.10 表述"on-session-start.sh 从'提示'改为'自动 init'"应修正为"提示措辞增强,指向 use-AGE 入口"。** 任务执行 agent 编辑 `on-session-start.sh` 时,应仅修改行 27 的 emit_context 文案,从:
> ```
> "AGE: This repo is not AGE-initialized ... run /age-init ..."
> ```
> 改为:
> ```
> "AGE: This repo is not AGE-initialized (no docs/index.md). To enable AGE, say '启动 AGE' or run /use-age — it will auto-initialize. If you did not intend to use AGE, ignore this message."
> ```
> **不增加任何 `age init` 调用**。这样既引导用户用新的主动入口,又不破坏 hook 只读原则。§8.10 文字若被字面执行(hook 自动 init),本审查不予放行(见 U-4)。

---

## 6. 风险

### 6.1 风险登记

| # | 风险 | 严重度 | 缓解措施 |
|---|---|---|---|
| R1 | **误触发 init**:用户说"设置项目"被误匹配,在不想用 AGE 的项目灌入 docs/ 全树 | 高 | U-2/U-3:description 强调 AGE 标记词;U-3:正文语义复核;U-5:冲突门 + git 门 |
| R2 | **SessionStart 自动 init**(若 §8.10 字面执行):每次开会话都 init,无意图 | 阻断 | U-4/U-10/U-11:hook 只提示,不 init |
| R3 | **覆盖已有文档**:`age init` 的 `cp -p` 覆盖同名文件,自动 init 毁掉用户已有 AGENTS.md/docs | 高 | U-5 冲突门:有任何文档痕迹则降级提示,不自动 init |
| R4 | **多项目混淆**:用户在 monorepo 子目录 init,docs/ 落错位置;或在多个项目间切换时 AGE 状态串 | 中 | U-6:monorepo 在 git 根执行;`age use` 每次重新检测(is_age_repo),不缓存状态 |
| R5 | **is_age_repo 判定不一致**:hook 严格、CLI 宽松、use-AGE 未定,导致同一项目在不同入口行为不同 | 中 | U-7:统一为严格判定(仅 docs/index.md) |
| R6 | **非 git 目录 init**:文件无人管理,用户难回滚 | 中 | U-5 git 门 + U-6 非 git 边界策略 |
| R7 | **init 失败半成品**:`age init` 中途失败(模板缺失、磁盘满),留下半截 docs/,is_age_repo 误判 | 中 | `age use` 在 init 后跑 `age doctor` 验证;失败时提示用户手动清理;可考虑 `.age/.initing` 标志位 |
| R8 | **激活但不 route 的预期落差**:用户说"启动 AGE"期望立刻开始干活,use-AGE 只激活不 route | 低 | U-8:激活后明确提示"下一步:用 /age-route <任务> 开始任务" |

### 6.2 与既有风险登记的关系

本节风险应并入 `docs/risk-register.md`(方案审批所有权,本轮可更新)。R2(R-阻断)若不解决,本功能不予放行。

---

## 7. 审批结论

### 7.1 结论

**CONDITIONALLY APPROVED(有条件批准)**

use-AGE 功能的**设计方向正确**(入口技能 + 自然语言触发 + 自动初始化),层级清晰,与现有 age 元 skill 互补。但 §8.10 的实现指令存在一处**阻断级偏差**(SessionStart 自动 init)与若干**重要级缺口**(门控、边界策略、判定统一),须在实现前满足前置条件。

### 7.2 前置条件(实现前必须满足)

| # | 条件 | 责任 | 关联发现 |
|---|---|---|---|
| C1 | **SessionStart hook 不自动 init,仅增强提示文案指向 use-AGE 入口** | 任务执行 | U-4, U-10, U-11 |
| C2 | **`age use` 实现四道门控**(意图门/git 门/未初始化门/冲突门),门控不满足时只提示不 init | 总调度 | U-5 |
| C3 | **is_age_repo 统一为严格判定(仅 docs/index.md)**,CLI 改一行,hook 已符合 | 总调度(v1.1 裁定) | U-7, §8.6 [J], §8.8 [X] |
| C4 | **use-AGE SKILL.md 正文显式委托 age-init 子流程**,不重写 init 逻辑;已初始化分支只激活不 route | 事实设计 | U-1, U-8 |
| C5 | **description 补充遗漏触发词**(set up AGE / 接入 AGE / AGE 搞起来 / 初始化 AGE 等),并强调 AGE 标记词边界降误召回 | 事实设计 | U-2, U-3 |
| C6 | **边界策略实现**(非 git 目录 / 已有 docs/ / monorepo 子目录 / 已有 AGENTS.md 非 AGE 生成) | 总调度 + 任务执行 | U-6 |
| C7 | **`/use-age` 命令与 use-AGE 技能共享 `age use` 后端**,命令体不重复检测逻辑 | 任务执行 | U-9 |

### 7.3 建议的 §8.10 修订(供总调度纳入 CONTRACT v1.2)

1. **on-session-start.sh 改动定性**:从"自动 init"修正为"提示文案增强,指向 use-AGE 入口"。
2. **`age use` 门控契约**:在 §3 CLI 子命令表补 `age use` 行,注明"主动入口;四道门控;门控不满足时 exit 0 + 提示"。
3. **is_age_repo 权威定义**:在 §5 或新增小节写死"仅 docs/index.md",联动 §8.6 [J] / §8.8 [X]。
4. **`age_activate` MCP tool**:§8.10 列了新增 `age_activate` tool(总调度,mcp/server.py)。须明确其语义——是"会话内主动激活(等价 age use)"还是"仅返回激活状态"?建议为前者,且同样遵守门控(不绕过冲突门)。在 §4 MCP tools 表补 `age_activate → {initialized, activated, action}`。

### 7.4 放行范围

满足 C1-C7 后,本轮 6 agent 可基于修订后的 §8.10 并发实现。**不满足 C1/C2(阻断级)则不予放行。** C3-C7 为重要级,可在实现中并行解决,但集成前须全部关闭。

---

## 8. 附:与既有审批文档的关系

- 本文档是 `docs/approval.md`(CONDITIONALLY APPROVED,第一轮契约审批)的**功能级补充**,针对 use-AGE 这一具体功能。
- 本文档发现 U-7(is_age_repo 不一致)联动 `docs/design-review.md` 的 D-系发现与 §8.6 [J] / §8.8 [X],是既有问题在新功能语境下的放大。
- 本文档不修改 CONTRACT.md(超出方案审批所有权);修订建议(U-7 统一判定、§8.10 文字修正)写入本节,供总调度协调。

# AGE Plugin 风险登记册

> 维护方:方案审批与建议 agent
> 创建日期:2026-07-11
> 关联:`docs/approval.md`(前置条件)、`docs/design-review.md`(缺陷 D-*)
> 概率/影响评级:H=高 / M=中 / L=低
> 风险等级 = 概率 × 影响(粗筛;H/H 与 H/M 视为需立即处理)

---

## 风险总览

| ID | 风险 | 概率 | 影响 | 等级 | 状态 |
|---|---|---|---|---|---|
| R1 | 协议成熟度(ZCode 插件/MCP/Hook 契约可能变动) | M | H | 高 | 待缓解 |
| R2 | 并发集成(6 agent 产出无法拼装) | H | H | 极高 | 待缓解 |
| R3 | CLI 跨平台(POSIX shell 在 Windows 原生失效) | H | M | 高 | 待缓解 |
| R4 | Hook 性能(PostToolUse 频繁触发 `age sync` 阻塞编辑) | M | H | 高 | 待缓解 |
| R5 | MCP 常驻开销(server.py 进程占用/启动延迟) | M | M | 中 | 待缓解 |
| R6 | 模板漂移(examples/context 模板与实际工作流偏离) | M | M | 中 | 待缓解 |
| R7 | Agent 触发可靠性(元 skill/子代理不触发或误触发) | H | M | 高 | 待缓解 |
| R8 | CI 环境差异(本地 `age ci` 通过但 CI 失败) | M | H | 高 | 待缓解 |
| R9 | 回写集状态丢失(route→doc-sync 闭环断裂) | M | H | 高 | 待缓解 |
| R10 | 文档爆炸(docs/ 目录层级过深导致 agent 检索失败) | L | M | 中 | 观察 |

---

## 风险详情

### R1 — 协议成熟度
- **描述**:AGE 插件依赖三类尚未稳定的协议:ZCode 插件 manifest 格式(`plugin.json`/`userConfig-schema.json`)、MCP server 协议(`mcp/server.py` 的 tools/resources 暴露方式)、Hook 事件机制(`SessionStart`/`PostToolUse`/`Stop` 的 matcher 语法与触发时机)。任一协议在构建期或后续版本变动,均可能使已实现组件失效。
- **概率**:M — 协议处于演进期,字段/matcher 语义存在调整先例。
- **影响**:H — 协议变动会同时影响 plugin.json、hooks.json、mcp/server.py 三个核心文件,牵涉事实设计/任务执行/总调度三方。
- **缓解**:
  1. 在 `plugin.json` 声明 `apiVersion`/`engineVersion` 约束,锁定目标 ZCode 版本。
  2. `age doctor`(第 3 节)增加协议兼容性自检,启动时探测 hook 事件名、MCP 工具枚举是否与契约一致。
  3. 将协议依赖集中到 `cli/lib/*.sh` 与 `mcp/server.py` 的薄适配层,核心逻辑不直接耦合协议字段。
  4. README 标注"目标 ZCode 版本 = X",并维护变更日志。
- **负责人**:总调度(适配层)+ 事实设计(manifest 版本锁定)

### R2 — 并发集成失败
- **描述**:6 个 agent 并发构建,各自基于 CONTRACT v1 独立产出。集成期若各 agent 对契约解读不同(见 D-3/D-4/D-5 命名与语义错配),产出无法拼装。典型场景:任务执行实现 hook 调 `age sync`,总调度实现的 CLI 命令名实际为 `age drift`;集成期 hook 报 command not found。
- **概率**:H — 契约已存在 4 项阻断级缺陷,并发解读偏差几乎必然发生。
- **影响**:H — 集成失败需返工多个 agent 产出,可能触发重建。
- **缓解**:
  1. **设置集成契约冻结点(D-15)**:集成前由总调度汇总第 8 节缺口、发布 CONTRACT v1.1,6 agent 基于同一版本集成。
  2. 总调度在集成前提供 CLI 命令的"冒烟测试脚本",hook/commands 可独立验证 CLI 接口。
  3. 元 skill(SKILL.md)的 command 引用名与 commands/ 文件名建立交叉校验,纳入 `age check`。
  4. 集成顺序固化:plugin.json → CLI → hook → MCP → SKILL.md,每层就绪后下一层基于已验证接口实现。
- **负责人**:总调度(协调 + 冻结点)

### R3 — CLI 跨平台
- **描述**:`cli/age` 与 `cli/lib/*.sh`、`hooks/scripts/*.sh` 均为 POSIX shell。macOS/Linux/WSL/Git-Bash 可运行,但 Windows 原生(PowerShell/cmd,无 bash)无法执行,导致 Windows CI 上 `age ci` 失效,"CI 态覆盖"在 Windows 断裂。
- **概率**:H — 一旦用户在 Windows 原生环境或 Windows-only CI(如 AppVeyor)使用,必然暴露。
- **影响**:M — 不影响类 Unix 用户,但削弱"确定性内核覆盖 CI"的普适承诺。
- **缓解**:
  1. 契约声明平台矩阵(D-2):明确支持 macOS/Linux/WSL/Git-Bash,原生 Windows 为"需 Git-Bash"。
  2. README 与 `age doctor` 检测 shell 类型,无 bash 时给出明确提示而非静默失败。
  3. 优先级:确保 WSL/Git-Bash 可用(成本 低);原生 Windows 支持(`cli/age.cmd` 包装)列为 P2(D-12)。
  4. CI 矩阵:在 GitHub Actions 跑 ubuntu + macos + windows-latest(bash)三档。
- **负责人**:总调度(CLI)+ 代码审查(CI 矩阵)

### R4 — Hook 性能
- **描述**:PostToolUse 在每次 `Edit|Write|MultiEdit` 后触发 `on-edit.sh → age sync --json`。`age sync` 需执行 `git diff`、比对基线、生成漂移报告,属 I/O 密集操作。高频编辑时同步触发会阻塞工具调用返回,导致编辑体验卡顿。
- **概率**:M — 中等规模仓库(千文件级)上 `git diff` + 基线比对耗时数百毫秒,频繁触发可感知。
- **影响**:H — 编辑态是用户最敏感路径,卡顿直接损害可用性,用户可能禁用 hook(AGE 失去编辑态覆盖)。
- **缓解**:
  1. **防抖(debounce)**:on-edit.sh 记录上次触发时间戳到 `.age/.last-sync`,1 秒内重复触发跳过,仅记"待同步"标记。
  2. **异步化**:on-edit.sh 后台启动 `age sync`,不阻塞工具返回;结果写入 `.age/sync-cache.json`,下次会话/Stop 时汇报。
  3. **增量**:`age sync --since REF` 默认只比对上次提交后变更,不全量扫描。
  4. **阈值**:漂移报告超过 N 条时仅返回摘要,完整报告落 `.age/sync-full.json`。
  5. 提供 `age sync --no-cache` 强制全量,供 CI 使用。
- **负责人**:任务执行(hook 脚本)+ 总调度(CLI 性能)

### R5 — MCP 常驻开销
- **描述**:`mcp/server.py` 作为 MCP server 常驻进程,占用内存与连接。`docs://status` 资源"实时算"漂移分数,每次访问触发计算。低配机器或多 MCP 共存时,启动延迟与内存占用累积。
- **概率**:M — 单个 MCP server 开销有限,但叠加其他 MCP 时可感知。
- **影响**:M — 不阻断功能,但影响会话启动速度与资源占用。
- **缓解**:
  1. `docs://status` 计算结果缓存 30 秒(TTL),避免每次访问实时算。
  2. server.py 启动时懒加载,首次 tools 调用才初始化重逻辑。
  3. resources 只读且轻量,重计算放 tools(按需调用)。
  4. `age doctor` 检测 MCP 启动耗时,超阈值(如 2 秒)告警。
  5. 文档说明 MCP 可选:无 MCP 时 AGE 退化为"CLI + hook + skill"三件套,核心功能不依赖 MCP。
- **负责人**:总调度(MCP)

### R6 — 模板漂移
- **描述**:`templates/repo/docs/context/*.md`(强制上下文模板)与 `templates/repo/docs/examples/`(示例)由事实设计与方案审批分别维护。若实际工作流演变(如新增子流程),而模板/示例未同步更新,新项目套用模板时会得到过时骨架,AGE 的"Day 0 一致性"承诺失效。
- **概率**:M — 模板与示例分散在两个 agent,缺乏自动同步机制。
- **影响**:M — 产出过时但不报错,隐性劣化。
- **缓解**:
  1. `age check`(第 3 节)增加"模板完整性"校验:context/ 与 examples/ 引用的子流程名必须与 SKILL.md 第 6 节一致。
  2. examples/ 示例文件标注"对应契约版本",CI 校验示例与当前 CONTRACT 版本匹配。
  3. 本风险登记册的 examples(方案审批产出)与 context 模板(事实设计)在 `age init` 后交叉引用,任一变更触发另一方 review。
  4. 文档路由器 `docs/index.md` 列出模板清单,新增子流程时强制更新。
- **负责人**:方案审批(examples)+ 事实设计(context 模板)

### R7 — Agent 触发可靠性
- **描述**:元 skill(`skills/age/SKILL.md`)的四个子流程(init/route/doc-sync/audit)依赖"语义边界触发"——新仓库触发 init、任务开始触发 route。但 skill 触发基于描述匹配,语义边界模糊时可能不触发(用户改了代码但没说"开始任务",route 不触发)或误触发(无关对话误命中 route)。子代理(doc-auditor 等)同理依赖 hooks.Stop 或 /age-audit,Stop 事件时机不稳。
- **概率**:H — 语义触发天然不可靠,ZCode skill 触发依赖描述质量与上下文。
- **影响**:M — 漏触发导致 AGE 流程缺失环节(如任务结束未 doc-sync,文档漂移积累);误触发产生噪音。
- **缓解**:
  1. **显式命令兜底**:每个子流程都有对应 slash command(/age-init、/age-route、/age-sync、/age-audit),用户可手动触发。skill 描述明确"也可用 /age-* 命令"。
  2. SKILL.md 描述采用"动作动词 + 边界条件"高触发率写法(参见 skill-creator 指南),避免模糊泛化。
  3. hook 作为确定性兜底:PostToolUse 触发 sync(不依赖 skill 判断),Stop 触发 audit。
  4. 子代理触发同时绑定 hook 事件与 command,双通道降低漏触发。
  5. `age doctor` 报告最近 N 次子流程触发记录,供用户自查 AGE 是否在运行。
- **负责人**:事实设计(SKILL.md)+ 任务执行(hook 兜底)

### R8 — CI 环境差异
- **描述**:`age ci` = `check --strict` + `sync --json`,设计为 CI 流水线非交互运行。但 CI 环境与本地差异:CI 无 `docs://context` MCP 资源(无会话)、git 浅克隆(`--depth 1`)使 `--since REF` 失效、CI 无 `.age/baseline.json`(未 init)。本地 `age ci` 通过但 CI 失败,或反之。
- **概率**:M — 浅克隆与缺失基线是 CI 常见差异。
- **影响**:H — CI 红绿不稳直接阻断合并,损害"确定性内核"可信度。
- **缓解**:
  1. `age ci` 自检环境:无 baseline 时自动 `age baseline`;浅克隆时降级为全量比对并告警。
  2. CI 文档明确前置:`age init` 与 `age baseline` 需在 CI 首次运行(或提交 baseline.json 到仓库)。
  3. `age ci` 不依赖 MCP/会话态资源,纯 CLI + 文件系统。契约第 3 节已隐含,需在 README 与 CI 示例显式声明。
  4. CI 矩阵测试:代码审查 agent 在 `tests/` 增加 CI 模拟(设置浅克隆、删除 baseline)验证 `age ci` 行为。
  5. `age ci --json` 输出结构化结果,CI 可解析而非仅看退出码。
- **负责人**:代码审查(CI 测试)+ 总调度(CLI 环境自检)

### R9 — 回写集状态丢失
- **描述**:第 6 节 route 子流程"标记回写集",doc-sync 子流程"对照回写集更新文档"。但回写集存储位置未定义(D-6)。若存会话内存,会话中断/重启后丢失,doc-sync 无据可依;若存文件但未规定路径,各实现不一致。
- **概率**:M — 会话中断在中长任务中常见。
- **影响**:H — 回写集丢失导致 doc-sync 无法执行,任务结束后文档不更新,漂移积累,AGE 闭环断裂。
- **缓解**:
  1. **契约补全(D-6)**:规定回写集落 `.age/writeback.json`,route 写入、doc-sync 读取并清空。
  2. writeback.json 结构简单:`{task, docs:[], skills:[], timestamp}`,幂等可重建。
  3. doc-sync 在 writeback.json 缺失时降级为"全量 sync 提醒",而非静默跳过。
  4. `age audit --scope closure` 校验 writeback.json 是否已清空(任务收尾完整性)。
- **负责人**:总调度(CLI 状态文件)+ 事实设计(SKILL.md 流程)

### R10 — 文档爆炸
- **描述**:`templates/repo/docs/` 下有 backlog/requirements/design/architecture/plans/audits/logs/bugs/testing/... 等多个目录(第 2 节 `...` 省略号暗示更多)。层级过深时,agent(SessionStart 注入上下文)与用户检索成本上升,反而降低文档可用性。
- **概率**:L — 初期目录可控,随项目演进才膨胀。
- **影响**:M — 不阻断,但降低 AGE 的"文档即路由"体验。
- **缓解**:
  1. `docs/index.md` 作为单一路由入口,强制扁平索引,避免递归深挖。
  2. SessionStart 注入"摘要"而非全文,只读 index + context,按需 route 深入。
  3. `age check` 检测 docs/ 深度超过阈值(如 3 层)告警。
  4. 各目录 README.md 明确"本目录放什么、不放什么",防止误存导致膨胀。
- **负责人**:过程计划(各目录 README)+ 事实设计(index 路由)

---

## 风险处置追踪

| ID | 等级 | 缓解状态 | 复查日期 |
|---|---|---|---|
| R1 | 高 | 待总调度建立适配层 | CONTRACT v1.1 发布时 |
| R2 | 极高 | 待设置集成冻结点 | 集成前 |
| R3 | 高 | 待声明平台矩阵 | CONTRACT v1.1 |
| R4 | 高 | 待任务执行实现防抖 | hook 实现评审时 |
| R5 | 中 | 待 MCP 缓存策略 | MCP 实现评审时 |
| R6 | 中 | 待 age check 模板校验 | v1.1 |
| R7 | 高 | 待 SKILL.md + command 兜底 | SKILL.md 评审时 |
| R8 | 高 | 待 CI 环境自检 | 代码审查产出时 |
| R9 | 高 | 待契约补 writeback.json | CONTRACT v1.1 |
| R10 | 中 | 观察 | 第一批项目落地后 |

---

> 本登记册为活文档,方案审批 agent 在每次契约变更(CONTRACT vN)后复查并更新。

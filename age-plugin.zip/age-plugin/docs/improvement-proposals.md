# AGE Plugin 改进建议

> 提出方:方案审批与建议 agent
> 日期:2026-07-11
> 关联:`docs/design-review.md`(缺陷 D-*)、`docs/risk-register.md`(风险 R-*)、`docs/approval.md`(前置条件)
> 优先级:P0 = 必须(阻断集成)/ P1 = 应该(显著降本或降险)/ P2 = 可选(锦上添花)
> 工作量估算:S = <1 人天 / M = 1-3 人天 / L = >3 人天

---

## P0 — 必须(集成前完成)

### P0-1: 补全方案审批 agent 的文件所有权(D-9)

- **现状**:CONTRACT 第 2 节所有权表列出 5 个 owner agent,完全缺失第 6 个"方案审批 agent"及其 9 个文件(`docs/design-review.md`、`docs/approval.md`、`docs/risk-register.md`、`docs/improvement-proposals.md`、`templates/repo/docs/examples/README.md` 及 4 个 examples 文件)。`docs/` 目录除 `index.md` 外所有权悬空,examples/ 与过程计划的 `...` 通配归属歧义。
- **建议**:在第 2 节补"方案审批"agent 列,显式登记:
  - `docs/design-review.md` | 方案审批 | 架构审查报告
  - `docs/approval.md` | 方案审批 | 审批记录
  - `docs/risk-register.md` | 方案审批 | 风险登记册
  - `docs/improvement-proposals.md` | 方案审批 | 改进建议
  - `templates/repo/docs/examples/README.md` | 方案审批 | examples 目录说明
  - `templates/repo/docs/examples/*.example.md` | 方案审批 | 带日期示例
  - `templates/repo/docs/examples/complete-small-app-walkthrough.md` | 方案审批 | 完整流程示例
- **预期收益**:消除所有权悬空,6 agent 边界清晰,集成期无文件冲突。
- **工作量**:S(契约编辑,10 分钟)

### P0-2: 修正 SessionStart hook 调用对象(D-5)

- **现状**:第 5 节 SessionStart 调用"`age route` 判定 + 读 context"。但 `age route <task>` 需 task 参数,会话启动时无 task,hook 必失败。
- **建议**:SessionStart 改为 `age doctor`(环境/配置诊断,无 task 参数)+ 读 `docs://context/project-context`。route 推迟到用户首个任务时由元 skill 或 /age-route 触发。
- **预期收益**:SessionStart 不再必然失败,会话态注入链路打通。
- **工作量**:S

### P0-3: 为 MCP propose/evolve 补 CLI 后端或显式声明会话态(D-3)

- **现状**:第 4 节 MCP 工具 `age_propose_doc_update`、`age_evolve` 无第 3 节对应 CLI 命令,违反"CLI = 确定性内核,覆盖 CI/headless"。
- **建议**:方案 A(推荐)补 CLI 命令 `age propose <change>` 与 `age evolve <task_id>`,使 CI 可复现;方案 B 在第 4 节注明"此二工具仅会话态,无 CI 镜像,理由:propose/evolve 需 agent 实时决策",并确保 `age ci` 不依赖它们。
- **预期收益**:CI 路径完整或边界明确,消除"确定性内核"承诺的破绽。
- **工作量**:M(方案 A,需实现 CLI)/ S(方案 B,契约标注)

### P0-4: 修正 plan-reviewer 子代理触发条件(D-13)

- **现状**:第 7 节 plan-reviewer 触发为"方案审批 agent 调用"。但构建期"方案审批 agent"无法调用运行期子代理,生命周期错配。
- **建议**:触发改为运行期事件 `/age-audit --scope plan` 或 plan 收尾命令。将构建期角色改称"方案审批(构建期)"、运行期子代理保持 `plan-reviewer`,消除名称歧义。
- **预期收益**:子代理触发可执行,角色边界清晰。
- **工作量**:S

### P0-5: 设置集成契约冻结点(D-15)

- **现状**:6 agent 并发基于 CONTRACT v1 实现,无冻结机制,集成期各 agent 产出基于不同契约版本解读,无法拼装。
- **建议**:流程增加里程碑——集成前由总调度汇总第 8 节缺口、发布 CONTRACT v1.1,6 agent 基于 v1.1 进入集成。集成顺序:plugin.json → CLI → hook → MCP → SKILL.md,每层就绪后下层基于已验证接口实现。
- **预期收益**:集成有统一基线,降低返工概率(直接缓解 R2 极高风险)。
- **工作量**:M(流程约定 + 总调度协调)

---

## P1 — 应该(v1.1 完成)

### P1-1: 统一漂移检测命名(D-4)

- **现状**:漂移检测在 MCP 层名 `age_check_drift`、CLI 层名 `sync`、skill 层名 `doc-sync`,三处三名,实现者需自行映射,易引入隐性 bug。
- **建议**:统一语义根名 `drift`。CLI 保留 `age sync`(已约定俗成)但别名 `age drift`;MCP 改 `age_drift`;skill 子流程改 `drift-sync` 或保留 `doc-sync` 但文档注明"= drift"。最关键是 CLI↔MCP 命名一致。
- **预期收益**:消除命名歧义,降低集成与维护成本。
- **工作量**:S

### P1-2: 定义回写集存储契约(D-6, R9)

- **现状**:route 子流程"标记回写集"、doc-sync"对照回写集",但存储位置未定义。会话中断后回写集丢失,doc-sync 闭环断裂。
- **建议**:第 3 节 `age route` 行补注"写入 `.age/writeback.json`",结构 `{task, docs:[], skills:[], timestamp}`。doc-sync 读取并清空;缺失时降级为全量 sync 提醒。`age audit --scope closure` 校验 writeback.json 已清空。
- **预期收益**:route→doc-sync 闭环状态持久化,任务收尾完整性可校验。
- **工作量**:M

### P1-3: 声明平台矩阵与 shell 依赖(D-2, R3)

- **现状**:CLI/hook 全为 POSIX shell,未声明平台,Windows 原生 CI 覆盖失效。
- **建议**:第 1 或第 3 节声明平台矩阵:支持 macOS/Linux/WSL/Git-Bash,原生 Windows 需 Git-Bash。`age doctor` 检测 shell 类型,无 bash 时明确提示。CI 跑 ubuntu+macos+windows(bash) 三档。
- **预期收益**:跨平台边界明确,Windows 用户有清晰预期。
- **工作量**:M

### P1-4: 补 MCP 依赖清单与测试 owner(D-11)

- **现状**:第 2 节 `mcp/server.py` 归总调度,但 `mcp/requirements.txt`/`pyproject.toml` 与 MCP Python 测试无 owner。`tests/*.bats`(代码审查)仅覆盖 bash,Python MCP 无测试。
- **建议**:第 2 节补 `mcp/requirements.txt`(总调度)与 `tests/test_mcp.py`(代码审查扩展,或总调度自测)。MCP server 启动后 `tools/list` 与 `resources/list` 与第 4 节逐项校验纳入测试。
- **预期收益**:MCP 可测、依赖可复现,降低 R1/R5。
- **工作量**:M

### P1-5: 第 1 节补"层→态"覆盖矩阵(D-1)

- **现状**:第 1 节只给四层,未显式映射四态(编辑/会话/提交/CI),实现者需推断。
- **建议**:第 1 节新增表:插件→(投递,全态)、skill→(判断,会话态)、CLI→(确定性,提交态+CI态)、MCP→(感知,会话态);Hook→编辑态。使"四层覆盖四态"成为契约级断言,`age check` 可校验。
- **预期收益**:架构意图显式化,降低实现偏差。
- **工作量**:S

### P1-6: Hook 性能防护——防抖与异步化(R4)

- **现状**:PostToolUse 每次 Edit/Write 触发 `age sync`,高频编辑时阻塞工具返回,卡顿损害可用性。
- **建议**:on-edit.sh 防抖(1 秒内重复触发跳过,记"待同步"标记);后台异步启动 sync,结果落 `.age/sync-cache.json`;`--since REF` 默认增量;漂移超 N 条仅返回摘要。提供 `--no-cache` 供 CI。
- **预期收益**:编辑态不卡顿,用户不弃用 hook(保住编辑态覆盖)。
- **工作量**:M

### P1-7: Agent 触发双通道兜底(R7)

- **现状**:元 skill 子流程与子代理依赖语义触发,不可靠。漏触发致流程缺环节,误触发生噪音。
- **建议**:每个子流程配 slash command 兜底(/age-init、/age-route、/age-sync、/age-audit);hook 作确定性兜底(PostToolUse→sync、Stop→audit);SKILL.md 描述用"动作动词+边界条件"高触发率写法;`age doctor` 报告最近触发记录供自查。
- **预期收益**:触发可靠性从"靠语义"升级为"语义+命令+hook"三重保障。
- **工作量**:M

### P1-8: `.age/` 状态文件 schema 所有权(D-10)

- **现状**:`.age/baseline.json`、writeback.json、sync-cache.json 等 schema 无 owner。
- **建议**:第 2 节补 `.age/` schema 文档(归总调度,如 `cli/lib/.age-schema.md` 或 docs/index.md 引用)。`age doctor` 校验状态文件符合 schema。
- **预期收益**:状态文件可演进、可校验,降低 R9。
- **工作量**:S

---

## P2 — 可选(后续迭代)

### P2-1: 定义组合命令退出码与失败码(D-7)

- **现状**:`age ci` = check + sync 组合退出码未定义(check 过但 sync 有漂移时 ci 返回 0 还是 1 不明);`age baseline` 仅 0 无失败码。
- **建议**:多命令组合取"最严重"退出码;`age baseline` 补 0/1(1=写入失败/权限)。
- **预期收益**:退出码语义完整,CI 脚本可精确判断。
- **工作量**:S

### P2-2: 定义 MCP route 未命中返回形状(D-8)

- **现状**:`age_route` 未命中时返回形状未定义,实现者可能返空 doc、null、或抛错。
- **建议**:规定未命中返回 `{doc: null, skill: null, reason: "no-match"}`,tool 不抛错,与 CLI 退出码 1 对称可观测。
- **预期收益**:未命中路径行为一致,消费方无需特判异常。
- **工作量**:S

### P2-3: 补 doc-auditor 默认 scope(D-14)

- **现状**:doc-auditor 触发"/age-audit"未规定 `--scope`,默认档不明。
- **建议**:补默认 `--scope full`,与 hooks.Stop 的 `--scope closure` 区分。
- **预期收益**:子代理行为可预期。
- **工作量**:S

### P2-4: 原生 Windows CLI 入口(D-12)

- **现状**:`cli/age` 为 POSIX,无 `cli/age.cmd`/`age.bat`,原生 Windows 无 bash 不可用。
- **建议**:补 `cli/age.cmd` 包装(调 Git-Bash 或 PowerShell 重实现核心命令)。优先级低于 P1-3(先确保 Git-Bash 可用)。
- **预期收益**:原生 Windows 用户零额外依赖。
- **工作量**:L

### P2-5: MCP `docs://status` 缓存策略(R5)

- **现状**:`docs://status` 实时算漂移分数,每次访问触发计算,低配机器开销可感知。
- **建议**:计算结果缓存 30 秒 TTL;server.py 懒加载;重计算放 tools 按需调用;`age doctor` 检测 MCP 启动耗时告警。
- **预期收益**:会话启动与资源访问更快。
- **工作量**:M

### P2-6: 文档深度防护(R10)

- **现状**:`templates/repo/docs/` 多目录,层级过深时检索成本上升。
- **建议**:`docs/index.md` 强制扁平索引;SessionStart 只注入 index+context 摘要;`age check` 检测 docs/ 深度超 3 层告警;各目录 README 明确"放什么/不放什么"。
- **预期收益**:文档可用性长期可控。
- **工作量**:M

---

## 优先级总览

| 优先级 | 数量 | 集成前必须 | 摘要 |
|---|---|---|---|
| P0 | 5 | 是 | 所有权补全 / hook 修正 / MCP 后端 / 子代理触发 / 冻结点 |
| P1 | 8 | 否(v1.1) | 命名统一 / 回写集 / 平台 / MCP 测试 / 层态矩阵 / hook 性能 / 触发兜底 / .age schema |
| P2 | 6 | 否(迭代) | 退出码 / route 形状 / scope / Windows / MCP 缓存 / 文档深度 |

> 建议执行顺序:P0 全部 → 集成 → P1 批量 → v1.1 发布 → P2 滚动。

# AGE Plugin 多客户端兼容方案审查报告

> 审查对象:`CONTRACT.md` §8.11 多客户端兼容(第三轮任务)
> 审查角色:方案审批与建议 agent
> 审查日期:2026-07-11
> 审查基线:`CONTRACT.md` §8.11 事实表 + 文件所有权表;关联 §1-7(分层/CLI/MCP/Hook/skill 契约)与 §8.5-8.9(前两轮接口约定)
> 审查状态:基于契约 §8.11 与事实表,本轮兼容层尚未实现(`compat/` 目录不存在,属构建前设计审批)

---

## 0. 审查范围与方法

本报告审查 §8.11 定义的多客户端兼容方案:让 AGE 插件兼容 ZCode / Claude Code / OpenAI Codex CLI / OpenCode CLI 四个客户端(Mutica 预留)。审查覆盖:

1. 兼容策略审查(ZCode 一等宿主 + 其他客户端适配层)
2. 客户端覆盖审查(逐一对照 §8.11 事实表核验扩展点覆盖)
3. `age install` 自动检测策略审查
4. AGENTS.md vs CLAUDE.md 同步审查
5. MCP server 跨客户端兼容审查
6. hooks 跨客户端审查(事件名/语义差异)
7. Mutica 预留审查
8. 审批结论与可执行前置条件

审查方法:以 §8.11 事实表为权威基线,逐一核验每个客户端的扩展点(MCP / 指令文件 / hooks / commands / skills)是否被适配配置覆盖,识别降级、缺口、误检、冲突。每条发现标注**严重度**(阻断/重要/次要)与**定位**。

> **审查前提声明**:本报告以 §8.11 事实表为"真"。若事实表本身有误(如某客户端实际支持 hooks 但表中标"无"),则结论需相应修正。事实表的准确性属调研质量范畴,不在本审查可验证范围——本审查假设事实表正确并据此推演。建议总调度在集成前对事实表做二次独立校验(见前置条件 CP-1)。

---

## 1. 兼容策略审查

### 1.1 策略概述

§8.11 兼容策略:
> ZCode 是一等宿主(完整插件);Claude Code / Codex / OpenCode 通过"适配层"兼容——CLI + AGENTS.md + MCP 是跨客户端可复用的公共层,hooks/commands/skills 按各客户端格式生成适配配置。

即:四层(插件/skill/CLI/MCP)+ hooks/commands 中,**CLI + AGENTS.md + MCP** 三件套被视为"跨客户端公共层",在所有客户端通用;**hooks / commands / skills** 被视为"客户端特化层",按各客户端格式适配。

### 1.2 "公共层"判断是否成立?

逐层核验"CLI + AGENTS.md + MCP 是否真能跨客户端复用":

| 公共层组件 | 跨客户端可复用性 | 评估 |
|---|---|---|
| **CLI(`cli/age` + `cli/lib/*.sh`)** | 高 | POSIX shell,不依赖 ZCode 运行时。各客户端只要能执行 shell 命令即可调用。唯一依赖:环境变量(`${ZCODE_PROJECT_DIR}`/`${ZCODE_PLUGIN_ROOT}`)在非 ZCode 客户端不存在,需适配层注入替代(见 §3/§5)。 |
| **AGENTS.md(指令文件)** | 中-高 | Claude Code 用 CLAUDE.md 而非 AGENTS.md(见 §4),需同步副本;Codex/OpenCode 用 AGENTS.md 可直接复用。内容本身(操作契约)客户端无关,可复用。 |
| **MCP server(`mcp/server.py`)** | 高 | stdio JSON-RPC 2.0 是 MCP 标准,各客户端 MCP 配置格式不同(JSON/TOML/数组)但协议层一致。server.py 用 python3 直跑、纯 stdlib(§8.8 Y),不依赖 ZCode。 |

**结论:公共层判断基本成立。** CLI/MCP 是协议级标准(stdio/shell),天然跨客户端;AGENTS.md 是内容层可复用,仅 Claude Code 需 CLAUDE.md 副本。三件套作为公共层是合理的最小可复用集。

### 1.3 "特化层"判断是否成立?

| 特化层组件 | 客户端差异 | 适配可行性 |
|---|---|---|
| **hooks** | ZCode PascalCase 7事件;Claude Code PascalCase(settings.json);OpenCode camelCase;Codex **无 hooks** | 需事件名映射表(PascalCase↔camelCase);Codex 直接降级(无 hook 路径) |
| **commands** | ZCode `.md+frontmatter`;Claude Code `.claude/commands/*.md+frontmatter`(格式相近);OpenCode `opencode.json` 内联(格式迥异);Codex **无 commands** | ZCode↔Claude 可近似复用;OpenCode 需转换为 JSON 内联;Codex 降级 |
| **skills** | ZCode 目录+SKILL.md;Claude Code `.claude/skills/SKILL.md`(路径不同但格式同);Codex **无 skills**;OpenCode **无 skills** | ZCode↔Claude 可复用(改路径);Codex/OpenCode 降级为"无元 skill 编排" |

**结论:特化层判断成立。** hooks/commands/skills 三件确有客户端格式差异,需适配。但需注意:**Codex 无 hooks/skills/commands**,意味着 Codex 适配后 AGE 退化为"CLI + AGENTS.md + MCP"三件套,丢失编辑态 hook 覆盖(漂移检测)与会话态 skill 编排——这是**功能降级**,非"兼容"(见 §2.3 与发现 C-5)。

### 1.4 策略总体评估

> **发现 C-1(重要):兼容策略方向正确,但"Codex 兼容"实为"Codex 降级",须在契约中显式声明降级矩阵。** §8.11 笼统说"兼容 Codex",但 Codex 无 hooks/skills/commands,AGE 在 Codex 上无法实现编辑态漂移检测(PostToolUse)、会话态元 skill 编排、slash 命令——只剩 CLI + AGENTS.md + MCP。这不是"兼容"而是"功能子集"。建议:
> - 在 `compat/README.md`(事实设计)显式给出**功能降级矩阵**:ZCode(全功能)/ Claude Code(全功能,CLAUDE.md 替代)/ OpenCode(无 skills,降级)/ Codex(无 hooks+skills+commands,重度降级)。
> - `age doctor` 须报告当前客户端的功能覆盖等级(full / partial / minimal),让用户知道降级程度。
> - AGENTS.md(模板)须注明"在无 hooks 客户端,编辑后须手动跑 `age sync`;在无 skills 客户端,须手动用 `age route`",提供降级操作指引。

---

## 2. 客户端覆盖审查

对照 §8.11 事实表,逐一审查每个客户端的适配配置是否覆盖其核心扩展点。

### 2.1 ZCode(一等宿主)— 覆盖完整,无需适配

ZCode 作为一等宿主,AGE 以原生插件形态运行(plugin.json + marketplace)。扩展点覆盖:

| 扩展点 | ZCode 支持 | AGE 覆盖方式 | 状态 |
|---|---|---|---|
| MCP | mcp.servers | `.zcode-plugin/plugin.json` mcpServers | ✓(§1 轮已实现) |
| 指令文件 | AGENTS.md | `templates/repo/AGENTS.md` | ✓ |
| Skills | 目录+SKILL.md | `skills/age/SKILL.md` + `skills/use-AGE/SKILL.md` | ✓ |
| Commands | .md+frontmatter | `commands/*.md` | ✓ |
| Hooks | PascalCase 7事件 | `hooks/hooks.json` + `hooks/scripts/*.sh` | ✓ |
| 插件打包 | plugin.json+marketplace | `.zcode-plugin/plugin.json` | ✓ |
| 项目目录 env | ${ZCODE_PROJECT_DIR} | plugin.json env 注入 | ✓ |

**结论:ZCode 覆盖完整,无适配缺口。** 本轮无需为 ZCode 增加适配文件。

### 2.2 Claude Code — 适配配置覆盖审查

§8.11 为 Claude Code 分配的适配文件:`compat/claude-code/` 下 README.md + settings.json + .mcp.json + CLAUDE.md。逐扩展点核验:

| 扩展点 | Claude Code 支持 | 适配文件 | 覆盖状态 |
|---|---|---|---|
| MCP | .mcp.json 顶层 mcpServers | `compat/claude-code/.mcp.json` | ✓ 覆盖 |
| 指令文件 | CLAUDE.md(非 AGENTS.md) | `compat/claude-code/CLAUDE.md` | ✓ 覆盖(同步问题见 §4) |
| Skills | .claude/skills/SKILL.md | settings.json 须配置 skills 路径 | **待确认**:settings.json 是否声明 skills 目录? |
| Commands | .claude/commands/*.md+frontmatter | settings.json 须配置 commands 路径 | **待确认**:settings.json 是否声明 commands? |
| Hooks | PascalCase(settings.json) | `compat/claude-code/settings.json` | ✓ 覆盖(事件名同 ZCode,见 §6) |
| 项目目录 env | 无标准 | 适配层须注入 | **缺口**(见发现 C-2) |
| 插件打包 | 无 | 不适用 | N/A(无插件机制) |

> **发现 C-2(重要):Claude Code 适配缺"项目目录 env 注入"策略。** §8.11 事实表显示 Claude Code "无标准"项目目录 env。AGE 的 MCP server(`mcp/server.py`)与 hook 脚本依赖项目根定位(§8.8 Y:server 读 `AGE_PROJECT_ROOT` → `AGE_PROJECT_DIR` → `os.getcwd()`)。在 ZCode 下 env 由 plugin.json 注入;在 Claude Code 下 `.mcp.json` 的 env 字段是否支持动态注入 `${projectDir}` 类变量?若不支持,server.py 回退 `os.getcwd()`,但 cwd 不一定等于项目根(取决于客户端启动 MCP 的工作目录)。建议:
> - 总调度在 `compat/claude-code/.mcp.json` 的 env 中显式设 `AGE_PROJECT_ROOT`(若 Claude Code 支持 `${workspaceFolder}` 类变量则注入,否则文档说明需用户手动设)。
> - `hooks/scripts/lib.sh`(§8.11 归总调度编辑)兼容 `CLAUDE_PROJECT_DIR`(§8.11 已列入总调度改动)——确认 Claude Code 是否实际暴露该变量,还是仅是预留名。
> - 在 `compat/claude-code/README.md` 明确:"若 MCP/hook 找不到项目根,手动 `export AGE_PROJECT_ROOT=/path/to/project` 后重启客户端"。

> **发现 C-3(次要):Claude Code skills/commands 的路径配置须在 settings.json 明确。** ZCode 下 skills 在插件目录自动发现;Claude Code 下 skills 在 `.claude/skills/`(用户级)或工作区 `.claude/skills/`。AGE 的 skills(`skills/age/`、`skills/use-AGE/`)需被 Claude Code 发现——是要求用户把 AGE skills 拷到 `.claude/skills/`,还是 settings.json 指向 AGE 插件目录的 skills/ 路径?§8.11 未明确。建议 `compat/claude-code/settings.json` 显式声明 skills 与 commands 的指向路径(指向 AGE 安装目录),`age install` 时写入。

### 2.3 Codex CLI — 适配配置覆盖审查(重度降级)

§8.11 为 Codex 分配的适配文件:`compat/codex/README.md` + `compat/codex/config.toml`。逐扩展点核验:

| 扩展点 | Codex 支持 | 适配文件 | 覆盖状态 |
|---|---|---|---|
| MCP | [mcp_servers.NAME](TOML) | `compat/codex/config.toml` | ✓ 覆盖(TOML 格式) |
| 指令文件 | AGENTS.md | 复用 `templates/repo/AGENTS.md` | ✓ 覆盖(原生 AGENTS.md) |
| Skills | **无** | 无 | ✗ **不可覆盖** |
| Commands | **无** | 无 | ✗ **不可覆盖** |
| Hooks | **无** | 无 | ✗ **不可覆盖** |
| 项目目录 env | 无 | 适配层须注入 | **缺口** |
| 插件打包 | 无 | 不适用 | N/A |

> **发现 C-4(阻断):Codex 无 hooks 导致 AGE 编辑态/收尾态覆盖完全失效,须显式定义降级操作路径。** 契约 §5 定义三个 hook:SessionStart(注入上下文)、PostToolUse(漂移检测)、Stop(收尾审计)。Codex 无 hooks,意味着:
> - 编辑后不会自动触发 `age sync`(漂移检测断裂)。
> - 会话结束不会自动触发 `age audit --scope closure`(收尾审计断裂)。
> - 会话开始不会自动注入 context(SessionStart 断裂,但 MCP resources 可部分替代)。
>
> 后果:在 Codex 上,AGE 的"四态覆盖"中**编辑态与收尾态断裂**,仅剩会话态(MCP)+ 提交态(CLI pre-commit)+ CI 态(CLI)。用户必须**手动**在编辑后跑 `age sync`、在任务结束跑 `age audit`,否则漂移积累。
>
> **要求(总调度 + 事实设计)**:
> 1. `compat/codex/README.md` 必须显式声明"Codex 无 hooks,以下操作须手动执行",并列出手动操作清单(编辑后 `age sync`;任务结束 `age audit --scope closure`)。
> 2. AGENTS.md 模板须有"Codex 降级指引"段(或在 `compat/codex/README.md` 覆盖),引导 Codex 用户养成手动 sync 习惯。
> 3. `age doctor` 须检测"当前客户端是否有 hooks 能力",无 hooks 时提示"编辑态漂移检测已禁用,请手动 `age sync`"。
> 4. 考虑在 Codex 的 AGENTS.md 中加入"每次 Edit 后提醒跑 age sync"的指令(利用 AGENTS.md 作为 agent 指令文件,让 Codex 的 agent 自觉执行——这是无 hooks 客户端的"指令兜底"策略)。

> **发现 C-5(重要):Codex 无 skills 导致元 skill 编排失效,须用 AGENTS.md 指令 + CLI 命令兜底。** AGE 的元 skill(`skills/age/SKILL.md`)负责路由/选技能/触发审计的编排逻辑。Codex 无 skills,意味着 ZCode 下"语义触发 skill"的能力在 Codex 上不存在。用户须用 CLI(`age route <task>` 等)手动替代。建议:
> - `compat/codex/README.md` 明确"Codex 用 `age route`/`age sync`/`age audit` CLI 命令替代 skill 编排",并列出 skill→CLI 映射表。
> - AGENTS.md(模板)本身已是"操作契约",可作为 Codex agent 的编排指令替代 skill(AGENTS.md 告诉 agent 何时调哪个 CLI)——这是无 skill 客户端的"指令兜底"。

> **发现 C-6(次要):Codex config.toml 的 MCP command/args 格式须按 TOML 语法生成,§8.11 未给样例。** §8.11 事实表仅说 Codex MCP 用 `[mcp_servers.NAME]` TOML 段,但未给 command/args/env 的 TOML 写法样例。TOML 与 JSON 语法差异大(数组、字符串、布尔语法不同)。建议 `compat/codex/config.toml` 提供完整可用的样例(含 command="python3"、args=[".../mcp/server.py"]、env={...}),`age install` 据此渲染。

### 2.4 OpenCode CLI — 适配配置覆盖审查

§8.11 为 OpenCode 分配的适配文件:`compat/opencode/README.md` + `compat/opencode/opencode.json`。逐扩展点核验:

| 扩展点 | OpenCode 支持 | 适配文件 | 覆盖状态 |
|---|---|---|---|
| MCP | mcp(command 为数组) | `compat/opencode/opencode.json` | ✓ 覆盖(但 command 数组格式特殊,见 §5) |
| 指令文件 | AGENTS.md | 复用 `templates/repo/AGENTS.md` | ✓ 覆盖 |
| Skills | **无**(用 commands) | 无 | ✗ **不可覆盖**(降级) |
| Commands | opencode.json 内联 | `compat/opencode/opencode.json` | ✓ 覆盖(但格式迥异,见发现 C-7) |
| Hooks | camelCase | `compat/opencode/opencode.json` | ✓ 覆盖(但事件名需映射,见 §6) |
| 项目目录 env | 无 | 适配层须注入 | **缺口** |
| 插件打包 | 无 | 不适用 | N/A |

> **发现 C-7(重要):OpenCode commands 为 JSON 内联格式,与 ZCode 的 .md+frontmatter 格式不兼容,须做格式转换。** ZCode commands 是 `.md` 文件 + frontmatter(name/description);OpenCode commands 是 `opencode.json` 内联对象。AGE 现有 5 个 commands(`commands/*.md`:age-init/age-sync/age-route/age-audit/use-age)。适配到 OpenCode 须把每个 .md 的 frontmatter + 正文转换为 opencode.json 的 commands 数组项。建议:
> - `compat/opencode/opencode.json` 的 commands 段提供完整样例(每个 command 的 name/description/body)。
> - `age install` 须能从 `commands/*.md` 自动提取 frontmatter + 正文,渲染到 opencode.json 的 commands 内联对象(或提供转换脚本)。
> - 考虑维护成本:每次 AGE 新增 command,Opencode 适配须同步——建议 `age install --client opencode` 每次重新生成 commands 段(而非手动维护)。

> **发现 C-8(重要):OpenCode 无 skills,与 Codex 同样面临元 skill 编排失效,须用 commands + AGENTS.md 兜底。** OpenCode 用 commands 替代 skills。AGE 元 skill 的编排逻辑(判断何时 route/sync/audit)在 OpenCode 上须转为:用户手动用 commands(/age-route 等)+ AGENTS.md 指令引导。这与 C-5(Codex)同类问题,降级策略可共用。建议 `compat/opencode/README.md` 明确降级,并与 Codex 降级指引保持一致措辞。

### 2.5 客户端覆盖审查小结

| 客户端 | MCP | 指令 | Hooks | Commands | Skills | 功能等级 |
|---|---|---|---|---|---|---|
| ZCode | ✓ | ✓ AGENTS.md | ✓ PascalCase | ✓ .md+frontmatter | ✓ 目录+SKILL | **full**(全功能) |
| Claude Code | ✓ | ✓ CLAUDE.md | ✓ PascalCase | ✓ .md+frontmatter | ✓ .claude/skills | **full**(全功能,需同步) |
| OpenCode | ✓ | ✓ AGENTS.md | ✓ camelCase(需映射) | ✓ 内联(需转换) | ✗ 无 | **partial**(无 skills) |
| Codex | ✓ | ✓ AGENTS.md | ✗ 无 | ✗ 无 | ✗ 无 | **minimal**(仅 CLI+AGENTS+MCP) |

> **发现 C-9(重要):§8.11 未定义"功能等级"概念,各客户端降级程度不可观测。** 建议引入 full/partial/minimal 三级功能等级(如上表),在 `compat/README.md`、`age doctor`、AGENTS.md 中统一使用,让用户与 agent 都能感知当前降级状态。这是 C-1 降级矩阵的可操作化。

---

## 3. `age install` 自动检测策略审查

§8.11 安排总调度实现 `cli/lib/install.sh`(`age install`)+ `cli/lib/common.sh::detect_host()`(检测当前客户端)。`age install` 自动检测客户端环境并装适配配置。

### 3.1 检测逻辑可靠性

`detect_host()` 须检测当前运行在哪个客户端。§8.11 未给检测算法,须推断可行方案:

| 检测信号 | ZCode | Claude Code | Codex | OpenCode |
|---|---|---|---|---|
| 环境变量 | `ZCODE_PROJECT_DIR`/`ZCODE_PLUGIN_ROOT` | `CLAUDE_PROJECT_DIR`(待确认) | `CODEX_HOME`(§8.11 提及) | `OPENCODE_CONFIG`(§8.11 提及) |
| 配置文件存在 | `~/.zcode/cli/config.json` | `~/.claude/settings.json` | `~/.codex/config.toml` | `~/.config/opencode/opencode.json` |
| 进程名 | zcode | claude | codex | opencode |

> **发现 C-10(重要):检测信号可靠性不均,环境变量是最可靠信号但非所有客户端都暴露。** §8.11 事实表明确:ZCode 有 `${ZCODE_PROJECT_DIR}`/`${ZCODE_PLUGIN_ROOT}`;Claude Code"无标准";Codex/OpenCode"无"标准 env(但 §8.11 在总调度改动里提到兼容 `CODEX_HOME`/`OPENCODE_CONFIG`,暗示这些变量存在但非事实表所列)。检测可靠性排序:
> 1. **环境变量(最可靠)**:ZCode 的 `ZCODE_*` 最确定。Claude Code 的 `CLAUDE_PROJECT_DIR` 待确认是否存在(§8.11 标"无标准",但总调度改动提及兼容它——矛盾,须澄清)。Codex/OpenCode 的 `CODEX_HOME`/`OPENCODE_CONFIG` 是否存在待确认。
> 2. **配置文件存在(次可靠)**:检查 `~/.zcode/`、`~/.claude/`、`~/.codex/`、`~/.config/opencode/` 是否存在。但这只能证明"客户端装过",不能证明"当前正运行在该客户端"——用户可能装了多个客户端。
> 3. **进程名(不可靠)**:shell 脚本检测父进程名跨平台不一致(macOS ps vs Linux ps),且 agent 进程名可能不含客户端名。
>
> **要求(总调度)**:`detect_host()` 须采用**优先级链**检测:
> 1. 先查 env 变量(`ZCODE_*` > `CLAUDE_*` > `CODEX_*` > `OPENCODE_*`)——命中即定。
> 2. env 全无时,查配置文件存在性——多命中时按"最近修改"或提示用户选择。
> 3. 全无时,提示"未检测到已知客户端,请用 `age install --client <zcode|claude|codex|opencode>` 显式指定"。
> 4. **绝不静默猜一个**——猜错会导致装错配置(如把 Claude 配置装到 Codex 用户目录)。

### 3.2 误检风险

> **发现 C-11(重要):多客户端共存场景下 detect_host 误检风险高,须支持显式指定与交互确认。** §8.11 要求检测"多客户端共存场景"。现代开发者常同时装 Claude Code + Codex(都在 ~/.claude/ 和 ~/.codex/)。若 `detect_host()` 仅靠配置文件存在性,会全部命中,无法判断"当前"是哪个。
>
> **要求**:
> 1. `age install` 默认交互模式:检测到多个客户端时,**列出检测结果让用户选**,不自动猜。非交互模式(`age install --client X` 或 `--force`)才跳过确认。
> 2. `age install --client <name>` 必须支持显式指定(覆盖自动检测)。
> 3. `age install --list` 列出所有可适配客户端及其检测结果(✓ 检测到 / ✗ 未检测到 / ? 不确定)。
> 4. 检测结果写入 `.age/installed-clients.json`(记录已装适配的客户端列表),供 `age doctor` 引用。

### 3.3 多客户端共存冲突

> **发现 C-12(阻断):多客户端共存时,AGE 的 AGENTS.md / CLAUDE.md / MCP 配置可能互相冲突,须定义共存规则。** 场景:用户同时用 Claude Code + Codex 开发同一项目。
> - **指令文件冲突**:Claude Code 读 CLAUDE.md,Codex 读 AGENTS.md。两者内容须同步(见 §4)。若用户编辑了 CLAUDE.md 但 AGENTS.md 未同步,两个客户端看到不同指令。
> - **MCP 配置冲突**:Claude Code 用 `.mcp.json`(工作区),Codex 用 `~/.codex/config.toml`(用户级,无工作区文件)。两者指向同一 MCP server,配置位置不同,不直接冲突,但 `age install` 须分别写入两处。
> - **hooks 冲突**:Claude Code settings.json 有 hooks,Codex 无。不冲突(Codex 无 hooks 不写)。
> - **`.age/` 共享**:两个客户端操作同一项目的 `.age/baseline.json`、`.age/writeback.json`,理论可共享(CLI 无状态隔离需求)。但若两客户端同时触发写(如 Claude PostToolUse 写 writeback,Codex 无 hook 但用户手动跑 age sync 也写),可能并发写冲突。
>
> **要求**:
> 1. `age install` 支持同时装多个客户端适配(`age install --client claude,codex` 或多次调用),各自写各自配置,不覆盖。
> 2. AGENTS.md 与 CLAUDE.md 的同步须有明确"源→副本"规则(见 §4),避免双向编辑失同步。
> 3. `.age/` 状态文件并发写风险:writeback.json 是 route 写、doc-sync 清空,若两客户端同时 route 不同任务,writeback 会被覆盖。建议 writeback.json 改为按任务追加(数组)而非单任务覆盖——但这超出本轮范围,记为风险(见风险登记册 RC-6)。

### 3.4 install 的写安全性

> **发现 C-13(重要):`age install` 是写操作(往用户家目录/工作区写配置),须有冲突保护与回滚。** 与 `age init`(见 use-age-design.md U-5)同理,`age install` 往 `~/.claude/settings.json` 等已有文件写配置时,若用户已有配置,直接覆盖会毁掉用户既有 hooks/skills 设置。
>
> **要求(总调度)**:
> 1. `age install` 写入前检测目标文件是否已有 AGE 相关配置(如已含 `age-mcp` server),有则跳过并提示"已安装",无则**合并**而非覆盖(对 JSON 须深合并,对 TOML 须段级追加)。
> 2. 用户既有配置不破坏:如 `~/.claude/settings.json` 已有其他 hooks,AGE 的 hooks 须追加到既有 hooks 数组,不替换。
> 3. 提供 `age uninstall --client <name>` 移除 AGE 适配配置(回滚)。
> 4. `age install --dry-run` 预览将写入的配置,不实际写。

---

## 4. AGENTS.md vs CLAUDE.md 审查

### 4.1 问题陈述

§8.11 事实表:Claude Code 用 `CLAUDE.md` 而非 `AGENTS.md`;Codex/OpenCode 用 AGENTS.md。§8.11 文件所有权表给 Claude Code 分配 `compat/claude-code/CLAUDE.md`,并要求"确认 AGENTS.md 跨客户端兼容(Claude 需 CLAUDE.md 软链/副本)"。

### 4.2 同步策略审查

两份文件内容须一致(都是 AGE 操作契约),但文件名不同。可能的同步策略:

| 策略 | 描述 | 评估 |
|---|---|---|
| A. 软链(symlink) | CLAUDE.md → AGENTS.md(或反向) | 跨平台问题:Windows 原生不支持 symlink(需管理员权限);Git 默认不跟踪 symlink 语义(可能提交为文本文件含路径)。不可靠。 |
| B. 硬拷贝副本 | `age init`/`age install` 时拷贝 AGENTS.md → CLAUDE.md | 简单可靠,但两份独立文件,编辑其一不同步。须有同步机制。 |
| C. 单源生成 | AGENTS.md 是源,`age install --client claude` 时从 AGENTS.md 生成 CLAUDE.md | 源唯一,无失同步风险。但要求 install 时模板渲染。 |

> **发现 C-14(重要):软链策略不可靠(跨平台+git),须用"AGENTS.md 为源、CLAUDE.md 为生成副本"策略。** §8.11 提"软链/副本",软链在 Windows/Git 下不可靠(见上表)。建议:
> - **AGENTS.md 是唯一源**(事实设计所有权,`templates/repo/AGENTS.md`)。
> - `age install --client claude`(或 `age init` 检测到 Claude Code)时,从 AGENTS.md **拷贝生成** CLAUDE.md(`cp AGENTS.md CLAUDE.md` 或渲染)。
> - CLAUDE.md 标注首行注释:"本文件由 AGENTS.md 自动生成,请勿直接编辑;修改请编辑 AGENTS.md 后重跑 `age install --client claude`"。
> - `age check` 须校验 CLAUDE.md 与 AGENTS.md 内容一致(若两者都存在),不一致则告警"CLAUDE.md 与 AGENTS.md 不同步,请重跑 age install --client claude"。

### 4.3 谁是源?

> **发现 C-15(次要):须明确 AGENTS.md 为源、CLAUDE.md 为副本,避免双向编辑。** §8.11 未指定谁是源。理由:
> - AGENTS.md 是 3/4 客户端(Codex/OpenCode/ZCode)的指令文件,CLAUDE.md 仅 Claude Code。
> - AGENTS.md 由事实设计在 `templates/repo/` 维护,是模板源。
> - CLAUDE.md 是适配产物,在 `compat/claude-code/`(也是事实设计,但是适配层)。
>
> 少数服从多数 + 模板源在 AGENTS.md,故 AGENTS.md 为源。CLAUDE.md 是生成副本。事实设计在 `compat/claude-code/CLAUDE.md` 维护的是"初始模板副本",`age install` 时覆盖用户项目的 CLAUDE.md。

### 4.4 Claude Code 是否同时读 AGENTS.md?

> **发现 C-16(次要):须确认 Claude Code 是否也读 AGENTS.md(若读,则无需 CLAUDE.md)。** §8.11 事实表标 Claude Code 指令文件为 CLAUDE.md。但部分客户端同时支持多个指令文件(如同时读 AGENTS.md + CLAUDE.md)。若 Claude Code 实际也读 AGENTS.md,则 CLAUDE.md 可省略,直接复用 AGENTS.md。建议总调度/事实设计二次确认 Claude Code 的指令文件读取优先级——若 Claude Code 优先读 CLAUDE.md、回退 AGENTS.md,则放一份 AGENTS.md 即可;若只读 CLAUDE.md,则必须生成 CLAUDE.md。这关系到是否需要 CLAUDE.md 同步机制(若可省略,§4 全节可简化)。

---

## 5. MCP server 跨客户端兼容审查

### 5.1 server.py 跨客户端一致性

§8.8 Y:`mcp/server.py` 用 python3 直跑、stdio JSON-RPC 2.0、纯 stdlib。MCP 协议层是标准的,各客户端配置格式不同但协议一致。核验:

| 客户端 | MCP 配置格式 | command | args | env | server.py 可工作? |
|---|---|---|---|---|---|
| ZCode | plugin.json mcpServers(JSON) | python3 | [server.py 路径] | AGE_PLUGIN_ROOT 等 | ✓(§1 轮已验证) |
| Claude Code | .mcp.json mcpServers(JSON) | python3 | [server.py 路径] | env(格式同 JSON) | ✓(若 env 注入正确) |
| Codex | config.toml [mcp_servers.NAME](TOML) | command="python3" | args=[...] | env={...} | ✓(TOML 语法,server 不变) |
| OpenCode | opencode.json mcp(command **为数组**) | command=[...] | (数组内含) | env | **待确认**(见 C-17) |

> **发现 C-17(重要):OpenCode MCP 的 command 为数组格式,与其他客户端的 command+args 分离格式不同,须确认 server.py 启动方式一致。** §8.11 事实表标 OpenCode MCP "command 为数组"。这可能意味着 OpenCode 把 command 与 args 合并为一个数组(如 `["python3", "/path/to/server.py"]`),而非 ZCode/Claude 的 `command: "python3", args: [...]` 分离格式。server.py 本身不变(都是被 python3 启动),但**适配配置的写法不同**。建议:
> - `compat/opencode/opencode.json` 的 mcp 段提供数组格式样例。
> - `age install --client opencode` 渲染时按数组格式生成。
> - 确认 OpenCode 是否支持 env 注入(若不支持,server.py 的 env 回退逻辑 `AGE_PROJECT_ROOT → AGE_PROJECT_DIR → os.getcwd()` 须在 OpenCode 下靠 cwd 兜底)。

### 5.2 项目根检测的跨客户端一致性

> **发现 C-18(重要):server.py 项目根检测在非 ZCode 客户端靠 cwd 兜底,但 cwd 不一定等于项目根,须适配层保证 cwd 正确或注入 env。** §8.8 Y:server 读 `AGE_PROJECT_ROOT` → `AGE_PROJECT_DIR` → `os.getcwd()`。ZCode 下 env 由 plugin.json 注入,可靠。其他客户端:
> - Claude Code:`.mcp.json` 的 env 是否支持 `${workspaceFolder}` 类变量?若不支持,cwd 兜底——但 MCP server 的 cwd 取决于客户端启动工作目录,可能不是项目根。
> - Codex:config.toml 的 env 是否支持动态变量?同上。
> - OpenCode:同上。
>
> **要求**:
> 1. 各客户端适配配置的 env 段**尽量注入** `AGE_PROJECT_ROOT`(若客户端支持变量替换则用变量,否则文档说明手动设)。
> 2. server.py 的 cwd 兜底须有**校验**:若 cwd 下无 `docs/` 或 `AGENTS.md`,输出 warning"项目根检测可能不准,当前 cwd=<...>,请设 AGE_PROJECT_ROOT"。
> 3. `age doctor` 须检测 MCP server 的项目根解析是否正确(server 启动后调 `age_route` 验证返回非空)。

### 5.3 MCP 协议版本一致性

> **发现 C-19(重要):各客户端的 MCP 协议版本可能不一致,server.py 须声明最低协议版本并优雅降级。** MCP 协议仍在演进(2024-2025)。不同客户端可能实现不同 MCP 版本(如 initialize 握手字段差异、resources/read vs tools/call 语义差异)。server.py 当前支持 initialize/resources/list/resources/read/tools/list/tools/call/ping(§8.8 Y),但若某客户端用旧版 MCP(如无 ping)或新版(如 streamable HTTP),server 须不崩。建议:
> - server.py 在 initialize 握手时记录客户端声明的 protocolVersion,若低于最低支持版本则告警(但不拒绝,尽力服务)。
> - `compat/*/README.md` 标注"目标 MCP 版本 = X",`age doctor` 检测客户端 MCP 版本兼容性。

---

## 6. hooks 跨客户端审查

### 6.1 事件名差异

§8.11 事实表:ZCode hooks 事件名 PascalCase(7事件);Claude Code PascalCase(settings.json);OpenCode **camelCase**;Codex **无 hooks**。

ZCode 7事件(PascalCase):SessionStart / SessionEnd / PreToolUse / PostToolUse / Notification / Stop / SubagentStop(典型 ZCode 事件集,契约 §5 用其中 3 个)。

OpenCode camelCase 对应(须映射):

| ZCode(PascalCase) | OpenCode(camelCase,推断) | AGE 用到? |
|---|---|---|
| SessionStart | sessionStart | ✓(§5) |
| PostToolUse | postToolUse | ✓(§5) |
| Stop | stop | ✓(§5) |
| SessionEnd | sessionEnd | ✗ |
| PreToolUse | preToolUse | ✗ |
| Notification | notification | ✗ |
| SubagentStop | subagentStop | ✗ |

> **发现 C-20(阻断):OpenCode hooks 事件名 camelCase 映射缺乏权威来源,§8.11 未给 OpenCode 事件名清单,映射表须二次确认。** §8.11 仅说 OpenCode "camelCase",但未列出 OpenCode 实际支持哪些事件。若 OpenCode 的事件集与 ZCode 7事件不完全对应(如 OpenCode 无 `stop` 事件,或命名不同如 `onStop`/`sessionEnd` 而非 `stop`),则映射表会有错。AGE 用到的 3 个事件(SessionStart/PostToolUse/Stop)若在 OpenCode 无对应,则 OpenCode 也降级为无 hooks(同 Codex)。
>
> **要求(总调度 + 事实设计)**:
> 1. `compat/opencode/opencode.json` 的 hooks 段须基于**实测的 OpenCode 事件名**(非推断的 camelCase),提供完整可用样例。
> 2. `compat/opencode/README.md` 明确 OpenCode 支持的事件子集与 ZCode 7事件的映射关系。
> 3. 若 OpenCode 实际不支持 SessionStart/PostToolUse/Stop 中的任一个,则 OpenCode 也须按 C-4(Codex 无 hooks)的降级策略处理(手动 sync/audit)。
> 4. `age doctor` 检测 OpenCode 下 hooks 是否实际触发(注入测试 hook 验证)。

### 6.2 hooks 语义差异

> **发现 C-21(重要):即便事件名映射正确,各客户端 hooks 的触发时机、matcher 语义、输出契约可能不同,须逐一验证。** ZCode hooks 的 matcher(如 `Edit|Write|MultiEdit`)是工具名正则;Claude Code 的 matcher 语法是否相同?OpenCode 的 matcher 是否支持正则?若不同,PostToolUse 的 matcher 须按客户端调整。同理:
> - **输出契约**:ZCode hook 用 stdout JSON `{"additionalContext":"..."}` 注入上下文(§8.6 K);Claude Code/OpenCode 的 hook 输出格式是否相同?若不同,`emit_context` 须按客户端分支。
> - **退出码语义**:ZCode hook exit 0 不阻断、exit 2 阻断(§8.6 K 严格 exit 0);Claude Code/OpenCode 退出码语义是否相同?
> - **触发时机**:PostToolUse 在工具调用后触发——是同步阻塞还是异步?各客户端可能不同,影响 R4(hook 性能)。
>
> **要求**:
> 1. `compat/claude-code/settings.json` 与 `compat/opencode/opencode.json` 的 hooks 段须基于各客户端**实测**的 matcher 语法与输出契约,非简单复制 ZCode hooks.json。
> 2. `hooks/scripts/lib.sh`(§8.11 归总调度编辑,兼容多客户端 env)须检测当前客户端,按客户端分支输出(emit_context 格式)。
> 3. `tests/test_compat.bats`(代码审查)须覆盖各客户端 hook 配置的合法性(至少 JSON/TOML 语法校验)。

### 6.3 Codex 无 hooks 的兜底(联动 C-4)

Codex 无 hooks,C-4 已定义降级路径。此处补充:无 hooks 客户端的"指令兜底"策略——在 AGENTS.md 中加入"agent 自觉执行"指令,让 Codex 的 agent 读 AGENTS.md 后自觉在编辑后跑 sync。这依赖 agent 遵守 AGENTS.md 指令(非强制),可靠性低于 hooks,但优于无兜底。

---

## 7. Mutica 预留审查

### 7.1 §8.11 Mutica 处理

§8.11:"Mutica 无可验证公开信息,在 compat/ 下预留 `compat/mutica/README.md`(事实设计)标注'待确认',不实现。"

### 7.2 预留是否合理?

> **发现 C-22(次要):Mutica 无信息预留策略合理,但须明确"待确认"的触发条件与复查机制。** 无可验证信息时,不实现、仅预留占位是正确策略(避免基于猜测实现导致返工)。但"待确认"不能是永久状态。建议:
> - `compat/mutica/README.md`(事实设计)标注:"Mutica 客户端扩展机制暂无可验证公开信息。本目录为预留占位。复查触发条件:Mutica 发布公开扩展文档 / 用户反馈需支持 Mutica。复查时按 §8.11 事实表格式补充 Mutica 列,并实现适配。"
> - `compat/README.md` 的客户端对照表标注 Mutica 为"待确认(预留)"。
> - `age install --client mutica` 须返回明确错误"Mutica 适配尚未实现(无公开扩展信息)",不静默跳过。
> - 本风险登记册记 RC-10(Mutica 信息缺失)追踪。

---

## 8. 审批结论

### 8.1 总体评估

| 维度 | 评级 | 说明 |
|---|---|---|
| 兼容策略合理性 | 通过 | 公共层(CLI+AGENTS+MCP)+ 特化层(hooks/commands/skills)划分成立 |
| 客户端覆盖完整性 | **需补强** | Codex 重度降级未显式声明(C-1/C-4/C-5);OpenCode skills 降级(C-8) |
| age install 检测可靠性 | **需补强** | 检测信号不均(C-10)、多客户端共存误检(C-11/C-12)、写安全性(C-13) |
| AGENTS.md/CLAUDE.md 同步 | **需补强** | 软链不可靠(C-14)、源未定(C-15) |
| MCP 跨客户端 | 有条件通过 | server.py 协议层一致,但 env/cwd 兜底须强化(C-17/C-18/C-19) |
| hooks 跨客户端 | **需返工** | OpenCode 事件名映射无权威来源(C-20 阻断)、语义差异未验证(C-21) |
| Mutica 预留 | 通过 | 无信息预留合理(C-22) |

### 8.2 结论

```
CONDITIONALLY APPROVED(有条件批准)
```

**裁决理由**:

多客户端兼容的**策略方向正确**(ZCode 一等宿主 + 其他客户端适配层,公共层/特化层划分成立),CLI+AGENTS.md+MCP 作为跨客户端公共层的判断经核验成立。但方案存在 **1 项阻断级缺陷**(C-20:OpenCode hooks 事件名映射无权威来源)与若干**重要级缺口**(降级矩阵未定义、age install 误检风险、AGENTS.md/CLAUDE.md 同步源未定、MCP env/cwd 兜底不足),须在实现前满足前置条件。

特别说明:Codex 的"重度降级"(无 hooks/skills/commands)不是方案缺陷而是客户端能力限制,但**降级程度须在契约/文档中显式声明**(C-1/C-4/C-5),否则用户会误以为"Codex 兼容 = Codex 全功能",实际编辑态/收尾态/编排态均断裂。

### 8.3 阻断项清单(实现前必须修复)

| ID | 缺陷 | 修复动作 | 责任 |
|---|---|---|---|
| C-20 | OpenCode hooks 事件名 camelCase 映射无权威来源 | 基于实测 OpenCode 事件名重写映射表;若 OpenCode 不支持 AGE 所需 3 事件,按 Codex 降级策略处理 | 总调度 + 事实设计 |

### 8.4 重要项清单(应在实现中修复,集成前关闭)

| ID | 缺陷 | 修复动作 | 责任 |
|---|---|---|---|
| C-1 | Codex"兼容"实为降级,未声明降级矩阵 | compat/README.md 给功能降级矩阵;age doctor 报功能等级 | 事实设计 + 总调度 |
| C-2 | Claude Code 项目目录 env 注入缺口 | .mcp.json 注入 AGE_PROJECT_ROOT;lib.sh 兼容 CLAUDE_PROJECT_DIR | 总调度 |
| C-4 | Codex 无 hooks 编辑态/收尾态断裂 | compat/codex/README.md 手动操作清单;AGENTS.md 降级指引;age doctor 检测 | 总调度 + 事实设计 |
| C-5 | Codex 无 skills 编排失效 | skill→CLI 映射表;AGENTS.md 指令兜底 | 事实设计 |
| C-7 | OpenCode commands 格式转换 | age install 从 .md 提取渲染到 opencode.json;提供样例 | 总调度 |
| C-8 | OpenCode 无 skills 降级 | 与 C-5 共用降级策略 | 事实设计 |
| C-9 | 未定义功能等级概念 | 引入 full/partial/minimal 三级 | 事实设计 |
| C-10 | detect_host 检测信号不均 | 优先级链检测(env>配置文件>提示) | 总调度 |
| C-11 | 多客户端共存误检 | 交互选择 + --client 显式指定 + --list | 总调度 |
| C-12 | 多客户端共存冲突 | 共存规则;AGENTS.md/CLAUDE.md 源→副本;writeback 并发风险记入 | 总调度 + 事实设计 |
| C-13 | age install 写安全性 | 合并不覆盖 + --dry-run + age uninstall | 总调度 |
| C-14 | 软链不可靠 | 改 AGENTS.md 为源、CLAUDE.md 生成副本;age check 校验同步 | 事实设计 + 总调度 |
| C-17 | OpenCode MCP command 数组格式 | opencode.json 数组样例;age install 渲染 | 事实设计 + 总调度 |
| C-18 | server.py 项目根 cwd 兜底不准 | env 注入 + cwd 校验 warning + age doctor 验证 | 总调度 |
| C-19 | MCP 协议版本不一致 | server 声明最低版本 + 优雅降级 | 总调度 |
| C-21 | hooks 语义差异未验证 | 各客户端实测 matcher/输出契约;lib.sh 按客户端分支 | 总调度 + 任务执行 |

### 8.5 次要项清单(后续迭代)

| ID | 缺陷 | 修复动作 |
|---|---|---|
| C-3 | Claude Code skills/commands 路径配置 | settings.json 显式声明指向 |
| C-6 | Codex config.toml 样例 | 提供完整 TOML 样例 |
| C-15 | AGENTS.md/CLAUDE.md 源未定 | 定 AGENTS.md 为源 |
| C-16 | Claude Code 是否读 AGENTS.md | 二次确认读取优先级 |
| C-22 | Mutica 预留复查机制 | 标注触发条件与复查日期 |

### 8.6 前置条件(实现前必须满足)

| # | 条件 | 强制级别 | 责任 | 关联发现 |
|---|---|---|---|---|
| CP-1 | §8.11 事实表二次独立校验(各客户端扩展点实际能力,尤 OpenCode hooks 事件名、Claude Code env 变量、Codex config.toml 格式) | P0 | 总调度 | C-20, C-16, C-2 |
| CP-2 | 定义功能降级矩阵(full/partial/minimal),写入 compat/README.md + age doctor + AGENTS.md | P0 | 事实设计 + 总调度 | C-1, C-4, C-5, C-8, C-9 |
| CP-3 | OpenCode hooks 事件名基于实测重写映射表(或确认降级) | P0 | 总调度 + 事实设计 | C-20 |
| CP-4 | age install 实现优先级链检测 + 交互选择 + --client/--list/--dry-run | P1 | 总调度 | C-10, C-11, C-13 |
| CP-5 | AGENTS.md 为源、CLAUDE.md 为生成副本策略写入契约;age check 校验同步 | P1 | 事实设计 + 总调度 | C-14, C-15 |
| CP-6 | 多客户端共存规则写入 compat/README.md | P1 | 事实设计 | C-12 |
| CP-7 | server.py 项目根 env 注入 + cwd 校验 warning | P1 | 总调度 | C-18 |
| CP-8 | hooks 脚本 lib.sh 按客户端分支输出(emit_context 格式) | P1 | 总调度 + 任务执行 | C-21 |
| CP-9 | Codex/OpenCode 降级操作清单(skill→CLI 映射 + 手动 sync/audit 指引) | P1 | 事实设计 | C-4, C-5, C-8 |

### 8.7 放行范围

满足 CP-1/CP-2/CP-3(P0)后,本轮 6 agent 可基于修订后的 §8.11 并发实现兼容层。**不满足 CP-3(阻断级)则 OpenCode 适配不予放行**;不满足 CP-1/CP-2 则整体不予放行(事实表准确性是全方案前提)。CP-4 至 CP-9 为 P1,可在实现中并行解决,但集成前须全部关闭。

### 8.8 建议的 §8.11 修订(供总调度纳入 CONTRACT v1.3)

1. **新增功能降级矩阵**:在 §8.11 兼容策略段补 full/partial/minimal 三级表(C-1/C-9)。
2. **新增 age install 检测契约**:在 §3 CLI 子命令表补 `age install [--client X] [--list] [--dry-run]` 行,注明优先级链检测与交互选择(C-10/C-11)。
3. **新增 AGENTS.md/CLAUDE.md 同步规则**:在 §8.11 或新增小节写死"AGENTS.md 为源、CLAUDE.md 为生成副本、age check 校验同步"(C-14/C-15)。
4. **新增 detect_host 优先级链**:在 §8.11 总调度改动项补 detect_host 检测算法(env > 配置文件 > 提示)(C-10)。
5. **OpenCode hooks 事件名实测**:§8.11 事实表 OpenCode 行的"Hooks 事件名 camelCase"须补具体事件名清单(实测后)(C-20)。

---

## 9. 附:与既有审批文档的关系

- 本文档是 `docs/approval.md`(CONDITIONALLY APPROVED,第一轮契约审批)与 `docs/use-age-design.md`(CONDITIONALLY APPROVED,第二轮 use-AGE 功能审批)的**第三轮补充**,针对多客户端兼容。
- 本文档发现 C-12(writeback 并发写风险)联动 `docs/risk-register.md` R9(回写集状态丢失),是多客户端场景下的放大。
- 本文档发现 C-18(项目根 cwd 兜底)联动 §8.8 Y(server.py env 回退链),是非 ZCode 客户端下的强化需求。
- 本文档不修改 CONTRACT.md(超出方案审批所有权);修订建议写入 §8.8,供总调度协调发布 CONTRACT v1.3。
- 兼容风险详见 `docs/compat-risk-register.md`(方案审批所有权,与本报告同步产出)。

---

## 10. 第二轮审查:CP-1 校验后修复验证(2026-07-11)

> 审查触发:第一轮 CONDITIONALLY APPROVED 列出 1 项阻断(C-20)+ 9 项前置条件(CP-1 至 CP-9)。CP-1 二次校验产生颠覆性结论(Codex 升级 full、OpenCode 降级 partial、Mutica 移除)。事实设计 / 总调度 / 代码审查三 agent 据此完成修复。本节逐项验证修复是否到位,并给出最终审批结论。
>
> 审查方法:逐文件读取实际内容,与修订后的 §8.11 事实表、CP-1 关键结论、功能降级矩阵逐一比对,不依赖假设。

### 10.1 CP-1 至 CP-3(P0 前置条件)逐项核验

**CP-1:§8.11 事实表二次独立校验 — 已关闭。**
- `CONTRACT.md` §8.11 已修订:事实表标注 Codex"PascalCase(10事件,与Claude一致)"、OpenCode"dot-notation小写(tool.execute.after等)",并在"CP-1 校验关键结论"段写明四项权威结论(Codex 有完整 hooks+skills / OpenCode 无 SessionStart·Stop / Claude 事实正确 / Mutica 不存在)。事实表与原始结论一致,无残留错误。✓

**CP-2:功能降级矩阵写入 compat/README.md + 契约 — 已关闭。**
- `CONTRACT.md` §8.11 含完整"功能降级矩阵"表(8 行 × 4 客户端)。`compat/README.md` 第 57-68 行含同名矩阵,内容与契约一致(ZCode/Claude/Codex 均覆盖 SessionStart/PostToolUse/Stop;OpenCode SessionStart=❌、Stop=❌、PostToolUse=⚠️ tool.execute.after)。`README.md`(根)第 66-76 行亦含降级矩阵。三处矩阵一致,无冲突。✓

**CP-3:OpenCode hooks 实测 → 降级为 partial — 已关闭。**
- `compat/opencode/opencode.json` 已移除不可行的 `onSessionStart`/`onStop`,仅保留 `tool.execute.after`(dot-notation 小写),并在 `_comment` 段写明"CP-1 校验结论:无 SessionStart/Stop 事件"。`compat/opencode/README.md` 第 17-19 行明确标注 SessionStart=❌(无此事件)、Stop=❌(无此事件)、PostToolUse=⚠️(tool.execute.after 近似),并给出"降级操作清单"小节(SessionStart 手动跑 /age-sync、Stop 手动跑 /age-audit)。opencode.json 的 commands 段含 age-sync 与 age-audit 降级命令,且 prompt 明确标注"DEGRADATION FALLBACK for missing SessionStart/Stop hook"。✓

### 10.2 CP-4 至 CP-9(P1 前置条件)逐项核验

**CP-4:age install 检测链 + --list + Codex hooks 安装 — 已关闭。**
- `cli/lib/install.sh`:支持 `--client`/`--dry-run`/`--list` 三选项(L19-29)。`age_install_list()`(L240-261)列出四客户端及兼容等级,注明 Mutica 已移除。`_age_install_codex()`(L154-195)合并 config.toml(含 [mcp_servers] + [hooks] 段),dry-run 时明确报告"含 MCP servers + hooks(SessionStart/PostToolUse/Stop)"。`_age_install_opencode()`(L205-233)正确降级:仅装 MCP + commands,提示"未安装 SessionStart/Stop hooks(OpenCode 无此事件,不可行)"。`cli/lib/common.sh::detect_host()`(L162-241)实现优先级链(env > 配置文件 > unknown),Codex 检测增强(检测 config.toml 含 [hooks] 段)。✓

**CP-5:AGENTS.md 为源、CLAUDE.md 为生成副本标注 — 已关闭。**
- `templates/repo/AGENTS.md` 第 5 行含"⚠️ CLAUDE.md 副本声明(CP-5)"段,明确 CLAUDE.md 是本文件的 Claude Code 适配副本,由 age install 生成,改操作指令改 AGENTS.md。
- `compat/claude-code/CLAUDE.md` 第 3 行含"⚠️ 源文件标注(CP-5):本文件是 AGENTS.md 的生成副本",明确改 AGENTS.md 后重跑 age install。第 10 行补充"若 AGENTS.md 与本文件冲突,以 AGENTS.md 为准"。
- `compat/README.md` 第 76-88 行"AGENTS.md vs CLAUDE.md 的关系(源与副本策略)"小节写明 AGENTS.md 为源、CLAUDE.md 为生成副本、修改规则(铁律三条)。三处标注一致。✓

**CP-6:多客户端共存规则写入 compat/README.md — 已关闭。**
- `cli/lib/install.sh::_age_install_coexistence_warn()`(L266-309)实现共存检测:安装某客户端时检测其他客户端配置痕迹(.zcode/、.claude/、CLAUDE.md、opencode.json、~/.codex/config.toml),命中则提示"AGENTS.md / CLAUDE.md 指令文件需保持同步(CLAUDE.md 是 AGENTS.md 的生成副本)"。`compat/README.md` 亦通过"源与副本策略"小节承载共存规则。安装入口 `age_install()` 在分发前调用 `_age_install_coexistence_warn`。✓

**CP-7:server.py 项目根 cwd warning — 已关闭。**
- `mcp/server.py::_warn_cwd_fallback()`(L91-115)实现:当 `_project_root()` 回退到 cwd(L86-88)时,二次校验 cwd 是否为 git 仓库根(避免误报),非 git 根则输出 warning 到 stderr:"AGE 警告(CP-7): 项目根检测回退到 cwd,可能不准确。建议设置 AGE_PROJECT_ROOT 环境变量。"。`_project_root()` 的优先级链(L46-88):AGE_PROJECT_ROOT → ZCODE_PROJECT_DIR → CLAUDE_PROJECT_DIR → AGE_PROJECT_DIR → git root → cwd(+warning)。链路完整。✓

**CP-8:hooks 按客户端分支 emit_context — 已关闭。**
- `hooks/scripts/lib.sh::detect_hook_client()`(L139-173)按优先级检测客户端(env 优先 → 配置文件特征),输出 zcode|claude|codex|opencode|unknown。
- `emit_context()`(L185-202)按客户端分支:opencode → `{"message":"<text>"}`;其余(zcode/claude/codex/unknown)→ `{"additionalContext":"<text>"}`。注释(L126-134)明确标注 CP-8 与各客户端输出格式依据。awk 转义保持可移植性。✓

**CP-9:Codex/OpenCode 降级操作清单 — 已关闭。**
- `compat/opencode/README.md` 第 23-43 行"降级操作清单"小节:列出 SessionStart/Stop 缺失的手动替代操作表 + 保留的 tool.execute.after hook + 推荐工作流(四步)。
- `compat/codex/README.md` 第 75-87 行"无标准 slash commands 的限制"小节:列出 slash command → CLI 子命令映射表(/age-route→age route、/age-sync→age sync 等)。
- `compat/codex/config.toml` 第 36-44 行含完整 [hooks.SessionStart]/[hooks.PostToolUse]/[hooks.Stop] 段(因 Codex 是 full 级,不需降级,但 README 仍提供 CLI 替代清单作为无 slash commands 的兜底)。✓

### 10.3 上一轮阻断项(C-4 / C-12 / C-20)关闭确认

**C-20(阻断):OpenCode hooks 事件名 camelCase 映射无权威来源 — 已关闭。**
- CP-1 校验已确认 OpenCode 用 dot-notation 小写(`tool.execute.after`),无 SessionStart/Stop。`compat/opencode/opencode.json` 与 `README.md` 已据此重写,不再用推断的 camelCase 映射。映射表无权威来源的问题已通过"降级为 partial + 仅保留实测的 tool.execute.after"消解。✓

**C-4(阻断):Codex 无 hooks 降级路径 — 已关闭(实为事实纠正,无需降级)。**
- CP-1 校验纠正:Codex 有完整 hooks(PascalCase,与 Claude Code 一致)。`compat/codex/config.toml` 含 [hooks.SessionStart|PostToolUse|Stop] 段,`README.md` 标注 Codex 为 full 级。原 C-4 基于"Codex 无 hooks"的错误事实,现已纠正,Codex 不再需要降级路径。✓

**C-12(阻断):多客户端共存规则 — 已关闭。**
- 见 CP-6 核验:`_age_install_coexistence_warn()` 已实现,compat/README.md 含源与副本策略。共存冲突(指令文件/MCP/hooks/.age)的规则已落地:AGENTS.md 为源、CLAUDE.md 为生成副本、各客户端配置各自写入不覆盖。✓

### 10.4 第一轮重要项(P1)关闭确认(抽样)

- **C-1/C-9(降级矩阵 + 功能等级)**:compat/README.md + 契约 + 根 README 三处含 full/partial 矩阵。✓
- **C-2(Claude Code env 注入)**:`compat/claude-code/.mcp.json` 注入 `AGE_PLUGIN_ROOT`/`AGE_PROJECT_ROOT`/`AGE_PROJECT_DIR`(均映射到 `$CLAUDE_PROJECT_DIR`),`lib.sh::age_project_dir()` 兼容 `CLAUDE_PROJECT_DIR`。✓
- **C-14/C-15(AGENTS.md 为源)**:见 CP-5。✓
- **C-17(OpenCode MCP command 数组)**:`opencode.json` 的 mcp.age-mcp.command 为 `["python3","$AGE_PLUGIN_ROOT/mcp/server.py"]` 数组格式,符合 OpenCode 规范。✓
- **C-18(server.py cwd 校验)**:见 CP-7。✓
- **C-21(hooks 语义差异 / emit_context 分支)**:见 CP-8。✓

### 10.5 测试断言更新核验

**`tests/test_compat.bats`:**
- 含"Codex config.toml contains a [hooks] section (CP-1: Codex has full hooks)"断言(L195-203),grep `^\[hooks` 段。
- 含"compat/codex/config.toml wires SessionStart/PostToolUse/Stop hooks"断言(L205-219)。
- 含"compat/codex has a skills adapter (CP-1)"断言(L221-240),校验 compat/codex/skills/README.md 含 `.codex/skills` 引用。
- 含"opencode.json does NOT wire SessionStart/Stop hooks (CP-1)"断言(L291-309),检查 hooks 键不含 onSessionStart/onStop/SessionStart。
- 含"opencode.json wires tool.execute.after as the PostToolUse fallback"断言(L311-323)。
- 含"opencode.json documents degrade commands age-sync and age-audit"断言(L325-337)。
- 含"compat/ does NOT contain a mutica/ subdirectory"断言(L97-105)与"compat/README.md does not list Mutica"断言(L358-369,容忍移除说明)。
- 含 Codex=full、OpenCode=partial 等级断言(L376-391)。
- 断言与修订后契约一致。✓

**`tests/test_install.bats`:**
- 含"age install --client codex installs a [hooks] section (CP-1)"断言(L181-197)。
- 含"age install --client opencode does NOT install SessionStart/Stop hooks (CP-1)"断言(L222-243)。
- 含"age install --list lists all four supported clients"断言(L252-266)与"does NOT list Mutica"断言(L268-283,容忍移除说明)。
- 断言与修订后契约一致。✓

### 10.6 新引入问题检查

逐文件审查后,发现 1 项**非阻断的残留不一致**(归任务执行 agent 所有权,不在本审查可编辑范围,仅记录供总调度协调):

> **发现 C-23(次要,非阻断):`commands/age-install.md` 仍列出 Mutica 为客户端,与 CP-1 结论冲突。**
> - 定位:`commands/age-install.md` 第 53 行客户端表含"| Mutica | `compat/mutica/README.md` | — | Not yet verified; README marks "待确认" |"。
> - 问题:CP-1 已确认 Mutica 不存在(实验性编程语言,非 AI 客户端),compat/mutica/ 已删除(实测目录不存在)。该表行仍引导用户查阅已删除的 `compat/mutica/README.md`,与契约 §8.11、compat/README.md、根 README、test_compat.bats 的移除结论不一致。
> - 严重度:次要(非阻断)。该文件是 slash command 文档,运行时由 age install 实际输出决定行为(install.sh 已正确移除 Mutica),表行仅为回退指引说明。不影响 install 功能正确性,但会造成用户阅读困惑。
> - 责任:任务执行 agent(commands/* 所有权,§2)。建议删除第 53 行 Mutica 表行,并在第 45 行附近补一句"Mutica 已移除(CP-1:非 AI 客户端)"。
> - 处置:本审查不编辑该文件(超出方案审批所有权)。记为 P2 后续项,不阻断本轮审批。

其余文件未发现新引入问题。各文件交叉一致性良好:
- 事实表(Codex full / OpenCode partial / Mutica 移除)在 CONTRACT §8.11、compat/README.md、根 README.md、codex/README.md、opencode/README.md、test_compat.bats、test_install.bats、install.sh、common.sh 七处一致。
- AGENTS.md 源/CLAUDE.md 副本标注在 AGENTS.md 模板、CLAUDE.md、compat/README.md 三处一致。
- 降级矩阵在 CONTRACT、compat/README.md、根 README.md 三处一致。
- hooks 事件名(Codex PascalCase / OpenCode dot-notation)在契约、compat 各 README、config.toml、opencode.json、lib.sh emit_context 分支一致。

### 10.7 最终审批结论

```
APPROVED(批准)
```

**裁决理由:**

1. **三项阻断项全部关闭**:C-20(OpenCode 事件名无权威来源)经 CP-1 校验降级为 partial 后消解;C-4(Codex 无 hooks)经 CP-1 纠正为 full 后无需降级;C-12(多客户端共存)经 `_age_install_coexistence_warn` + 源/副本策略落地。

2. **九项前置条件(CP-1 至 CP-9)全部关闭**:逐文件核验通过,见 §10.1-10.2。P0(CP-1/CP-2/CP-3)与 P1(CP-4 至 CP-9)均已实现且与契约一致。

3. **第一轮重要项(P1)关闭**:C-1/C-2/C-9/C-14/C-15/C-17/C-18/C-21 等抽样核验通过。

4. **测试断言同步更新**:test_compat.bats 与 test_install.bats 已按 CP-1 修订结论更新断言(Codex 有 hooks+skills、OpenCode 无 SessionStart/Stop、Mutica 移除),与契约对齐。

5. **无新引入阻断**:仅发现 1 项次要残留(C-23:commands/age-install.md 仍列 Mutica 表行),属任务执行 agent 文档,不影响 install 功能正确性,记为 P2 后续项,不阻断审批。

**放行范围:** 本轮 6 agent 修复全部到位,多客户端兼容方案可进入集成阶段。建议总调度协调:
- (P2)通知任务执行 agent 修正 `commands/age-install.md` 第 53 行 Mutica 残留(C-23)。
- (P2,延续第一轮)C-3/C-6/C-16/C-19/C-22 等次要项可在后续迭代处理,不阻断集成。
- 集成测试时运行 `bats tests/test_compat.bats tests/test_install.bats` 验证兼容层与安装命令的契约一致性。

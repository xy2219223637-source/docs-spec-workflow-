# AGE Plugin Win11 兼容风险登记册

> 风险对象:`CONTRACT.md` §8.12 Win11 兼容(第四轮任务)
> 维护角色:方案审批与建议 agent
> 建册日期:2026-07-11
> 关联文档:`docs/win11-design-review.md`(审查报告,风险的发现 ID 对应本文 Risk ID)
> 状态约定:Open(未关闭)/ Mitigating(已识别缓解,实现中)/ Closed(已关闭)

---

## 风险评估标准

- **概率(H/M/L)**:在 Win11 兼容层实现与运行期间,该风险发生的可能性。
  - H = 大多数 Win11 用户会触发;M = 特定配置/场景触发;L = 罕见但须防范。
- **影响(H/M/L)**:发生后对 AGE 功能的影响程度。
  - H = 功能完全不可用(命令/hook/MCP 失败);M = 部分功能降级或需手动干预;L = 体验受损但可 workaround。
- **风险等级 = 概率 × 影响**(H/H=阻断,H/M 或 M/H=重要,其余=次要)。

---

## 风险登记表

### RW-1:PowerShell 5.1 vs 7 语法差异导致 age.ps1 报错

| 字段 | 内容 |
|---|---|
| 风险 ID | RW-1 |
| 描述 | age.ps1 若使用 PowerShell 7 独有语法(`??` 空合并、`?:` 三元、`&&`/`||` 短路、`ForEach-Object -Parallel`、`$PSNativeCommand*`),在仅装 PowerShell 5.1 的 Win11(大多数用户,5.1 为预装默认)上会语法错误退出,age.ps1 完全不可用。反之若实现者误以为只支持 5.1 而禁用有用特性,在装了 7 的用户上体验降级。§8.12 未声明目标 PS 版本。 |
| 概率 | H(5.1 是预装默认,大多数 Win11 用户仅此版本) |
| 影响 | H(age.ps1 全部命令不可用,Win11 原生层失效) |
| 风险等级 | 阻断 |
| 缓解 | (1) age.ps1 强制兼容 PowerShell 5.1,首部加 `#Requires -Version 5.1`,禁用 7 独有语法;(2) 用 PSScriptAnalyzer 静态校验 5.1 兼容性;(3) `age doctor` 报告当前 PS 版本与兼容性;(4) tests/test_win11.bats 在 PS 5.1 与 7 双版本下各跑一次(若 CI 无 Win11,至少静态校验);(5) compat/win11/README.md 声明"支持 PS 5.1+(含 7)"。 |
| 负责人 | 总调度(实现 age.ps1 + cli/lib/*.ps1);代码审查(PSScriptAnalyzer + 测试) |
| 关联发现 | W-1 |
| 状态 | Open |

---

### RW-2:CRLF 污染导致模板占位符渲染失败与 JSON 解析失败

| 字段 | 内容 |
|---|---|
| 风险 ID | RW-2 |
| 描述 | Win11 上 git autocrlf 默认 true,checkout 时把 .sh/.ps1/.md/.json 的 LF 转 CRLF。后果:(1) 模板文件含 CRLF 时,占位符 `{{key}}` 可能跨行或在行尾带 `\r`,sed 式替换不匹配,`age init` 渲染后 `{{}}` 残留;(2) `age sync --json` 输出经 PowerShell 捕获后若隐式转 CRLF,下游 hook 的 JSON 解析报错;(3) `.age/baseline.json` 若 CRLF,bash 侧 jq 解析失败;(4) .sh 脚本本身含 CRLF 时,bash 执行报 `\r: command not found`。这是最隐蔽的 Win11 兼容陷阱,跨模板渲染/CLI 输出/状态文件/hook 脚本四层。 |
| 概率 | H(Win11 默认 autocrlf,几乎所有用户) |
| 影响 | H(模板渲染失败 + JSON 解析失败 + .sh 脚本不可执行) |
| 风险等级 | 阻断 |
| 缓解 | (1) 仓库根加 `.gitattributes` 强制 `*.sh text eol=lf`、`*.ps1 text eol=lf`、`*.json text eol=lf`、`*.md text eol=lf`(根因防护);(2) age.ps1 渲染前用 `[System.IO.File]::ReadAllText` 读取 + `-replace "\`r\`n", "\`n"` 转 LF,写出用 `WriteAllText`(LF);(3) age.ps1 输出 JSON 前 trim `\r`;(4) hook 读取 age 输出后先 trim `\r`;(5) tests/test_win11.bats 加 CRLF 测试用例(autocrlf 环境下跑 age init,断言无 `{{}}` 残留、无 `\r` 污染);(6) conventions.md(过程计划)补"Win11 行结束符约定:统一 LF"。 |
| 负责人 | 总调度(.gitattributes + age.ps1 normalize + JSON trim);事实设计(conventions.md);代码审查(测试) |
| 关联发现 | W-10 |
| 状态 | Open |

---

### RW-3:Python 命令名差异(python vs python3 vs py -3)致 MCP server 无法启动

| 字段 | 内容 |
|---|---|
| 风险 ID | RW-3 |
| 描述 | §8.12 事实:Win11 上 python 通常是 `python`(不含 3),需 `py -3` 启动特定版本。现有 `.zcode-plugin/plugin.json` 的 mcpServers.command 静态写 `python3`(§8.8 Y),Win11 上该命令不存在,ZCode 启动 MCP server 时 `python3 mcp/server.py` 报"python3 不是命令",MCP 全部 resources/tools 不可用。同理,age.ps1 若硬编码调 `python3` 也会失败。 |
| 概率 | H(Win11 几乎无 `python3` 命令名) |
| 影响 | H(MCP server 无法启动,会话态 resources/tools 全失效) |
| 风险等级 | 阻断 |
| 缓解 | (1) age.ps1 实现 Python 检测链 `python`→`python3`→`py -3`,检测后写入 `$AGE_PYTHON` 变量;(2) `age install --client win11` 动态生成 Win11 MCP 配置(command=检测到的 python 命令名),而非用静态 `python3`;(3) `age doctor` 在 Win11 检测 python 命令名是否与 MCP 配置一致,不一致时提示重跑 install;(4) compat/win11/env-template.ps1(事实设计)提供 `$AGE_PYTHON` 变量模板;(5) tests/test_win11.bats 验证三种 python 命令名场景下 MCP server 可启动。 |
| 负责人 | 总调度(age.ps1 检测链 + install 动态生成 MCP 配置 + doctor 校验);事实设计(env-template.ps1) |
| 关联发现 | W-5, W-13 |
| 状态 | Open |

---

### RW-4:路径分隔符(\ vs /)差异导致 sed/grep/find/路径校验失效

| 字段 | 内容 |
|---|---|
| 风险 ID | RW-4 |
| 描述 | Win11 路径用 `\`,POSIX 用 `/`。AGE 的 bash 脚本中 `[ -d "$path" ]`、`grep`/`sed` 处理路径、`age_resolve_cli()` 拼接 `${ZCODE_PLUGIN_ROOT}/cli/age` 在 Win11 上若 env 注入的是 `C:\Users\...`,拼接产生混合分隔符 `C:\Users\.../cli/age`,bash 的 `[ -x ]` 可能失败。age.ps1 若用字符串拼接路径(`$root + "\" + ...`)也产生混合分隔符。`age check` 死链检测、`age route` 路由解析若用 `\` 路径,grep 正则可能失效。 |
| 概率 | M(ZCode 在 Win11 注入的 env 路径风格待确认,见 RW-9;Git-Bash 下 cygpath 可转换) |
| 影响 | H(路径校验失败 → CLI 命令/hook 误判插件根/项目根不存在) |
| 风险等级 | 阻断 |
| 缓解 | (1) age.ps1 与 cli/lib/*.ps1 须用 `Join-Path`/`Split-Path`/`Resolve-Path`,禁止字符串拼接;(2) compat/win11/path-utils.ps1(事实设计)提供 `Convert-ToPosixPath`(Win→POSIX)与 `Convert-ToWinPath` 工具;(3) Git-Bash 层用 `cygpath -u` 转换 Windows 路径为 `/c/...` 风格,lib.sh 的 age_resolve_cli 加路径转换;(4) 模板内引用路径统一用 `/`(POSIX 风格,PS/Python/Git 都接受);(5) `.age/*.json` 状态文件存储路径统一用 `/`(避免 Win11 写 `\` 后 Linux 读不了);(6) `age check` 路径解析同时接受 `/` 与 `\`。 |
| 负责人 | 总调度(age.ps1 Join-Path + Git-Bash cygpath 转换);事实设计(path-utils.ps1) |
| 关联发现 | W-9 |
| 状态 | Open |

---

### RW-5:Git-Bash 环境差异(macOS BSD vs Win GNU coreutils)

| 字段 | 内容 |
|---|---|
| 风险 ID | RW-5 |
| 描述 | 现有 .sh 脚本已做 macOS BSD / Linux GNU 兼容(§8.8 AB:`stat -f '%m'` vs `stat -c '%Y'`、`tac` vs `tail -r`、awk 可移植写法)。Git-Bash 提供 GNU coreutils,理论走 GNU 分支可用。但 Git-Bash 有特有差异:(1) 路径风格 `/c/...` 而非 `/usr/...`;(2) 部分工具版本较旧(Git for Windows 绑定的 coreutils);(3) `cygpath`/`winpty` 等 Git-Bash 专有工具;(4) 文件权限模型不同(无传统 UNIX exec 权限,见 RW-9)。现有脚本的 BSD/GNU 双分支是否在 Git-Bash 下正确走 GNU 分支,未实测验证。 |
| 概率 | M(大多 GNU 分支可用,但路径风格与权限模型差异可能致特定命令失败) |
| 影响 | M(Git-Bash 层部分命令失败,需回退 PowerShell 原生层) |
| 风险等级 | 重要 |
| 缓解 | (1) tests/test_win11.bats 加 Git-Bash 层测试:在 Git-Bash 下跑现有 cli/age + hooks/scripts/*.sh 的核心命令(init/sync/route/audit/doctor),断言可用;(2) compat/win11/README.md 列出 Git-Bash 依赖清单(bash 4.4+、git、GNU coreutils);(3) `age doctor` 在 Git-Bash 下检测 coreutils 工具(find/grep/sed/awk/sort/wc)可用性;(4) 若 Git-Bash 层某命令失败,文档指引"回退 PowerShell 原生层"。 |
| 负责人 | 总调度(Git-Bash 层验证 + doctor 检测);代码审查(test_win11.bats Git-Bash 测试) |
| 关联发现 | W-17, W-18 |
| 状态 | Open |

---

### RW-6:hook 的 pwsh(PowerShell 7)启动延迟

| 字段 | 内容 |
|---|---|
| 风险 ID | RW-6 |
| 描述 | §8.12 标题提"pwsh vs powershell 回退"。若 hook command 用 `pwsh -File ...`(PowerShell 7),pwsh 启动延迟较 `powershell.exe`(5.1)更高(7 的 .NET Core 冷启动约 0.5-1.5s,5.1 约 0.3-0.8s)。PostToolUse hook 每次编辑触发(timeout 15s),若 pwsh 冷启动 + age.ps1 执行 + age sync 耗时,可能逼近 timeout,致 hook 超时或用户感知卡顿。SessionStart hook timeout 30s,风险较低;Stop hook timeout 15s,与 PostToolUse 同风险。 |
| 概率 | M(装了 PS 7 且 hook 用 pwsh 时;若用 powershell 5.1 则无此风险) |
| 影响 | M(hook 超时致漂移检测/收尾审计未执行,功能降级) |
| 风险等级 | 重要 |
| 缓解 | (1) hook command 默认用 `powershell.exe`(5.1,预装,启动快),而非 `pwsh`(7,可选,启动慢);(2) `-ExecutionPolicy Bypass` 避免策略交互延迟;(3) age.ps1 启动优化:延迟 source cli/lib/*.ps1(仅按需 source 对应命令的 lib);(4) `age doctor` 报告 hook 启动延迟(实测 powershell vs pwsh 的冷启动时间);(5) 若用户明确选 pwsh,doctor 提示"PostToolUse hook 可能因 pwsh 启动延迟超时,建议用 powershell";(6) 文档标注 hook timeout 与 PS 启动时间的关系。 |
| 负责人 | 任务执行(hook command 用 powershell 5.1 + -ExecutionPolicy Bypass);总调度(age.ps1 延迟 source + doctor 延迟报告) |
| 关联发现 | W-8 |
| 状态 | Open |

---

### RW-7:环境变量注入差异($env: vs $)致 .ps1 脚本读取失败

| 字段 | 内容 |
|---|---|
| 风险 ID | RW-7 |
| 描述 | PowerShell 用 `$env:VAR` 读取环境变量,bash 用 `$VAR`/`${VAR}`。age.ps1 与 .ps1 hook 若误用 `$VAR`(PowerShell 中 `$VAR` 是普通变量非环境变量),读不到 ZCode 注入的 `ZCODE_PLUGIN_ROOT`/`ZCODE_PROJECT_DIR` 等。更深问题:ZCode 的 hook 运行器在 Win11 上启动 PowerShell 进程时,是否把 `ZCODE_PLUGIN_ROOT` 作为环境变量传入?若 ZCode hook 运行器历史上只对 bash 脚本注入该变量(基于 bash hook 的实现假设),PowerShell 进程拿不到,age_resolve_cli 无法定位插件根。§8.12 事实表未声明 ZCode Win11 hook 的 env 注入行为。 |
| 概率 | M(env 语法错误是实现者易犯错误;ZCode 注入行为待确认) |
| 影响 | H(.ps1 hook 读不到插件根 → age_resolve_cli 失败 → hook 静默 exit 0 但不工作) |
| 风险等级 | 阻断 |
| 缓解 | (1) age.ps1 与 .ps1 hook 统一用 `$env:VAR` 读取环境变量,code review 把关;(2) **WP-1 二次校验**:确认 ZCode 在 Win11 上对 PowerShell hook 是否注入 `ZCODE_PLUGIN_ROOT` 及路径风格;(3) 若不注入,.ps1 hook 须有自动探测插件根的逻辑(基于 `$PSScriptRoot` 向上查找,如 `Split-Path -Parent $PSScriptRoot`);(4) compat/win11/env-template.ps1(事实设计)显式设置 `$env:AGE_PLUGIN_ROOT` 等作为模板;(5) `Detect-HookClient`(lib.ps1)的客户端检测逻辑与 .sh 版本一致(env 优先 → 配置文件回退),语法用 `$env:`;(6) tests/test_win11.bats 验证 .ps1 hook 在无 env 注入时仍能定位插件根(回退 $PSScriptRoot)。 |
| 负责人 | 总调度(age.ps1 + lib.ps1 env 读取 + WP-1 校验);任务执行(.ps1 hook $PSScriptRoot 回退);事实设计(env-template.ps1) |
| 关联发现 | W-11 |
| 状态 | Open |

---

### RW-8:Windows Defender 拦截 .ps1 脚本执行

| 字段 | 内容 |
|---|---|
| 风险 ID | RW-8 |
| 描述 | Windows Defender(含 SmartScreen / Attack Surface Reduction)可能拦截未经数字签名的 .ps1 脚本,尤其是从网络下载或 git clone 的插件目录中的脚本。表现为:执行 .ps1 时弹出 SmartScreen 警告、Defender 隔离脚本、ASR 规则阻止脚本执行。AGE 插件的 age.ps1、hooks/scripts/*.ps1 均无数字签名,首次运行可能被拦。后果:用户首次 age install 或首次 hook 触发时脚本不执行,Win11 原生层失效。 |
| 概率 | M(取决于 Defender 策略与企业管控;家庭版默认较宽松,企业版 ASR 可能严格) |
| 影响 | M(.ps1 被拦需用户手动放行,体验受损但可 workaround) |
| 风险等级 | 重要 |
| 缓解 | (1) compat/win11/README.md 明确告知"Windows Defender 可能拦截未签名 .ps1,首次运行时需在 Defender 警告中选'仍要运行'或加排除目录";(2) `age install --client win11` 检测 Defender 策略(若可),提示用户加 AGE 插件目录到 Defender 排除列表(`Add-MpPreference -ExclusionPath <AGE_PLUGIN_ROOT>`);(3) hook command 用 `powershell -ExecutionPolicy Bypass -File` 绕过 ExecutionPolicy(但不绕过 Defender 实时保护);(4) 不追求数字签名(超出开源插件范围),文档说明"如需彻底消除警告,可自签名 .ps1 或加 Defender 排除目录";(5) `age doctor` 检测 Defender 是否拦截了 age.ps1(尝试执行并捕获错误)。 |
| 负责人 | 事实设计(compat/win11/README.md Defender 说明);总调度(install 检测 + doctor 探测 + ExclusionPath 提示) |
| 关联发现 | (新增,无直接 W- 对应) |
| 状态 | Open |

---

### RW-9:exec 权限概念不存在致 [ -x ] 校验失败

| 字段 | 内容 |
|---|---|
| 风险 ID | RW-9 |
| 描述 | Windows 无传统 UNIX exec 权限位(chmod +x),文件是否可执行由扩展名关联决定(.ps1→PowerShell、.exe→直接执行、.sh→需 bash)。现有 .sh 脚本的 `age_resolve_cli()` 用 `[ -x "${ZCODE_PLUGIN_ROOT}/cli/age" ]` 校验可执行性(§8.6 K),在 Win11 + Git-Bash 下:Git-Bash 模拟了部分权限位(git clone 的 .sh 默认有 exec 位,但 git autocrlf 或某些 git 配置可能丢失),`[ -x ]` 可能对 cli/age(bash 脚本)返回 false。同理,cli/age.ps1 不能用 `[ -x ]` 校验(PowerShell 脚本无 exec 位概念),须用 `Test-Path`。 |
| 概率 | M(Git-Bash 对 .sh 的 exec 位模拟依赖 git 配置,某些场景丢失) |
| 影响 | M(age_resolve_cli 找到 cli/age 但 [ -x ] 失败 → 回退 PATH → 可能找不到 → hook 静默 exit 0) |
| 风险等级 | 重要 |
| 缓解 | (1) Git-Bash 层:lib.sh 的 age_resolve_cli 在 Win11 上放宽校验,`[ -x ]` 失败时回退到 `[ -f ]`(文件存在即可,bash 可直接执行 .sh 不严格依赖 exec 位);(2) PowerShell 层:lib.ps1 的 Resolve-AgeCli 用 `Test-Path -PathType Leaf` 而非 exec 位校验;(3) .gitattributes 或安装时确保 .sh 有 exec 位(Git-Bash 下 `chmod +x cli/age hooks/scripts/*.sh`,或在 install 时执行);(4) `age install --client win11` 在装 Git-Bash 层时显式 `chmod +x` 所有 .sh;(5) tests/test_win11.bats 验证 [ -x ] 失败场景下的回退逻辑。 |
| 负责人 | 任务执行(lib.sh age_resolve_cli 放宽 + lib.ps1 Test-Path);总调度(install chmod +x) |
| 关联发现 | W-6, W-17 |
| 状态 | Open |

---

### RW-10:PowerShell ExecutionPolicy 限制致 .ps1 无法执行

| 字段 | 内容 |
|---|---|
| 风险 ID | RW-10 |
| 描述 | Win11 默认 ExecutionPolicy 可能是 `Restricted`(禁止运行任何 .ps1)或 `RemoteSigned`(本地脚本可跑,网络下载的须签名)。AGE 插件经 git clone 后,若 git 目录被标记为"网络来源"(NTFS Alternate Data Stream 的 Zone.Identifier),RemoteSigned 策略下 age.ps1/hooks/scripts/*.ps1 会被拒绝执行。后果:age.ps1 首次运行报"无法加载文件,因为在此系统上禁止运行脚本",Win11 原生层完全失效。这是 Win11 PowerShell 最常见的阻塞问题。 |
| 概率 | H(Restricted/RemoteSigned 是常见默认策略,尤其企业环境) |
| 影响 | H(所有 .ps1 不可执行,Win11 原生层完全失效) |
| 风险等级 | 阻断 |
| 缓解 | (1) hook command 用 `powershell -ExecutionPolicy Bypass -File <path>.ps1`(会话级绕过,不改变系统策略,无需管理员权限);(2) `age install --client win11` 检测当前 ExecutionPolicy,若 Restricted 提示用户两个选项:(a) `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned`(用户级,无需管理员),(b) 使用 Git-Bash 层(若已装);(3) age.ps1 自身被直接双击/调用时(非经 -ExecutionPolicy Bypass),首行检测策略并提示用户;(4) compat/win11/README.md 详述 ExecutionPolicy 三种策略(Restricted/RemoteSigned/Unrestricted)对 AGE 的影响与配置方法;(5) 解除 Zone.Identifier:install 时对插件目录执行 `Unblock-File -Path <AGE_PLUGIN_ROOT>\*.ps1`(递归),消除"网络来源"标记;(6) `age doctor` 检测 ExecutionPolicy 与 Zone.Identifier,给修复指引。 |
| 负责人 | 总调度(install 检测 + Unblock-File + doctor);任务执行(hook command -ExecutionPolicy Bypass);事实设计(README 说明) |
| 关联发现 | W-2, W-8 |
| 状态 | Open |

---

### RW-11:PowerShell 与 bash 双 CLI 实现长期等价性漂移

| 字段 | 内容 |
|---|---|
| 风险 ID | RW-11 |
| 描述 | §8.12 要求 cli/lib/*.ps1 等价于 cli/lib/*.sh(7 个文件、约 100KB 成熟实现)。这是两套独立实现(非薄包装),任何 bash 侧的 bug 修复/功能新增/退出码调整都须同步到 .ps1,反之亦然。若无约束,两套实现必然漂移:例如 bash 侧修了 sync 的 JSON schema(§8.6 H),.ps1 侧未同步,Win11 用户与 Linux 用户的 `age sync --json` 输出不一致,下游 hook/MCP 解析失败。这是双实现的长期维护风险,非一次性修复可解决。 |
| 概率 | H(随时间推移,漂移几乎必然发生) |
| 影响 | M(Win11 与其他平台行为不一致,功能降级,难排查) |
| 风险等级 | 重要 |
| 缓解 | (1) **等价性测试**:tests/test_win11.bats 对每个命令用相同输入分别跑 age(bash,在 Git-Bash 下)与 age.ps1,断言退出码 + 输出 schema 一致(允许路径分隔符差异);(2) **CONTRACT v1.4 补双实现同步规则**:cli/lib/*.sh 的任何行为变更须同步到 cli/lib/*.ps1,反之亦然;PR 须同时改两边或显式声明仅单边;(3) **共享数据 schema**:`.age/baseline.json`、`.age/writeback.json`、`age sync --json` 输出的 schema 写入 CONTRACT,作为双实现的共同契约(实现方都不得单边改 schema);(4) 考虑用代码生成或共享中间层降低双写成本(如未来用 Python 重写核心逻辑,bash/PS1 都调 Python)— 但这超出本轮范围,记为长期方向。 |
| 负责人 | 总调度(双实现同步);代码审查(等价性测试 + schema 守卫) |
| 关联发现 | W-3, W-4 |
| 状态 | Open |

---

### RW-12:hooks.win11.json 加载机制未定义致 Win11 hook 配置成死文件

| 字段 | 内容 |
|---|---|
| 风险 ID | RW-12 |
| 描述 | §8.12 新增 `hooks/hooks.win11.json`(指向 .ps1 脚本),但 ZCode 插件的 hook 配置入口是 plugin.json 指向单一 `hooks/hooks.json`(现有实现)。若 ZCode 不支持按 OS 切换 hooks 配置(类似 plugin.json 的 platform 字段),hooks.win11.json 永远不会被加载,Win11 上 ZCode 仍读 hooks.json(指向 .sh 脚本),.sh 在 Win11 原生无 bash 时失败。这是 Win11 hook 适配的加载层断点,与脚本本身(.ps1)是否正确无关。 |
| 概率 | M(取决于 ZCode 是否支持 OS 分发,待 WP-2 确认) |
| 影响 | H(Win11 上 hook 全部失效,SessionStart/PostToolUse/Stop 断裂) |
| 风险等级 | 阻断 |
| 缓解 | (1) **WP-2 二次校验**:确认 ZCode 是否支持 hooks 配置的 OS 条件分发;(2) 若支持,plugin.json 声明 Win11 用 hooks.win11.json;(3) **若不支持,采用方案 C**:`age install --client win11` 改写 hooks.json 的 command 字段指向 .ps1 脚本(安装时检测 OS,Win11 写 .ps1 command,其他平台写 .sh command),hooks.json 成为动态配置;(4) 方案 C 须支持回退(`age install --client zcode` 在非 Win11 上改回 .sh command);(5) 无论哪个方案,§8.12 须明确 hooks.win11.json 的加载路径,否则该文件无意义;(6) tests/test_win11.bats 验证 install 后 hooks.json 的 command 指向正确脚本(.ps1 或 .sh)。 |
| 负责人 | 总调度(WP-2 校验 + 方案 C 实现);事实设计(plugin.json platform 字段,若支持) |
| 关联发现 | W-7 |
| 状态 | Open |

---

### RW-13:server.py 的 _age_cli 硬编码 cli/age 致 Win11 MCP 全断

| 字段 | 内容 |
|---|---|
| 风险 ID | RW-13 |
| 描述 | 实测 `mcp/server.py::_age_cli()` 硬编码返回 `_plugin_root() / "cli" / "age"`(bash 脚本路径)。Win11 原生无 bash 时,`subprocess.run([_age_cli(), *args])` 因 Windows 不认识无扩展名的可执行文件(且无 bash 解释器)而 FileNotFoundError。后果:MCP 的 age_route/age_check_drift/age_propose_doc_update/age_evolve/age_activate 全部经 _run_age() 调 cli/age,Win11 原生下全失败。此外 `_plugin_root()` 的校验 `Path(env, "cli", "age").exists()` 在 Win11 上若只有 age.ps1,校验失败,回退到 `__file__` 定位(尚可工作但不一致)。这是 MCP server 在 Win11 的最直接断点。 |
| 概率 | H(Win11 原生无 bash 必然触发) |
| 影响 | H(MCP 全部 tools 失败,会话态 agent 感知层断裂) |
| 风险等级 | 阻断 |
| 缓解 | (1) `_age_cli()` 平台分支:`if os.name == "nt"`(或 `sys.platform == "win32"`)时返回 `cli/age.ps1`,否则返回 `cli/age`;(2) Win11 上调用 .ps1 须经 PowerShell:`subprocess.run(["powershell", "-ExecutionPolicy", "Bypass", "-File", _age_cli(), *args], ...)`,而非直接 `[_age_cli(), *args]`(Windows 不直接执行 .ps1);(3) `_plugin_root()` 校验放宽为 `Path(env, "cli", "age").exists() or Path(env, "cli", "age.ps1").exists()`;(4) tests/test_win11.bats 验证 Win11 上 MCP server 能调通 age.ps1(模拟 os.name=nt,断言 _age_cli 返回 age.ps1);(5) 考虑性能:每次 MCP tool 调用都启动 powershell 进程有延迟,可缓存 powershell 进程或改用 PowerShell 内嵌运行(长期优化,超出本轮)。 |
| 负责人 | 总调度(server.py _age_cli 平台分支 + _plugin_root 校验放宽) |
| 关联发现 | W-12 |
| 状态 | Open |

---

### RW-14:Win11(OS 维度)与客户端(应用维度)正交性致 install 语义混淆

| 字段 | 内容 |
|---|---|
| 风险 ID | RW-14 |
| 描述 | §8.12 把 win11 作为 `age install --client` 的一个取值,但 Win11 是 OS 而非客户端应用。用户在 Win11 上可能用 ZCode、Claude Code、Codex 中的任一个。`age install --client win11` 装的是 OS 级适配(PS1 入口、路径工具、.gitattributes、MCP 配置),`age install --client zcode` 装的是客户端级适配(插件配置)。若 --client 是互斥单选,用户在 Win11 上装了 win11 就无法装 zcode,导致 ZCode 插件配置缺失;若 --client win11 隐含装了 ZCode 适配,则在 Win11 上用 Claude Code 的用户装错配置。语义混淆致安装结果与用户预期不符。 |
| 概率 | M(用户在 Win11 上用非 ZCode 客户端时触发) |
| 影响 | M(装错适配配置,需重装或手动修复) |
| 风险等级 | 重要 |
| 缓解 | (1) 重新定义 `--client win11` 语义:它是"OS 级 Win11 适配",与客户端级适配可共存,`age install --client win11,zcode` 同时装两者(或分两次调用);(2) compat/README.md 客户端对照表加"Win11 OS 适配"行(横向,与各客户端正交),标注"Win11 适配是 OS 层,叠加在任意客户端之上";(3) `age doctor` 在 Win11 上同时报告 OS 适配状态(PS/python/ExecutionPolicy/Defender)+ 客户端适配状态(当前客户端等级);(4) `age install --list` 分两段显示:OS 适配(win11)+ 客户端适配(zcode/claude/codex/opencode/multica);(5) CONTRACT v1.4 澄清 Win11 与客户端的正交性。 |
| 负责人 | 总调度(install 语义 + doctor 双报告 + --list 分段);事实设计(compat/README 对照表) |
| 关联发现 | W-16 |
| 状态 | Open |

---

## 风险汇总

| 风险 ID | 等级 | 概率 | 影响 | 状态 | 关联发现 |
|---|---|---|---|---|---|
| RW-1 | 阻断 | H | H | Open | W-1 |
| RW-2 | 阻断 | H | H | Open | W-10 |
| RW-3 | 阻断 | H | H | Open | W-5, W-13 |
| RW-4 | 阻断 | M | H | Open | W-9 |
| RW-5 | 重要 | M | M | Open | W-17, W-18 |
| RW-6 | 重要 | M | M | Open | W-8 |
| RW-7 | 阻断 | M | H | Open | W-11 |
| RW-8 | 重要 | M | M | Open | (新增) |
| RW-9 | 重要 | M | M | Open | W-6, W-17 |
| RW-10 | 阻断 | H | H | Open | W-2, W-8 |
| RW-11 | 重要 | H | M | Open | W-3, W-4 |
| RW-12 | 阻断 | M | H | Open | W-7 |
| RW-13 | 阻断 | H | H | Open | W-12 |
| RW-14 | 重要 | M | M | Open | W-16 |

**统计:**
- 阻断级:7 条(RW-1, RW-2, RW-3, RW-4, RW-7, RW-10, RW-12, RW-13)— 实为 8 条
- 重要级:6 条(RW-5, RW-6, RW-8, RW-9, RW-11, RW-14)
- 总计:14 条

**关闭路径:**
- 阻断级风险须在实现前满足对应前置条件(WP-1 至 WP-6,见 `docs/win11-design-review.md` §8.6),否则对应模块不予放行。
- 重要级风险须在集成前关闭(实现中并行解决)。
- 本登记册随实现进展更新状态(Mitigating → Closed),由方案审批 agent 维护。

---

## 附:与既有风险登记册的关系

- 本登记册是 `docs/risk-register.md`(第一轮契约风险)、`docs/compat-risk-register.md`(第三轮多客户端风险)的**第四轮补充**,针对 Win11 OS 兼容。
- RW-11(双实现等价性漂移)是 `docs/compat-risk-register.md` RC-6(writeback 并发)的同类长期维护风险,但聚焦 PS/bash 双实现。
- RW-13(server.py _age_cli 硬编码)是 §8.8 Y(server.py 实现)在 Win11 场景的具体化断点。
- RW-2(CRLF)是 §8.2 [D-2](跨平台策略未声明)的具体风险实现。
- 本登记册不修改 CONTRACT.md(超出方案审批所有权);风险关闭后由总调度在 CONTRACT v1.4 标注。

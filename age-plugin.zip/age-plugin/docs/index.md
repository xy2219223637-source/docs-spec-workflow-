# AGE Plugin — 文档路由器

> 本文件是 **AGE 插件自身**的文档路由器(不是 AGE 渲染到目标仓库的模板——那个在 `templates/repo/docs/index.md`)。
> 与 `CONTRACT.md` 同源:CONTRACT.md 是 agent 间的共享契约,本文件是插件内部导航。任何修改插件内部结构者,先读本文件 + CONTRACT.md。

## 插件是什么

AGE(Attractor-Guided Engineering)= 分层系统,非四选一:

- **插件外壳** (`.zcode-plugin/plugin.json`) = 投递单元 + 事件触发器
- **元 skill** (`skills/age/`) = 编排大脑(判断层:路由/选技能/触发审计)
- **CLI** (`cli/`) = 确定性内核(覆盖 CI/headless,git/提交边界)
- **MCP server** (`mcp/server.py`) = agent 感知层(resources + tools)

AGE 是**方法选择器**:它编排四个子流程(age-init/route/doc-sync/audit),自己不替代项目专属路由。详见 `skills/age/SKILL.md`。

## 路由表(如果你要改 X → 先读 Y)

| 你要做的事 | 先读 | 可能改 |
|---|---|---|
| 改插件 manifest / Day 0 字段 | `.zcode-plugin/plugin.json`、`.zcode-plugin/userConfig-schema.json`、CONTRACT.md §2 | 这两个文件 |
| 改路由决策逻辑 | `skills/age/SKILL.md`、`skills/age/references/routing-rules.md` | references/ |
| 改基线 schema(五个 owner 基线) | `skills/age/references/baseline-schema.md`、CONTRACT.md §2 | references/baseline-schema.md |
| 改同步清单 | `skills/age/references/sync-checklist.md` | references/ |
| 改代理操作契约模板 | `templates/repo/AGENTS.md`、CONTRACT.md §6 | templates/repo/AGENTS.md |
| 改仓库文档路由器模板 | `templates/repo/docs/index.md`、`routing-rules.md` | templates/repo/docs/index.md |
| 改强制上下文模板 | `templates/repo/docs/context/*.md`、`baseline-schema.md` | templates/repo/docs/context/ |
| 改 CLI 子命令 | CONTRACT.md §3、`cli/` | cli/(总调度 agent) |
| 改 MCP 接口 | CONTRACT.md §4、`mcp/server.py` | mcp/(总调度 agent) |
| 改 hook 事件 | CONTRACT.md §5、`hooks/` | hooks/(任务执行 agent) |
| 改子代理 | CONTRACT.md §7、`agents/` | agents/(总调度 agent) |
| 改 slash commands | CONTRACT.md §3、`commands/` | commands/(任务执行 agent) |
| 改测试 | `tests/`、CONTRACT.md §3 | tests/(代码审查 agent) |

## 组件索引

| 路径 | 所有者 agent | 职责 |
|---|---|---|
| `.zcode-plugin/plugin.json` | 事实设计 | manifest:声明 skills/commands/hooks/agents/mcpServers/userConfig |
| `.zcode-plugin/userConfig-schema.json` | 事实设计 | Day 0 个性化字段 schema(owner_name/project_kind/doc_language/require_backlog/validate_cmd) |
| `skills/age/SKILL.md` | 事实设计 | 元 skill 主文件(编排四子流程,progressive disclosure) |
| `skills/age/references/routing-rules.md` | 事实设计 | 路由决策表(输入类型→READ/WRITEBACK 集) |
| `skills/age/references/baseline-schema.md` | 事实设计 | 五个 owner 基线最小 schema |
| `skills/age/references/sync-checklist.md` | 事实设计 | 任务前后同步清单 |
| `commands/*.md` | 任务执行 | slash commands(/age-init /age-route /age-sync /age-audit) |
| `hooks/hooks.json` + `hooks/scripts/*.sh` | 任务执行 | SessionStart/PostToolUse/Stop 事件触发 |
| `agents/*.md` | 总调度 | doc-auditor / bug-tracker / plan-reviewer 子代理 |
| `cli/age` + `cli/lib/*.sh` | 总调度 | CLI 路由分发 + 核心函数库 |
| `mcp/server.py` | 总调度 | MCP server(resources + tools) |
| `templates/repo/AGENTS.md` | 事实设计 | 代理操作契约模板(渲染到目标仓库) |
| `templates/repo/START-HERE-after-copy.md` | 过程计划 | Day 0 清单 |
| `templates/repo/docs/index.md` | 事实设计 | 文档路由器模板 |
| `templates/repo/docs/context/*.md` | 事实设计 | 五个强制上下文模板 |
| `templates/repo/docs/{backlog,requirements,design,architecture,plans,audits,logs,bugs,testing,...}/README.md` | 过程计划 | 各目录职责说明 |
| `tests/*.bats` | 代码审查 | CLI/hook 测试 |
| `README.md` | 代码审查 | 插件总说明 |

> 完整所有权矩阵见 `CONTRACT.md §2`。**铁律:agent 只写自己所有权列里的文件。**

## 推荐阅读顺序(新 agent 接手 AGE 插件)

1. `CONTRACT.md` — 共享契约(所有人必读)
2. 本文件 — 插件内部导航
3. `skills/age/SKILL.md` — 元 skill(理解四子流程)
4. `skills/age/references/*.md` — 路由/基线/同步的细节
5. 对应所有权的目录(按上表)

## 维护

- 改插件内部结构后,同步本文件 + CONTRACT.md。
- 本文件的路由表与 CONTRACT.md §2 所有权矩阵必须一致;不一致以 CONTRACT.md 为准。
- 插件版本号在 `plugin.json` 的 `version` 字段;本文件不重复。

# AGE Plugin 方案审批记录

> 本文件遵循 AGE 收尾审计模板格式(审查对象 / 审查标准 / 发现 / 结论 / 前置条件)。
> 审批类型:方案级(构建前契约审批),非代码级。

| 字段 | 值 |
|---|---|
| 审批对象 | `CONTRACT.md`(共享契约 v1,94 行) |
| 审批角色 | 方案审批与建议 agent |
| 审批日期 | 2026-07-11 |
| 审批依据 | 任务背景:6 agent 并发构建的分层 AGE 插件 |
| 关联文档 | `docs/design-review.md`(详细审查报告) |
| 审批结论 | **CONDITIONALLY APPROVED(有条件批准)** |

---

## 1. 审查对象

AGE 插件的共享契约 `CONTRACT.md`,共 8 节:

1. 形态裁决(四层:插件/skill/CLI/MCP)
2. 目录与文件所有权(19 路径 × 5 owner)
3. CLI 子命令契约(9 命令)
4. MCP 接口契约(3 resources + 4 tools)
5. Hook 事件契约(3 事件)
6. 元 skill 编排契约(4 子流程)
7. 子代理契约(3 agents)
8. 缺口与协调(空)

本审批针对契约的自洽性与可构建性,不针对具体实现代码(并发构建中,尚未产出)。

---

## 2. 审查标准

| # | 标准 | 通过门槛 |
|---|---|---|
| S1 | 分层架构合理性 | 四层正交、职责无重叠、四态(编辑/会话/提交/CI)全覆盖 |
| S2 | 接口自洽性 | CLI ↔ MCP ↔ Hook ↔ 元 skill 四方命名与语义一致,无断点 |
| S3 | 所有权完备性 | 第 2 节覆盖所有构建期 agent 的全部文件,无悬空、无冲突 |
| S4 | 退出码与状态可观测 | 退出码语义统一,组合命令退出码可推断,状态文件路径明确 |
| S5 | 并发可构建性 | 6 agent 可基于契约独立产出且能在集成期拼装,无关键路径串行瓶颈 |
| S6 | 跨平台契约 | CLI/hook 的平台依赖明示,CI 覆盖声明平台矩阵 |

---

## 3. 发现(对照标准)

### S1 分层架构 — 通过

四层(插件外壳 / 元 skill 编排 / CLI 确定性内核 / MCP 感知层)正交分解合理。四态覆盖经核对充分(详见 design-review.md 第 1.2 节)。**唯一缺口**:第 1 节未显式给出"层→态"映射矩阵(D-1,重要),但属文档补强,不阻断。

### S2 接口自洽性 — 不通过(2 阻断)

- **D-3(阻断)**:`age_propose_doc_update`、`age_evolve` 两个 MCP 工具无对应 CLI 命令。违反第 1 节"CLI = 确定性内核,覆盖 CI/headless"原则——可变操作无 CI 镜像。
- **D-5(阻断)**:Hook SessionStart 调用 `age route <task>`,但会话启动时无 task,`route` 必需参数缺失,hook 必失败。
- **D-4(重要)**:漂移检测在 MCP 层名 `age_check_drift`、CLI 层名 `sync`、skill 层名 `doc-sync`,三处三名。

### S3 所有权完备性 — 不通过(1 阻断)

- **D-9(阻断)**:第 2 节所有权表完全缺失"方案审批 agent"及其 9 个文件(`docs/design-review.md`、`docs/approval.md`、`docs/risk-register.md`、`docs/improvement-proposals.md`、`templates/repo/docs/examples/` 下 5 文件)。`docs/` 目录除 `index.md` 外全部悬空,examples/ 与过程计划的 `...` 通配归属歧义。
- **D-10(重要)**:`.age/` 运行时状态(baseline.json、回写集)schema 所有权未分配。
- **D-11(重要)**:MCP server 依赖清单与 Python 测试无 owner。

### S4 退出码与状态 — 部分通过

- **D-6(重要)**:回写集(writeback set)存储位置未定义,route→doc-sync 闭环状态缺失。
- **D-7(次要)**:`age ci` 组合退出码未定义;`age baseline` 缺失败码。
- **D-8(次要)**:`age_route` MCP 未命中返回形状未定义。

### S5 并发可构建性 — 有条件通过

- **D-15(重要)**:无"集成契约冻结点",6 agent 基于不同版本契约产出将无法拼装。

### S6 跨平台 — 不通过(重要)

- **D-2(重要)**:CLI/hook 全为 POSIX shell,未声明平台矩阵,Windows 原生 CI 覆盖失效。

---

## 4. 结论

### APPROVED / CONDITIONALLY APPROVED / CHANGES REQUESTED

```
CONDITIONALLY APPROVED(有条件批准)
```

**裁决理由**:

架构方向(四层分层 + 四态覆盖)经审查成立,分层裁决稳健,予以方向性批准。但契约存在 **4 项阻断级缺陷**(D-3、D-5、D-9、D-13),若不修复,6 agent 的并发产出在集成期将无法拼装:

- D-9 使本审批 agent 自身的文件所有权在契约中缺失(自指矛盾);
- D-5 使 SessionStart hook 必然失败;
- D-3 使 CI 路径无法复现 MCP 的可变操作;
- D-13 使 plan-reviewer 子代理触发条件不可执行。

故为**有条件批准**:方向可推进,但阻断项须在进入集成阶段前修复并发布 CONTRACT v1.1。未修复前,各 agent 可继续按 v1 实现非阻断部分,但**禁止进入集成测试**。

---

## 5. 前置条件(集成前必须满足)

以下条件按强制级别排列。**P0 为硬性前置条件,全部满足方可进入集成;P1 为强烈建议,缺失将显著抬高集成成本。**

### P0(强制前置条件 — 不满足则集成阻塞)

| # | 前置条件 | 验证方式 | 对应缺陷 |
|---|---|---|---|
| P0-1 | CONTRACT 第 2 节补全"方案审批 agent"及其 9 文件所有权 | 审查第 2 节表包含审批 agent 列 | D-9 |
| P0-2 | SessionStart hook 调用对象改为 `age doctor` 或读 `docs://context`,不再调 `age route` | hooks.json 与 on-start.sh 验证 | D-5 |
| P0-3 | `age_propose_doc_update`、`age_evolve` 补 CLI 后端,或契约显式声明"仅会话态、无 CI 镜像"并附理由 | CLI 命令表或第 4 节注释 | D-3 |
| P0-4 | `plan-reviewer` 子代理触发条件改为运行期事件(如 `/age-audit --scope plan`),删除"方案审批 agent 调用"表述 | 第 7 节表 | D-13 |
| P0-5 | 所有 CLI 命令通过 `tests/*.bats` 测试(至少 happy path + 退出码) | `bats tests/` 全绿 | S4 |
| P0-6 | `hooks/hooks.json` 通过 ZCode hook 配置合法性验证(事件名/matcher/脚本可执行) | `age doctor` 或客户端加载无报错 | S2 |
| P0-7 | MCP server 启动后 `tools/list` 与 `resources/list` 与第 4 节契约逐项一致 | MCP 客户端枚举对比 | S2 |

### P1(强烈建议前置条件)

| # | 前置条件 | 验证方式 | 对应缺陷 |
|---|---|---|---|
| P1-1 | 漂移检测三处命名统一(语义根名 `drift`) | 第 3/4/6 节交叉一致 | D-4 |
| P1-2 | 回写集存储路径与 schema 写入契约(建议 `.age/writeback.json`) | 第 3 节 `age route` 行补注 | D-6 |
| P1-3 | `.age/` 状态文件 schema 归属总调度并补文档 | 第 2 节 + 文档 | D-10 |
| P1-4 | MCP server 依赖清单 + Python 测试归属明确 | 第 2 节补 mcp/requirements.txt、tests/test_mcp.py | D-11 |
| P1-5 | 设置"集成契约冻结点":集成前由总调度汇总第 8 节、发布 CONTRACT v1.1 | 流程里程碑 | D-15 |
| P1-6 | 第 1 节补"层→态"覆盖矩阵 | 第 1 节新增表 | D-1 |
| P1-7 | 声明 CLI/hook 平台矩阵(macOS/Linux/WSL/Git-Bash/原生 Windows) | 第 1 或第 3 节 | D-2 |

### P2(后续迭代)

D-7(ci 退出码)、D-8(route 未命中形状)、D-12(Windows 入口)、D-14(doc-auditor scope 默认值)。

---

## 6. 审批签字

| 角色 | 结论 | 日期 |
|---|---|---|
| 方案审批与建议 agent | CONDITIONALLY APPROVED | 2026-07-11 |
| 总调度 agent(待会签) | ______ | ______ |

> 总调度 agent 会签后,本审批生效。P0 条件全部满足后,集成禁令解除。

---

## 7. 附录:缺陷索引(详见 design-review.md)

| ID | 严重度 | 节 | 摘要 |
|---|---|---|---|
| D-1 | 重要 | 1 | 缺层→态映射 |
| D-2 | 重要 | 1 | 跨平台策略未声明 |
| D-3 | 阻断 | 3↔4 | MCP propose/evolve 无 CLI 后端 |
| D-4 | 重要 | 3↔4↔6 | 漂移检测三处命名错配 |
| D-5 | 阻断 | 5↔3 | SessionStart 调 route 语义错配 |
| D-6 | 重要 | 6↔3 | 回写集存储未定义 |
| D-7 | 次要 | 3 | ci 退出码/baseline 失败码 |
| D-8 | 次要 | 4 | route 未命中返回形状 |
| D-9 | 阻断 | 2 | 审批 agent 所有权缺失 |
| D-10 | 重要 | 2 | .age schema 所有权 |
| D-11 | 重要 | 2 | MCP 依赖/测试无 owner |
| D-12 | 次要 | 2 | Windows CLI 入口 |
| D-13 | 阻断 | 7 | plan-reviewer 触发角色混淆 |
| D-14 | 次要 | 7 | doc-auditor scope 默认 |
| D-15 | 重要 | 8 | 无集成契约冻结点 |

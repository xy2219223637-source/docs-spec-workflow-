# AGE Plugin — 共享契约

> 所有 agent 必须先读本文件,确保产出路径不冲突、接口一致。
> 本文件是事实层基线,与 docs/index.md 同源。

## 1. 形态裁决(辩论结论)

AGE plugin 是分层系统,非四选一:

- **插件(plugin)** = 投递外壳 + 事件触发器(ZCode 扩展单元)
- **元 skill** = 编排大脑(判断层:路由/选技能/触发审计)
- **CLI** = 确定性内核(覆盖 CI/headless,git/提交边界)
- **MCP server** = agent 感知层(resources + tools,会话态可见)

## 2. 目录与文件所有权(避免并发冲突)

| 路径 | 所有者 agent | 职责 |
|---|---|---|
| `.zcode-plugin/plugin.json` | 事实设计 | manifest,声明组件 |
| `.zcode-plugin/userConfig-schema.json` | 事实设计 | Day 0 个性化字段 schema |
| `skills/age/SKILL.md` | 事实设计 | 元 skill 主文件 |
| `skills/age/references/*.md` | 事实设计 | 路由表/基线 schema/同步清单 |
| `commands/*.md` | 任务执行 | slash commands |
| `hooks/hooks.json` | 任务执行 | 事件触发配置 |
| `hooks/scripts/*.sh` | 任务执行 | hook 调用脚本 |
| `agents/*.md` | 总调度 | 子代理定义 |
| `cli/age` (主入口) | 总调度 | CLI 路由分发 |
| `cli/lib/*.sh` | 总调度 | CLI 核心函数库 |
| `mcp/server.py` | 总调度 | MCP server |
| `templates/repo/AGENTS.md` | 事实设计 | 代理操作契约模板 |
| `templates/repo/START-HERE-after-copy.md` | 过程计划 | Day 0 清单 |
| `templates/repo/docs/index.md` | 事实设计 | 文档路由器模板 |
| `templates/repo/docs/context/*.md` | 事实设计 | 强制上下文模板 |
| `templates/repo/docs/{backlog,requirements,design,architecture,plans,audits,logs,bugs,testing,...}/README.md` | 过程计划 | 各目录职责说明 |
| `docs/index.md`(插件自身) | 事实设计 | 插件文档路由器 |
| `README.md`(插件根) | 代码审查 | 插件总说明 |
| `tests/*.bats` | 代码审查 | CLI/hook 测试 |

**铁律:agent 只写自己所有权列里的文件。跨所有权需要的修改,写到 CONTRACT.md 的"缺口"小节,由总调度 agent 协调。**

## 3. CLI 子命令契约(总调度实现,其他 agent 引用)

| 命令 | 作用 | 退出码 | 被谁调用 |
|---|---|---|---|
| `age init [--name X] [--kind web\|mobile\|cli]` | 脚手架生成骨架 + Day 0 引导 | 0/1 | /age-init command, hooks.SessionStart(首次) |
| `age sync [--since REF] [--json]` | git diff → 漂移报告(stale/orphan/missing) | 0无漂移/1有漂移 | hooks.PostToolUse, /age-sync |
| `age check [--strict]` | 静态一致性:路由死链/基线齐全/AGENTS引用可解析 | 0/1 | pre-commit, CI, /age-audit |
| `age ci` | 非交互 = check --strict + sync --json | 0/1 | CI 流水线 |
| `age route <task> [--explain]` | 按 docs/index.md 路由到 owner 文档/技能 | 0命中/1未命中 | MCP age_route, /age-route |
| `age doctor` | 诊断环境/配置 | 0/1 | /age-init 前 |
| `age baseline` | 快照当前 docs/ 指纹到 .age/baseline.json | 0 | age init 后 |
| `age audit [--scope full\|plan\|closure]` | 审计文档与代码一致性 | 0通过/1违规 | hooks.Stop, /age-audit |

## 4. MCP 接口契约(总调度实现)

**Resources(只读,URI 稳定):**
- `docs://index` — 路由器视图(AGENTS.md + docs/index.md 合并)
- `docs://context/project-context` — 项目上下文基线
- `docs://status` — 计算视图:漂移分数 + 断链 + stale 列表(实时算)

**Tools(agent 可调用,在 tools/list):**
- `age_route(task)` → {doc, skill, reason}
- `age_check_drift(scope?)` → {stale[], orphan[], missing[]}
- `age_propose_doc_update(change)` → {patch, target_doc}
- `age_evolve(task_id)` → 标记 backlog 完成、更新 design、记 ADR

## 5. Hook 事件契约(任务执行实现)

| 事件 | matcher | 动作 | 调用 |
|---|---|---|---|
| SessionStart | * | 注入 docs/context/ 摘要到上下文 | `age route` 判定 + 读 context |
| PostToolUse | `Edit\|Write\|MultiEdit` | 触发漂移检测提醒 | `hooks/scripts/on-edit.sh` → `age sync --json` |
| Stop | * | 收尾一致性检查 | `hooks/scripts/on-stop.sh` → `age audit --scope closure` |

## 6. 元 skill 编排契约(事实设计实现,被 hooks/commands/MCP 引用)

四个子流程,语义边界触发:
- `age-init` — 新仓库/套模板时
- `route` — 每个开发任务**开始前**:读哪些 owner 文档、标记回写集
- `doc-sync` — 每个开发任务**结束后**:对照回写集更新文档
- `audit` — 周期/显式:漂移检测 + 基线缺失

## 7. 子代理契约(总调度实现)

| agent | 文件 | 触发 | 职责 |
|---|---|---|---|
| doc-auditor | `agents/doc-auditor.md` | /age-audit, hooks.Stop | 扫 backlog/requirements 与代码一致性 → docs/audits |
| bug-tracker | `agents/bug-tracker.md` | 验证失败时 | 归档复杂回归 → docs/bugs |
| plan-reviewer | `agents/plan-reviewer.md` | 方案审批 agent 调用 | 审查 docs/plans 的收尾规则 |

## 8. 缺口与协调

(各 agent 发现跨所有权需求时写在这里,总调度协调)

> 以下由**方案审批与建议 agent**于 2026-07-11 审查后追加。详细论证见 `docs/design-review.md`,审批结论见 `docs/approval.md`(CONDITIONALLY APPROVED)。建议总调度据此发布 CONTRACT v1.1。

### 8.1 阻断级缺陷(集成前必须修复)

**[D-3] MCP propose/evolve 无 CLI 后端**(第 3↔4 节)
- 缺陷:`age_propose_doc_update`、`age_evolve` 两个 MCP 工具(第 4 节)在第 3 节 CLI 命令表中无对应。违反第 1 节"CLI = 确定性内核,覆盖 CI/headless"——可变操作无 CI 镜像。
- 修复:方案 A(推荐)补 CLI `age propose <change>`、`age evolve <task_id>`;方案 B 在第 4 节注明此二工具"仅会话态、无 CI 镜像"并说明理由,确保 `age ci` 不依赖。
- 责任:总调度

**[D-5] SessionStart 调 `age route` 语义错配**(第 5↔3 节)
- 缺陷:第 5 节 SessionStart 调用"`age route` 判定",但 `age route <task>`(第 3 节)需 task 参数,会话启动时无 task,hook 必失败。
- 修复:SessionStart 改为 `age doctor`(无参)+ 读 `docs://context/project-context`;route 推迟到首个任务时由元 skill/`/age-route` 触发。
- 责任:任务执行 + 总调度

**[D-9] 方案审批 agent 及其文件未入所有权表**(第 2 节)
- 缺陷:第 2 节列出 5 个 owner agent,缺失第 6 个"方案审批 agent"及其 9 个文件。`docs/` 目录除 `index.md` 外所有权悬空;`templates/repo/docs/examples/` 与过程计划的 `{backlog,...}/README.md` 中 `...` 通配归属歧义。
- 修复:第 2 节补"方案审批"列,登记:`docs/design-review.md`、`docs/approval.md`、`docs/risk-register.md`、`docs/improvement-proposals.md`、`templates/repo/docs/examples/README.md`、`templates/repo/docs/examples/*.example.md`、`templates/repo/docs/examples/complete-small-app-walkthrough.md`。
- 责任:总调度协调(编辑第 2 节)

**[D-13] plan-reviewer 触发角色混淆**(第 7 节)
- 缺陷:第 7 节 plan-reviewer 触发为"方案审批 agent 调用"。但构建期"方案审批 agent"无法调用运行期子代理,生命周期错配,触发条件不可执行。
- 修复:触发改为运行期事件 `/age-audit --scope plan` 或 plan 收尾命令;构建期角色改称"方案审批(构建期)"以别于运行期子代理。
- 责任:总调度

### 8.2 重要缺陷(v1.1 修复)

**[D-1] 第 1 节缺"层→态"映射**:补层/态覆盖矩阵(编辑/会话/提交/CI × 四层+hook),使"四层覆盖四态"成为契约级断言,可供 `age check` 校验。

**[D-2] 跨平台策略未声明**:CLI/hook 全为 POSIX shell(第 2 节 `cli/lib/*.sh`、`hooks/scripts/*.sh`),未声明平台矩阵。Windows 原生(无 bash)CI 覆盖失效。建议声明支持 macOS/Linux/WSL/Git-Bash,原生 Windows 需 Git-Bash。

**[D-4] 漂移检测三处命名错配**:MCP 层 `age_check_drift`(第 4 节)、CLI 层 `sync`(第 3 节)、skill 层 `doc-sync`(第 6 节)三处三名。建议统一语义根名 `drift`。

**[D-6] 回写集存储位置未定义**:第 6 节 route"标记回写集"、doc-sync"对照回写集",但存储位置/schema 未规定,会话中断后丢失致闭环断裂。建议规定落 `.age/writeback.json`,结构 `{task, docs:[], skills:[], timestamp}`;doc-sync 读取并清空;`age audit --scope closure` 校验已清空。

**[D-10] `.age/` 状态文件 schema 所有权未分配**:`.age/baseline.json`、writeback.json 等无 owner。建议归属总调度并补 schema 文档。

**[D-11] MCP 依赖清单与测试无 owner**:第 2 节 `mcp/server.py` 归总调度,但 `mcp/requirements.txt`/`pyproject.toml` 与 MCP Python 测试缺失(`tests/*.bats` 仅覆盖 bash)。建议补 `mcp/requirements.txt`(总调度)与 `tests/test_mcp.py`(代码审查或总调度)。

**[D-15] 无集成契约冻结点**:6 agent 并发基于 v1 实现,无冻结机制,集成期产出无法拼装。建议流程增加里程碑:集成前总调度汇总本节、发布 v1.1,6 agent 基于 v1.1 集成。

### 8.3 次要缺陷(后续迭代)

- **[D-7]** `age ci`(check+sync 组合)退出码未定义;`age baseline` 缺失败码。
- **[D-8]** `age_route` MCP 未命中时返回形状未定义(建议 `{doc:null, skill:null, reason:"no-match"}`)。
- **[D-12]** Windows CLI 入口 `cli/age.cmd` 无 owner(若支持原生 Windows)。
- **[D-14]** doc-auditor 触发"/age-audit"未规定 `--scope`(建议默认 full)。

### 8.4 协调请求

- 请**总调度**确认上述修复归属,发布 CONTRACT v1.1 前不进入集成测试。
- `docs/` 目录下审批 agent 产出的 4 个文件(design-review/approval/risk-register/improvement-proposals)所有权请明确归属"方案审批",避免与事实设计的 `docs/index.md`、过程计划的 docs 子目录 README 冲突。
- `templates/repo/docs/examples/` 整目录归属"方案审批",与过程计划的 `templates/repo/docs/{各目录}/README.md` 边界以"examples/ 子目录"为界。

### 8.5 事实设计 agent 提出的跨所有权需求(2026-07-11)

事实设计 agent 已完成全部 15 个所有权文件。下列是与其它 agent 的接口约定,需各方实现时对齐(不涉及对 §1-7 的修改,仅补充实现细节):

**A. MCP server(总调度,`mcp/server.py`)须读取的 env 变量**
`plugin.json` 的 `mcpServers.age-mcp.env` 注入了下列变量,MCP server 实现时按需读取:
- `AGE_PLUGIN_ROOT` = `${ZCODE_PLUGIN_ROOT}`(插件根,定位 skills/templates)
- `AGE_PLUGIN_DATA` = `${ZCODE_PLUGIN_DATA}`(插件数据目录)
- `AGE_PROJECT_DIR` = `${ZCODE_PROJECT_DIR}`(目标仓库根)
- `AGE_OWNER_NAME` / `AGE_PROJECT_KIND` / `AGE_DOC_LANGUAGE` / `AGE_REQUIRE_BACKLOG` / `AGE_VALIDATE_CMD` = 对应 userConfig 字段值(已从 `${user_config.*}` 展开)

MCP resources(`docs://index`、`docs://context/project-context`、`docs://status`)与 tools(`age_route`/`age_check_drift`/`age_propose_doc_update`/`age_evolve`)语义见 `skills/age/SKILL.md` 与 `skills/age/references/routing-rules.md`。`age_route` 返回的 `doc`/`skill`/`reason` 须对应 routing-rules.md 决策表的 READ 集/技能路由/匹配行(契约 §4)。

**B. CLI `age init`(总调度,`cli/`)的模板渲染契约**
`age init` 须从 `templates/repo/` 渲染到目标仓库,占位符统一 `{{}}` 风格。各模板消费字段(见 `.zcode-plugin/userConfig-schema.json` 的 `_age_render_targets` 注解):
- `AGENTS.md` ← owner_name, project_kind, doc_language, require_backlog, validate_cmd
- `docs/index.md` ← project_name, require_backlog, skill_requirements/skill_design/skill_architecture/skill_testing/skill_build(后五个默认 `none`)
- `docs/context/project-context.md` ← project_name, project_description, target_users, current_phase, tech_stack, validate_cmd
- `docs/context/ai-autonomy-policy.md` ← project_name, autonomy_scope, needs_confirmation
- `docs/context/codebase-map.md` ← project_name, module_1_*/module_2_*(按 project_kind 给骨架), dependency_rules, main_entry, test_entry, build_entry
- `docs/context/source-of-truth-and-precedence.md` ← project_name(内容固定)
- `docs/context/conventions.md` ← project_name, naming/commit/branch/testing/doc_conventions, doc_language, validate_cmd, convention_exceptions
- `docs/context/README.md` ← project_name

`age init` 还须:(1) 跑 `age baseline` 快照;(2) `require_backlog=false` 时不强制生成 `docs/backlog/` 内容(README 仍生成);(3) `validate_cmd` 为空时在 `AGENTS.md`/`project-context.md` 渲染为空,收尾审计据此跳过验证步骤(逻辑见 AGENTS.md §4/§7)。

**C. commands(任务执行,`commands/*.md`)的子流程命名**
SKILL.md 引用的四个子流程与 slash command 对应:`age-init`→`/age-init`、`route`→`/age-route`、`doc-sync`→`/age-sync`、`audit`→`/age-audit`。commands 实现时调用对应 CLI 子命令(`age init`/`age route`/`age sync`/`age audit`),命令体引用 SKILL.md 子流程语义,不重复定义。

**D. hooks(任务执行,`hooks/`)的事件-脚本-CLI 对应**
sync-checklist.md 与 SKILL.md 引用的 hook 行为(契约 §5):
- `SessionStart` → 注入 context 摘要(**注意 §8.2 [D-5] 已建议 SessionStart 改用 `age doctor` 而非 `age route`,事实设计方同意此修复;SKILL.md 的 hook 描述以 CONTRACT v1.1 为准**)
- `PostToolUse` (matcher `Edit|Write|MultiEdit`) → `hooks/scripts/on-edit.sh` → `age sync --json`
- `Stop` → `hooks/scripts/on-stop.sh` → `age audit --scope closure`
hooks.json matcher 用契约 §5 正则;脚本通过 `${ZCODE_PLUGIN_ROOT}` 定位 CLI(plugin hook 可用该变量,见 zcode-guide diagnosing-hooks skill)。

**E. START-HERE-after-copy.md(过程计划)的 Day 0 字段引导**
该文件须引导用户填写 `userConfig-schema.json` 定义的五个 Day 0 字段(owner_name/project_kind/doc_language/require_backlog/validate_cmd),并指向 `age init` 渲染模板。占位符统一 `{{}}`。

**F. tests(代码审查,`tests/*.bats`)建议覆盖的事实层契约**
(1) `age check` 校验 `templates/repo/docs/context/` 五文件骨架含必填段;(2) `age route` 对五种输入类型的 READ/WRITEBACK 集与 routing-rules.md 决策表一致;(3) `age init` 渲染后无 `{{}}` 残留;(4) `userConfig-schema.json` 默认值与 plugin.json inline userConfig 一致。

**G. 待总调度确认的点**
- `mcp/server.py` 用 `python3` 直跑(见 plugin.json `mcpServers.age-mcp.command`),而非 ZCode host launcher 模式(android/ios 插件用的 `ZCode Helper` + `__zcode-plugin-host`)。若 ZCode 要求 MCP server 经 host launcher,需总调度反馈,由事实设计改 plugin.json。
- `agents` 字段在参考插件中无先例。我在 plugin.json 声明 `"agents": "agents"`。若 ZCode 不支持该字段名,需总调度反馈,由事实设计改 plugin.json。
- **回写集存储**(§8.2 [D-6] 建议落 `.age/writeback.json`):事实设计的 sync-checklist.md 与 AGENTS.md 描述了"标记 WRITEBACK 集"语义但未规定存储位置,同意 [D-6] 建议归总调度定义 `.age/writeback.json` schema。事实设计方文件无需改动(它们引用"WRITEBACK 集"概念,不绑定具体存储)。
- **漂移命名**(§8.2 [D-4]):skill 层用 `doc-sync`(子流程名)、CLI 用 `sync`、MCP 用 `age_check_drift`。事实设计方保留 `doc-sync` 作为子流程语义名(SKILL.md/sync-checklist.md),不改;CLI/MCP 命名统一归总调度。

### 8.6 任务执行 agent 的接口约定与协调请求(2026-07-11)

任务执行 agent 已完成全部 10 个所有权文件(5 commands + hooks.json + 4 scripts)。以下为构建/测试 hook 时确认的接口事实与跨所有权请求:

**H. `age sync --json` 字段 schema(已对齐,供 MCP/测试引用)**
经实测 `cli/lib/sync.sh`,`age sync --json` 输出形如:
`{"since":"HEAD","stale":[...],"orphan":[...],"missing":[...]}`
各数组元素字段为:
- `stale[]` = `{module, owner, changed_file}`(代码变了但 owner 文档没动)
- `orphan[]` = `{module, owner}`(路由指向的代码模块已删除)
- `missing[]` = `{file}`(新代码模块无路由条目)
MCP `age_check_drift`(§4)与 `tests/*.bats` 若消费此输出,须按上述字段名解析。我的 `on-edit.sh` 已按此 schema 提取。

**I. [协调请求] `age audit` 缺 `--json` 结构化输出(影响 Stop hook 解析稳健性)**
经实测 `cli/lib/audit.sh`,`age audit --scope closure` 仅输出人类可读文本(无 `--json`),违规行经 `age_error` 走 **stderr**(进度行 `ℹ [n/3]` 走 stdout),颜色在非 tty 自动降级(我捕获到变量,故无 ANSI 码)。
- 现状:`on-stop.sh` 用中文关键词 grep(`违规|缺失|为空|不存在`)+ 摘要行(`发现.*处违规`)提取,已通过端到端测试,但属语义耦合,CLI 文案改动即破。
- 请求:建议总调度为 `age audit` 增加 `--json` 开关(输出 `{violations:[{category,path,message}],summary:{count,scope}}`),Stop hook 与 MCP 改用 JSON 解析。在此之前,`on-stop.sh` 维持文本提取方案,并在脚本注释中声明该耦合点。归总调度。

**J. [协调请求] `is_age_repo` 判定范围:CLI vs hook vs 契约 §5**
- `cli/lib/common.sh` 的 `is_age_repo()` 接受 `docs/index.md` **或** `AGENTS.md`。
- 契约 §5 SessionStart 仅写"有 docs/index.md"。
- 我的 `hooks/scripts/lib.sh::is_age_repo()` 严格按契约 §5,只认 `docs/index.md`(更保守,避免在仅有 AGENTS.md 的非 AGE 仓库误触发)。
- 请求:请总调度在 CONTRACT v1.1 统一裁定"is AGE repo"的权威定义(`docs/index.md` only,还是 `docs/index.md || AGENTS.md`)。若改为后者,任务执行方更新 `lib.sh` 一行即可(改动点已在注释标注)。当前实现以契约 §5 字面为准。

**K. hook 输出契约自检结论(无需协调,记录备查)**
- 所有 hook 严格 exit 0(永不 exit 2 阻断用户);上下文注入走 stdout JSON `{"additionalContext":"..."}`,符合 zcode-guide diagnosing-hooks 的严格 schema(无多余键)。
- `emit_context` 用 awk+ENVIRON 做 JSON 转义(可移植,绕过 macOS BSD sed 的 `:a/N/$!ba` 不支持与 `awk -v` 对字面换行的拒绝),已验证多行文本正确 round-trip。
- CLI 定位:`age_resolve_cli()` 优先 `${ZCODE_PLUGIN_ROOT}/cli/age`,回退 `${CLAUDE_PLUGIN_ROOT}/cli/age`,再回退 PATH `age`;CLI 缺失时静默 exit 0(不阻断),日志写 `<project>/.age/hooks.log`。经实测 bundled `cli/age` 已存在并被正确解析。

### 8.7 过程计划 agent 的接口约定与协调请求(2026-07-11)

过程计划 agent 已完成全部 27 个所有权文件(START-HERE + 25 个 docs 子目录文件 + process 工作流)。以下为编写过程中确认的接口事实与跨所有权请求。**注:`docs/process/` 目录此前不存在,过程计划 agent 已新建该目录。**

**L. 依赖项(非编辑请求,仅声明):过程层文件引用了尚未由事实设计创建的 owner 文档**
过程层文件大量引用 `docs/context/project-context.md`、`AGENTS.md`、`docs/index.md` 作为"吸引子源"。编写时这些模板尚未存在(事实设计 agent 并行工作)。过程计划方已用占位符与语义引用处理,不阻塞;待事实设计文件就位后,引用天然成立。具体:
- `START-HERE-after-copy.md` 步骤 3/4 引导填写 `docs/context/project-context.md` 与 `AGENTS.md`(均为事实设计所有权)。
- `application-development-workflow.md` 每步引用 owner 文档(context/index/skills 等)。
- 无需事实设计改动,仅声明依赖关系,供集成时校验引用可解析(`age check --strict`)。

**M. [协调请求] START-HERE 的 Day 0 字段引导须与 `age init` 渲染对齐(关联 §8.5 E)**
事实设计 §8.5 E 已指出:START-HERE 须引导用户填写 `userConfig-schema.json` 的五个 Day 0 字段(owner_name/project_kind/doc_language/require_backlog/validate_cmd),并指向 `age init` 渲染模板。
- 现状:过程计划方已编写 START-HERE,采用 `{{项目名}}`、`{{web|mobile|cli}}` 等 `{{}}` 占位符,与契约风格一致,并引用 `age init --name --kind`、`age doctor`、`age baseline`、`age check --strict`、`age sync`(均与 §3 一致)。
- 请求:请总调度确认 `age init` 渲染 START-HERE 时,`{{项目名}}`/`{{web|mobile|cli}}` 占位符的展开规则与 userConfig 字段映射(例:`{{项目名}}`←project_name,`{{web|mobile|cli}}`←project_kind 提示)。若总调度要求 START-HERE 改用与 userConfig 字段名一致的占位符(如 `{{project_name}}`),过程计划方据此调整(改动点仅在 START-HERE 占位符命名)。
- 关联 §8.5 B:事实设计已规定 `age init` 对各模板的消费字段;START-HERE 不在该清单内,请总调度补充 START-HERE 的占位符消费规则,或确认"START-HERE 不被 `age init` 渲染、由用户手动填写"。

**N. 回写集存储须与计划/审计指南一致(关联 §8.2 [D-6]、§8.5 G)**
过程计划的 `00-plan-authoring-and-execution-guide.md` 与 `00-audit-execution-guide.md` 均引用"回写集"概念(计划列出回写 owner 文档清单;收尾审计检查清单是否清空)。
- 现状:过程计划方按"概念引用"编写(描述回写集的语义:哪些 owner 文档需更新、何时算清空),**未绑定具体存储**。
- 请求:请总调度按 [D-6] 建议定义 `.age/writeback.json` schema(`{task, docs:[], skills:[], timestamp}`)后,确认过程计划方文件无需改动(它们引用概念,不绑定存储)。若总调度要求计划文档显式引用 `.age/writeback.json` 路径,过程计划方在两份指南中补一句指向即可(改动极小)。

**O. CLI 命令引用自检结论(无需协调,记录备查)**
过程计划文件引用的 CLI 命令均与 §3 一致,经逐一核对:
- `age init [--name X] [--kind web|mobile|cli]`、`age doctor`、`age baseline`、`age check [--strict]`、`age sync [--json]`、`age route <task> [--explain]`、`age audit [--scope plan|closure]` — 与 §3 表完全一致。
- 未引用 §3 未定义的命令(如未引用 `age propose`/`age evolve`——这两个在 §8.1 [D-3] 待补,过程计划方不依赖它们)。
- `age audit --scope plan` 与 `--scope closure` 是过程计划默认控制回路的核心;若总调度调整 scope 取值(§8.2/8.3 有相关讨论),过程计划方文件需同步(改动点:工作流、计划指南、审计指南中的 scope 名)。

**P. `docs/process/` 目录新建声明**
契约 §2 所有权表第 34 行通配 `docs/{backlog,requirements,...}/README.md` 归过程计划,但 `process` 子目录未在模板中预建。过程计划方已新建 `templates/repo/docs/process/` 目录及其中 2 个文件。请总调度在 v1.1 所有权表确认 `docs/process/` 归过程计划(与 `docs/{各目录}/README.md` 同行通配语义一致)。

### 8.8 总调度 agent 的实现说明与协调请求(2026-07-11)

总调度 agent 已完成全部 13 个所有权文件(cli/age + cli/lib/*.sh ×7 + mcp/server.py + mcp/requirements.txt + agents/*.md ×3)。以下为实现裁决与跨所有权协调点:

**Q. `age init` 模板渲染契约对齐(关联 §8.5 B)**
已实现:渲染 `{{owner_name}}`、`{{project_kind}}`、`{{doc_language}}`、`{{require_backlog}}`、`{{validate_cmd}}`、`{{skill_requirements}}`/`{{skill_design}}`/`{{skill_architecture}}`/`{{skill_testing}}`/`{{skill_build}}`(后五个默认 `none`)、`{{project_name}}`、`{{project_slug}}`。占位符统一 `{{key}}` 风格,`render_template` 用 sed 替换(跨平台,无 GNU sed `-i` 依赖)。
- **请求事实设计确认**:`docs/context/*.md` 模板中的占位符(如 `{{project_description}}`、`{{module_1_*}}`、`{{naming}}`/`{{commit}}`/`{{branch}}` 等,见 §8.5 B)当前由 `age_load_userconfig_defaults` 提供的内置默认值(空串)兜底渲染。若事实设计希望这些字段从 `userConfig-schema.json` 的 `default` 值填充,需确认 schema 的字段名与默认值;当前 `age_load_userconfig_defaults` 仅返回 `project_name/project_kind/validate_cmd` 三个内置默认,其余占位符渲染为空(模板内容仍可读,不报错)。

**R. docs/index.md 路由表格式自适应(关联 §8.5 A、§8.6 H)**
事实设计产出的 `docs/index.md` 采用**意图式路由表**(`| 你要做的事 | READ 集 | WRITEBACK 集 |`)而非总调度最初假设的模块式(`| 模块/路径 | owner 文档 | 技能 |`)。`cli/lib/common.sh::age_parse_index_routes` 与 `age_parse_index_skills` 已改为**章节感知 + 双格式自适应**:优先按意图式解析(匹配任务描述→READ/WRITEBACK),模块式作为兼容回退。`age route` 据意图表返回 READ 集与技能路由表的技能。`age sync` 在意图式下用目录约定推断 owner(无法精确路径映射),模块式下做 module→owner 映射。
- **协调点**:§8.6 H 约定的 `age sync --json` 字段 schema(`stale[]={module,owner,changed_file}` 等)在意图式下,`module` 字段实际填入代码文件路径(因意图式无模块概念)。任务执行 agent 的 `on-edit.sh` 若依赖 `module` 字段语义,请注意此差异。

**S. [D-3] propose/evolve 的实现裁决**
§8.1 [D-3] 指出 `age_propose_doc_update`/`age_evolve` 无 CLI 后端。总调度采用**方案 B**:此二工具在 `mcp/server.py` 内直接实现(`age_propose_doc_update` 调 `age route` 路由 + 生成补丁建议;`age_evolve` 直接写 `docs/audits/adr-*.md` + `docs/logs/evolve-*.md` + 标记 backlog),**仅会话态、无 CI 镜像**。`age ci`(= check --strict + sync --json)不依赖此二工具。若后续需 CI 镜像,再补 `age propose`/`age evolve` CLI 子命令。

**T. [D-5] SessionStart 调用语义**
同意 §8.1 [D-5]:SessionStart 应调 `age doctor`(无参)+ 读 `docs://context/project-context`,而非 `age route`(无 task 会失败)。`age doctor` 已实现无参诊断。此修复需任务执行 agent 在 `hooks/scripts/` 调整(任务执行所有权),总调度方 `age doctor` 已就绪。

**U. [D-6] 回写集存储未实现(待 v1.1)**
`.age/writeback.json` schema(`{task, docs:[], skills:[], timestamp}`)本次**未实现**。`age route` 当前输出 READ/WRITEBACK 集到 stdout(供会话态消费),不落盘。若 v1.1 确定该 schema,需在 `cli/lib/route.sh` 增加落盘逻辑、`cli/lib/audit.sh` closure 增加校验已清空逻辑。归总调度,待 v1.1 确认。

**V. [D-8] age_route MCP 未命中返回形状**
已实现:`age_route` 未命中时返回 `{"doc":[], "skill":"none", "reason":"未命中路由"}`(空 doc 数组 + none 技能 + reason 说明),非 null。命中时 `{"doc":[...], "skill":"...", "reason":"<匹配意图>"}`。与 §8.3 [D-8] 建议(`{doc:null,...}`)略有差异——用空数组而非 null,因 MCP 工具结果经 JSON 序列化,空数组对消费者更友好。请确认可接受。

**W. [I] age audit --json 未实现**
§8.6 I 请求 `age audit` 增加 `--json`。本次**未实现**(`age audit` 仅人类可读输出,违规走 stderr)。任务执行 agent 的 `on-stop.sh` 维持文本提取方案。`age audit --json` 归总调度,待后续迭代补(输出 `{violations:[{category,path,message}],summary:{count,scope}}`)。

**X. [J] is_age_repo 权威定义**
`cli/lib/common.sh::is_age_repo` 接受 `docs/index.md` **或** `AGENTS.md`。请 v1.1 裁定:若改为 `docs/index.md` only,总调度方改 `is_age_repo` 一行即可。当前采用宽松定义(两者之一即视为 AGE 仓库),因 `age init` 先生成 AGENTS.md 再生成 index.md,宽松定义避免初始化中途误判。

**Y. MCP server 运行方式与 env 变量(关联 §8.5 A、§8.5 G)**
- `mcp/server.py` 用 `python3` 直跑(纯 stdlib,无第三方依赖),符合 §8.5 G 的 python3 直跑方案。
- env 变量:读取 `AGE_PLUGIN_ROOT`(定位 cli/age 与 skills);项目根读取 `AGE_PROJECT_ROOT`,**若未设则回退 `AGE_PROJECT_DIR`**(§8.5 A 注入的是 `AGE_PROJECT_DIR`),再回退 `os.getcwd()`。请事实设计确认 plugin.json 的 env 注入与 server 读取一致(当前 server 兼容两种变量名)。
- 传输:stdio JSON-RPC 2.0,逐行读 stdin、逐行写 stdout;支持 initialize/resources/list/resources/read/tools/list/tools/call/ping。

**Z. CLI 退出码自检(关联 §8.3 [D-7])**
- `age ci` 退出码:check 或 sync 任一失败→1;全过→0(已实现)。
- `age baseline` 退出码:0 成功;无 docs/ 时输出空基线并返回 0(不算失败);IO 错误时 1。
- `age sync` 退出码:0 无漂移 / 1 有漂移 / 无 git 时 0(优雅降级)。
- `age route` 退出码:0 命中 / 1 未命中。
- `age check` 退出码:0 通过 / 1 有 error;`--strict` 时 warning 也算失败→1。
- `age audit` 退出码:0 通过 / 1 违规。
- `age doctor` 退出码:0 全健康 / 1 有问题。

**AA. 子代理 frontmatter 与 ZCode 兼容性(关联 §8.5 G)**
三个子代理 `agents/*.md` 含 frontmatter(name/description/tools/model)。`model` 字段填 `builtin:bigmodel/GLM-5.2`(与当前运行模型一致)。若 ZCode 不识别 `model` 字段或 `agents` 字段(见 §8.5 G),需事实设计在 plugin.json 调整;子代理正文(系统提示)不依赖该字段,可独立工作。

**AB. 跨平台声明(关联 §8.2 [D-2])**
CLI 全为 POSIX shell(`cli/age` + `cli/lib/*.sh`),依赖标准工具 git/sed/grep/find/awk/stat/wc。`stat` 已兼容 BSD(`-f '%m'`)与 GNU(`-c '%Y'`)。`sed` 替换走 stdout→文件(避开 `-i` 跨平台差异)。支持 macOS/Linux/WSL/Git-Bash;原生 Windows 需 Git-Bash(无 `cli/age.cmd`,见 §8.3 [D-12])。

### 8.9 代码审查 agent 的契约测试结论与跨所有权请求(2026-07-11)

代码审查 agent 已完成全部 9 个所有权文件(README.md + tests/{test_cli,test_hooks,test_mcp,test_templates}.bats + tests/helpers/test_helper.bash + templates/repo/docs/{articles,archive}/README.md + templates/repo/docs/articles/attractor-before-harness.md)。测试针对 §3/§4/§5 契约编写,不依赖实现细节。当前全套 66 测试:61 通过 / 0 失败 / 5 跳过(跳过均因同一根因,见 [CR-1])。以下为测试暴露的跨所有权缺口:

**[CR-1] BSD awk 路由解析器丢弃数据行(归总调度,阻断级)**
`cli/lib/common.sh::age_parse_index_routes` 的表头跳过正则 `o ~ /owner|文档|doc/i`(及 `/模块|路径|module/i`)在 macOS BSD awk 下误匹配**数据行**——只要 owner 列含子串 `doc`(如所有 `docs/...` 路径)或模块列含 `module` 子串,整行被当作表头丢弃。后果:`age check` 死链检测、`age route`、`age doctor` 的路由行解析在 macOS 全部返回 0 行。
- 影响:5 个测试跳过(test_cli #9 死链、#17/#19 route 命中与 explain、#20 doctor 健康、test_mcp #9 age_route 非空 doc)。Linux/gawk 不复现。
- 请求总调度:将表头跳过逻辑限定为"仅前 1-2 行"或"列分隔符行(`|---|`)"判断,而非对每行做子串正则。修复后 5 个跳过测试应自动转通过(测试已用 `if grep -q feature.md; then ... else skip ...` 守卫,无需改测试)。
- 测试侧规避:`tests/helpers/test_helper.bash::write_module_route_index` 已把 owner 写成不带 `docs/` 前缀的 `architecture/overview.md`(让 `age check` 经 `$root/docs/$owner` 回退解析),仅供 check/sync 测试通过;route/doctor 测试无法规避,故跳过。

**[CR-2] docs/index.md 路由表格式与解析器仍不一致(归事实设计 + 总调度,关联 §8.5 A、§8.8 R)**
事实设计产出的模板 `docs/index.md` 用**意图式**表(`| 你要做的事 | READ 集 | WRITEBACK 集 |`);总调度 §8.8 R 称已做"双格式自适应"。但实测 `age route` 仍不命中(见 [CR-1] 根因叠加):意图式下 `age sync` 的 owner 推断退化为目录约定,精确路径映射失效。
- 请求:事实设计与总调度联合确认 index.md 的**唯一**权威格式(意图式 or 模块式),并在 §3/§4 契约中写死列语义(列序、表头关键字)。当前两套语义共存使 `age check`/`sync`/`route` 行为对同一文件产生不同结果,契约测试只能按"哪条命令读哪列"分别 seed 不同的 index.md(见 test_helper 的 `write_module_route_index` vs `write_intent_route_index`),这不是长期可接受状态。

**[CR-3] MCP 工具结果的 JSON 二次编码(归总调度,契约澄清)**
`mcp/server.py` 的 tools/call 结果统一包装为 `{"content":[{"type":"text","text":"<内层 JSON>"}],"isError":false}`,内层 JSON 的引号被转义为 `\"`。契约 §4 描述 `age_route→{doc,skill,reason}` 等为"结构化结果",但未说明是裸 JSON 还是 content-text 包装。
- 请求总调度:在 §4 明确 MCP 工具结果遵循标准 MCP `content` 包装(内层为 JSON 字符串),或改为直接返回结构化 result 字段。测试侧已适配(用裸键名 `grep -Eq 'stale'` 而非 `"stale"` 匹配,规避转义),但契约应写清以免下游消费者(任务执行的 on-edit/on-stop)误解析。

**[CR-4] age init 偶发 `rev[@]: unbound variable`(归总调度,次要)**
`cli/lib/common.sh` 第 203 行 `${rev[@]+"${rev[@]}"}` 在 bats 环境下偶发触发 `set -u` 报错(GNU bash 3.2.57 / macOS),导致 `age init` 退出 1。直接 shell 复现不可稳定重现(多数时候 exit 0)。疑为数组空态展开与 `set -u` 交互的边界问题。
- 请求总调度:确认该行在 `set -u` + 空数组下的展开安全性(建议 `rev=("${rev[@]}" "$kv")` 或先 `rev+=("$kv")`)。非阻断(测试重跑即过),但影响首次运行体验。

**[CR-5] 测试运行器 bats-core 未声明为依赖(归事实设计/总调度,次要)**
`tests/*.bats` 依赖 bats-core(本仓库无 vendored 副本,需 `git clone https://github.com/bats-core/bats-core` 到 `/tmp/bats-prefix` 后用其 `bin/bats` 运行)。契约 §2/§8 未声明测试运行依赖。
- 请求:在 README 或 CONTRIBUTING 中补一句"运行测试需 bats-core,安装方式:git clone bats-core && ./install.sh /tmp/bats-prefix,然后 /tmp/bats-prefix/bin/bats tests/"。归事实设计(README/文档所有权)或总调度(构建脚本),由二者裁定。

**[CR-6] 测试所有权边界声明(非编辑请求,仅记录)**
代码审查 agent 仅写 9 个文件(见 §2 所有权表)。测试中引用的 `cli/age`、`hooks/scripts/*.sh`、`mcp/server.py`、`templates/repo/**` 均为其他 agent 所有权,测试仅以契约(§3/§4/§5)为断言基准。若实现 agent 调整行为偏离契约,测试将失败——此时应优先修实现或更新契约,而非改测试(测试是契约的守卫,不是实现的附庸)。

### 8.10 use-AGE 功能:第二轮 6-agent 并发任务分配(2026-07-11)

**功能目标:** 用户用自然语言说"开启 AGE / 启动 AGE / enable AGE / use AGE / 用 AGE"等相同语义时,自动激活 AGE 插件;若当前项目未初始化,自动执行 `age init` 完成初始化。

**文件所有权(本轮,严格不重叠):**

| 路径 | 所有者 | 职责 |
|---|---|---|
| `skills/use-AGE/SKILL.md` | 事实设计 | 新建独立 use-AGE 技能,description 覆盖中英文触发词 |
| `skills/age/SKILL.md`(编辑) | 事实设计 | 修改原 age 元 skill 的 description,增加"被 use-AGE 激活"语义 |
| `commands/use-age.md` | 任务执行 | 新建 /use-age slash command |
| `hooks/scripts/on-session-start.sh`(编辑) | 任务执行 | 修改:检测未初始化时从"提示"改为"自动 init" |
| `hooks/hooks.json`(编辑) | 任务执行 | 如需新增 hook 事件则改 |
| `cli/age`(编辑) | 总调度 | 新增 `age use` 子命令:检测+自动初始化+激活 |
| `cli/lib/use.sh` | 总调度 | `age use` 实现 |
| `mcp/server.py`(编辑) | 总调度 | 新增 `age_activate` tool,供 agent 会话内主动激活 |
| `agents/age-activator.md` | 总调度 | 新建激活子代理 |
| `templates/repo/docs/context/ai-autonomy-policy.md`(编辑) | 事实设计 | 补充"自动初始化"自治策略说明 |
| `tests/test_use_age.bats` | 代码审查 | use-AGE 功能测试 |
| `tests/test_cli.bats`(编辑) | 代码审查 | 补充 age use 命令测试 |
| `docs/use-age-design.md` | 方案审批 | use-AGE 功能设计审查与审批 |
| `templates/repo/START-HERE-after-copy.md`(编辑) | 过程计划 | 补充 use-AGE 快速启动说明 |
| `templates/repo/docs/process/application-development-workflow.md`(编辑) | 过程计划 | 在工作流开头加"激活 AGE"步骤 |
| `README.md`(编辑) | 代码审查 | 补充 use-AGE 快速开始说明 |

**use-AGE 技能的 description 必须覆盖的触发词(中英文):**
- 中文:开启AGE、启动AGE、用AGE、使用AGE、激活AGE、启用吸引子工程、开始AGE
- 英文:enable AGE、start AGE、use AGE、activate AGE、turn on AGE、init AGE
- 语义变体:"帮我设置AGE"、"这个项目用AGE吧"、"装一下AGE"

### 8.11 多客户端兼容:第三轮 6-agent 并发任务分配(2026-07-11)

**目标:** 让 AGE 插件兼容 ZCode / Claude Code / OpenAI Codex CLI / OpenCode CLI / Multica 五个有公开扩展机制的客户端。

**客户端兼容事实(CP-1 二次校验后修订 + Multica 恢复,2026-07-11):**

| 维度 | ZCode | Claude Code | Codex CLI | OpenCode CLI | Multica |
|---|---|---|---|---|---|
| 配置语言 | JSON | JSON | TOML | JSON | JSON(云 workspace,CLI 注册) |
| 配置文件(用户) | ~/.zcode/cli/config.json | ~/.claude/settings.json | ~/.codex/config.toml | ~/.config/opencode/opencode.json | ~/.multica/config.json(server_url+workspace_id+token) |
| 配置文件(工作区) | .zcode/config.json | .claude/settings.json + .mcp.json | ~/.codex/config.toml(含hooks段) | opencode.json | 无工作区配置文件(skill/agent/autopilot 注册到云 workspace) |
| MCP 键 | mcp.servers | .mcp.json 顶层 mcpServers | [mcp_servers.NAME](TOML) | mcp(command 为数组) | agent --mcp-config(mcpServers JSON,与 Claude Code 一致) |
| 指令文件 | AGENTS.md | CLAUDE.md | AGENTS.md | AGENTS.md | agent --instructions(等价 AGENTS.md) |
| Skills | 目录+SKILL.md | .claude/skills/SKILL.md | .codex/skills/SKILL.md | 无(用 commands) | multica skill create 注册到 workspace(SKILL.md,与 ZCode/Claude 格式一致) |
| Slash commands | .md+frontmatter | .claude/commands/*.md+frontmatter | 无标准(用 AGENTS.md) | opencode.json 内联 commands | 无(用 skill + autopilot 替代) |
| Hooks 机制 | hooks.json(插件) | settings.json 配置键 | config.toml [hooks]段 | **plugin 模块**(Hooks 接口,非配置键) | **无本地 hooks**(autopilot schedule/webhook 部分替代) |
| Hooks 事件名 | PascalCase(7事件) | PascalCase(20+事件) | PascalCase(10事件,与Claude一致) | dot-notation小写(tool.execute.after 等),plugin 接口方法名 | 不适用(无本地 hooks) |
| Hooks 可用事件 | SessionStart/PreToolUse/PostToolUse/Stop 等 | 同左(20+) | 同 Claude Code | tool.execute.after(PostToolUse 对应)、tool.execute.before(PreToolUse 对应)、chat.message(部分替代 SessionStart);**无 SessionStart/Stop** | 无;autopilot trigger(schedule --cron / webhook)部分替代 Stop 的定时触发 |
| 插件打包 | plugin.json+marketplace | 无 | 无 | 无 | 无(skill/agent/autopilot 注册到云 workspace) |
| 项目目录 env | ${ZCODE_PROJECT_DIR} | ${CLAUDE_PROJECT_DIR} | 无(用cwd/git) | 无(用cwd/git) | AGE_PROJECT_ROOT(agent --custom-env) |
| 插件根 env | ${ZCODE_PLUGIN_ROOT} | 无 | 无 | 无 | AGE_PLUGIN_ROOT(agent --custom-env,install.sh 注册) |
| **兼容等级** | **full(原生)** | **full** | **full**(hooks+skills+MCP) | **partial**(MCP+commands,无SessionStart/Stop hooks) | **full**(skill+MCP+autopilot,无本地 hooks,autopilot 部分替代) |

**CP-1 校验关键结论(权威源码验证) + Multica 恢复(2026-07-11):**
- Codex 有完整 hooks(PascalCase,与 Claude Code 事件名一致:PreToolUse/PostToolUse/SessionStart/Stop 等)+ skills(.codex/skills/SKILL.md)+ AGENTS.md。**原事实表"Codex 无 hooks/skills"是严重错误,已纠正。**
- OpenCode hooks 是 **plugin 机制**(本机 `@opencode-ai/plugin` SDK 1.17.18 复核,路径 `/Users/ale/.opencode/node_modules/@opencode-ai/plugin/dist/index.d.ts`):hooks **不能在 opencode.json 配置**,必须实现 `Hooks` 接口写成一个 JS/TS plugin 模块(`plugin.ts`),通过 `opencode plugin <module>` 安装或在 `opencode.json` 的 `"plugin": ["./plugin.ts"]` 数组引用。`Plugin` 函数签名:`(input: PluginInput, options?) => Promise<Hooks>`。Hooks 接口事件:`dispose`、`event`、`config`、`tool`、`auth`、`provider`、`chat.message`、`chat.params`、`chat.headers`、`permission.ask`、`command.execute.before`、`tool.execute.before`、`shell.env`、`tool.execute.after`、`experimental.*`。**没有 SessionStart、没有 Stop**。`tool.execute.after` 是 PostToolUse 的真实对应(input `{tool,sessionID,callID,args}`,output `{title,output,metadata}`);`tool.execute.before` 是 PreToolUse 对应;`chat.message` 部分替代 SessionStart(每次用户发消息触发,可注入 context)。原 opencode.json 的 `hooks` 配置键是错误,已移除,改为 `plugin` 引用 + `plugin.ts` 实现。
- Claude Code 事实全部正确:${CLAUDE_PROJECT_DIR} 存在,.mcp.json 在项目根,hooks 在 settings.json。
- **Multica 恢复(纠正 CP-1 拼写错误):** Multica 是真实存在的 AI 原生团队工作区客户端(Go 写的,云 workspace 模式,开源 https://github.com/multica-ai/multica)。CP-1 原结论"Mutica 不存在,是实验性编程语言"是**拼写错误导致的误判**——正确拼写是 Multica,且是真实 AI 客户端。本机验证(2026-07-11):CLI 路径 `/Applications/Multica.app/Contents/Resources/app.asar.unpacked/resources/bin/multica`(也在 PATH `~/.local/bin/multica`),版本 `v0.3.43`(commit 37b0a6e72,built 2026-07-10,go1.26.1 darwin/arm64),配置 `~/.multica/config.json`(server_url `https://api.multica.ai`,workspace_id `360e1725-aa5c-49bb-90b1-7d30aa828a63`)。`multica skill list` 实跑可用。扩展机制完整:`multica skill create --name --description --content-file`(技能注册到 workspace,SKILL.md 与 ZCode/Claude 格式一致)、`multica agent create/update --mcp-config/--mcp-config-file`(标准 mcpServers JSON,与 Claude Code `.mcp.json` 一致)、`multica agent skills add <id> --skill-ids <id>`(技能绑定,注意是 `--skill-ids` 复数逗号分隔)、`multica agent env set <id> --custom-env`(环境变量)、`multica autopilot create + trigger-add --kind schedule --cron`(定时触发,部分替代 Stop hook)。**无本地 hooks**(无配置文件式钩子),SessionStart/Stop 降级为 use-AGE 技能(显式激活)+ autopilot(定时漂移检测)。兼容等级 = **full**(skill+MCP+autopilot,无本地 hooks 但 autopilot 部分替代)。

**兼容策略(修订):** ZCode 是一等宿主;Claude Code 和 Codex CLI 均为 full 级(hooks+skills+MCP+指令文件全支持,事件名 PascalCase 一致);OpenCode CLI 为 partial 级(MCP+commands+AGENTS.md+plugin 模块实现 Hooks 接口,无 SessionStart/Stop 事件,chat.message 部分替代 SessionStart、tool.execute.after 真实对应 PostToolUse);Multica 为 full 级(skill+MCP+autopilot+agent instructions,无本地 hooks,use-AGE 技能替代 SessionStart 的一次性激活、autopilot 定时漂移检测部分替代 Stop 的 closure audit)。

**功能降级矩阵:**

| 功能 | ZCode | Claude Code | Codex CLI | OpenCode CLI | Multica |
|---|---|---|---|---|---|
| MCP(resources+tools) | ✅ | ✅ | ✅ | ✅ | ✅(agent --mcp-config,标准 mcpServers) |
| AGENTS.md/CLAUDE.md 指令 | ✅ | ✅(CLAUDE.md) | ✅(AGENTS.md) | ✅(AGENTS.md) | ✅(agent --instructions=AGENTS.md) |
| Skills(use-AGE/age等) | ✅ | ✅ | ✅(.codex/skills/) | ❌(用commands替代) | ✅(multica skill create,注册到 workspace) |
| Slash commands | ✅ | ✅ | ❌(用AGENTS.md引导) | ✅(内联prompt) | ❌(用 skill + autopilot 替代) |
| SessionStart hook | ✅ | ✅ | ✅ | ⚠️(chat.message 部分替代,每会话首条消息注入 context) | ⚠️(use-AGE 技能显式激活替代一次性上下文注入;无自动 SessionStart) |
| PostToolUse hook | ✅ | ✅ | ✅ | ✅(tool.execute.after,plugin hook,真实对应) | ⚠️(autopilot 定时 age sync 部分替代,非实时;或对话中手动 age sync) |
| Stop hook | ✅ | ✅ | ✅ | ❌ | ⚠️(autopilot 定时部分替代;closure audit 需对话中触发) |
| age install 适配 | 原生 | ✅ | ✅ | ✅ | ✅(调 compat/multica/install.sh 注册技能到 workspace) |

**第三轮修复(打回重做)文件所有权:**

| 路径 | 所有者 | 修复内容 |
|---|---|---|
| `compat/README.md`(编辑) | 事实设计 | CP-2:更新降级矩阵+客户端对照表+移除Mutica |
| `compat/codex/README.md`(编辑) | 事实设计 | CP-2:Codex升级为full级,补hooks+skills说明 |
| `compat/codex/config.toml`(编辑) | 事实设计 | CP-2:补[hooks]段(SessionStart/PostToolUse/Stop) |
| `compat/codex/skills/`(新建) | 事实设计 | CP-2:Codex skills适配(符号链接或副本指向age skills) |
| `compat/opencode/README.md`(编辑) | 事实设计 | CP-4:基于本机 SDK 1.17.18 重写,plugin 模块机制说明(无 SessionStart/Stop,tool.execute.after=PostToolUse 对应,chat.message=部分 SessionStart) |
| `compat/opencode/opencode.json`(编辑) | 事实设计 | CP-4:移除 hooks 配置键(错误),改 plugin 引用 + 保留 mcp/commands + 降级说明 |
| `compat/opencode/plugin.ts`(新建) | 事实设计 | CP-4:OpenCode AGE plugin 模块,实现 Hooks 接口(chat.message/tool.execute.after/tool.execute.before/dispose) |
| `compat/opencode/package.json`(新建) | 事实设计 | CP-4:plugin 模块 package.json(@age/opencode-plugin,依赖 @opencode-ai/plugin 1.17.18) |
| `compat/mutica/`(删除) | 事实设计 | CP-1:Mutica不存在,移除 |
| `compat/multica/`(新建) | 总调度 | Multica 恢复(纠正 CP-1 拼写错误:Mutica→Multica,真实 AI 客户端 v0.3.43 本机验证):use-AGE.skill.md + mcp-config.json + install.sh + README.md。install.sh 调 multica CLI 注册技能+配置 agent+autopilot。full 级(skill+MCP+autopilot,无本地 hooks) |
| `compat/claude-code/CLAUDE.md`(编辑) | 事实设计 | CP-5:标注"AGENTS.md为源,CLAUDE.md为生成副本" |
| `templates/repo/AGENTS.md`(编辑) | 事实设计 | CP-5:补充"CLAUDE.md是本文件副本"声明 |
| `cli/lib/install.sh`(编辑) | 总调度 | CP-4:补--list选项+多客户端共存检测+Codex hooks安装;OpenCode 改为拷贝 opencode.json+plugin.ts+package.json 并提示 opencode plugin 安装(plugin 模块机制);Multica 恢复:补 multica 分支(调 compat/multica/install.sh)+ --list/help 含 multica |
| `cli/lib/common.sh`(编辑) | 总调度 | CP-4:detect_host()补Codex hooks/skills检测信号;Multica 恢复:detect_host()补 multica 检测(AGE_MULTICA_WORKSPACE env 或 multica CLI/Multica.app/~/.multica/config.json) |
| `mcp/server.py`(编辑) | 总调度 | CP-7:项目根cwd校验warning |
| `hooks/scripts/lib.sh`(编辑) | 总调度 | CP-8:按客户端分支emit_context格式 |
| `tests/test_compat.bats`(编辑) | 代码审查 | 更新:Codex有hooks+skills断言;OpenCode 改为断言 opencode.json 无 hooks 键+有 plugin 引用、plugin.ts 存在且导出 default、package.json 存在;Multica 恢复:断言 compat/multica/ 存在+文件齐全+mcp-config.json 合法 JSON 含 mcpServers+use-AGE.skill.md 含触发词+install.sh 可执行且引用 multica CLI 子命令+age install --list 含 multica |
| `tests/test_install.bats`(编辑) | 代码审查 | 更新:age install --client codex 安装hooks段 |
| `docs/compat-design-review.md`(编辑) | 方案审批 | CP-1校验后重新审查 |
| `docs/compat-risk-register.md`(编辑) | 方案审批 | 更新风险(Codex升级+OpenCode降级+Multica恢复) |
| `README.md`(编辑) | 代码审查 | 更新兼容矩阵+Multica 恢复(改回 full 级,标注本机验证) |

### 8.12 Win11 兼容:第四轮 6-agent 并发任务分配(2026-07-11)

**目标:** 让 AGE 插件在 Windows 11 上可用。当前 CLI/hooks 全是 POSIX shell(bash),Win11 原生无 bash。需要:PowerShell CLI 入口、Win11 hook 脚本适配、路径/环境变量兼容、MCP server 启动适配、安装脚本、测试。

**Win11 兼容事实:**
- Win11 原生 shell:PowerShell 5.1(预装)/ PowerShell 7(可选)
- bash 可用场景:Git-Bash(随 Git for Windows 安装)、WSL(Ubuntu 等)
- 路径分隔符:`\`(反斜杠) vs POSIX `/`
- 环境变量:`%VAR%`(CMD) / `$env:VAR`(PowerShell) vs `$VAR`(bash)
- Python3:Win11 上通常是 `python`(不含 3),需检测
- 可执行脚本:.ps1(PowerShell)/ .cmd(CMD)/ .bat
- 行结束符:CRLF vs LF(git autocrlf)

**兼容策略(双层):**
1. **PowerShell 原生层**:cli/age.ps1(PowerShell 入口) + hooks .ps1 脚本,不依赖 bash
2. **Git-Bash 兼容层**:现有 bash 脚本在 Git-Bash 下直接可用(验证 + 修小问题)
- 优先 PowerShell 原生(不要求用户装 Git-Bash),Git-Bash 作为回退

**文件所有权(本轮,严格不重叠):**

| 路径 | 所有者 | 职责 |
|---|---|---|
| `compat/win11/README.md` | 事实设计 | Win11 兼容说明 + 双层策略 + 环境要求 |
| `compat/win11/path-utils.ps1` | 事实设计 | PowerShell 路径工具(POSIX↔Win 转换、插件根定位) |
| `compat/win11/env-template.ps1` | 事实设计 | Win11 环境变量模板(AGE_PLUGIN_ROOT 等) |
| `templates/repo/AGENTS.md`(编辑) | 事实设计 | 补充 Win11 路径/环境变量说明 |
| `templates/repo/START-HERE-after-copy.md`(编辑) | 过程计划 | 补充 Win11 安装步骤 |
| `templates/repo/docs/process/application-development-workflow.md`(编辑) | 过程计划 | 补充 Win11 工作流注意事项 |
| `templates/repo/docs/context/conventions.md`(编辑) | 过程计划 | 补充 Win11 行结束符/路径约定 |
| `cli/age.ps1` | 总调度 | PowerShell CLI 入口(等价 cli/age,调 lib/*.ps1) |
| `cli/lib/*.ps1` | 总调度 | PowerShell 核心函数(等价 lib/*.sh) |
| `cli/lib/common.ps1` | 总调度 | PowerShell 共享函数(渲染/检测/日志) |
| `hooks/scripts/*.ps1`(新建4个) | 任务执行 | PowerShell hook 脚本(on-session-start/edit/stop/lib) |
| `hooks/hooks.win11.json` | 任务执行 | Win11 hook 配置(指向 .ps1 脚本) |
| `mcp/server.py`(编辑) | 总调度 | Win11 路径兼容(os.path 已跨平台,确认+修) |
| `cli/lib/install.sh`(编辑) | 总调度 | age install --client win11 安装 PS1 入口 |
| `cli/lib/common.sh`(编辑) | 总调度 | detect_host() 加 win11 检测 |
| `docs/win11-design-review.md` | 方案审批 | Win11 兼容方案审查 |
| `docs/win11-risk-register.md` | 方案审批 | Win11 风险登记册 |
| `tests/test_win11.bats` | 代码审查 | Win11 兼容测试 |
| `README.md`(编辑) | 代码审查 | 补充 Win11 安装说明 |

**PowerShell CLI 契约(与 bash CLI 等价):**
- `cli/age.ps1` 支持:init/use/install/check/sync/route/audit/doctor/ci/baseline/help
- 调用 `cli/lib/*.ps1` 函数
- 路径用 `$AGE_PLUGIN_ROOT`(环境变量)或自动探测(脚本位置向上找)
- Python 检测:`python` → `python3` → `py -3`
- MCP server 启动:`python mcp/server.py`(Win11 上 python 不含 3)


---
description: Run a full doc/code consistency audit and write results to docs/audits/.
allowed-tools: Bash, Read, Write
---

# /age-audit — full documentation audit

You are executing the `audit` subflow of the AGE meta-skill (`skills/age/SKILL.md`, CONTRACT.md §6). The deterministic core is the `age audit` CLI (CONTRACT.md §3), and the deep inspection is delegated to the `doc-auditor` subagent (CONTRACT.md §7, file `agents/doc-auditor.md`).

## Step 1 — run the full audit
Run: `age audit --scope full`
Per CONTRACT.md §3 this audits documentation-vs-code consistency across the whole repo. Exit code `0` = pass, `1` = violations. Capture the structured output (drift, broken links, missing baseline fields, unresolved AGENTS references).

## Step 2 — quick consistency gate
Also run `age check --strict` (CONTRACT.md §3) for the static checks (dead route links, baseline completeness, AGENTS reference resolution). Merge its findings with the `audit` output so the audit report covers both runtime drift and structural defects.

## Step 3 — delegate deep review to doc-auditor
Dispatch the `doc-auditor` subagent (CONTRACT.md §7) on the backlog/requirements vs. code consistency. Pass it:
- the `age audit` + `age check` findings as input
- instruction to scan `docs/backlog/` and `docs/requirements/` against the current code and flag mismatches

Collect the subagent's structured findings.

## Step 4 — write the audit report
Write the consolidated report to `docs/audits/` (CONTRACT.md §2 owner: process-plan). Use a dated filename, e.g. `docs/audits/<YYYY-MM-DD>-full-audit.md`, containing:
- summary (pass/fail, drift score, counts by category)
- the raw `age audit` + `age check` findings
- the doc-auditor subagent findings
- per-violation: file path, category, severity, suggested fix

If `docs/audits/` does not exist, create it (it is part of the AGE skeleton; creating it here is a recovery action, not a new path invention).

## Step 5 — report to the user
Summarize:
- overall pass/fail
- top violations by severity
- the audit report path
- next step: run `/age-sync` to reconcile actionable drift, or fix structural defects manually

Be concise in chat; the full detail lives in the written report. Do not fix violations here unless the user explicitly asks — auditing is read/analyze + write-report only.

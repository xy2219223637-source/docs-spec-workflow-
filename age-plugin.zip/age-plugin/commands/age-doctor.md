---
description: Diagnose the AGE environment and config; report findings and fix suggestions.
allowed-tools: Bash, Read
---

# /age-doctor — diagnose AGE environment and configuration

You are running the AGE environment diagnostic. The deterministic core is the `age doctor` CLI (CONTRACT.md §3).

## Step 1 — run the doctor
Run: `age doctor`
Per CONTRACT.md §3 this diagnoses environment and configuration. Exit code `0` = healthy, `1` = problems found. Capture all output (it should enumerate each check and its pass/fail status).

If the `age` CLI itself is not on PATH or not executable, that is the first finding: report that the CLI is missing and point the user to installing/building it (CONTRACT.md §2 puts the CLI entry at `cli/age`). Stop after reporting this.

## Step 2 — interpret and explain findings
For each check the doctor reports, translate it into plain language for the user:
- what was checked
- pass / fail
- if fail: the likely cause and a concrete fix (exact command or file to edit)

Common areas the doctor covers (infer from its actual output, do not assume):
- git presence and repo state
- `age` CLI availability and version
- `docs/index.md` presence and valid route table
- `.age/baseline.json` presence and freshness
- AGENTS.md references resolvable
- hook scripts present and executable

## Step 3 — report and recommend
Present a compact table or list: check | status | action. Group failures first. For each failure give the single most likely fix. If everything passes, say so plainly and suggest running `/age-init` (if the repo isn't initialized) or `/age-sync` (to reconcile drift).

Do not modify anything automatically — the doctor is diagnostic only. Offer to apply a fix only if the user confirms.

Keep it short and actionable.

---
description: Route a task to the right owner docs/skill and mark the writeback set.
allowed-tools: Bash, Read
---

# /age-route — route a task to owner documentation

Argument: `$ARGUMENTS` is the task description (free text). If `$ARGUMENTS` is empty, ask the user for a one-line task description and stop.

You are executing the `route` subflow of the AGE meta-skill (`skills/age/SKILL.md`, CONTRACT.md §6). The deterministic core is the `age route` CLI (CONTRACT.md §3).

## Step 1 — route the task
Run: `age route "<task>" --explain`
Per CONTRACT.md §3 this returns the owning doc(s) and/or skill, plus a reason. Exit code `0` = a route hit, `1` = no owner found (unrouted). Inspect stdout (JSON or structured text).

## Step 2 — read the owner documentation
For every owner doc the route returned, read it (typically under `docs/{requirements,design,architecture,backlog}/`). Read the referenced skill file if one is named. The `--explain` output tells you WHY this doc owns the task — use that to judge whether the task is fully covered or needs a doc update.

## Step 3 — mark the writeback set
Before the user starts coding, decide and record which documents will need updating as a result of this task (the "writeback set"). This is the same set `/age-sync` will reconcile afterward (CONTRACT.md §6 doc-sync subflow). State the writeback set explicitly to the user as a short bulleted list, e.g.:
- docs/requirements/foo.md (acceptance criteria)
- docs/design/bar.md (sequence diagram)

If the route is a miss (exit 1): tell the user no owner doc exists, propose either (a) creating a new backlog/requirements entry, or (b) refining the task wording. Do not fabricate an owner.

## Step 4 — brief the user
Summarize concisely:
- the route result (owner doc + skill + reason)
- the writeback set to update when the task is done
- the next action: do the task, then run `/age-sync` to reconcile the writeback set

Keep it short. Do not edit any docs here — routing is read-only; writes happen during `/age-sync`.

---
description: Initialize an AGE-managed repo: scaffold docs, fill Day 0, snapshot baseline.
allowed-tools: Bash, Read, Edit, Write
---

# /age-init — initialize AGE in the current repository

You are executing the AGE bootstrap flow. Follow the age-init subflow of the AGE meta-skill (`skills/age/SKILL.md`). The deterministic core runs through the `age` CLI (CONTRACT.md §3).

## Step 1 — preflight diagnosis
Run `age doctor` (CONTRACT.md §3). Report any environment problems (missing git, missing CLI deps, broken config) to the user and propose fixes. Do NOT proceed with scaffolding if `age doctor` reports a fatal environment error; tell the user what to fix first.

## Step 2 — gather scaffold parameters
If the user did not pass `--name` or `--kind`, ask (concisely) for:
- project name (default: current directory basename)
- project kind: `web` | `mobile` | `cli` (default: `web`)

Do not ask more than one combined question. Use the answers as CLI flags.

## Step 3 — generate the skeleton
Run: `age init --name <name> --kind <kind>`
This (per CONTRACT.md §3) generates the docs skeleton + AGENTS.md and triggers Day 0 guidance. Inspect the exit code: `0` = success, `1` = failure (report the CLI's stderr and stop).

After generation, verify the scaffold landed by listing `docs/` and confirming `docs/index.md`, `AGENTS.md`, and `START-HERE-after-copy.md` exist. If `age init` claims success but files are missing, note the discrepancy in `.age/hooks.log` and tell the user.

## Step 4 — guide Day 0 fill
Read `START-HERE-after-copy.md` (it is the Day 0 checklist, CONTRACT.md §2 owner: process-plan). Walk the user through the Day 0 fields defined in `.zcode-plugin/userConfig-schema.json` (project name, mission, non-goals, tech stack, conventions). Prompt the user for each unfilled field and write the answers into the matching `docs/context/*.md` template slots. Keep the prompts short and batch trivial defaults.

## Step 5 — snapshot the baseline
Run: `age baseline` (CONTRACT.md §3) — snapshots the current `docs/` fingerprint to `.age/baseline.json`. Confirm exit code `0` and that `.age/baseline.json` was written.

## Step 6 — verify and report
Run `age check` (CONTRACT.md §3, non-strict) to confirm the freshly initialized repo is internally consistent (no dead links, baseline present, AGENTS references resolvable). Summarize to the user:
- what was scaffolded
- the baseline path
- any `check` warnings and how to resolve them
- next step: use `/age-route` before starting the first task

Be concise. Only create files via the CLI or by filling template slots — do not invent new doc paths outside the AGE skeleton.

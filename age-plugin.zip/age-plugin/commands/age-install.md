---
description: Install AGE into the current client (ZCode/Claude Code/Codex/OpenCode) — detect host, copy the matching compat/ config to the right location, report results.
allowed-tools: Bash, Read, Write
---

# /age-install — install AGE for the current client

You are executing the AGE multi-client install flow (CONTRACT.md §8.11). AGE's portable core — the `age` CLI, `AGENTS.md`, and the MCP server — works across clients; the client-specific bits (hooks, slash commands, skills format, MCP wiring) live under `compat/<client>/` and are copied into the right place by the deterministic `age install` command (CONTRACT.md §8.11; implemented by the coordinator in `cli/lib/install.sh`, host detection in `cli/lib/common.sh::detect_host`).

`age install` does three things deterministically: (1) detect the current client environment (ZCode / Claude Code / Codex CLI / OpenCode CLI), (2) copy the matching `compat/<client>/` configuration to the correct location for that client, and (3) report what it installed and where. Your job is to call it, interpret the result, and tell the user what to do next.

## Step 1 — invoke the installer
Run: `age install`

Capture stdout, stderr, and the exit code.

- Exit code `0` = install succeeded. The output identifies the detected client, the source `compat/<client>/` tree, and the destination paths written. Proceed to Step 2.
- Exit code `1` = install failed. The stderr should explain why (unknown host, missing compat files, permission denied, etc.). Report the reason to the user and fall back to the manual instructions in Step 4.
- If the `age` CLI is missing entirely, or `age install` is not implemented (e.g. prints "unknown command install" / `command not found`), treat it as a fallback case: go to Step 4 and give the user the manual install path.

## Step 2 — parse and report the install result
Read the installer's output and summarize, for the user, in plain language:

- **Which client was detected** (ZCode / Claude Code / Codex / OpenCode). If the detection seems wrong (e.g. you know you're in Claude Code but it said ZCode), say so and point the user at the manual path for their actual client.
- **What was installed** — the list of files/configs the installer copied (e.g. settings.json, .mcp.json, CLAUDE.md, hooks, commands).
- **Where it was installed** — the destination paths (user-level vs workspace-level, per the client facts in CONTRACT.md §8.11, e.g. `~/.claude/settings.json` + `.mcp.json` + `CLAUDE.md` for Claude Code; `~/.codex/config.toml` for Codex; `~/.config/opencode/opencode.json` for OpenCode).
- **Anything that needs a manual step** — e.g. an MCP server entry that points at the bundled `age mcp` and may need a path tweak, or a hook script that must be `chmod +x`.

Keep the report compact: a short detected-client line, then a bullet list of "X → Y" (source → destination) for what was copied.

## Step 3 — recommend activation
Once install reports success, tell the user how to actually turn AGE on for this project. Recommend, in one or two lines:

> AGE is installed for `<client>`. To activate it in this project, say **"启动 AGE"** or run **`/use-age`** — it will initialize the repo (if needed) and inject project context. If this project is already AGE-initialized, AGE is already active.

If the client is not ZCode (so `/use-age` as a slash command may not exist yet in that client's format), adapt the recommendation: tell the user to say the natural-language phrase "启动 AGE" / "use AGE", which the use-AGE skill is designed to catch across clients.

## Step 4 — fallback: manual install guidance
If `age install` is unavailable, fails, or detects the wrong host, do NOT block the user. Give manual install instructions pointing at the per-client README that the 事实设计 agent maintains under `compat/` (CONTRACT.md §8.11 ownership table):

1. Read the client table below and identify the user's client. If you cannot tell which client the user is in, ask one concise question.
2. Point them at the matching `compat/<client>/README.md` (absolute path under the plugin root if you can resolve it via `${ZCODE_PLUGIN_ROOT}` or the repo path; otherwise the relative path `compat/<client>/README.md`). That README documents exactly which files to copy where for that client.
3. Offer to open that README and walk through it with them.

Client → manual guide mapping (CONTRACT.md §8.11 compat facts):

| Client | Manual guide | Config language | Key destinations |
|---|---|---|---|
| ZCode | `compat/README.md` (ZCode is the first-class host; plugin.json + marketplace) | JSON | plugin install via marketplace |
| Claude Code | `compat/claude-code/README.md` | JSON | `~/.claude/settings.json`, `.mcp.json`, `CLAUDE.md` |
| Codex CLI | `compat/codex/README.md` | TOML | `~/.codex/config.toml` (`[mcp_servers.age]`) |
| OpenCode CLI | `compat/opencode/README.md` | JSON | `~/.config/opencode/opencode.json` |

If the `compat/` directory or a specific `compat/<client>/README.md` does not exist yet (the 事实设计 agent may still be writing it in parallel), tell the user plainly that the compat files for their client are not present yet and suggest re-running `/age-install` once they are available, or falling back to the ZCode plugin install which is the primary distribution.

## Rules
- Only write files the installer writes for you (`age install`) — do not manually scatter configs into the user's home directory yourself. The CLI owns the deterministic copy; you interpret and report.
- Never leave the user uncertain about whether install succeeded — always end with a clear "installed / not installed" statement plus the single next action.
- Respect CONTRACT.md §2 ownership: you may only edit `commands/*.md` and `hooks/scripts/*.sh`. If `age install` is missing, point the user at the coordinator (`cli/lib/install.sh`, CONTRACT.md §8.11 owner: coordinator) — do not implement the install logic in this command.

---
description: Activate AGE in the current project — auto-initialize if needed, then inject context. Triggered by "开启AGE/启动AGE/用AGE/use AGE/enable AGE" and similar phrasing.
allowed-tools: Bash, Read, Edit, Write
---

# /use-age — activate AGE in the current project

You are executing the AGE activation flow (CONTRACT.md §8.10). The deterministic core is the `age use` CLI (CONTRACT.md §8.10; implemented by the coordinator in `cli/lib/use.sh`).

`age use` does three things deterministically: (1) detect whether the current project is already AGE-initialized, (2) if NOT initialized, automatically run `age init` to scaffold the project, and (3) print an activation-status report. Your job is to call it, interpret the result, and complete whichever path it indicates.

## Step 1 — invoke the activator
Run: `age use`

Per CONTRACT.md §8.10, `age use` auto-initializes when the repo is not yet AGE-managed, then reports activation status. Capture stdout and the exit code.

- Exit code `0` = activation succeeded (either already-initialized or just-initialized).
- Exit code `1` = activation failed. Report the CLI's stderr to the user, suggest `age doctor`, and stop.

If the `age` CLI is missing or `age use` is not yet implemented (unknown subcommand), fall back gracefully:
1. Detect AGE-init state yourself: the repo is initialized if `docs/index.md` exists (CONTRACT.md §5 / `is_age_repo`).
2. If NOT initialized, run `age init --name <basename> --kind web` (sensible defaults) and continue from Step 3 below.
3. If already initialized, skip to Step 2.

Do NOT block the user on a missing CLI — use the Read tool to confirm `docs/index.md` presence directly.

## Step 2 — already-initialized branch: inject context and report active
If `age use` reports the repo is already initialized (or you confirmed `docs/index.md` exists):

1. Read every file under `docs/context/` (`project-context.md`, `codebase-map.md`, `conventions.md`, `ai-autonomy-policy.md`, `source-of-truth-and-precedence.md`, and any others present).
2. Tell the user, concisely, that AGE is active for this project.
3. Summarize the injected context in 3-5 lines: project name/mission, current phase, tech stack, and any autonomy constraints from `ai-autonomy-policy.md`.
4. Skip to Step 4 (recommend the next task).

## Step 3 — just-initialized branch: guide Day 0
If `age use` performed initialization (or you ran `age init` in the fallback):

1. Verify the scaffold landed by listing `docs/` and confirming `docs/index.md`, `AGENTS.md`, and `START-HERE-after-copy.md` exist (CONTRACT.md §3 init contract). If files are missing, note the discrepancy and stop.
2. Read `START-HERE-after-copy.md` (the Day 0 checklist; CONTRACT.md §2 owner: process-plan).
3. Walk the user through the Day 0 fields defined in `.zcode-plugin/userConfig-schema.json`: `owner_name`, `project_kind`, `doc_language`, `require_backlog`, `validate_cmd` (and any context-template fields the checklist surfaces — project name, mission, non-goals, tech stack, conventions). Batch trivial defaults; do not ask more than one combined question at a time.
4. Write the user's answers into the matching `docs/context/*.md` template slots using Edit/Write.
5. Run `age baseline` to snapshot the fresh `docs/` fingerprint to `.age/baseline.json` (CONTRACT.md §3). Confirm exit code `0`.
6. Tell the user AGE is now initialized and active for this project.

## Step 4 — recommend the first task
Once AGE is active (whether from Step 2 or Step 3), recommend the next action:

> AGE is active. To start your first task, run `/age-route <task description>` — it will route you to the right owner docs and mark the writeback set to reconcile later with `/age-sync`.

Keep the recommendation to one or two lines. Do not narrate the whole workflow.

## Rules
- Only create files via the CLI (`age init`) or by filling existing template slots — do not invent new doc paths outside the AGE skeleton.
- Be concise throughout. The activation should feel like one quick step to the user.
- Never leave the user in an ambiguous "is it on?" state — always end with a clear active/not-active statement.

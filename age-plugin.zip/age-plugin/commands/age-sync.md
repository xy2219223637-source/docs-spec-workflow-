---
description: Detect doc drift after edits and propose updates for stale/orphan/missing docs.
allowed-tools: Bash, Read, Edit, Write
---

# /age-sync — reconcile documentation drift

You are executing the `doc-sync` subflow of the AGE meta-skill (`skills/age/SKILL.md`, CONTRACT.md §6). The deterministic core is the `age sync` CLI (CONTRACT.md §3).

## Step 1 — compute the drift report
Run: `age sync --json`
Per CONTRACT.md §3 this runs a git-diff-based drift analysis and returns a JSON report with three categories:
- `stale[]` — docs whose content no longer matches the code they describe
- `orphan[]` — docs that reference code/sections that no longer exist
- `missing[]` — code/behavior that has no corresponding documentation

Exit code `0` = no drift, `1` = drift present. Parse the JSON. If the CLI is unavailable or errors, report the raw stderr and stop.

## Step 2 — if no drift, stop cleanly
On exit `0` / empty report: tell the user docs are in sync and stop.

## Step 3 — propose a concrete update per drift item
For each item in `stale`, `orphan`, and `missing`:
1. Read the affected doc (for stale/orphan) or the relevant code (for missing).
2. Propose the specific edit needed — show the user the targeted change (section + what to add/fix/remove), not a vague "please update this doc".
3. For `missing` items, propose which doc should capture it (route via the owner implied by the change) and offer to draft the new section.
4. Ask for confirmation before writing. Apply confirmed edits with the Edit tool against the exact doc path.

Prefer minimal, surgical edits that keep the doc within its declared owner scope (CONTRACT.md §2). Do not move content between owner directories.

## Step 4 — re-verify
After applying edits, re-run `age sync --json` to confirm drift is cleared (exit `0`). Report a one-line summary: N docs updated, drift now clean (or list residual items the user declined to fix).

## Step 5 — refresh baseline (optional)
If the user confirms the docs are now accurate, offer to run `age baseline` to snapshot a new fingerprint so future drift detection starts from this clean state. Do not run it without confirmation.

Keep output focused: list the drift, the proposed fix, and the result. Avoid restating unchanged docs.

#!/usr/bin/env python3
"""AGE MCP server — 模型上下文协议服务端(纯 stdlib 实现,stdio 传输)。

实现 CONTRACT.md 第4节:
  Resources(只读):
    - docs://index                  路由器视图(AGENTS.md + docs/index.md 合并)
    - docs://context/project-context 项目上下文基线
    - docs://status                 计算视图:漂移分数 + 断链 + stale 列表(实时算)
  Tools(agent 可调用):
    - age_route(task)               → {doc, skill, reason}
    - age_check_drift(scope?)       → {stale[], orphan[], missing[]}
    - age_propose_doc_update(change)→ {patch, target_doc}
    - age_evolve(task_id)           → 标记 backlog 完成、更新 design、记 ADR

Tools 内部通过 subprocess 调用 cli/age 复用核心逻辑(核心逻辑共享)。

传输:stdio,JSON-RPC 2.0(支持 MCP initialize/resources/list/resources/read
      /tools/list/tools/call)。
"""

# 兼容 Python 3.9+:用字符串注解延迟求值,避免 Path | None 语法(3.10+)
from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Any, Optional

# ---------------------------------------------------------------------------
# 路径定位
# ---------------------------------------------------------------------------

def _plugin_root() -> Path:
    """定位 AGE 插件根目录(含 mcp/server.py 自身)。"""
    # 优先环境变量
    env = os.environ.get("AGE_PLUGIN_ROOT")
    if env and Path(env, "cli", "age").exists():
        return Path(env)
    # 基于本文件位置: mcp/server.py → 上一级即插件根
    here = Path(__file__).resolve().parent
    return here.parent


def _project_root() -> Path:
    """当前项目根(cwd)。AGE 操作的目标项目。

    多客户端兼容检测优先级(CONTRACT §8.11):
      AGE_PROJECT_ROOT → ZCODE_PROJECT_DIR → CLAUDE_PROJECT_DIR → git root → os.getcwd()
    注意:CODEX_HOME / OPENCODE_CONFIG 指向配置目录而非项目目录,不用于项目定位。
    """
    # 1. AGE_PROJECT_ROOT(MCP 专用覆盖,最高优先级)
    env = os.environ.get("AGE_PROJECT_ROOT")
    if env and Path(env).is_dir():
        return Path(env).resolve()
    # 2. ZCODE_PROJECT_DIR(ZCode 宿主注入)
    env = os.environ.get("ZCODE_PROJECT_DIR")
    if env and Path(env).is_dir():
        return Path(env).resolve()
    # 3. CLAUDE_PROJECT_DIR(Claude Code 宿主)
    env = os.environ.get("CLAUDE_PROJECT_DIR")
    if env and Path(env).is_dir():
        return Path(env).resolve()
    # 4. 兼容旧变量名 AGE_PROJECT_DIR(§8.5 A 注入的是 AGE_PROJECT_DIR)
    env = os.environ.get("AGE_PROJECT_DIR")
    if env and Path(env).is_dir():
        return Path(env).resolve()
    # 5. git 仓库根(Codex/OpenCode/裸 shell 通用回退)
    try:
        import subprocess as _sp
        git_root = _sp.run(
            ["git", "rev-parse", "--show-toplevel"],
            capture_output=True, text=True, timeout=5,
        )
        if git_root.returncode == 0 and git_root.stdout.strip():
            gpath = git_root.stdout.strip()
            if Path(gpath).is_dir():
                return Path(gpath).resolve()
    except (FileNotFoundError, OSError, _sp.TimeoutExpired):
        pass
    # 6. 最终回退:当前工作目录(CP-7:若 cwd 不是 git 仓库根,输出 warning)
    #    到达此分支意味着:无 AGE_PROJECT_ROOT/ZCODE_PROJECT_DIR/CLAUDE_PROJECT_DIR
    #    且 git 仓库根检测失败(非 git 仓库,或 git 不可用)。cwd 可能不是项目根,
    #    提醒用户设置 AGE_PROJECT_ROOT 以确保项目根定位准确。
    cwd = Path(os.getcwd()).resolve()
    _warn_cwd_fallback(cwd)
    return cwd


def _warn_cwd_fallback(cwd: Path) -> None:
    """CP-7:项目根检测回退到 cwd 时,若 cwd 不是 git 仓库根,输出 warning 到 stderr。

    到达 _project_root() 的 cwd 回退分支已说明 git 仓库根检测失败,此处进一步
    确认 cwd 确实不是 git 仓库根(二次校验,避免 git 命令瞬时失败导致的误报),
    然后提示用户设置 AGE_PROJECT_ROOT 环境变量。
    """
    # 二次校验:若 cwd 恰好是 git 仓库根(前次检测因瞬时原因失败),不告警
    try:
        proc = subprocess.run(
            ["git", "rev-parse", "--show-toplevel"],
            capture_output=True, text=True, timeout=5,
        )
        if proc.returncode == 0 and proc.stdout.strip():
            git_root = Path(proc.stdout.strip()).resolve()
            if git_root == cwd:
                return  # cwd 就是 git 仓库根,无需告警
    except (FileNotFoundError, OSError, subprocess.TimeoutExpired):
        pass
    # cwd 不是 git 仓库根 → 输出 warning(CONTRACT §8.11 CP-7)
    print(
        "AGE 警告(CP-7): 项目根检测回退到 cwd,可能不准确。"
        "建议设置 AGE_PROJECT_ROOT 环境变量。",
        file=sys.stderr,
    )


def _age_cli() -> str:
    """返回 cli/age(bash 入口)路径字符串(供显示/日志用)。

    Win11 兼容(§8.12):Win11 原生无 bash,cli/age 可能不可执行。
    实际调用经 _age_cli_command() 选择 bash 入口或 PowerShell 入口。
    """
    return str(_plugin_root() / "cli" / "age")


def _is_windows() -> bool:
    """是否运行在 Windows 上(Win11 兼容,§8.12)。

    os.name == 'nt' 覆盖 CPython on Windows;sys.platform 兜底。
    """
    return os.name == "nt" or sys.platform.startswith("win")


def _age_cli_command(args: list[str]) -> list[str]:
    """构造调用 AGE CLI 的命令列表(跨平台)。

    Win11 兼容(§8.12 双层策略):
      - Windows 上优先 cli/age.ps1(PowerShell 原生,不依赖 bash),
        经 pwsh 或 powershell -NoProfile -File 调用。
      - 若 PowerShell 入口不存在但 bash 可用(Git-Bash 层),回退 cli/age + bash。
      - 非 Windows 直接用 cli/age(POSIX shell)。
    """
    root = _plugin_root()
    bash_age = str(root / "cli" / "age")
    ps1_age = str(root / "cli" / "age.ps1")
    if _is_windows():
        # 优先 PowerShell 入口
        if Path(ps1_age).exists():
            # 选 pwsh(PowerShell 7)优先,回退 powershell(Windows PowerShell 5.1)
            for ps_exe in ("pwsh", "powershell"):
                ps_path = shutil.which(ps_exe)
                if ps_path:
                    return [ps_path, "-NoProfile", "-File", ps1_age, *args]
            # 两者都未在 PATH(罕见):尝试 powershell 绝对路径
            return ["powershell", "-NoProfile", "-File", ps1_age, *args]
        # PowerShell 入口不存在:回退 bash(Git-Bash/WSL 层)
        bash_path = shutil.which("bash")
        if bash_path and Path(bash_age).exists():
            return [bash_path, bash_age, *args]
        # 都没有:返回 bash 入口(让 _run_age 报 FileNotFoundError 给出清晰错误)
        return [bash_age, *args]
    # 非 Windows:POSIX shell 直跑 cli/age
    return [bash_age, *args]


# ---------------------------------------------------------------------------
# CLI 调用封装(核心逻辑共享)
# ---------------------------------------------------------------------------

def _run_age(*args: str, cwd: Path | None = None) -> tuple[int, str, str]:
    """调用 cli/age,返回 (returncode, stdout, stderr)。

    设置 AGE_NO_COLOR=1 避免颜色码干扰输出解析。
    Win11 兼容(§8.12):经 _age_cli_command() 选择 bash 入口或 PowerShell 入口。
    """
    env = dict(os.environ)
    env["AGE_NO_COLOR"] = "1"
    env["AGE_PLUGIN_ROOT"] = str(_plugin_root())
    try:
        proc = subprocess.run(
            _age_cli_command(list(args)),
            cwd=str(cwd or _project_root()),
            capture_output=True,
            text=True,
            env=env,
            timeout=60,
        )
        return proc.returncode, proc.stdout, proc.stderr
    except FileNotFoundError:
        return 1, "", f"age CLI 未找到: {_age_cli()}"
    except subprocess.TimeoutExpired:
        return 1, "", "age CLI 调用超时(60s)"


def _run_age_json(*args: str, cwd: Path | None = None) -> Any:
    """调用 cli/age 并解析 JSON 输出;失败时返回 {error}。"""
    rc, out, err = _run_age(*args, cwd=cwd)
    if rc != 0 and not out.strip():
        return {"error": err.strip() or f"age {' '.join(args)} 失败 (exit {rc})"}
    # 尝试从输出中提取首行 JSON(age sync --json 输出纯 JSON)
    for line in out.strip().splitlines():
        line = line.strip()
        if line.startswith("{") or line.startswith("["):
            try:
                return json.loads(line)
            except json.JSONDecodeError:
                continue
    # 整体尝试
    try:
        return json.loads(out)
    except json.JSONDecodeError:
        return {"error": "无法解析 JSON 输出", "raw": out[:500], "stderr": err[:200]}


# ---------------------------------------------------------------------------
# Resources 实现
# ---------------------------------------------------------------------------

def _read_file(path: Path) -> str:
    """安全读取文件;不存在返回占位说明。"""
    try:
        return path.read_text(encoding="utf-8")
    except FileNotFoundError:
        return f"(文件不存在: {path})"
    except OSError as e:
        return f"(读取失败: {e})"


def resource_index() -> str:
    """docs://index — 路由器视图:AGENTS.md + docs/index.md 合并展示。"""
    proj = _project_root()
    parts = []
    agents_md = proj / "AGENTS.md"
    if agents_md.exists():
        parts.append("# === AGENTS.md ===\n\n" + _read_file(agents_md))
    else:
        parts.append("# === AGENTS.md (不存在) ===\n\n运行 `age init` 生成。")
    index_md = proj / "docs" / "index.md"
    if index_md.exists():
        parts.append("\n\n# === docs/index.md ===\n\n" + _read_file(index_md))
    else:
        parts.append("\n\n# === docs/index.md (不存在) ===\n\n运行 `age init` 生成。")
    return "\n".join(parts)


def resource_project_context() -> str:
    """docs://context/project-context — 项目上下文基线文件。"""
    proj = _project_root()
    ctx = proj / "docs" / "context" / "project-context.md"
    return _read_file(ctx)


def resource_status() -> str:
    """docs://status — 实时计算:漂移分数 + 断链 + stale 列表。

    调用 age sync --json + age check 聚合状态视图。
    """
    sync = _run_age_json("sync", "--json")
    # check 退出码:0/1;输出人类可读,这里只取退出码与简要
    rc_check, out_check, _ = _run_age("check")

    stale = sync.get("stale", []) if isinstance(sync, dict) else []
    orphan = sync.get("orphan", []) if isinstance(sync, dict) else []
    missing = sync.get("missing", []) if isinstance(sync, dict) else []
    drift_count = len(stale) + len(orphan) + len(missing)
    # 漂移分数:0-100,0=无漂移,越高越严重(简单线性,封顶100)
    drift_score = min(100, drift_count * 15)

    status = {
        "drift_score": drift_score,
        "drift_count": drift_count,
        "stale": stale,
        "orphan": orphan,
        "missing": missing,
        "check_passed": rc_check == 0,
        "check_exit_code": rc_check,
        "since": sync.get("since", "") if isinstance(sync, dict) else "",
    }
    if "error" in sync:
        status["sync_error"] = sync["error"]

    lines = ["# AGE 项目状态(实时计算)", ""]
    lines.append(f"- 漂移分数: **{drift_score}/100**")
    lines.append(f"- 漂移条数: {drift_count} (stale={len(stale)} orphan={len(orphan)} missing={len(missing)})")
    lines.append(f"- age check: {'通过' if rc_check == 0 else '未通过'} (exit {rc_check})")
    if stale:
        lines.append("")
        lines.append("## Stale(代码变文档未动)")
        for s in stale:
            lines.append(f"- {s}")
    if missing:
        lines.append("")
        lines.append("## Missing(新模块无路由)")
        for m in missing:
            lines.append(f"- {m}")
    lines.append("")
    lines.append("```json")
    lines.append(json.dumps(status, ensure_ascii=False, indent=2))
    lines.append("```")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Tools 实现
# ---------------------------------------------------------------------------

def tool_age_route(task: str) -> dict:
    """age_route(task) → {doc, skill, reason}

    调用 cli/age route <task> 解析输出,提取 owner 文档与技能。
    """
    if not task:
        return {"error": "task 不能为空"}
    rc, out, err = _run_age("route", task, "--explain")
    if rc != 0 and not out.strip():
        return {"doc": [], "skill": "none", "reason": err.strip() or "未命中路由"}

    # 解析 CLI 人类可读输出
    docs: list[str] = []
    skill = "none"
    reason = ""
    section = ""
    for line in out.splitlines():
        stripped = line.strip()
        if stripped.startswith("匹配意图:"):
            reason = stripped.replace("匹配意图:", "").strip()
        elif "应读 (READ 集)" in stripped or "可能回写 (WRITEBACK 集)" in stripped:
            section = "read" if "READ" in stripped else "writeback"
        elif stripped.startswith("- ") and section == "read":
            docs.append(stripped[2:].strip())
        elif stripped.startswith("- ") and "建议技能" in section:
            skill = stripped[2:].strip()
        elif "建议技能" in stripped:
            section = "skill"
    return {"doc": docs, "skill": skill, "reason": reason or "命中路由"}


def tool_age_check_drift(scope: str = "full") -> dict:
    """age_check_drift(scope?) → {stale[], orphan[], missing[]}

    调用 cli/age sync --json 获取漂移数据。scope 参数保留以兼容契约,
    当前直接返回 sync 的三类漂移(full 等价)。
    """
    result = _run_age_json("sync", "--json")
    if "error" in result:
        return result
    return {
        "stale": result.get("stale", []),
        "orphan": result.get("orphan", []),
        "missing": result.get("missing", []),
        "scope": scope,
    }


def tool_age_propose_doc_update(change: str) -> dict:
    """age_propose_doc_update(change) → {patch, target_doc}

    根据 change 描述,路由到对应 owner 文档,生成更新建议补丁。
    change 形如:"修改了 src/api/index.ts 的 hello 函数签名"
    """
    if not change:
        return {"error": "change 不能为空"}
    # 先路由:change 作为任务描述,确定 target_doc
    route = tool_age_route(change)
    target_docs = route.get("doc", [])
    target_doc = target_docs[0] if target_docs else "docs/architecture/overview.md"

    # 生成补丁建议(markdown diff 片段)
    patch_lines = [
        f"<!-- AGE 提议的文档更新,针对变更: {change} -->",
        f"## 待更新: {target_doc}",
        "",
        "### 变更摘要",
        f"- {change}",
        "",
        "### 建议补充内容",
        "- [ ] 更新接口/数据结构描述",
        "- [ ] 更新调用方说明",
        "- [ ] 如涉及架构,补充 ADR 到 docs/audits/",
        "",
        "> 此补丁由 age_propose_doc_update 生成,需人工审核后合并到 owner 文档。",
    ]
    return {
        "patch": "\n".join(patch_lines),
        "target_doc": target_doc,
        "route_reason": route.get("reason", ""),
    }


def tool_age_evolve(task_id: str) -> dict:
    """age_evolve(task_id) → 标记 backlog 完成、更新 design、记 ADR

    在 docs/backlog/ 标记任务完成,在 docs/audits/ 记录 ADR,在 docs/logs/ 记日志。
    不直接调 CLI(无对应子命令),由 server 直接写文件。
    """
    if not task_id:
        return {"error": "task_id 不能为空"}
    proj = _project_root()
    actions: list[str] = []

    # 1. 标记 backlog 完成:在 backlog/ 找含 task_id 的文件,追加完成标记
    backlog_dir = proj / "docs" / "backlog"
    marked = False
    if backlog_dir.exists():
        for bf in backlog_dir.glob("*.md"):
            try:
                content = bf.read_text(encoding="utf-8")
            except OSError:
                continue
            if task_id in content:
                if "状态: 完成" not in content and "status: done" not in content.lower():
                    with bf.open("a", encoding="utf-8") as fh:
                        fh.write(f"\n\n---\n**状态: 完成** (age_evolve 标记于 {task_id})\n")
                    actions.append(f"标记 backlog 完成于 {bf.name}")
                marked = True
                break
    if not marked:
        actions.append(f"backlog 未找到 task_id={task_id}(跳过标记)")

    # 2. 记 ADR 到 docs/audits/
    audits_dir = proj / "docs" / "audits"
    audits_dir.mkdir(parents=True, exist_ok=True)
    adr_path = audits_dir / f"adr-{task_id}.md"
    adr_path.write_text(
        f"# ADR: {task_id}\n\n"
        f"> 由 age_evolve 自动生成。task_id={task_id}\n\n"
        "## 决策\n\n(待补充)\n\n## 状态\n\n已演进(完成)\n",
        encoding="utf-8",
    )
    actions.append(f"记录 ADR: docs/audits/adr-{task_id}.md")

    # 3. 记日志到 docs/logs/
    logs_dir = proj / "docs" / "logs"
    logs_dir.mkdir(parents=True, exist_ok=True)
    import time
    log_path = logs_dir / f"evolve-{task_id}.md"
    log_path.write_text(
        f"# 演进日志: {task_id}\n\n"
        f"- 时间: {time.strftime('%Y-%m-%dT%H:%M:%S%z')}\n"
        f"- 动作: age_evolve\n"
        f"- 详情: {actions}\n",
        encoding="utf-8",
    )
    actions.append(f"记录日志: docs/logs/evolve-{task_id}.md")

    return {"task_id": task_id, "actions": actions, "status": "evolved"}


def tool_age_activate(project_path: str = "") -> dict:
    """age_activate(project_path?) → {activated, initialized, project}

    激活 AGE 插件:检测目标项目是否已初始化,未初始化则自动 age init。
    供 agent 在会话内主动激活 AGE(对应 use-AGE 技能语义)。

    project_path 默认为当前项目根(AGE_PROJECT_ROOT/cwd)。
    内部调用 cli/age use --json,返回其 JSON 结果。
    """
    cwd: Path | None = None
    resolved_project = project_path
    if project_path:
        try:
            cwd = Path(project_path).resolve()
            resolved_project = str(cwd)
        except OSError:
            return {"error": f"无效的 project_path: {project_path}"}
    else:
        resolved_project = str(_project_root())

    result = _run_age_json("use", "--json", cwd=cwd)
    if isinstance(result, dict) and "error" in result:
        return result
    # age use --json 输出 {"activated":bool,"initialized":bool,"project":"..."}
    if isinstance(result, dict):
        # 确保 project 字段反映实际解析路径(若 CLI 未回填则用 resolved_project)
        if not result.get("project"):
            result["project"] = resolved_project
        return result
    return {"error": "无法解析 age use --json 输出", "raw": str(result)[:500]}


# ---------------------------------------------------------------------------
# MCP 资源/工具注册表
# ---------------------------------------------------------------------------

RESOURCES = [
    {
        "uri": "docs://index",
        "name": "index",
        "description": "文档路由器视图(AGENTS.md + docs/index.md 合并)",
        "mimeType": "text/markdown",
    },
    {
        "uri": "docs://context/project-context",
        "name": "project-context",
        "description": "项目上下文基线(docs/context/project-context.md)",
        "mimeType": "text/markdown",
    },
    {
        "uri": "docs://status",
        "name": "status",
        "description": "实时计算:漂移分数 + 断链 + stale 列表",
        "mimeType": "text/markdown",
    },
]

TOOLS = [
    {
        "name": "age_route",
        "description": "按 docs/index.md 路由任务到 owner 文档与技能。返回 {doc, skill, reason}。",
        "inputSchema": {
            "type": "object",
            "properties": {
                "task": {"type": "string", "description": "任务描述(自然语言)"},
            },
            "required": ["task"],
        },
    },
    {
        "name": "age_check_drift",
        "description": "检测代码-文档漂移,返回 {stale[], orphan[], missing[]}。",
        "inputSchema": {
            "type": "object",
            "properties": {
                "scope": {
                    "type": "string",
                    "description": "范围: full(默认)",
                    "default": "full",
                },
            },
        },
    },
    {
        "name": "age_propose_doc_update",
        "description": "根据代码变更提议文档更新补丁,返回 {patch, target_doc}。",
        "inputSchema": {
            "type": "object",
            "properties": {
                "change": {
                    "type": "string",
                    "description": "变更描述(如'修改了 src/api 的接口')",
                },
            },
            "required": ["change"],
        },
    },
    {
        "name": "age_evolve",
        "description": "标记 backlog 完成、更新 design、记 ADR 与日志。",
        "inputSchema": {
            "type": "object",
            "properties": {
                "task_id": {"type": "string", "description": "任务/backlog ID"},
            },
            "required": ["task_id"],
        },
    },
    {
        "name": "age_activate",
        "description": "激活 AGE 插件:检测项目是否已初始化,未初始化则自动 age init。返回 {activated, initialized, project}。",
        "inputSchema": {
            "type": "object",
            "properties": {
                "project_path": {
                    "type": "string",
                    "description": "目标项目路径(默认当前项目根 cwd)",
                },
            },
        },
    },
]

RESOURCE_READERS = {
    "docs://index": resource_index,
    "docs://context/project-context": resource_project_context,
    "docs://status": resource_status,
}

TOOL_HANDLERS = {
    "age_route": lambda args: tool_age_route(args.get("task", "")),
    "age_check_drift": lambda args: tool_age_check_drift(args.get("scope", "full")),
    "age_propose_doc_update": lambda args: tool_age_propose_doc_update(args.get("change", "")),
    "age_evolve": lambda args: tool_age_evolve(args.get("task_id", "")),
    "age_activate": lambda args: tool_age_activate(args.get("project_path", "")),
}


# ---------------------------------------------------------------------------
# JSON-RPC 2.0 over stdio
# ---------------------------------------------------------------------------

def _send(msg: dict) -> None:
    """写一行 JSON-RPC 消息到 stdout。"""
    sys.stdout.write(json.dumps(msg, ensure_ascii=False) + "\n")
    sys.stdout.flush()


def _result(req_id: Any, result: Any) -> None:
    _send({"jsonrpc": "2.0", "id": req_id, "result": result})


def _error(req_id: Any, code: int, message: str, data: Any = None) -> None:
    err = {"code": code, "message": message}
    if data is not None:
        err["data"] = data
    _send({"jsonrpc": "2.0", "id": req_id, "error": err})


def _read_message() -> dict | None:
    """从 stdin 读一行 JSON。返回 None 表示 EOF。"""
    line = sys.stdin.readline()
    if not line:
        return None
    line = line.strip()
    if not line:
        return None
    try:
        return json.loads(line)
    except json.JSONDecodeError as e:
        _send({"jsonrpc": "2.0", "id": None, "error": {"code": -32700, "message": f"解析错误: {e}"}})
        return None


def handle_request(msg: dict) -> None:
    """处理单个 JSON-RPC 请求。"""
    method = msg.get("method")
    req_id = msg.get("id")
    params = msg.get("params", {}) or {}

    # 通知(无 id)不返回
    if method == "notifications/initialized":
        return

    if method == "initialize":
        _result(req_id, {
            "protocolVersion": "2024-11-05",
            "serverInfo": {"name": "age-mcp", "version": "0.1.0"},
            "capabilities": {
                "resources": {"listChanged": False},
                "tools": {"listChanged": False},
            },
        })
        return

    if method == "ping":
        _result(req_id, {})
        return

    if method == "resources/list":
        _result(req_id, {"resources": RESOURCES})
        return

    if method == "resources/read":
        uri = params.get("uri", "")
        reader = RESOURCE_READERS.get(uri)
        if reader is None:
            _error(req_id, -32602, f"未知资源 URI: {uri}")
            return
        try:
            content = reader()
        except Exception as e:  # noqa: BLE001
            _error(req_id, -32603, f"读取资源失败: {e}")
            return
        _result(req_id, {
            "contents": [
                {
                    "uri": uri,
                    "mimeType": "text/markdown",
                    "text": content,
                }
            ]
        })
        return

    if method == "tools/list":
        _result(req_id, {"tools": TOOLS})
        return

    if method == "tools/call":
        name = params.get("name", "")
        args = params.get("arguments", {}) or {}
        handler = TOOL_HANDLERS.get(name)
        if handler is None:
            _error(req_id, -32601, f"未知工具: {name}")
            return
        try:
            result = handler(args)
        except Exception as e:  # noqa: BLE001
            _error(req_id, -32603, f"工具执行失败: {e}")
            return
        # 工具结果按 MCP 规范封装为 content 数组
        _result(req_id, {
            "content": [
                {"type": "text", "text": json.dumps(result, ensure_ascii=False, indent=2)}
            ],
            "isError": bool(isinstance(result, dict) and "error" in result),
        })
        return

    # 未实现的方法
    if req_id is not None:
        _error(req_id, -32601, f"未实现的方法: {method}")


def main() -> int:
    """主循环:逐行读取 stdin 的 JSON-RPC 消息并处理。"""
    # stderr 日志(不干扰 stdout 的 JSON-RPC)
    print("AGE MCP server 启动 (stdio)", file=sys.stderr)
    while True:
        msg = _read_message()
        if msg is None:
            break  # EOF
        try:
            handle_request(msg)
        except Exception as e:  # noqa: BLE001
            req_id = msg.get("id") if isinstance(msg, dict) else None
            _error(req_id, -32603, f"内部错误: {e}")
    return 0


if __name__ == "__main__":
    sys.exit(main())

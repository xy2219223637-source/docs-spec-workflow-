# Routing Rules — AGE 路由决策表

> 这是 `route` 子流程的核心。本表是**默认路由**:当目标仓库的 `docs/index.md` 对某输入类型沉默时,回退到此表。仓库自己的路由表永远优先。
>
> 路由产出两样东西:① **READ 集**(任务开始前必读的 owner 文档);② **WRITEBACK 集**(任务结束后允许回写的 owner 文档)。WRITEBACK 集 ⫦ READ 集——你可以读得比写得宽,但不能写你没读过的。

## 输入类型分类

所有进入 AGE 的任务,先归入下列五种输入类型之一。归类的判断层是 prose,不要试图用正则硬匹配。

| 输入类型 | 识别信号 | 谁是 source of truth |
|---|---|---|
| **需求 (requirement)** | "要做 X"、"用户需要"、"加个功能"、"修个 bug 期望" | `docs/requirements/` |
| **设计 (design)** | "怎么实现"、"接口长什么样"、"数据结构"、"流程" | `docs/design/` |
| **架构 (architecture)** | "模块边界"、"依赖方向"、"技术选型"、"分层" | `docs/architecture/` |
| **上下文 (context)** | "这个项目是干嘛的"、"约定是什么"、"现状" | `docs/context/` |
| **审计 (audit)** | "查一下漂移"、"对不对得上"、"baseline 齐不齐" | 无 owner 文档;审计**产出** `docs/audits/` |

## 决策表

| 输入类型 | READ 集(任务前读) | WRITEBACK 集(任务后写) | 默认技能路由 | 备注 |
|---|---|---|---|---|
| **需求** | `docs/context/project-context.md`, `docs/context/source-of-truth-and-precedence.md`, `docs/backlog/`, `docs/requirements/` | `docs/backlog/`, `docs/requirements/`, `docs/plans/`(若进入计划) | 项目专属需求技能;无则 `Skill: none` | 先确认 backlog 是否已记录此需求;重复需求去重而非新建 |
| **设计** | `docs/context/conventions.md`, `docs/architecture/`, `docs/design/`, 相关 `docs/requirements/` 条目 | `docs/design/`, `docs/plans/`(若产出计划), `docs/architecture/`(仅当涉及契约变更) | 项目专属设计/建模技能;无则 `Skill: none` | 设计变更若影响架构契约,**必须**把 architecture 加入 WRITEBACK 集 |
| **架构** | `docs/context/codebase-map.md`, `docs/context/conventions.md`, `docs/architecture/`, `docs/design/`(现有契约) | `docs/architecture/`, `docs/context/codebase-map.md`(若边界变化), `docs/audits/`(若为架构决策记录 ADR) | 项目专属架构技能;无则 `Skill: none` | 架构变更**必须**产出 ADR 入 `docs/audits/` 或专门的 ADR 目录;不允许"沉默式重构" |
| **上下文** | `docs/context/` 全部五个文件, `docs/index.md` | `docs/context/` 中被实际更新的文件, `docs/logs/`(若记录会话) | `Skill: none`(上下文查询本身不需要技能) | 上下文查询通常只读不写;若发现上下文文档过期,**不在此处修**,而是开一个需求/设计任务 |
| **审计** | `docs/index.md`, `docs/context/source-of-truth-and-precedence.md`, 全部 owner 基线目录, `docs/audits/`(历史) | `docs/audits/`(本次审计报告), `docs/bugs/`(若发现回归) | `age check` / `age audit` / `age ci`(机械层);判断层 `Skill: none` | 审计**不直接改** owner 文档;审计产出的是报告,修复走需求/设计流程 |

## 默认技能路由表(按 project_kind 兜底)

当仓库没有自己的技能路由表,且输入类型未指定项目专属技能时,按 `userConfig.project_kind` 兜底:

| project_kind | 需求 | 设计 | 架构 | 备注 |
|---|---|---|---|---|
| `web` | none | none | none | web 项目通常无内建模建技能;走 owner 文档 |
| `mobile` | none | none | none | 平台模块边界由 architecture owner 文档承载 |
| `cli` | none | none | none | 命令面由 design owner 文档承载 |
| `library` | none | none | none | 公共 API 面由 design + architecture 共同承载 |
| `data` | none | none | none | 管线/DAG 由 architecture 承载 |
| `other` | none | none | none | 最小骨架,全部走 owner 文档 |

> "none" 不代表"不路由",而是"无项目专属技能,直接路由到 owner 文档"。在计划的对应阶段记 `Skill: none`。

## 路由失败的处理

`age route <task>` 返回未命中(退出码 1)时,按下列顺序排查:

1. **目标仓库未装 AGE?** → 走 `age-init`。无 `docs/index.md` 则路由无锚点。
2. **`docs/index.md` 路由表有死链?** → `age check` 会报;先修路由表再路由。
3. **输入类型无法归类?** → 这是 prose 判断失败。要求用户澄清是需求/设计/架构/上下文/审计中的哪一种;不要强行归类。
4. **WRITEBACK 集为空?** → 纯查询任务(如上下文查询),合法;但要在计划里显式标 `Writeback: none`,避免 doc-sync 误报。

## 与 MCP / CLI 的对应

- 决策表本身是 prose,但 `age route <task> --explain` 会输出 `{doc, skill, reason}` 结构化结果,其 `doc` 即 READ 集、`skill` 即技能路由、`reason` 引用本表的某一行。
- MCP `age_route(task)` 返回同结构;agent 拿到后**仍需自己读 READ 集文档**,不要把 MCP 返回当作已读。
- `age check --strict` 会校验 `docs/index.md` 路由表与本表的兼容性:仓库路由表指向的 owner 文档必须在 `baseline-schema.md` 定义的五个基线内。

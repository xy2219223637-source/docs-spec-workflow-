# Sync Checklist — 任务前后同步清单

> 本清单是 `route`(任务前)与 `doc-sync`(任务后)的执行体。机械步骤 shell out 到 CLI,判断步骤保持 prose。每个开发任务必须跑完整闭环:**route → 执行 → doc-sync → (closure) audit**。

## 任务前:route 阶段(必做,在写任何代码之前)

### 1. 归类输入类型
判断任务是 需求/设计/架构/上下文/审计 中的哪一种(见 `routing-rules.md`)。无法归类→要求用户澄清,不要硬猜。

### 2. 读 READ 集
按 `routing-rules.md` 决策表读对应 owner 文档。机械替代:`age route <task> --explain` 输出 READ 集,但**仍需自己读**——MCP/CLI 返回的是路径,不是内容。

### 3. 标记 WRITEBACK 集
从决策表取出 WRITEBACK 集,记录到本次任务的计划里(显式列出将回写的 owner 文档)。纯查询任务标 `Writeback: none`。

### 4. 记技能选择
若进入计划阶段,每个阶段记 `Skill: <name>` 或 `Skill: none`(见 AGENTS.md)。AGE 是选择器,这一步记录的是"AGE 给本阶段选了哪个项目技能"。

### 5. 冲突检查
READ 集文档若与任务目标冲突:owner 文档优先。要么先更新 owner 文档(开一个独立任务),要么修正任务目标。**不允许沉默地绕过 owner 文档。**

**前置检查命令:**
```bash
age doctor              # 环境就绪?
age route "<task>" --explain   # 输出 READ 集 + WRITEBACK 集 + 技能路由
```

## 任务后:doc-sync 阶段(必做,在提交/交接之前)

### 1. 取代码 delta
```bash
age sync --since <ref>   # ref = 任务开始的 git ref,如 HEAD~1 或分支基点
```
输出 `{stale[], orphan[], missing[]}`:
- `stale` = owner 文档描述的接口/结构在代码里已变,文档过期
- `orphan` = 代码里有公共面,但无 owner 文档承载
- `missing` = WRITEBACK 集里有文档该更新但还没动

### 2. 对照 WRITEBACK 集回写
**只**回写 WRITEBACK 集里的 owner 文档。若发现需要回写 WRITEBACK 集之外的文档:
- 小修补(错别字、链接)→ 直接改,记入日志
- 实质变更(新接口、新模块边界)→ **不要在此任务里改**,新开一个需求/设计任务。这是为了防止任务范围蔓延。

### 3. 更新 backlog / requirements
若任务完成了一个 backlog 条目:`age evolve <task_id>`(标记完成 + 联动 design + 记 ADR 若涉及架构)。
若任务引入了新需求:在 `docs/requirements/` 新增条目,**不要**只写在聊天/计划里。

### 4. 记日志
`docs/logs/`(若存在):记本次任务的 READ 集、WRITEBACK 集、实际改动、技能选择记录。日志是 source-of-truth 链的第三级,低于 owner 文档和计划。

### 5. 跑验证
```bash
<validate_cmd>          # 若 userConfig.validate_cmd 非空
age check               # 静态一致性:路由死链/基线齐全/AGENTS 引用
```
`validate_cmd` 为空时跳过验证命令,但 `age check` 仍要跑。

## 何时进 plans/

进 `docs/plans/` 的信号(满足任一即应落计划,不要只留在聊天):
- 任务跨多个 owner 文档(同时动 requirements + design + architecture)
- 任务预计 ≥ 3 个执行阶段
- 任务涉及架构变更(必先进 plan,再进 ADR)
- 用户显式要求"先出方案"

计划文件最小内容:目标、READ 集、WRITEBACK 集、分阶段步骤(每阶段 `Skill:` 记录)、验收标准、关联需求/backlog ID。

## 何时进 audits/

进 `docs/audits/` 的信号:
- 架构变更(必须配 ADR)
- `age audit` 显式跑且发现违规
- 收尾审计 `age audit --scope closure` 的报告(每次任务收尾都产一份简报,违规才详写)
- 周期性全量审计 `age audit --scope full`(建议每周或每个里程碑)

审计报告最小内容:审计范围、基线齐全矩阵、漂移列表(stale/orphan/missing)、违规项、修复建议(指向需求/设计任务,不直接改 owner 文档)。

## 何时进 bugs/

进 `docs/bugs/` 的信号:
- 验证命令失败且属于复杂回归(非一次性可修)
- `age audit` 发现代码与需求验收标准系统性不符
简单 bug 直接修 + 记日志,不进 `docs/bugs/`。

## 闭环校验矩阵

| 阶段 | 必跑命令 | 必产产物 |
|---|---|---|
| route | `age route --explain` | 计划(若进 plans)含 READ/WRITEBACK 集 + 技能记录 |
| 执行 | (项目测试) | 代码改动 |
| doc-sync | `age sync --since <ref>` | 更新后的 owner 文档 + 日志 |
| closure audit | `age audit --scope closure`(+ `validate_cmd`) | 审计简报(违规才详写) |

**未跑 closure audit 的任务不算完成。** 若 closure audit 失败,回 doc-sync 修;若 doc-sync 无法修(如 owner 文档需大改),新开任务,本任务标 `已阻塞` 并在日志说明。

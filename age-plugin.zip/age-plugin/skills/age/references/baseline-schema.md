# Baseline Schema — 五个 owner 基线

> AGE 的"基线"= 一组必须存在、内容可被 `age check` 校验的 owner 文档。`age init` 脚手架生成它们,`age check --strict` 校验它们齐全且符合最小 schema,`age audit` 检测它们与代码的漂移。
>
> 五个基线对应五个 owner 目录。每个目录有 **README**(职责说明,由过程计划 agent 维护)和 **内容文件**。本文件定义的是内容文件的最小 schema——即"至少要有什么"。

## 1. `docs/context/` — 上下文基线(强制,不可缺)

**Owner:** 项目负责人 / 全员共识。**变更频率:** 低(月级)。**source-of-truth 等级:** 最高(优先于计划/日志/聊天)。

强制文件(五个,`age init` 全部生成):

| 文件 | 最小内容 | 必填字段 |
|---|---|---|
| `README.md` | 目录说明:context 是什么、谁更新、何时更新 | 无内容校验,但必须存在 |
| `project-context.md` | 项目是什么、为谁、当前阶段、验证命令 | `## 验证命令` 段含 `{validate_cmd}` 占位 |
| `ai-autonomy-policy.md` | AI 可自主做什么、禁止做什么、何时必须问人 | `## 自主范围` / `## 禁止行为` 两个段 |
| `codebase-map.md` | 模块/目录地图、入口点、依赖方向 | `## 模块地图` 段含至少一条模块条目 |
| `source-of-truth-and-precedence.md` | 事实来源优先级链 | `## 优先级` 段含 `owner 文档 > 计划 > 日志 > 聊天` |
| `conventions.md` | 命名/提交/测试/分支约定 | `## 约定` 段 |

> `age check` 校验:五个文件全部存在;`project-context.md` 含验证命令段;`source-of-truth-and-precedence.md` 含优先级链(允许措辞不同,但必须出现 owner/计划/日志/聊天四个词)。

## 2. `docs/backlog/` — 待办基线(条件强制)

**Owner:** 产品/负责人。**变更频率:** 中(周级)。**强制条件:** `userConfig.require_backlog == true`(默认)。设为 false 时 `age check` 不报缺,但若目录存在则仍参与路由。

最小内容:

| 文件 | 最小内容 | 必填字段 |
|---|---|---|
| `README.md` | backlog 格式说明:条目结构、状态流转 | 状态枚举:`未开始`/`进行中`/`已完成`/`已取消` |
| 条目文件(可多个,如 `backlog.md` 单文件或 `*.md` 多文件) | 每条:`ID`、`标题`、`状态`、`来源`(需求/bug/技术债)、`简述` | 每条必须有唯一 ID 和状态 |

> `age check` 校验(require_backlog=true 时):目录存在、README 存在、每条目有 ID 与状态字段。`age evolve(task_id)` 用于把条目标记完成并联动 design 更新。

## 3. `docs/requirements/` — 需求基线(强制)

**Owner:** 产品/负责人。**变更频率:** 中(周级)。**source-of-truth 等级:** 高(需求变更必须落此)。

最小内容:

| 文件 | 最小内容 | 必填字段 |
|---|---|---|
| `README.md` | 需求文档格式:用例/验收标准/优先级 | 无 |
| 需求条目(可单文件 `requirements.md` 或多文件) | 每条:`ID`、`标题`、`用户故事`/`验收标准`、`优先级`、`状态`、`关联 backlog` | ID + 验收标准 + 状态 |

> `age check` 校验:目录与 README 存在。需求条目的验收标准段**必须可被验证命令覆盖**——若 `validate_cmd` 非空,审计时尝试关联需求验收标准与测试;无法关联记为 stale(警告,不 fail)。

## 4. `docs/design/` — 设计基线(强制)

**Owner:** 技术负责人。**变更频率:** 中(周级)。**source-of-truth 等级:** 高(接口/数据结构变更必须落此)。

最小内容:

| 文件 | 最小内容 | 必填字段 |
|---|---|---|
| `README.md` | 设计文档格式:接口契约/数据模型/流程图/决策 | 无 |
| 设计文档(可 `design.md` 单文件或按模块拆) | 每个设计单元:`接口签名`/`数据结构`/`关键流程`、`关联需求 ID`、`状态`(草案/已定/已弃) | 接口签名段 + 关联需求 ID |

> `age check` 校验:目录与 README 存在。`age sync` 检测代码接口与 design 文档签名漂移:若代码新增/删除公共接口而 design 未更新,记为 `missing`/`stale`。

## 5. `docs/architecture/` — 架构基线(强制)

**Owner:** 架构师/技术负责人。**变更频率:** 低(月级,但变更影响大)。**source-of-truth 等级:** 最高(模块边界/依赖方向由此定)。

最小内容:

| 文件 | 最小内容 | 必填字段 |
|---|---|---|
| `README.md` | 架构文档格式:分层图/依赖规则/技术选型/ADR 索引 | 无 |
| 架构文档(可 `architecture.md` 单文件或按视图拆) | `分层与模块边界`、`依赖方向规则`、`技术栈与版本`、`ADR 索引`(指向 `docs/audits/` 或独立 ADR 目录) | 依赖方向规则段 + ADR 索引段 |

> `age check` 校验:目录与 README 存在;架构文档含依赖方向规则段。架构变更**必须**有对应 ADR——`age audit --scope closure` 会检查:若 architecture 文档在本次任务中被改,而 `docs/audits/` 无对应 ADR,记为违规(退出码 1)。

## 基线齐全校验矩阵(`age check --strict` 用)

| 基线 | 强制? | 缺失行为 |
|---|---|---|
| context(5 文件) | 强制 | fail |
| backlog | 条件强制(require_backlog) | require_backlog=true 缺失→fail;false 缺失→pass |
| requirements | 强制 | fail |
| design | 强制 | fail |
| architecture | 强制 | fail |

## 与目录 README 的边界

各 owner 目录的 `README.md`(格式说明、谁维护、流转规则)由**过程计划 agent** 维护(见 CONTRACT.md §2)。本文件只定义**内容文件的最小 schema**,不定义 README 内容。`age init` 生成 README 骨架时引用本 schema;若 README 与本 schema 冲突,以本 schema 为准(README 是给人看的说明,schema 是给 check 用的契约)。

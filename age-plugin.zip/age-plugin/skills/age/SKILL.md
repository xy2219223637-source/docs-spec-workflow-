---
name: age
description: Attractor-Guided Engineering meta-skill — the method selector that orchestrates documentation discipline around a project's owner docs. Use on four occasions (1) project initialization or scaffolding a new repo (age-init), (2) the START of any development task to route it to the right owner docs and skills and to mark the writeback set (route), (3) the END of any development task to sync docs against code (doc-sync), and (4) periodic or explicit audit of doc/code drift and baseline completeness (audit). AGE decides WHICH project skill applies and WHICH owner docs to read/write; it does NOT replace project-specific skills, it routes to them. Mechanical work shells out to the `age` CLI; judgment stays in prose here. Once activated by the `use-AGE` skill (triggered when a user says 开启AGE / 启动AGE / 用AGE / 使用AGE / enable AGE / start AGE / use AGE / activate AGE / turn on AGE, etc.), this meta-skill takes over all subsequent routing and orchestration for the session — `use-AGE` is the entry/activator, `age` is the brain that owns the four sub-flows below.
---

# AGE — Attractor-Guided Engineering

AGE is a **method selector**, not a method itself. Every project already has (or should have) owner documents — the small set of files whose owners are the source of truth for requirements, design, architecture, context, and backlog. AGE's only job is to make sure the agent reads the right owner docs before a task and writes back to the right owner docs after, then audits that the two stay consistent. This skill **orchestrates** that loop; it does **not** substitute for the project's own routing rules in `docs/index.md`.

## The four sub-flows AGE orchestrates

AGE runs one of four sub-flows depending on when it is invoked. Each has a clear trigger and a clear hand-off.

| Sub-flow | Trigger | What it does | Mechanical layer |
|---|---|---|---|
| `age-init` | New repo, or copying AGE templates into a repo; `SessionStart` (first time); `/age-init` | Scaffold `docs/` skeleton, render AGENTS.md + context from Day-0 fields, snapshot baseline | `age init`, `age baseline`, `age doctor` |
| `route` | The START of every development task; before writing code; `/age-route <task>` | Decide which owner docs to READ and which to mark for WRITEBACK; record the chosen skill per plan phase | `age route <task> [--explain]` |
| `doc-sync` | The END of every development task; after code lands; `Stop` (non-closure) | Diff code changes against the marked writeback set; update owner docs; log the change | `age sync`, `age evolve` |
| `audit` | Periodic; pre-commit; CI; explicit `/age-audit`; `Stop` (closure) | Detect drift (stale/orphan/missing), baseline completeness, route dead-links, AGENTS.md reference resolution | `age check`, `age audit`, `age ci` |

**Boundary:** `route` and `audit` are judgment layers — they live as prose decisions here and in `references/routing-rules.md`. `age-init`, `doc-sync`'s mechanical steps, and the deterministic parts of `audit` are the CLI's job. **When in doubt, shell out to the CLI for the mechanical part and keep the decision in prose.** Do not reimplement `age sync` or `age check` by hand.

## How to decide which sub-flow to run

1. **Is this a brand-new repo, or is AGE not yet installed in it?** → `age-init`. Confirm with `age doctor` first if the environment is uncertain.
2. **Am I about to start a development task (write/edit code, design a feature, fix a bug)?** → `route` first, *before* touching code. Route decides the read-set and the writeback-set.
3. **Did I just finish a development task (code changed, about to commit or hand off)?** → `doc-sync`. Compare code delta to the writeback-set and update owner docs.
4. **Am I being asked to audit, is it pre-commit/CI, or is the task fully closing out?** → `audit`. Run `age check` (static) and/or `age audit --scope closure` (closure gate) or `age ci` (non-interactive).

If two apply (e.g. closing a task = `doc-sync` then `audit`), run them in the order above: route → doc-sync → audit.

## The non-negotiables (apply to every sub-flow)

- **Source-of-truth precedence:** owner docs > plans > logs > chat. Never let a chat decision silently override an owner doc; if chat conflicts with an owner doc, the owner doc wins until it is explicitly updated. See `templates/repo/docs/context/source-of-truth-and-precedence.md`.
- **Read before write.** Every task starts by reading the owner docs that `route` identified. Skipping the read is the #1 cause of drift.
- **Mark the writeback set at route time, not at sync time.** Route output includes the set of owner docs the task *may* update. doc-sync only writes to that set; surprises go to a discussion, not a silent edit.
- **One skill per plan phase.** When producing a plan, record `Skill: <name>` or `Skill: none` for each phase. AGE itself is the orchestrator, not the per-phase skill — but AGE is the one that selected that skill, so the record is how AGE stays auditable. See `templates/repo/AGENTS.md`.
- **Closure gate.** A task is not done until `age audit --scope closure` passes: owner docs updated, validation command green (or empty), writeback set reconciled.

## Progressive disclosure — where the details live

This file is the entry point. The decision tables and schemas are in `references/`:

- **`references/routing-rules.md`** — the decision table: input type (requirement / design / architecture / context / audit) → which owner docs to READ → which to mark for WRITEBACK. This is the heart of the `route` sub-flow.
- **`references/baseline-schema.md`** — the minimal content schema for the five owner baselines: `context/`, `backlog/`, `requirements/`, `design/`, `architecture/`. `age check` validates against this; `age-init` scaffolds it.
- **`references/sync-checklist.md`** — what to read before a task, what to write after, and when something graduates into `plans/` or `audits/` rather than living in chat.

Read the reference that matches the sub-flow you are running. Do not load all three at once unless you are doing a full audit.

## Interaction with the CLI and MCP

- **CLI (`age`)** is the deterministic core. Prefer it for: init, sync (drift detection), check (static consistency), audit (closure), ci (non-interactive), baseline. The CLI is what runs in CI and headless; if your prose decision can be expressed as a CLI call, use the CLI.
- **MCP server (`age-mcp`)** exposes the same decisions as agent-callable tools (`age_route`, `age_check_drift`, `age_propose_doc_update`, `age_evolve`) and read-only resources (`docs://index`, `docs://context/project-context`, `docs://status`). When you are operating as an agent with MCP available, prefer the MCP tools — they return structured output and keep the judgment in prose. The CLI is the fallback when MCP is absent.
- **Hooks** (`SessionStart`, `PostToolUse`, `Stop`) call back into this skill's sub-flows automatically. You do not need to manually trigger route on every edit — the `PostToolUse` hook fires `age sync` and surfaces drift. But you DO need to run `route` consciously at task start; the hook only detects drift after the fact.

## What AGE is NOT

- AGE is not a project skill. It will not tell you *how* to build a web frontend or a CLI; it tells you which project skill/owner doc owns that decision. If no project skill exists, AGE records `Skill: none` and routes to the owner doc directly.
- AGE is not a replacement for `docs/index.md`. The project's own router is the first-class citizen; AGE's `references/routing-rules.md` is the fallback when the project router is silent.
- AGE is not a ticket system. `docs/backlog` is an owner doc, not a Kanban board; AGE keeps it consistent, it does not manage sprints.
- AGE is not optional once installed. If AGE templates are in the repo, the closure gate applies. To opt out, remove AGENTS.md's AGE section or set `require_backlog: false` and leave `validate_cmd` empty.

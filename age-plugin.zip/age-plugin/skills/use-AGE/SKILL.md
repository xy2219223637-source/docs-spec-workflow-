---
name: use-AGE
description: AGE 插件的入口激活器。当用户想要开启 / 启动 / 使用 / 激活 AGE(Attractor-Guided Engineering)时触发——覆盖开启AGE、启动AGE、用AGE、使用AGE、激活AGE、启用吸引子工程、开始AGE、enable AGE、start AGE、use AGE、activate AGE、turn on AGE、init AGE、帮我设置AGE、这个项目用AGE吧、装一下AGE 等中英文语义变体。本技能检测当前项目是否已初始化 AGE,未初始化则自动执行 age init 完成脚手架,已初始化则加载 age 元 skill 接管后续路由。激活后控制权交给 age 元 skill,本技能不再参与。
---

# use-AGE — AGE 激活入口

本技能是 AGE 的**入口/激活器**,不是编排大脑。它的唯一职责:确认 AGE 是否已在当前项目就绪,就绪则把控制权交给 `age` 元 skill;未就绪则自动初始化后再交。**激活后的一切路由、回写、审计由 `age` 元 skill 负责,本技能不重复其逻辑。**

## 触发语义

用户用自然语言表达"让 AGE 在这个项目生效"的意图时触发。命中下列任一语义即激活(非穷举,语义等价即可):

- 中文:开启AGE、启动AGE、用AGE、使用AGE、激活AGE、启用吸引子工程、开始AGE、帮我设置AGE、这个项目用AGE吧、装一下AGE
- 英文:enable AGE、start AGE、use AGE、activate AGE、turn on AGE、init AGE

## 执行步骤

### 第 1 步:检测当前项目是否已初始化 AGE

检查当前项目根(即 agent 的工作目录)是否存在 AGE 初始化标志:

- 有 `docs/index.md` **且** 有 `AGENTS.md` → 视为**已初始化**,跳到第 3 步。
- 缺其一或两者皆无 → 视为**未初始化**,进入第 2 步。

> 判定口径与 `age doctor` 一致(见契约 §8.8 X:接受 `docs/index.md` 或 `AGENTS.md` 之一即视为 AGE 仓库,但本技能为稳健起见采用更严格的"两者齐全"标准,避免半初始化态被误判为就绪)。若不确定,先跑 `age doctor` 确认。

### 第 2 步:未初始化 → 自动执行 `age init`

按 `ai-autonomy-policy.md` 的"自动初始化"自治策略,agent 可不经逐项确认自主完成脚手架生成:

1. 用合理默认值调用 CLI:
   ```
   age init --name <当前目录名> --kind web
   ```
   - 项目名取当前目录名(`basename $PWD`),无需询问用户。
   - `--kind` 默认 `web`;仅当项目特征能明确推断为 mobile(含 iOS/Android 工程文件)或 cli(纯命令行工具、无 UI)时,改用对应 kind。无法明确推断就用 `web`。
2. 初始化完成后跑 `age baseline`(快照基线)与 `age doctor`(确认健康)。若 `age doctor` 报错,把诊断结果告诉用户并暂停,不要继续。
3. **Day 0 业务字段需用户参与**(自治边界):init 生成的 `docs/context/project-context.md`、`AGENTS.md` 等含业务判断字段(`owner_name` / `project_description` / `target_users` / `tech_stack` / `validate_cmd` 等),这些**不得擅自编造**。引导用户参照 `START-HERE-after-copy.md` 填写 Day 0 字段;用户填完前,AGE 处于"脚手架就绪、上下文待补"态,可路由但 route 输出的 owner 文档内容为骨架。

> 若 `age init` 不可用(CLI 缺失)或 `age doctor` 显示已初始化,**不重复 init**。CLI 缺失时,提示用户先安装 AGE 插件;已初始化时直接进第 3 步。

### 第 3 步:已初始化 → 加载 age 元 skill 并注入上下文

1. **加载 `age` 元 skill**(同名目录 `skills/age/SKILL.md`),由它接管后续四个子流程(age-init / route / doc-sync / audit)的路由判断。
2. **注入 `docs/context/` 摘要**:读取当前项目的 `docs/context/` 下各 owner 文档(`project-context.md`、`ai-autonomy-policy.md`、`codebase-map.md`、`source-of-truth-and-precedence.md`、`conventions.md`)的要点,作为本次会话的强制上下文。若 MCP 可用,优先读 `docs://context/project-context` resource(契约 §4)。
3. **告诉用户 AGE 已激活**:简短确认(如"AGE 已激活,当前项目 <项目名> 已初始化,上下文已加载。后续开发任务我会先 route 再动手。"),然后**交出控制权**——本技能的任务到此结束。

### 第 4 步:明确控制权交接

- 激活成功后,**后续一切由 `age` 元 skill 负责**:任务开始前的 route、任务结束后的 doc-sync、周期 audit,都走 `age` 元 skill 的子流程。
- 本技能**不**重复 age 元 skill 的路由表、回写集、审计逻辑。它是"启动开关",不是"运行时大脑"。
- 若用户激活后又说"关闭 AGE / 退出 AGE",这不属于本技能职责(无对应的关闭流程,AGE 一旦初始化即对仓库生效;要退出需移除 AGENTS.md 的 AGE 段,见 age 元 skill "What AGE is NOT")。

## 边界与不做什么

- **不重复 age 元 skill。** 本技能只做"检测 + 自动 init + 交权",不做 route/doc-sync/audit 的判断。
- **不擅自填业务字段。** 脚手架可自治,Day 0 业务字段(`project_description` 等)需用户参与(见 `ai-autonomy-policy.md` 自动初始化段)。
- **不在已初始化项目重复 init。** `age doctor` 显示已初始化即跳过 init,直接交权。
- **不替代 SessionStart hook。** hook 负责每次会话注入上下文;本技能负责用户**显式表达激活意图**时的一次性激活。两者互补,不冲突。

#Requires -Version 5.1
# on-session-start.ps1 — AGE SessionStart hook(PowerShell 版)。
# 等价 hooks/scripts/on-session-start.sh。
#
# CONTRACT.md §5 + §8.10:向上下文注入 docs/context/ 摘要;在非 AGE 仓库的会话
# 启动时,应用 use-AGE 激活策略:
#   有 .age/      → 积极提示重新激活(不自动 init,§8.10 U-4 修复);
#   有 git 无 .age/ → 轻提示一次;
#   非 git        → 静默。
#
# CONTRACT.md §8.11(多客户端兼容):项目目录跨客户端解析。
# ZCode 设 ZCODE_PROJECT_DIR;Claude Code 设 CLAUDE_PROJECT_DIR;Codex
# (CODEX_HOME)与 OpenCode(OPENCODE_CONFIG)只暴露配置目录(非项目目录),
# 故这些客户端的项目目录仍回退到 cwd 的 git root,再回退 cwd。
# 解析顺序:ZCODE_PROJECT_DIR → CLAUDE_PROJECT_DIR → git root → cwd。
#
# 始终 exit 0,永不阻断。上下文经 Emit-Context 注入。

$ErrorActionPreference = 'Continue'

# dot-source 共享函数库(lib.ps1 与本脚本同目录)。
$libPath = Join-Path $PSScriptRoot 'lib.ps1'
if (-not (Test-Path -LiteralPath $libPath -PathType Leaf)) { exit 0 }
. $libPath

# --- 关键:在任何日志之前捕获项目状态 -----------------------------------------
# Log() 会写 <project>/.age/hooks.log 并 mkdir .age/,这会污染下面的 .age/
# 存在性检测。故先快照检测信号,再写日志。
$proj = Get-ProjectDir
# "曾用过 AGE" = .age/ 目录已存在(baseline/状态文件残留)。
# 必须在日志创建 .age/ 之前捕获。
$ageUsedBefore = (Test-Path -LiteralPath (Join-Path $proj '.age') -PathType Container)

Log "SessionStart hook fired"

# --- 情况 1:非 AGE 仓库 -------------------------------------------------------
# CONTRACT.md §8.10(use-AGE):项目尚未 AGE 初始化时,选择非激进激活策略
# (U-4 修复:hook 只读,绝不写文件 —— 自动 init 只走主动入口):
#   a) 会话启动时 .age/ 已存在(项目曾用过 AGE)→ 积极提示(不静默),
#      因为用户明显曾打算用 AGE。但不自动跑 age use/age init —— SessionStart
#      是被动触发,无用户意图信号;在此写文件违反 hook 只读原则(§8.10 U-4)。
#   b) 无 .age/ 但是 git 仓库 → 轻提示一次。
#   c) 连 git 仓库都不是 → 静默。
# 用户会话中途显式说"启动 AGE / use AGE"由 use-AGE 技能 + /use-age 命令 +
# age use CLI 处理 —— 那些才是可写的主动入口。本 hook 只读与提示。
if (-not (Test-AgeRepo)) {
  if ($ageUsedBefore) {
    # 分支 a:项目曾用过 AGE(.age/ 存在)→ 积极提示。
    Log "Not an AGE repo but .age/ exists; prompting for re-activation (read-only, no auto-init)"
    Emit-Context "AGE: This project has a .age/ directory (you've used AGE here before) but docs/index.md is missing. Say “启动 AGE” or run /use-age to re-initialize — it will restore the router automatically. To start a task after that, run /age-route <task>."
    exit 0
  }

  $gitCmd = Get-Command git -ErrorAction SilentlyContinue
  $isGitRepo = $false
  if ($gitCmd) {
    & git -C $proj rev-parse --git-dir 2>$null | Out-Null
    if ($LASTEXITCODE -eq 0) { $isGitRepo = $true }
  }
  if ($isGitRepo) {
    # 分支 b:git 仓库,无 AGE 状态 → 轻提示一次,不自动跑。
    Log "Not an AGE repo, no .age/, but is a git repo; prompting once"
    Emit-Context "AGE: This repo is not AGE-initialized. If you want attractor-guided documentation here, say “启动 AGE” (or run /use-age) and it will be set up automatically. If you did not intend to use AGE, ignore this message."
  } else {
    # 分支 c:非 git 仓库 → 静默。
    Log "Not a git repo and not AGE; staying silent"
  }
  exit 0
}

# --- 情况 2:是 AGE 仓库 → 注入上下文摘要 --------------------------------------
# 构建 docs/context/ 的紧凑摘要,让 agent 每次会话开始即定位:项目使命、
# 非目标、当前焦点、技术栈。($proj 已在顶部捕获。)
$contextDir = Join-Path $proj 'docs\context'

if (-not (Test-Path -LiteralPath $contextDir -PathType Container)) {
  Log "AGE repo but docs/context/ missing; nothing to inject"
  exit 0
}

$summaryLines = [System.Collections.Generic.List[string]]::new()
$summaryLines.Add("AGE project context (auto-injected from docs/context/):")
$summaryLines.Add("")

# 读取 docs/context/ 下每个 markdown 文件,取其正文开头(跳过 YAML frontmatter),
# 各截断到几行,保持注入成本低。
$contextFiles = @(Get-ChildItem -LiteralPath $contextDir -Filter '*.md' -File -ErrorAction SilentlyContinue | Sort-Object Name)

if ($contextFiles.Count -eq 0) {
  Log "docs/context/ empty; injecting minimal pointer"
  Emit-Context "AGE: docs/context/ is empty. Consider running /age-sync to populate project context, or /age-doctor to diagnose."
  exit 0
}

foreach ($f in $contextFiles) {
  $summaryLines.Add("## $($f.Name)")
  # 读取文件内容,跳过 YAML frontmatter(--- ... ---),再取最多 8 行非空正文。
  $raw = Get-Content -LiteralPath $f.FullName -Raw -ErrorAction SilentlyContinue
  if (-not $raw) { $summaryLines.Add("(empty)"); $summaryLines.Add(""); continue }

  $bodyLines = [System.Collections.Generic.List[string]]::new()
  $inFrontmatter = $false
  $firstLine = $true
  foreach ($ln in $raw -split "`r?`n") {
    if ($ln -match '^---$') {
      if ($firstLine) { $inFrontmatter = $true; $firstLine = $false; continue }
      if ($inFrontmatter) { $inFrontmatter = $false; continue }
      # 非首行的独立 --- 且不在 frontmatter 中:当作正文分隔符,保留。
    }
    $firstLine = $false
    if ($inFrontmatter) { continue }
    if ($ln -match '^\s*$') { continue }   # 跳过空行
    $bodyLines.Add($ln)
    if ($bodyLines.Count -ge 8) { break }
  }

  if ($bodyLines.Count -gt 0) {
    foreach ($bl in $bodyLines) { $summaryLines.Add($bl) }
  } else {
    $summaryLines.Add("(empty)")
  }
  $summaryLines.Add("")
}

# 若 CLI 可用,追加一个状态提示。保持低成本:SessionStart 不跑完整 sync,
# 只提示 baseline 位置。
$cli = Resolve-AgeCli
if ($cli) {
  $baseline = Join-Path $proj '.age\baseline.json'
  if (Test-Path -LiteralPath $baseline -PathType Leaf) {
    $summaryLines.Add("Baseline snapshot: .age/baseline.json present. Run /age-sync after edits to reconcile drift.")
  } else {
    $summaryLines.Add("No baseline snapshot found. Run /age-init (or age baseline) to create one.")
  }
}

$joined = ($summaryLines -join "`n")
Log "Injecting context summary ($($contextFiles.Count) file(s))"
Emit-Context $joined
exit 0

#!/usr/bin/env bash
# on-session-start.sh — AGE SessionStart hook.
# CONTRACT.md §5 + §8.10: inject docs/context/ summary into context; on session
# start in a non-AGE repo, apply the use-AGE activation strategy:
#   .age/ present → auto-activate via `age use` (re-init the missing router);
#   git repo, no .age/ → prompt once (do not auto-run init);
#   not a git repo → stay silent.
#
# CONTRACT.md §8.11 (multi-client compat): the project directory is resolved
# across clients. ZCode sets ZCODE_PROJECT_DIR; Claude Code sets
# CLAUDE_PROJECT_DIR; Codex (CODEX_HOME) and OpenCode (OPENCODE_CONFIG) only
# expose config dirs (NOT project dirs), so for those clients the project dir
# still falls back to the git root of the cwd, then $PWD. Resolution order:
#   ZCODE_PROJECT_DIR → CLAUDE_PROJECT_DIR → git rev-parse --show-toplevel → $PWD
# This hook re-defines age_project_dir() (originally from lib.sh) so that the
# script-local `proj`, is_age_repo(), and age_log_file() all agree on the same
# multi-client-aware root. lib.sh itself is left untouched (it is owned by the
# coordinator per CONTRACT.md §2/§8.11).
#
# Triggered by ZCode on every SessionStart (matcher: match-all / omitted).
# Must NEVER block: always exit 0. Surface context via `emit_context`.

set -u

# Locate lib.sh relative to this script.
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=lib.sh
. "${SCRIPT_DIR}/lib.sh"

# --- Multi-client project directory resolution (CONTRACT.md §8.11) -----------
# Re-define age_project_dir() (originally from lib.sh) with a multi-client-aware
# version, so that this hook's `proj`, is_age_repo(), and age_log_file() all
# agree on the same resolved root regardless of which client hosts the session.
#
# Resolution order (§8.11):
#   ZCODE_PROJECT_DIR → CLAUDE_PROJECT_DIR → git rev-parse --show-toplevel → $PWD
# CODEX_HOME and OPENCODE_CONFIG are intentionally NOT consulted: per §8.11 they
# point at *config* directories, not project directories — for Codex/OpenCode the
# project dir must still come from the git root of the cwd (then $PWD). Host
# *detection* (which client are we in) is the job of `age install` /
# detect_host() (coordinator), not this project-dir resolver.
#
# lib.sh (owned by the coordinator per §2/§8.11) is NOT edited from this file.
# The coordinator has aligned lib.sh's age_project_dir() to the same §8.11
# semantics; this re-definition is kept as a defensive, self-contained guarantee
# that on-session-start.sh resolves the project dir correctly even if lib.sh's
# version lags or differs. The two are intentionally identical in behavior.
age_project_dir() {
  if [ -n "${ZCODE_PROJECT_DIR:-}" ] && [ -d "${ZCODE_PROJECT_DIR}" ]; then
    printf '%s' "${ZCODE_PROJECT_DIR}"
    return 0
  fi
  if [ -n "${CLAUDE_PROJECT_DIR:-}" ] && [ -d "${CLAUDE_PROJECT_DIR}" ]; then
    printf '%s' "${CLAUDE_PROJECT_DIR}"
    return 0
  fi
  # Codex / OpenCode / generic: resolve the project dir from the git working
  # tree root of the current directory. Falls through to $PWD when not in a git
  # repo (git rev-parse exits non-zero, which we swallow).
  local git_root
  if git_root="$(git rev-parse --show-toplevel 2>/dev/null)" && [ -n "${git_root}" ] && [ -d "${git_root}" ]; then
    printf '%s' "${git_root}"
    return 0
  fi
  printf '%s' "${PWD}"
}

# IMPORTANT: capture project state BEFORE any logging. The `log()` helper writes
# to <project>/.age/hooks.log and `mkdir -p`s that directory as a side effect,
# which would pollute the `.age/` presence check below. Snapshot the detection
# signals first, then log.
proj="$(age_project_dir)"
# "Used AGE before" = the .age/ dir already exists (baseline/state files linger).
# We capture this BEFORE logging creates .age/ for the hooks.log.
age_used_before=0
[ -d "${proj}/.age" ] && age_used_before=1

log "SessionStart hook fired"

# --- Case 1: not an AGE repo -----------------------------------------------
# CONTRACT.md §8.10 (use-AGE): when the project is not yet AGE-initialized,
# choose a non-aggressive activation strategy (U-4 fix: hook is READ-ONLY,
# never writes files — auto-init only via active entry points):
#   a) `.age/` existed at session start (the project used AGE before) →
#      PROMPT actively (not silent), because the user clearly intended AGE.
#      But do NOT auto-run `age use`/`age init` — SessionStart is a passive
#      trigger with no user intent signal; writing files here would violate
#      the hook read-only principle (§8.10 U-4).
#   b) no `.age/` but it IS a git repo → prompt once softly.
#   c) not even a git repo → stay silent.
# The user explicitly saying "启动 AGE / use AGE" mid-session is handled by the
# use-AGE skill + /use-age command + `age use` CLI — those ARE the active
# entry points that may write. This hook only reads and prompts.
if ! is_age_repo; then
  if [ "${age_used_before}" -eq 1 ]; then
    # Branch (a): project has used AGE before (.age/ exists) — prompt actively.
    log "Not an AGE repo but .age/ exists; prompting for re-activation (read-only, no auto-init)"
    emit_context "AGE: This project has a .age/ directory (you've used AGE here before) but docs/index.md is missing. Say “启动 AGE” or run /use-age to re-initialize — it will restore the router automatically. To start a task after that, run /age-route <task>."
    exit 0
  fi

  if [ -d "${proj}/.git" ] || git -C "${proj}" rev-parse --git-dir >/dev/null 2>&1; then
    # Branch (b): git repo, no AGE state — prompt ONCE, do not auto-run.
    log "Not an AGE repo, no .age/, but is a git repo; prompting once"
    emit_context "AGE: This repo is not AGE-initialized. If you want attractor-guided documentation here, say “启动 AGE” (or run /use-age) and it will be set up automatically. If you did not intend to use AGE, ignore this message."
  else
    # Branch (c): not even a git repo; stay silent.
    log "Not a git repo and not AGE; staying silent"
  fi
  exit 0
fi

# --- Case 2: it IS an AGE repo — inject context summary ---------------------
# Build a compact summary of docs/context/ so the agent starts each session
# oriented: project mission, non-goals, current focus, tech stack.
# (`proj` was already captured at the top of the script.)
context_dir="${proj}/docs/context"

if [ ! -d "${context_dir}" ]; then
  log "AGE repo but docs/context/ missing; nothing to inject"
  exit 0
fi

summary_lines=()
summary_lines+=("AGE project context (auto-injected from docs/context/):")
summary_lines+=("")

# Read each markdown file in docs/context/, take its leading non-frontmatter
# content, truncated to a few lines each so the injection stays cheap.
shopt -s nullglob
context_files=("${context_dir}"/*.md)
shopt -u nullglob

if [ "${#context_files[@]}" -eq 0 ]; then
  log "docs/context/ empty; injecting minimal pointer"
  emit_context "AGE: docs/context/ is empty. Consider running /age-sync to populate project context, or /age-doctor to diagnose."
  exit 0
fi

for f in "${context_files[@]}"; do
  fname="$(basename "${f}")"
  summary_lines+=("## ${fname}")
  # Skip YAML frontmatter (--- ... ---), then grab up to 8 non-empty body lines.
  body="$(
    awk '
      /^---$/ { if (in_fm) { in_fm=0; next } else if (NR==1) { in_fm=1; next } }
      in_fm { next }
      { print }
    ' "${f}" 2>/dev/null | grep -v '^[[:space:]]*$' | head -n 8
  )"
  if [ -n "${body}" ]; then
    while IFS= read -r line; do
      summary_lines+=("${line}")
    done <<<"${body}"
  else
    summary_lines+=("(empty)")
  fi
  summary_lines+=("")
done

# Append a status hint computed via `age route` if a current task is inferable.
# Keep this cheap: only attempt if the CLI is present; never block on it.
if cli="$(age_resolve_cli)"; then
  # Compute a lightweight drift/status line. We do NOT run a full sync here
  # (too slow for SessionStart); just note where the baseline is.
  baseline="${proj}/.age/baseline.json"
  if [ -f "${baseline}" ]; then
    summary_lines+=("Baseline snapshot: .age/baseline.json present. Run /age-sync after edits to reconcile drift.")
  else
    summary_lines+=("No baseline snapshot found. Run /age-init (or age baseline) to create one.")
  fi
fi

# Join the array into a single string with newlines.
printf -v joined '%s\n' "${summary_lines[@]}"
log "Injecting context summary (${#context_files[@]} file(s))"
emit_context "${joined}"
exit 0

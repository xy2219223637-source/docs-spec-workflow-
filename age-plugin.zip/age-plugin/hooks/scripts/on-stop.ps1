#Requires -Version 5.1
# on-stop.ps1 — AGE Stop hook(PowerShell 版)。
# 等价 hooks/scripts/on-stop.sh。
#
# CONTRACT.md §5:回合结束时,跑 closure 作用域一致性审计,提醒 agent 哪些
# 违规应在停止前解决。
#
# age audit --scope closure(§3)是轻量收尾检查(比 /age-audit 用的
# --scope full 更便宜)。退出码 0 = 通过,1 = 有违规。
#
# 始终 exit 0。永不阻断。违规经 Emit-Context 暴露让 agent 处理;干净则静默。

$ErrorActionPreference = 'Continue'

# dot-source 共享函数库。
$libPath = Join-Path $PSScriptRoot 'lib.ps1'
if (-not (Test-Path -LiteralPath $libPath -PathType Leaf)) { exit 0 }
. $libPath

Log "Stop hook fired"

# --- 非 AGE 仓库 → 静默退出 ---------------------------------------------------
if (-not (Test-AgeRepo)) {
  Log "Not an AGE repo; skipping closure audit"
  exit 0
}

# --- CLI 缺失 → 静默退出 ------------------------------------------------------
$cli = Resolve-AgeCli
if (-not $cli) {
  Log "age CLI missing; skipping closure audit (non-blocking)"
  exit 0
}

# --- 跑收尾审计 ----------------------------------------------------------------
# CONTRACT.md §3:age audit --scope closure。轻量回合末检查。
# audit CLI 输出人类可读文本(无 --json 模式,见 §8.6 I 协调请求):进度 +
# 摘要走 stdout,违规行经 age_error 走 stderr。此处合并捕获两者以便提醒可
# 引用违规。颜色在非 tty 时自动降级(我们捕获到变量),故文本干净。
$auditOutput = & $cli audit --scope closure 2>&1
$auditRc = $LASTEXITCODE
$auditOut = ($auditOutput -join "`n")

# 退出码 0 → 干净。静默。
if ($auditRc -eq 0) {
  Log "Closure audit passed (exit 0)"
  exit 0
}

# --- 有违规:emit 紧凑提醒 -----------------------------------------------------
# audit CLI 打印人类可读文本(无 JSON 模式),行如:
#   "✗ 违规: 收尾前存在漂移,需先 sync 修复"  (age_error,走 stderr)
#   "ℹ [1/3] 代码-文档漂移..."               (age_info,进度)
#   "  结果  发现 6 处违规"                   (摘要)
# 去除进度噪声与 ✗/ℹ/✓ 标记,保留违规与摘要行。
# 防御性:若无匹配,回退到截断原文。
function Format-Violations {
  param([string]$Out)
  $violationLines = [System.Collections.Generic.List[string]]::new()
  $allLines = $Out -split "`r?`n"
  # 违规行含"违规|缺失|为空|不存在"。捕获,去除前导标记。
  foreach ($ln in $allLines) {
    if ($ln -match '违规|缺失|为空|不存在') {
      $cleaned = $ln -replace '^\s*[✗⚠ℹ✓]\s*', ''
      if (-not [string]::IsNullOrWhiteSpace($cleaned)) {
        $violationLines.Add($cleaned)
      }
    }
  }
  # 追加摘要行(违规计数),若存在。去重防摘要本身命中违规 grep。
  $summary = $null
  foreach ($ln in $allLines) {
    if ($ln -match '发现.*处违规|审计通过') {
      $summary = ($ln -replace '^\s*', '').Trim()
      break
    }
  }
  if ($summary -and -not ($violationLines -contains $summary)) {
    $violationLines.Add($summary)
  }
  if ($violationLines.Count -gt 0) {
    return ($violationLines -join "`n")
  }
  # 回退:前 12 行非空原文。
  $fallback = [System.Collections.Generic.List[string]]::new()
  foreach ($ln in $allLines) {
    if (-not [string]::IsNullOrWhiteSpace($ln)) { $fallback.Add($ln) }
    if ($fallback.Count -ge 12) { break }
  }
  return ($fallback -join "`n")
}

$violations = Format-Violations -Out $auditOut
if ([string]::IsNullOrWhiteSpace($violations)) {
  $violations = "  - (closure audit reported violations but details could not be parsed; run /age-audit for the full report)"
}

Log "Closure audit found violations; emitting reminder"

$message = @(
  "AGE closure audit found unresolved issues before stopping:"
  $violations
  "Resolve these before ending the session, or run /age-audit for a full audit and /age-sync to reconcile drift. If these are intentional, you may ignore this reminder."
) -join "`n`n"

Emit-Context $message
exit 0

#!/usr/bin/env bash
# lib.sh — shared functions for AGE hook scripts.
# Sourced by on-session-start.sh, on-edit.sh, on-stop.sh.
# All scripts MUST `source` this file first.

# Guard against double-sourcing.
if [ -n "${AGE_HOOK_LIB_LOADED:-}" ]; then return 0 2>/dev/null || true; fi
AGE_HOOK_LIB_LOADED=1

# -----------------------------------------------------------------------------
# Paths
# -----------------------------------------------------------------------------

# Plugin root: prefer ZCODE_PLUGIN_ROOT (set for plugin hooks), fall back to
# CLAUDE_PLUGIN_ROOT (compat), then derive from this script's location.
age_plugin_root() {
  if [ -n "${ZCODE_PLUGIN_ROOT:-}" ] && [ -d "${ZCODE_PLUGIN_ROOT}" ]; then
    printf '%s' "${ZCODE_PLUGIN_ROOT}"
    return 0
  fi
  if [ -n "${CLAUDE_PLUGIN_ROOT:-}" ] && [ -d "${CLAUDE_PLUGIN_ROOT}" ]; then
    printf '%s' "${CLAUDE_PLUGIN_ROOT}"
    return 0
  fi
  # lib.sh lives at <root>/hooks/scripts/lib.sh → go up two levels.
  local script_dir
  script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
  printf '%s' "$(cd "${script_dir}/../.." && pwd)"
}

# Project directory: detect the current project root across multiple clients.
# Priority: ZCODE_PROJECT_DIR → CLAUDE_PROJECT_DIR → git root → $PWD
# NOTE: CODEX_HOME / OPENCODE_CONFIG point at *config* directories, not project
# directories, so they are intentionally NOT used for project location.
age_project_dir() {
  if [ -n "${ZCODE_PROJECT_DIR:-}" ] && [ -d "${ZCODE_PROJECT_DIR}" ]; then
    printf '%s' "${ZCODE_PROJECT_DIR}"
    return 0
  fi
  if [ -n "${CLAUDE_PROJECT_DIR:-}" ] && [ -d "${CLAUDE_PROJECT_DIR}" ]; then
    printf '%s' "${CLAUDE_PROJECT_DIR}"
    return 0
  fi
  # Fall back to git repository root (works for Codex/OpenCode and bare shells).
  if command -v git >/dev/null 2>&1; then
    local git_root
    git_root="$(git rev-parse --show-toplevel 2>/dev/null)"
    if [ -n "${git_root}" ] && [ -d "${git_root}" ]; then
      printf '%s' "${git_root}"
      return 0
    fi
  fi
  printf '%s' "${PWD}"
}

# Resolve the age CLI. Preference order:
#   1. ${ZCODE_PLUGIN_ROOT}/cli/age   (bundled with the plugin)
#   2. ${CLAUDE_PLUGIN_ROOT}/cli/age  (compat)
#   3. `age` on PATH
# Prints the command path (with no args) and returns 0 if found, else returns 1
# and prints nothing.
age_resolve_cli() {
  local root cli_path
  root="$(age_plugin_root)"
  cli_path="${root}/cli/age"
  if [ -x "${cli_path}" ]; then
    printf '%s' "${cli_path}"
    return 0
  fi
  if [ -n "${CLAUDE_PLUGIN_ROOT:-}" ] && [ -x "${CLAUDE_PLUGIN_ROOT}/cli/age" ]; then
    printf '%s' "${CLAUDE_PLUGIN_ROOT}/cli/age"
    return 0
  fi
  if command -v age >/dev/null 2>&1; then
    printf '%s' "$(command -v age)"
    return 0
  fi
  return 1
}

# -----------------------------------------------------------------------------
# Logging
# -----------------------------------------------------------------------------

# Log directory lives inside the project: <project>/.age/hooks.log
age_log_file() {
  local proj
  proj="$(age_project_dir)"
  printf '%s/.age/hooks.log' "${proj}"
}

# log <level> <message...>
age_log() {
  local level="$1"; shift
  local log_file
  log_file="$(age_log_file)"
  # Best-effort: create .age dir if missing; never fail the hook over logging.
  mkdir -p "$(dirname "${log_file}")" 2>/dev/null || true
  local ts
  ts="$(date '+%Y-%m-%dT%H:%M:%S%z' 2>/dev/null || date)"
  printf '[%s] [%s] %s\n' "${ts}" "${level}" "$*" >>"${log_file}" 2>/dev/null || true
}

# Convenience wrappers.
log()  { age_log INFO  "$@"; }
warn() { age_log WARN  "$@"; }
err()  { age_log ERROR "$@"; }

# -----------------------------------------------------------------------------
# Repo detection
# -----------------------------------------------------------------------------

# is_age_repo → 0 if the project has docs/index.md (the AGE router doc),
# non-zero otherwise. This is the "is this an AGE-managed repo?" predicate.
is_age_repo() {
  local proj index
  proj="$(age_project_dir)"
  index="${proj}/docs/index.md"
  [ -f "${index}" ]
}

# -----------------------------------------------------------------------------
# Hook output helpers
# -----------------------------------------------------------------------------

# AGE hooks must NEVER block the user. Always exit 0. To surface context to the
# agent, emit a JSON object on stdout. The exact key differs by client
# (CONTRACT §8.11 CP-8: 按客户端分支 emit_context 格式):
#   - ZCode / Claude Code / Codex  → {"additionalContext": "<text>"}
#     (PascalCase hooks, identical runner schema across these full-level clients)
#   - OpenCode CLI                 → {"message": "<text>"}
#     (dot-notation hooks tool.execute.after; OpenCode parses stdout JSON and
#      injects `message` as context — see §8.11 OpenCode partial compat)
# If there is nothing to say, print nothing and exit 0.
#
# detect_hook_client:检测当前 hook 运行所在的客户端(§8.11)。
# 优先用环境变量(多客户端共存时最可靠),回退到配置文件特征。
# 输出:zcode|claude|codex|opencode|unknown。返回 0 始终。
detect_hook_client() {
  # 环境变量优先(运行中的客户端会设置自己的 env)
  if [ -n "${ZCODE_PLUGIN_ROOT:-}" ] && [ -d "${ZCODE_PLUGIN_ROOT}" ]; then
    echo "zcode"; return 0
  fi
  if [ -n "${ZCODE_PROJECT_DIR:-}" ] && [ -d "${ZCODE_PROJECT_DIR}" ]; then
    echo "zcode"; return 0
  fi
  if [ -n "${CLAUDE_PLUGIN_ROOT:-}" ] && [ -d "${CLAUDE_PLUGIN_ROOT}" ]; then
    echo "claude"; return 0
  fi
  if [ -n "${CLAUDE_PROJECT_DIR:-}" ] && [ -d "${CLAUDE_PROJECT_DIR}" ]; then
    echo "claude"; return 0
  fi
  if [ -n "${CODEX_HOME:-}" ] && [ -d "${CODEX_HOME}" ]; then
    echo "codex"; return 0
  fi
  if [ -n "${OPENCODE_CONFIG:-}" ]; then
    echo "opencode"; return 0
  fi
  # 回退:配置文件/目录特征
  if [ -d "$(pwd)/.zcode" ]; then
    echo "zcode"; return 0
  fi
  if [ -d "$(pwd)/.claude" ] || [ -d "$HOME/.claude" ]; then
    echo "claude"; return 0
  fi
  if [ -d "$HOME/.codex" ]; then
    echo "codex"; return 0
  fi
  if [ -f "$(pwd)/opencode.json" ] || [ -d "$HOME/.config/opencode" ]; then
    echo "opencode"; return 0
  fi
  echo "unknown"; return 0
}

# emit_context <text>
#   按当前客户端输出格式(CP-8):
#     ZCode/Claude/Codex → {"additionalContext": "<text>"}
#     OpenCode           → {"message": "<text>"}
#     unknown            → {"additionalContext": "<text>"}(默认用 ZCode 格式)
#   Uses awk for portability (GNU sed's :a/N/$!ba idiom is unavailable on
#   macOS BSD sed, and `awk -v` rejects/mangles literal newlines). We pass the
#   text through the environment (ENVIRON) so raw bytes — including newlines —
#   survive untouched, then escape in awk. Order matters: backslash first,
#   then quotes, then real newline/tab/CR.
emit_context() {
  local text="$1"
  local client key
  client="$(detect_hook_client)"
  case "$client" in
    opencode) key="message";;
    *)        key="additionalContext";;   # zcode/claude/codex/unknown 用标准格式
  esac
  AGE_CTX="${text}" AGE_KEY="${key}" awk 'BEGIN {
    s = ENVIRON["AGE_CTX"]
    gsub(/\\/, "\\\\", s)
    gsub(/"/,  "\\\"", s)
    gsub(/\n/, "\\n", s)
    gsub(/\t/, "\\t",  s)
    gsub(/\r/, "\\r",  s)
    printf "{\"%s\":\"%s\"}", ENVIRON["AGE_KEY"], s
  }'
}

# Run age silently; returns the CLI's exit status. If the CLI is missing,
# returns 0 (treated as "nothing to do") and logs a warning.
# run_age <args...>
run_age() {
  local cli
  if ! cli="$(age_resolve_cli)"; then
    warn "age CLI not found; skipping command: age $*"
    return 0
  fi
  "${cli}" "$@"
}

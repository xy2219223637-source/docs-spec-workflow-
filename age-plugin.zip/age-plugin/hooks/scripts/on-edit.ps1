#Requires -Version 5.1
# on-edit.ps1 — AGE PostToolUse(Edit|Write|MultiEdit) hook(PowerShell 版)。
# 等价 hooks/scripts/on-edit.sh。
#
# CONTRACT.md §5:编辑/写入后,检测文档漂移并提醒哪些文档需更新。
#
# 策略(必须快、不阻断):
#   1. 从 stdin 读取工具调用 payload(ZCode 传入描述工具输入的 JSON,含被编辑
#      文件路径)。
#   2. 提取文件路径。
#   3. 非 AGE 仓库 → 静默 exit 0。
#   4. 跑 age sync --json --since HEAD(§3)取漂移报告。--since HEAD 限定范围,
#      保持低成本、仅受影响模块。
#   5. 有漂移 → emit additionalContext 提醒,点名需更新的文档。无漂移 → 静默。
#
# 始终 exit 0。永不阻断(exit 2 保留给 PreToolUse 拒绝)。

$ErrorActionPreference = 'Continue'

# dot-source 共享函数库。
$libPath = Join-Path $PSScriptRoot 'lib.ps1'
if (-not (Test-Path -LiteralPath $libPath -PathType Leaf)) { exit 0 }
. $libPath

Log "PostToolUse(edit) hook fired"

# --- 从 stdin 读取工具调用 payload --------------------------------------------
# ZCode 在 stdin 喂入描述工具调用的 JSON。Edit/Write/MultiEdit 的文件路径在
# .tool_input.file_path(Edit/Write)或 .tool_input.paths(MultiEdit)。
# 防御性解析:schema 可能变化,故尝试多个键并回退到扫描路径式值。
$payload = [Console]::In.ReadToEnd()

# 提取文件路径。优先 ConvertFrom-Json;失败则正则回退。
function Get-EditedPaths {
  param([string]$P)
  $paths = [System.Collections.Generic.List[string]]::new()
  if ($P) {
    $parsed = $null
    try { $parsed = $P | ConvertFrom-Json -ErrorAction Stop } catch { }
    if ($parsed) {
      # 常见键位置(Edit/Write/MultiEdit 变体)。
      $ti = $parsed.tool_input
      if ($ti) {
        foreach ($k in @('file_path','path','notebook_path')) {
          $v = $ti.$k
          if ($v) { [void]$paths.Add("$v") }
        }
        if ($ti.paths) {
          foreach ($p in @($ti.paths)) { if ($p) { [void]$paths.Add("$p") } }
        }
      }
    }
  }
  if ($paths.Count -eq 0 -and $P) {
    # 回退:扫描 "file_path": "..." 式值。
    # 注意:不用 $matches 变量名(它是 PowerShell 自动变量,会被 -match 覆盖)。
    $reMatches = [regex]::Matches($P, '"(?:file_path|path|notebook_path)"\s*:\s*"([^"]+)"')
    foreach ($m in $reMatches) { [void]$paths.Add($m.Groups[1].Value) }
  }
  return , $paths
}

$editedPaths = Get-EditedPaths -P $payload
if ($editedPaths.Count -gt 0) {
  Log "Edited file(s): $($editedPaths -join ' ')"
} else {
  Log "Could not extract file path from payload; continuing with drift check"
}

# --- 非 AGE 仓库 → 静默退出 ---------------------------------------------------
if (-not (Test-AgeRepo)) {
  Log "Not an AGE repo; skipping drift check"
  exit 0
}

# --- 跑作用域漂移检测 ---------------------------------------------------------
# age sync --json --since HEAD 返回含 stale/orphan/missing 数组的 JSON 报告(§3)。
# 退出码 0 = 无漂移,1 = 有漂移。
# Invoke-Age 合并 stderr 到 stdout;CLI 缺失时返回空串。
$cli = Resolve-AgeCli
if (-not $cli) {
  Log "age CLI missing; skipping drift check (non-blocking)"
  exit 0
}

$driftOutput = & $cli sync --json --since HEAD 2>&1
$syncRc = $LASTEXITCODE
$driftJson = ($driftOutput -join "`n")

# 退出码 0 → 无漂移。静默(无输出,exit 0)。
if ($syncRc -eq 0) {
  Log "No drift detected (age sync exit 0)"
  exit 0
}

# --- 有漂移:构建紧凑提醒 -----------------------------------------------------
# 解析漂移 JSON。age sync --json schema(cli/lib/sync.sh,§8.6 H):
#   stale[]   = {module, owner, changed_file}
#   orphan[]  = {module, owner}
#   missing[] = {file}
# 优先 ConvertFrom-Json;失败回退到截断原文。
function Format-Drift {
  param([string]$Json)
  $lines = [System.Collections.Generic.List[string]]::new()
  $parsed = $null
  try { $parsed = $Json | ConvertFrom-Json -ErrorAction Stop } catch { }
  if ($parsed) {
    if ($parsed.stale) {
      foreach ($s in @($parsed.stale)) {
        $lines.Add("  - stale: $($s.module) → $($s.owner)  (changed: $($s.changed_file))")
      }
    }
    if ($parsed.orphan) {
      foreach ($o in @($parsed.orphan)) {
        $lines.Add("  - orphan: $($o.module) → $($o.owner)  (code module gone)")
      }
    }
    if ($parsed.missing) {
      foreach ($m in @($parsed.missing)) {
        $lines.Add("  - missing: $($m.file)  (no owner doc / route entry)")
      }
    }
  }
  if ($lines.Count -eq 0) {
    # 无结构化数据:截断原文前 600 字符。
    $excerpt = if ($Json.Length -gt 600) { $Json.Substring(0, 600) } else { $Json }
    $lines.Add($excerpt)
  }
  return ($lines -join "`n")
}

$driftSummary = Format-Drift -Json $driftJson
if ([string]::IsNullOrWhiteSpace($driftSummary)) {
  # 无法解析细节但 sync 报告有漂移(rc=1)。给通用提示。
  $driftSummary = "  - (age sync reported drift but details could not be parsed; run /age-sync for the full report)"
}

Log "Drift detected; emitting reminder"

# 组合提醒。引用被编辑文件,让 agent 把编辑与需更新的文档关联。
$editedInline = ($editedPaths -join ' ').TrimEnd()
$header = if ($editedInline) { "AGE drift detected after editing: $editedInline" } else { "AGE drift detected after an edit" }

$message = @(
  $header
  ""
  "The following docs are out of sync and may need updating:"
  $driftSummary
  ""
  "Run /age-sync to review and apply doc updates, or /age-route to confirm the owner docs for this change."
) -join "`n"

Emit-Context $message
exit 0

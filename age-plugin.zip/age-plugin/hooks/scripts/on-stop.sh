#!/usr/bin/env bash
# on-stop.sh — AGE Stop hook.
# CONTRACT.md §5: at end of turn, run a closure-scope consistency audit and
# remind the agent of any violations that should be resolved before stopping.
#
# `age audit --scope closure` (CONTRACT.md §3) is the lightweight closure check
# (cheaper than --scope full, which /age-audit uses). Exit 0 = pass, 1 = violations.
#
# Always exit 0. Never block. Surface violations via `emit_context` so the
# agent can act on them; if clean, stay silent.

set -u

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=lib.sh
. "${SCRIPT_DIR}/lib.sh"

log "Stop hook fired"

# --- Bail out silently if not an AGE repo -----------------------------------
if ! is_age_repo; then
  log "Not an AGE repo; skipping closure audit"
  exit 0
fi

# --- Bail out if the CLI is missing -----------------------------------------
if ! age_resolve_cli >/dev/null 2>&1; then
  log "age CLI missing; skipping closure audit (non-blocking)"
  exit 0
fi

# --- Run the closure audit ---------------------------------------------------
# CONTRACT.md §3: age audit --scope closure. Lightweight end-of-turn check.
# The audit CLI emits human-readable text (no --json mode): progress + summary
# to stdout, violation lines via age_error to stderr. Capture BOTH so the
# reminder can quote the violations. Colors auto-degrade when stdout is not a
# tty (we capture to a variable), so the text is clean.
audit_out="$(run_age audit --scope closure 2>&1)"
audit_rc=$?

# rc 0 → clean. Stay silent.
if [ "${audit_rc}" -eq 0 ]; then
  log "Closure audit passed (exit 0)"
  exit 0
fi

# --- Violations present: emit a compact reminder ----------------------------
# The audit CLI prints human-readable text (no JSON mode): lines like
#   "✗ 违规: 收尾前存在漂移,需先 sync 修复"  (age_error, to stderr)
#   "ℹ [1/3] 代码-文档漂移..."               (age_info, progress)
#   "  结果  发现 6 处违规"                   (summary)
# Strip progress noise and the ✗/ℹ/✓ markers; keep violation + summary lines.
# Be defensive: if nothing matches, fall back to a trimmed raw excerpt.
format_violations() {
  local out="$1"
  local lines=""
  # Violation lines carry "违规" (violation). Capture them, strip leading marker.
  lines="$(printf '%s\n' "${out}" | grep -E '违规|缺失|为空|不存在' | sed -E 's/^[[:space:]]*[✗⚠ℹ✓][[:space:]]*//' | grep -v '^[[:space:]]*$' || true)"
  # Append the summary line if present (count of violations). Dedup in case the
  # summary text itself matched the violation grep.
  local summary
  summary="$(printf '%s' "${out}" | grep -E '发现.*处违规|审计通过' | sed -E 's/^[[:space:]]*//' | head -n1 || true)"
  if [ -n "${summary}" ] && ! printf '%s' "${lines}" | grep -qF "${summary}"; then
    lines="${lines}${lines:+$'\n'}${summary}"
  fi
  if [ -n "${lines}" ]; then
    printf '%s' "${lines}"
    return 0
  fi
  # Fallback: first non-empty lines of the raw output, capped.
  printf '%s\n' "${out}" | grep -v '^[[:space:]]*$' | head -n 12
}

violations="$(format_violations "${audit_out}")"
if [ -z "${violations}" ]; then
  violations="  - (closure audit reported violations but details could not be parsed; run /age-audit for the full report)"
fi

log "Closure audit found violations; emitting reminder"

message=$(printf '%s\n\n%s\n\n%s' \
  "AGE closure audit found unresolved issues before stopping:" \
  "${violations}" \
  "Resolve these before ending the session, or run /age-audit for a full audit and /age-sync to reconcile drift. If these are intentional, you may ignore this reminder.")

emit_context "${message}"
exit 0

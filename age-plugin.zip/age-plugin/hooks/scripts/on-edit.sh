#!/usr/bin/env bash
# on-edit.sh — AGE PostToolUse(Edit|Write|MultiEdit) hook.
# CONTRACT.md §5: after an edit/write, detect doc drift and remind which docs
# need updating.
#
# Strategy (must be FAST and non-blocking):
#   1. Read the tool-call payload from stdin (ZCode passes JSON describing the
#      tool input, including the edited file path).
#   2. Extract the file path(s).
#   3. If not an AGE repo, exit 0 silently.
#   4. Run `age sync --json --since HEAD` (CONTRACT.md §3) to get a drift
#      report. Scope is implicit in --since HEAD (only changes since the last
#      commit), keeping it cheap and limited to affected modules.
#   5. If drift is found, emit an additionalContext reminder naming the docs
#      that need updating. If no drift, exit 0 with no output.
#
# Always exit 0. Never block (exit 2 is reserved for PreToolUse denies).

set -u

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=lib.sh
. "${SCRIPT_DIR}/lib.sh"

log "PostToolUse(edit) hook fired"

# --- Read tool-call payload from stdin --------------------------------------
# ZCode feeds the hook a JSON object on stdin describing the tool invocation.
# For Edit/Write/MultiEdit the file path is under .tool_input.file_path
# (Edit/Write) or .tool_input.paths (MultiEdit). Be defensive: the schema may
# vary, so try several keys and fall back to scanning for a path-like value.
payload="$(cat)"

# Extract file path(s). Prefer jq; fall back to grep if jq is absent.
extract_paths() {
  local p="$1"
  local paths=""
  if command -v jq >/dev/null 2>&1; then
    # Common key locations across Edit/Write/MultiEdit variants.
    paths="$(
      printf '%s' "${p}" | jq -r '
        (.tool_input.file_path // empty),
        (.tool_input.path // empty),
        (.tool_input.notebook_path // empty),
        (.tool_input.paths[]? // empty)
      ' 2>/dev/null | grep -v '^$' || true
    )"
  fi
  if [ -z "${paths}" ]; then
    # Fallback: scan for "file_path": "..." style values.
    paths="$(
      printf '%s' "${p}" | grep -oE '"(file_path|path|notebook_path)"[[:space:]]*:[[:space:]]*"[^"]+"' \
        | sed -E 's/.*:[[:space:]]*"([^"]+)"/\1/' | grep -v '^$' || true
    )"
  fi
  printf '%s' "${paths}"
}

edited_paths="$(extract_paths "${payload}")"
if [ -n "${edited_paths}" ]; then
  log "Edited file(s): $(printf '%s' "${edited_paths}" | tr '\n' ' ')"
else
  log "Could not extract file path from payload; continuing with drift check"
fi

# --- Bail out silently if not an AGE repo -----------------------------------
if ! is_age_repo; then
  log "Not an AGE repo; skipping drift check"
  exit 0
fi

# --- Run scoped drift detection ---------------------------------------------
# `age sync --json --since HEAD` returns a JSON report with stale/orphan/missing
# arrays (CONTRACT.md §3). Exit 0 = no drift, 1 = drift present.
drift_json="$(run_age sync --json --since HEAD 2>/dev/null)"
sync_rc=$?

# run_age returns 0 when the CLI is missing (treated as no-op); distinguish
# "missing CLI" from "ran clean". If the CLI is missing, drift_json is empty.
if ! age_resolve_cli >/dev/null 2>&1; then
  log "age CLI missing; skipping drift check (non-blocking)"
  exit 0
fi

# sync_rc == 0 → no drift. Stay silent (no output, exit 0).
if [ "${sync_rc}" -eq 0 ]; then
  log "No drift detected (age sync exit 0)"
  exit 0
fi

# --- Drift present: build a compact reminder --------------------------------
# Parse the drift JSON. The `age sync --json` schema (cli/lib/sync.sh) is:
#   stale[]   = {module, owner, changed_file}
#   orphan[]  = {module, owner}
#   missing[] = {file}
# Prefer jq for clean extraction; fall back to a raw excerpt if absent.
format_drift() {
  local json="$1"
  if command -v jq >/dev/null 2>&1; then
    local stale orphan missing
    stale="$(printf '%s' "${json}" | jq -r '
      .stale[]? | "  - stale: \(.module) → \(.owner)  (changed: \(.changed_file))"' 2>/dev/null || true)"
    orphan="$(printf '%s' "${json}" | jq -r '
      .orphan[]? | "  - orphan: \(.module) → \(.owner)  (code module gone)"' 2>/dev/null || true)"
    missing="$(printf '%s' "${json}" | jq -r '
      .missing[]? | "  - missing: \(.file)  (no owner doc / route entry)"' 2>/dev/null || true)"
    [ -n "${stale}" ]   && printf '%s\n' "${stale}"
    [ -n "${orphan}" ]  && printf '%s\n' "${orphan}"
    [ -n "${missing}" ] && printf '%s\n' "${missing}"
  else
    # No jq: surface a trimmed raw excerpt so the reminder still fires.
    printf '%s\n' "$(printf '%s' "${json}" | head -c 600)"
  fi
}

drift_summary="$(format_drift "${drift_json}")"
if [ -z "${drift_summary}" ]; then
  # Couldn't parse specifics but sync reported drift (rc=1). Give a generic nudge.
  drift_summary="  - (age sync reported drift but details could not be parsed; run /age-sync for the full report)"
fi

log "Drift detected; emitting reminder"

# Compose the reminder. Reference the edited file so the agent connects the
# edit to the docs that need updating.
edited_inline="$(printf '%s' "${edited_paths}" | tr '\n' ' ' | sed 's/ *$//')"
if [ -n "${edited_inline}" ]; then
  header="AGE drift detected after editing: ${edited_inline}"
else
  header="AGE drift detected after an edit"
fi

message=$(printf '%s\n\n%s\n\n%s' \
  "${header}" \
  "The following docs are out of sync and may need updating:" \
  "${drift_summary}")
message="${message}

Run /age-sync to review and apply doc updates, or /age-route to confirm the owner docs for this change."

emit_context "${message}"
exit 0

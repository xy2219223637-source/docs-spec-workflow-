#Requires -Version 5.1
# lib.ps1 — AGE hook 共享函数库(PowerShell 版)。
# 被 on-session-start.ps1 / on-edit.ps1 / on-stop.ps1 dot-source 引用。
# 等价于 hooks/scripts/lib.sh。
#
# 铁律(与 .sh 版一致):
#   - 所有 hook 始终 exit 0,永不阻断用户。
#   - CLI 缺失时静默退出(不阻断)。
#   - 日志写到 <project>/.age/hooks.log。
#   - 上下文注入走 stdout JSON,严格 schema({"additionalContext":"..."} 或
#     OpenCode 的 {"message":"..."}),无多余键。

# 防止重复加载(等价 lib.sh 的 AGE_HOOK_LIB_LOADED 守卫)。
if ($script:AGE_HOOK_LIB_LOADED) { return }
$script:AGE_HOOK_LIB_LOADED = $true

# -----------------------------------------------------------------------------
# 路径
# -----------------------------------------------------------------------------

# Get-PluginRoot:定位插件根目录(等价 age_plugin_root)。
# 优先级:$env:ZCODE_PLUGIN_ROOT → $env:CLAUDE_PLUGIN_ROOT → 脚本位置向上两级。
# 输出插件根路径字符串;找不到目录则返回空串。
function Get-PluginRoot {
  if ($env:ZCODE_PLUGIN_ROOT -and (Test-Path -LiteralPath $env:ZCODE_PLUGIN_ROOT -PathType Container)) {
    return $env:ZCODE_PLUGIN_ROOT
  }
  if ($env:CLAUDE_PLUGIN_ROOT -and (Test-Path -LiteralPath $env:CLAUDE_PLUGIN_ROOT -PathType Container)) {
    return $env:CLAUDE_PLUGIN_ROOT
  }
  # lib.ps1 位于 <root>/hooks/scripts/lib.ps1 → 向上两级。
  # $PSScriptRoot 在 dot-source 后仍指向本文件所在目录(PowerShell 5.1+)。
  $scriptDir = $PSScriptRoot
  if (-not $scriptDir) {
    # 极端回退:用 $MyInvocation 解析(仅在直接运行时有效,dot-source 时为空)。
    $scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Definition
  }
  if ($scriptDir) {
    $root = (Resolve-Path -LiteralPath (Join-Path $scriptDir '..\..') -ErrorAction SilentlyContinue).Path
    if ($root -and (Test-Path -LiteralPath $root -PathType Container)) {
      return $root
    }
  }
  return ''
}

# Get-ProjectDir:定位项目目录(等价 age_project_dir)。
# 优先级:$env:ZCODE_PROJECT_DIR → $env:CLAUDE_PROJECT_DIR → git root → cwd。
# 注意:CODEX_HOME / OPENCODE_CONFIG 指向*配置*目录而非项目目录,故不用。
function Get-ProjectDir {
  if ($env:ZCODE_PROJECT_DIR -and (Test-Path -LiteralPath $env:ZCODE_PROJECT_DIR -PathType Container)) {
    return $env:ZCODE_PROJECT_DIR
  }
  if ($env:CLAUDE_PROJECT_DIR -and (Test-Path -LiteralPath $env:CLAUDE_PROJECT_DIR -PathType Container)) {
    return $env:CLAUDE_PROJECT_DIR
  }
  # 回退到 git 仓库根(适用于 Codex/OpenCode/裸 shell)。
  $gitCmd = Get-Command git -ErrorAction SilentlyContinue
  if ($gitCmd) {
    $gitRoot = & git rev-parse --show-toplevel 2>$null
    if ($LASTEXITCODE -eq 0 -and $gitRoot -and (Test-Path -LiteralPath $gitRoot -PathType Container)) {
      return $gitRoot.Trim()
    }
  }
  return (Get-Location).Path
}

# Resolve-AgeCli:定位 age CLI(等价 age_resolve_cli)。
# 优先级:Win11 PowerShell 入口 $pluginRoot/cli/age.ps1 →
#         bash 入口 $pluginRoot/cli/age →
#         CLAUDE_PLUGIN_ROOT 下同名 → PATH 上的 age。
# 找到则输出命令字符串(含路径,可直接 & 调用),找不到返回 $null。
function Resolve-AgeCli {
  $root = Get-PluginRoot
  if ($root) {
    # 优先 Win11 PowerShell 入口 cli/age.ps1(§8.12 双层策略:PowerShell 原生层)。
    $ps1Path = Join-Path $root 'cli\age.ps1'
    if (Test-Path -LiteralPath $ps1Path -PathType Leaf) {
      return $ps1Path
    }
    # 回退到 bash 入口 cli/age(Git-Bash 兼容层;在 Win11 上需 Git-Bash,但若
    # 用户装了 Git-Bash 且 age 可执行则仍可用)。
    $shPath = Join-Path $root 'cli\age'
    if (Test-Path -LiteralPath $shPath -PathType Leaf) {
      return $shPath
    }
  }
  if ($env:CLAUDE_PLUGIN_ROOT -and (Test-Path -LiteralPath $env:CLAUDE_PLUGIN_ROOT -PathType Container)) {
    $ps1Path = Join-Path $env:CLAUDE_PLUGIN_ROOT 'cli\age.ps1'
    if (Test-Path -LiteralPath $ps1Path -PathType Leaf) { return $ps1Path }
    $shPath = Join-Path $env:CLAUDE_PLUGIN_ROOT 'cli\age'
    if (Test-Path -LiteralPath $shPath -PathType Leaf) { return $shPath }
  }
  # 回退到 PATH 上的 age。
  $ageCmd = Get-Command age -ErrorAction SilentlyContinue
  if ($ageCmd) { return $ageCmd.Source }
  return $null
}

# -----------------------------------------------------------------------------
# 日志
# -----------------------------------------------------------------------------

# Get-AgeLogFile:日志文件路径 <project>/.age/hooks.log(等价 age_log_file)。
function Get-AgeLogFile {
  $proj = Get-ProjectDir
  return (Join-Path $proj '.age\hooks.log')
}

# Write-AgeLog:写日志(等价 age_log)。
# 尽力而为:缺失 .age/ 目录时自动创建;日志失败绝不阻断 hook。
# 参数:Level, Message
function Write-AgeLog {
  param(
    [Parameter(Mandatory=$true, Position=0)][string]$Level,
    [Parameter(Mandatory=$true, Position=1, ValueFromRemainingArguments)][string[]]$Message
  )
  $logFile = Get-AgeLogFile
  $logDir = Split-Path -Parent $logFile
  if (-not (Test-Path -LiteralPath $logDir -PathType Container)) {
    New-Item -ItemType Directory -Path $logDir -Force -ErrorAction SilentlyContinue | Out-Null
  }
  $ts = (Get-Date -Format 'yyyy-MM-ddTHH:mm:sszzz')
  $line = "[$ts] [$Level] $($Message -join ' ')"
  Add-Content -LiteralPath $logFile -Value $line -ErrorAction SilentlyContinue
}

# 便捷封装(等价 log/warn/err)。
# 接受多个位置参数(用 ValueFromRemainingArguments,等价 bash "$@")并拼成
# 单条消息传给 Write-AgeLog。
function Log  { param([Parameter(ValueFromRemainingArguments)][string[]]$Msg) Write-AgeLog 'INFO'  @Msg }
function Warn { param([Parameter(ValueFromRemainingArguments)][string[]]$Msg) Write-AgeLog 'WARN'  @Msg }
function Err  { param([Parameter(ValueFromRemainingArguments)][string[]]$Msg) Write-AgeLog 'ERROR' @Msg }

# -----------------------------------------------------------------------------
# 仓库检测
# -----------------------------------------------------------------------------

# Test-AgeRepo:检测是否 AGE 仓库(等价 is_age_repo)。
# 严格按契约 §5:仅认 docs/index.md(更保守,避免仅有 AGENTS.md 的非 AGE 仓库
# 误触发。详见 §8.6 J 的协调请求:当前实现以契约 §5 字面为准)。
# 返回 $true/$false。
function Test-AgeRepo {
  $proj = Get-ProjectDir
  $index = Join-Path $proj 'docs\index.md'
  return (Test-Path -LiteralPath $index -PathType Leaf)
}

# -----------------------------------------------------------------------------
# Hook 输出辅助
# -----------------------------------------------------------------------------

# Detect-HookClient:检测当前 hook 运行所在的客户端(等价 detect_hook_client)。
# 优先用环境变量(多客户端共存时最可靠),回退到配置文件特征。
# 输出:zcode|claude|codex|opencode|unknown(§8.11 CP-8)。
function Detect-HookClient {
  # 环境变量优先。
  if ($env:ZCODE_PLUGIN_ROOT -and (Test-Path -LiteralPath $env:ZCODE_PLUGIN_ROOT -PathType Container)) { return 'zcode' }
  if ($env:ZCODE_PROJECT_DIR -and (Test-Path -LiteralPath $env:ZCODE_PROJECT_DIR -PathType Container)) { return 'zcode' }
  if ($env:CLAUDE_PLUGIN_ROOT -and (Test-Path -LiteralPath $env:CLAUDE_PLUGIN_ROOT -PathType Container)) { return 'claude' }
  if ($env:CLAUDE_PROJECT_DIR -and (Test-Path -LiteralPath $env:CLAUDE_PROJECT_DIR -PathType Container)) { return 'claude' }
  if ($env:CODEX_HOME -and (Test-Path -LiteralPath $env:CODEX_HOME -PathType Container)) { return 'codex' }
  if ($env:OPENCODE_CONFIG) { return 'opencode' }
  # 回退:配置文件/目录特征。
  $cwd = (Get-Location).Path
  if (Test-Path -LiteralPath (Join-Path $cwd '.zcode') -PathType Container) { return 'zcode' }
  if ((Test-Path -LiteralPath (Join-Path $cwd '.claude') -PathType Container) -or
      (Test-Path -LiteralPath (Join-Path $env:HOME '.claude') -PathType Container)) { return 'claude' }
  if ($env:HOME -and (Test-Path -LiteralPath (Join-Path $env:HOME '.codex') -PathType Container)) { return 'codex' }
  if ((Test-Path -LiteralPath (Join-Path $cwd 'opencode.json') -PathType Leaf) -or
      ($env:HOME -and (Test-Path -LiteralPath (Join-Path $env:HOME '.config\opencode') -PathType Container))) { return 'opencode' }
  return 'unknown'
}

# Emit-Context:输出上下文注入 JSON 到 stdout(等价 emit_context)。
# 按当前客户端输出格式(§8.11 CP-8):
#   ZCode/Claude/Codex/unknown → {"additionalContext": "<text>"}
#   OpenCode                   → {"message": "<text>"}
# 无内容时输出空 JSON 数组 [](等价 .sh 版"无话可说则不输出";此处为保持
# PowerShell 输出确定性,输出空对象,下游忽略)。
#
# JSON 转义:ConvertTo-Json 对字符串会加额外换行与引号包裹,故手动转义以
# 产出严格单行 schema({"key":"value"}),与 zcode-guide diagnosing-hooks
# 要求的严格 schema 一致(无多余键、单行)。转义顺序:反斜杠→引号→换行→
# 制表符→回车(与 .sh 版 awk 转义顺序一致)。
function Emit-Context {
  param([Parameter(Mandatory=$true)][string]$Text)
  $client = Detect-HookClient
  $key = if ($client -eq 'opencode') { 'message' } else { 'additionalContext' }
  $s = $Text
  $s = $s -replace '\\', '\\'
  $s = $s -replace '"', '\"'
  $s = $s -replace "`r`n", "`n"   # 先归一化 CRLF→LF(Win11 路径常见)
  $s = $s -replace "`n", '\n'
  $s = $s -replace "`t", '\t'
  $s = $s -replace "`r", '\r'
  # 输出严格单行 JSON。
  [Console]::Out.Write("{`"$key`":`"$s`"}")
}

# Invoke-Age:调用 age CLI 并返回结果(等价 run_age)。
# CLI 缺失时返回空串并写 WARN 日志(不阻断)。
# 参数:Args — 传给 age 的参数数组。
# 输出:age 的 stdout 内容。脚本可通过 $LASTEXITCODE 判断退出码。
# Invoke-Age:调用 age CLI 并返回结果(等价 run_age)。
# CLI 缺失时返回空串并写 WARN 日志(不阻断)。
# 参数:CliArgs — 传给 age 的参数数组。
# 输出:age 的 stdout 内容。脚本可通过 $LASTEXITCODE 判断退出码。
# 注意:不能用 $Args 作参数名(它是 PowerShell 自动变量)。
function Invoke-Age {
  param([Parameter(ValueFromRemainingArguments)][string[]]$CliArgs)
  $cli = Resolve-AgeCli
  if (-not $cli) {
    Warn "age CLI not found; skipping command: age $($CliArgs -join ' ')"
    return ''
  }
  # 调用 CLI,合并 stderr 到 stdout 以便调用方统一解析(audit 的违规走 stderr)。
  $output = & $cli @CliArgs 2>&1
  return ($output -join "`n")
}

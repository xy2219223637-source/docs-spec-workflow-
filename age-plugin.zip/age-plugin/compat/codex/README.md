# Codex CLI 适配说明

> 本目录是 AGE 插件对 OpenAI Codex CLI 的适配配置。所有权归事实设计 agent(见 CONTRACT.md §8.11)。
>
> **修订说明(2026-07-11,CP-1 二次校验后):** Codex 升级为 **full** 级。原事实表"Codex 无 hooks/skills"经权威源码验证为**严重错误**——Codex 有完整 hooks(PascalCase,与 Claude Code 事件名一致)+ skills(`.codex/skills/SKILL.md`)+ AGENTS.md。本文件已全面修订。

## 兼容等级:full

Codex CLI 经 CP-1 二次校验确认具备**完整**扩展能力,与 Claude Code 同级(full):

| 能力 | Codex CLI 机制 | AGE 适配 | 等级 |
|---|---|---|---|
| MCP server | `~/.codex/config.toml` 的 `[mcp_servers.NAME]` 段 | `compat/codex/config.toml` | ✅ |
| 指令文件 | `AGENTS.md`(项目根,Codex 原生读取) | 共用 AGE 的 `templates/repo/AGENTS.md` | ✅ |
| Skills | `.codex/skills/<name>/SKILL.md`(PascalCase 目录,与 Claude Code 一致) | `compat/codex/skills/`(`age install` 拷贝/链接 age skills) | ✅ |
| Hooks | `config.toml` 的 `[hooks]` 段(PascalCase 事件名,与 Claude Code 一致:SessionStart/PostToolUse/Stop 等) | `compat/codex/config.toml` 的 `[hooks]` 段 | ✅ |
| Slash commands | **无标准**(用 AGENTS.md 引导 + CLI 子命令替代) | 用 `age route`/`age sync`/`age audit` 等 CLI 替代 | ⚠️(CLI 替代) |

**CP-1 校验关键结论:** Codex hooks 事件名是 **PascalCase**(与 Claude Code 一致:`PreToolUse`/`PostToolUse`/`SessionStart`/`Stop` 等),配置在 `~/.codex/config.toml` 的 `[hooks]` 段。这与原事实表"Codex 无 hooks"完全相反。skills 用 `.codex/skills/<name>/SKILL.md` 格式,与 ZCode/Claude Code 一致。

## config.toml 格式

Codex CLI 用 TOML 配置(`~/.codex/config.toml`,用户级)。MCP server 配置在 `[mcp_servers.NAME]` 段,hooks 配置在 `[hooks.EVENT_NAME]` 段:

```toml
[mcp_servers.age-mcp]
command = "python3"
args = ["/absolute/path/to/mcp/server.py"]

[mcp_servers.age-mcp.env]
AGE_PLUGIN_ROOT = "/absolute/path/to/age-plugin"
AGE_PROJECT_ROOT = "/path/to/your/project"

# Hooks(PascalCase 事件名,与 Claude Code 一致)
[hooks.SessionStart]
command = "bash /absolute/path/to/age-plugin/hooks/scripts/on-session-start.sh"

[hooks.PostToolUse]
matcher = "Edit|Write|MultiEdit"
command = "bash /absolute/path/to/age-plugin/hooks/scripts/on-edit.sh"

[hooks.Stop]
command = "bash /absolute/path/to/age-plugin/hooks/scripts/on-stop.sh"
```

与 ZCode/Claude Code 的区别:

- **TOML 格式**(非 JSON)。`env` 是独立的 `[mcp_servers.NAME.env]` 子表,不能内联在 server 段里。hooks 是 `[hooks.EVENT_NAME]` 子表。
- **无变量展开**:Codex 的 TOML 不支持 `${VAR}` 或 `$VAR` 展开,路径必须写**绝对路径**。`age install` 会把当前 AGE 插件根与项目根的绝对路径写入。
- **用户级配置**:Codex 无标准的工作区级配置文件,MCP server 与 hooks 配置写 `~/.codex/config.toml`(全局)。若多个项目用 AGE,需为每个项目维护一份配置(或用不同 server 名,如 `age-mcp-myproj`)。
- **Hooks 事件名 PascalCase**:与 Claude Code 完全一致(`SessionStart`/`PostToolUse`/`Stop`),与 OpenCode 的 dot-notation 小写(`tool.execute.after`)不同。故 AGE 的 hooks 脚本可直接复用,无需适配事件名。

### Hooks 段详解

`config.toml` 的 `[hooks]` 段配置 Codex 的事件触发器,对应 AGE 的三个核心 hook(CONTRACT.md §5):

| Codex hook 事件 | 对应 AGE 行为 | 调用脚本 | 说明 |
|---|---|---|---|
| `SessionStart` | 会话开始注入 `docs/context/` 摘要 | `hooks/scripts/on-session-start.sh` | 调 `age doctor`(无参)+ 读 context(见 §8.1 [D-5] 修复) |
| `PostToolUse`(matcher `Edit\|Write\|MultiEdit`) | 编辑后触发漂移检测提醒 | `hooks/scripts/on-edit.sh` | 调 `age sync --json` |
| `Stop` | 收尾一致性检查 | `hooks/scripts/on-stop.sh` | 调 `age audit --scope closure` |

hooks 脚本与 ZCode/Claude Code **完全共用同一份**(`hooks/scripts/*.sh`),`lib.sh` 已内置对多客户端 env 的回退支持(见 CONTRACT.md §8.6 K)。Codex 下脚本通过 `AGE_PLUGIN_ROOT`(config.toml 的 env 段注入的绝对路径)定位 CLI 与脚本。

### AGENTS.md 共用

Codex CLI 原生读取项目根的 `AGENTS.md` 作为指令文件。AGE 的 `templates/repo/AGENTS.md` 渲染到目标项目后,Codex 直接消费,**无需额外适配**。

`AGENTS.md` 是跨客户端通用契约的**源文件**(见 `compat/README.md` 的"AGENTS.md vs CLAUDE.md"小节)。Codex 与 OpenCode 都直接读它;Claude Code 读的是它的生成副本 `CLAUDE.md`。

### Skills 机制

Codex skills 用 `.codex/skills/<name>/SKILL.md` 格式,与 ZCode/Claude Code 一致。`age install` 会把 AGE 的 skills(`skills/age/`、`skills/use-AGE/`)拷贝或软链到 `.codex/skills/`。详见 `compat/codex/skills/README.md`。

### 无标准 slash commands 的限制

Codex CLI 支持完整 hooks + skills + MCP + AGENTS.md,但**无标准 slash commands 机制**。AGE 的 slash commands(`/age-route`、`/age-sync`、`/age-audit`、`/use-age`)在 Codex 下由以下方式替代:

| AGE slash command | Codex 替代方式 |
|---|---|
| `/age-route` | `age route "<task>" --explain`(CLI 子命令) |
| `/age-sync` | `age sync --json`(CLI 子命令) |
| `/age-audit` | `age audit --scope closure`(CLI 子命令) |
| `/age-init` | `age init --name <X> --kind <web\|mobile\|cli>`(CLI 子命令) |
| `/use-age` | `age use`(CLI 子命令,激活 AGE,未初始化则自动 init) |

此外,会话内可通过 MCP tools(`age_route`、`age_check_drift` 等)调等价能力,agent 通过读 `AGENTS.md` 获取完整操作契约。

## 安装步骤

### 方式一:`age install` 自动安装(推荐)

```bash
# 在项目根运行(需 age CLI 已就绪)
age install
```

`age install` 检测到 Codex CLI 后,会:

1. 读取/创建 `~/.codex/config.toml`。
2. 把 `compat/codex/config.toml` 的 `[mcp_servers.age-mcp]` + `[hooks]` 段合并写入(把路径占位符替换为当前 AGE 插件根与项目根的绝对路径)。
3. 把 AGE skills(`skills/age/`、`skills/use-AGE/`)拷贝/软链到 `.codex/skills/`(见 `compat/codex/skills/README.md`)。
4. 确保 `age` CLI 在 PATH(提示用户软链 `cli/age`)。
5. 若项目尚未初始化 AGE,提示跑 `age use` 或 `age init`。
6. 跑 `age doctor` 验证。

### 方式二:手动安装

```bash
# 假设 AGE 插件仓库在 /path/to/age-plugin,目标项目在 /path/to/myproj
AGE_SRC=/path/to/age-plugin
DST=/path/to/myproj
CODEX_HOME=~/.codex

# 1. 把 [mcp_servers.age-mcp] + [hooks] 段追加到 ~/.codex/config.toml(手动编辑,把路径改成绝对路径)
mkdir -p $CODEX_HOME
# 编辑 $CODEX_HOME/config.toml,加入 compat/codex/config.toml 的内容,把
#   /path/to/age-plugin/mcp/server.py 改成 $AGE_SRC/mcp/server.py 的绝对路径
#   AGE_PLUGIN_ROOT 改成 $AGE_SRC 的绝对路径
#   AGE_PROJECT_ROOT 改成 $DST 的绝对路径
#   hooks 脚本路径改成 $AGE_SRC/hooks/scripts/*.sh 的绝对路径

# 2. 拷贝/链接 skills 到 .codex/skills/(见 compat/codex/skills/README.md)
mkdir -p $CODEX_HOME/skills
ln -s $AGE_SRC/skills/age $CODEX_HOME/skills/age
ln -s $AGE_SRC/skills/use-AGE $CODEX_HOME/skills/use-AGE

# 3. 确保 age CLI 在 PATH
ln -s $AGE_SRC/cli/age /usr/local/bin/age

# 4. 在项目里初始化 AGE(若尚未)
cd $DST
age init --name myproj --kind web
age baseline

# 5. 验证
age doctor
```

## 使用

安装后,在 Codex CLI 里打开该项目:

- **激活 AGE**:跑 `age use`(未初始化则自动 init)。Codex 也会自动加载 `.codex/skills/use-AGE/SKILL.md`,自然语言"启动 AGE / use AGE"可触发激活。
- **日常开发**(hooks 自动触发,与 ZCode/Claude Code 一致):
  - 会话开始:`SessionStart` hook 自动注入 `docs/context/` 摘要。
  - 编辑后:`PostToolUse` hook 自动触发漂移检测提醒(`age sync --json`)。
  - 任务收尾:`Stop` hook 自动跑收尾审计(`age audit --scope closure`)。
- **任务前路由**:跑 `age route "<task>" --explain`(读哪些 owner 文档),或调 MCP `age_route`。
- **MCP tools**:Codex 会话内可调用 `age_route`、`age_check_drift` 等 MCP tools(经 config.toml 的 age-mcp server)。
- **AGENTS.md**:Codex 自动读项目根 `AGENTS.md`,获取完整操作契约(路由规则、禁止行为、收尾审计流程等)。
- **skills**:Codex 自动加载 `.codex/skills/age/SKILL.md`(元 skill)与 `.codex/skills/use-AGE/SKILL.md`(激活器)。

## 文件清单

| 文件 | 作用 |
|---|---|
| `config.toml` | Codex MCP 配置(`[mcp_servers.age-mcp]` 段)+ hooks 配置(`[hooks]` 段,TOML 格式) |
| `skills/README.md` | Codex skills 适配说明(`.codex/skills/` 拷贝/链接 age skills) |

## 已知限制

- **无标准 slash commands**:Codex 支持 hooks+skills+MCP+AGENTS.md,但无标准 slash commands 机制。`/age-*` commands 用 CLI 子命令(`age route` 等)替代。
- config.toml 是用户级,多项目需维护多份配置(或用项目级 PATH 与软链隔离)。
- TOML 不展开环境变量,路径必须写绝对值;`age install` 自动写入正确路径,手动安装需自行替换。
- Codex CLI 的 hooks/skills/MCP 支持以官方文档为准;本适配基于 CONTRACT.md §8.11 CP-1 二次校验结论,若 Codex 升级机制变化,需同步本目录。

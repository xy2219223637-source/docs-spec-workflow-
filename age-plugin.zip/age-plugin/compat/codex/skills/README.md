# Codex Skills 适配说明

> 本目录说明 AGE 插件的 skills 如何适配 Codex CLI 的 skills 机制。所有权归事实设计 agent(见 CONTRACT.md §8.11)。
>
> **CP-2 新建(2026-07-11):** CP-1 二次校验确认 Codex 支持 skills(`.codex/skills/<name>/SKILL.md`),格式与 ZCode/Claude Code 一致。本文件指导 `age install` 如何把 AGE 的 skills 适配到 Codex。

## Codex skills 机制

Codex CLI 用 `.codex/skills/<name>/SKILL.md` 格式加载 skills,与 ZCode(`skills/<name>/SKILL.md` 插件根)和 Claude Code(`.claude/skills/<name>/SKILL.md` 工作区)的目录结构与文件格式**完全一致**:

```
.codex/skills/
├── age/
│   ├── SKILL.md                  # AGE 元 skill(路由/同步/审计编排大脑)
│   └── references/
│       ├── routing-rules.md      # 路由决策表
│       ├── baseline-schema.md    # 基线 schema
│       └── sync-checklist.md     # 同步清单
└── use-AGE/
    └── SKILL.md                  # AGE 激活器(自然语言"启动 AGE"触发)
```

`SKILL.md` 用 YAML frontmatter(`name` / `description`)+ Markdown 正文,与 ZCode/Claude Code 的 skill 文件格式相同,无需翻译。

## 适配方式:拷贝或软链

`age install` 检测到 Codex CLI 后,把 AGE 插件根的 skills 适配到 Codex 的 skills 目录:

| AGE 源(插件根) | Codex 目标 | 方式 |
|---|---|---|
| `skills/age/` | `.codex/skills/age/` | 拷贝或软链 |
| `skills/use-AGE/` | `.codex/skills/use-AGE/` | 拷贝或软链 |

**软链(推荐):** 若 `.codex/` 与 AGE 插件根在同一文件系统,用符号链接,保持 skills 与插件源同步更新:

```bash
mkdir -p ~/.codex/skills
ln -s /path/to/age-plugin/skills/age ~/.codex/skills/age
ln -s /path/to/age-plugin/skills/use-AGE ~/.codex/skills/use-AGE
```

**拷贝:** 若跨文件系统或需锁定版本,直接拷贝:

```bash
mkdir -p ~/.codex/skills
cp -R /path/to/age-plugin/skills/age ~/.codex/skills/age
cp -R /path/to/age-plugin/skills/use-AGE ~/.codex/skills/use-AGE
```

> 拷贝方式下,AGE skills 更新后需重新跑 `age install` 或手动重新拷贝,否则 Codex 用的是旧版 skills。软链方式则自动跟随源更新。

## 与 ZCode/Claude Code 的一致性

三个客户端的 skills 格式完全一致,AGE 的 skill 文件(`skills/age/SKILL.md`、`skills/use-AGE/SKILL.md`)无需任何修改即可在 Codex 下工作:

| 客户端 | skills 目录 | 格式 | AGE 适配 |
|---|---|---|---|
| ZCode(一等宿主) | 插件根 `skills/`(`plugin.json` 声明) | `SKILL.md` + frontmatter | 原生,无需适配 |
| Claude Code | 工作区 `.claude/skills/` | `SKILL.md` + frontmatter | 拷贝(见 `compat/claude-code/README.md`) |
| Codex CLI | `.codex/skills/` | `SKILL.md` + frontmatter | 拷贝或软链(见本文件) |

skill 文件内的路径引用(如 `references/routing-rules.md`)是相对于 skill 目录的相对路径,三个客户端下均能正确解析。

## 已知限制

- `.codex/skills/` 是用户级目录(`~/.codex/skills/`),非工作区级。多项目共用同一份 skills(与 ZCode 插件根 skills 语义一致)。若需项目级隔离,需手动维护。
- Codex skills 的自动触发(基于 `description` 的语义匹配)以 Codex 官方实现为准;本适配假设 Codex 与 Claude Code 的 skill 触发机制一致(CP-1 校验结论)。
- 本目录只提供**适配说明**(`README.md`),不含 skill 文件本身——skill 源文件在 AGE 插件根 `skills/`,`age install` 负责拷贝/软链。

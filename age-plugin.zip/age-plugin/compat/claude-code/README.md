# Claude Code 适配说明

> 本目录是 AGE 插件对 Claude Code 的适配配置。所有权归事实设计 agent(见 CONTRACT.md §8.11)。

## Claude Code 的扩展机制

Claude Code 没有 `plugin.json` 这类统一 manifest,而是通过一组**约定文件**与目录承载扩展能力:

| 能力 | Claude Code 机制 | AGE 适配文件 |
|---|---|---|
| 指令文件(系统提示) | `CLAUDE.md`(项目根或 `.claude/`) | `compat/claude-code/CLAUDE.md` |
| MCP server | `.mcp.json`(项目根,顶层 `mcpServers`) | `compat/claude-code/.mcp.json` |
| Hooks | `.claude/settings.json` 的 `hooks` 段(事件名 PascalCase) | `compat/claude-code/settings.json` |
| Skills | `.claude/skills/<name>/SKILL.md` | 复制 AGE 插件 `skills/age/`、`skills/use-AGE/` 到 `.claude/skills/` |
| Slash commands | `.claude/commands/<name>.md`(frontmatter) | 复制 AGE 插件 `commands/*.md` 到 `.claude/commands/` |

### `.claude/` 目录约定

Claude Code 在项目根读取 `.claude/` 目录,内含:

- `settings.json` — 工作区级设置(含 hooks)。
- `skills/<name>/SKILL.md` — 技能(与 ZCode 的 `skills/<name>/SKILL.md` 同构,只是目录前缀不同)。
- `commands/<name>.md` — slash commands(与 ZCode 的 `commands/*.md` 同构)。

> Claude Code 也支持用户级 `~/.claude/settings.json`,但 AGE 的 hooks/skills/commands 是**项目级**的(绑定具体仓库的 `docs/` 与 `AGENTS.md`),故适配配置放工作区级 `.claude/`。

### settings.json 的 hooks 格式

Claude Code 的 `settings.json` hooks 结构:

```jsonc
{
  "hooks": {
    "<EventName>": [           // 事件名 PascalCase,如 SessionStart / PostToolUse / Stop
      {
        "matcher": "<regex>",  // 可选,匹配工具名(PostToolUse 用);SessionStart/Stop 可省略
        "hooks": [
          {
            "type": "command",
            "command": "<shell command>",  // 执行的命令
            "timeout": <seconds>           // 可选,超时秒数
          }
        ]
      }
    ]
  }
}
```

与 ZCode 的 `hooks.json` 区别:

- ZCode 用 `${ZCODE_PLUGIN_ROOT}` 定位插件根;**Claude Code 无此变量**,用 `$CLAUDE_PROJECT_DIR`(工作区根)或相对路径。本适配用 `$CLAUDE_PROJECT_DIR/.age-plugin/hooks/scripts/...` 形式(假设 AGE 插件仓库被放在项目内的 `.age-plugin/` 子目录),或让 `age install` 把脚本路径写死为绝对路径。
- AGE 的 hook 脚本(`hooks/scripts/*.sh`)内部已通过 `lib.sh` 兼容 `CLAUDE_PROJECT_DIR`(见 CONTRACT.md §8.6 K),脚本本身无需改动,只需 settings.json 正确指向。

### `.mcp.json` 格式

Claude Code 的 `.mcp.json` 放项目根,顶层 `mcpServers`:

```jsonc
{
  "mcpServers": {
    "<name>": {
      "command": "<executable>",
      "args": ["<arg>", ...],
      "cwd": "<dir>",          // 可选
      "env": { "<KEY>": "<value>", ... }  // 可选
    }
  }
}
```

与 ZCode `plugin.json` 的 `mcpServers` 结构几乎一致,但:

- ZCode 用 `${ZCODE_PLUGIN_ROOT}`、`${ZCODE_PROJECT_DIR}` 等变量;**Claude Code 不展开这些变量**,需用绝对路径或 `$CLAUDE_PROJECT_DIR`。
- Claude Code 的 `.mcp.json` 是项目级(放仓库根),首次使用会提示用户授权信任。

## 安装步骤

### 方式一:`age install` 自动安装(推荐)

```bash
# 在项目根运行(需 age CLI 已就绪)
age install
```

`age install` 检测到 Claude Code 后,会:

1. 创建 `.claude/` 目录(若不存在)。
2. 把 `compat/claude-code/settings.json` 写入 `.claude/settings.json`(若已有 settings.json,合并 hooks 段)。
3. 把 `compat/claude-code/.mcp.json` 写入项目根 `.mcp.json`。
4. 把 `compat/claude-code/CLAUDE.md` 写入项目根 `CLAUDE.md`。
5. 复制 AGE 插件 `skills/age/`、`skills/use-AGE/` 到 `.claude/skills/`;复制 `commands/*.md` 到 `.claude/commands/`。
6. 提示用户在 Claude Code 里信任 `.mcp.json`(首次连接 MCP server 需用户确认)。

### 方式二:手动安装

```bash
# 假设 AGE 插件仓库在 /path/to/age-plugin,目标项目在 /path/to/myproj
AGE_SRC=/path/to/age-plugin
DST=/path/to/myproj

# 1. 拷贝配置文件
cp $AGE_SRC/compat/claude-code/settings.json $DST/.claude/settings.json
cp $AGE_SRC/compat/claude-code/.mcp.json      $DST/.mcp.json
cp $AGE_SRC/compat/claude-code/CLAUDE.md      $DST/CLAUDE.md

# 2. 拷贝 skills 与 commands
cp -r $AGE_SRC/skills/age      $DST/.claude/skills/age
cp -r $AGE_SRC/skills/use-AGE  $DST/.claude/skills/use-AGE
cp    $AGE_SRC/commands/*.md   $DST/.claude/commands/

# 3. 确保 age CLI 在 PATH(供 MCP server 与 hooks 调用)
ln -s $AGE_SRC/cli/age /usr/local/bin/age

# 4. 验证
age doctor
```

> **路径注意:** `settings.json` 与 `.mcp.json` 中的脚本/server 路径用 `$CLAUDE_PROJECT_DIR/.age-plugin/...` 占位。如果你的 AGE 插件不在项目内的 `.age-plugin/` 子目录,需手动改成实际绝对路径,或用 `age install` 自动写入正确路径。最稳妥的方式是把 AGE 插件仓库克隆到项目内的 `.age-plugin/` 子目录(或软链),让 `$CLAUDE_PROJECT_DIR/.age-plugin` 成立。

## 使用

安装后,在 Claude Code 里打开该项目:

- **激活 AGE**:对 Claude 说"启动 AGE / use AGE / enable AGE",或运行 `/use-age` slash command。`use-AGE` skill 自动触发,未初始化则自动 `age init`。
- **日常开发**:`SessionStart` hook 注入 `docs/context/` 摘要;`PostToolUse` hook 在编辑后提醒漂移;`Stop` hook 跑收尾审计。
- **手动触发**:`/age-route`、`/age-sync`、`/age-audit`、`/age-init` slash commands。
- **MCP tools**:Claude 会话内可调用 `age_route`、`age_check_drift`、`age_propose_doc_update`、`age_evolve` 等 MCP tools,以及读 `docs://index`、`docs://status` 等 resources。

## 文件清单

| 文件 | 作用 |
|---|---|
| `settings.json` | hooks 配置(SessionStart→on-session-start.sh、PostToolUse→on-edit.sh、Stop→on-stop.sh) |
| `.mcp.json` | MCP 配置(`mcpServers.age-mcp`,指向 `mcp/server.py`) |
| `CLAUDE.md` | Claude Code 指令文件(AGENTS.md 的 Claude 语境版) |

## 已知限制

- Claude Code 无 `${ZCODE_PLUGIN_ROOT}`,路径用 `$CLAUDE_PROJECT_DIR` 或绝对路径;`age install` 会写入正确路径。
- MCP server 首次连接需用户在 Claude Code 内信任 `.mcp.json`。
- `.claude/skills/` 与 `.claude/commands/` 是 AGE 插件 `skills/`、`commands/` 的副本;AGE 升级后需重新同步(`age install` 重跑,或手动覆盖)。

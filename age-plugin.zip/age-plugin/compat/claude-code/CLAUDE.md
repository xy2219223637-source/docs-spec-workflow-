# CLAUDE.md — {{project_name}} 代理操作契约(Claude Code 版)

> **⚠️ 源文件标注(CP-5):本文件是 `AGENTS.md` 的生成副本。`AGENTS.md` 是源文件,修改操作契约时改 `AGENTS.md`,然后 `age install` 重新生成本文件。直接改本文件会在下次 `age install` 被覆盖。**
>
> 本文件是本仓库所有 AI agent(含 Claude Code 会话、子代理、CI)的操作契约。它是 AGE(Attractor-Guided Engineering)插件生成的 `AGENTS.md` 的 **Claude Code 语境版**——语义契约与 `AGENTS.md` 完全一致,只是把"AGE 插件"语境换成"Claude Code 下的 AGE",并引用 `.claude/skills/`、`.claude/commands/` 而非插件根路径。
>
> **Owner:** {{owner_name}}(为空时由首次 `age init` 填入)
> **Project kind:** {{project_kind}}  **Doc language:** {{doc_language}}  **Require backlog:** {{require_backlog}}
>
> 若 `AGENTS.md` 与本文件冲突,以 `AGENTS.md`(通用契约源)为准;修改操作契约时改 `AGENTS.md`,然后 `age install` 重新生成本文件,两者自动同步。

## 1. 事实来源优先级(铁律)

冲突时按此链裁决,高者优先:

1. **owner 文档** — `docs/context/`、`docs/backlog/`、`docs/requirements/`、`docs/design/`、`docs/architecture/`
2. **计划** — `docs/plans/`
3. **日志** — `docs/logs/`
4. **聊天** — 任何会话内口头决定(含 Claude Code 会话)

聊天决定不得沉默覆盖 owner 文档。若聊天与 owner 文档冲突:owner 文档胜,直到被显式更新(开独立任务)。

## 2. 路由规则

**所有任务的入口是 `docs/index.md`**——它是本仓库的文档路由器。开始任何任务前:

1. 读 `docs/index.md` 的路由表,确定本任务该读哪些 owner 文档。
2. 若 `docs/index.md` 对本任务类型沉默,回退到 AGE 默认路由(见 `.claude/skills/age/references/routing-rules.md`)。
3. 机械替代:`age route "<task>" --explain` 输出 READ 集 + WRITEBACK 集 + 技能路由。

强制上下文(每次会话必读,Claude Code `SessionStart` hook 自动注入摘要):

- `docs/context/project-context.md`
- `docs/context/ai-autonomy-policy.md`
- `docs/context/codebase-map.md`
- `docs/context/source-of-truth-and-precedence.md`
- `docs/context/conventions.md`

## 3. 技能选择记录(每个计划阶段必填)

AGE 是**方法选择器**:它决定每个任务阶段用哪个项目技能,自己不替代项目技能。在 `docs/plans/` 的每个计划里,**每个阶段必须记录**:

```
### 阶段 N: <阶段名>
Skill: <skill-name>      # 或 Skill: none(无项目技能,直接走 owner 文档)
READ: <owner 文档列表>
WRITEBACK: <owner 文档列表,或 none>
```

- `Skill: none` 是合法值,表示"本阶段无项目专属技能,按 owner 文档执行"。不要留空。
- 若 AGE 路由选了某技能但执行中发现不适用,改记 `Skill: none` 并在日志说明原因。
- 这条记录是 AGE 可审计性的核心——`age audit` 会校验计划文件含每阶段的 `Skill:` 行。

## 4. 验证命令(收尾门禁)

本仓库的验证命令:
```
{{validate_cmd}}
```
- **非空时**:每个任务收尾前必须跑此命令并绿。`age audit --scope closure` 会跑它。
- **为空时**(`{{validate_cmd}}` 渲染为空字符串):收尾审计跳过验证步骤,`age audit` 只查文档一致性。此时不意味着"不验证"——若项目有测试,Claude 仍应手动跑,只是 AGE 不强制。

## 5. 禁止行为

1. **禁止沉默绕过 owner 文档。** 任务前不读 READ 集、任务后不回写 WRITEBACK 集,均为违规。
2. **禁止跨 WRITEBACK 集回写。** doc-sync 只改 route 标记的 WRITEBACK 集;实质性的额外变更开新任务。
3. **禁止沉默式重构。** 任何架构变更(模块边界/依赖方向/技术选型)必须先有 `docs/plans/` 计划 + 产出 ADR 入 `docs/audits/`。
4. **禁止用聊天决定覆盖 owner 文档。** 见 §1。
5. **禁止跳过收尾审计。** 未跑 `age audit --scope closure` 的任务不算完成。
6. **禁止手动重算 `age sync`/`age check`。** 机械活交给 CLI;判断层保持 prose。
7. **禁止删除或留空强制上下文文件。** `docs/context/` 五个文件必须存在且非空骨架。

## 6. 计划审计(进入 `docs/plans/` 前)

满足任一条件必须先进 `docs/plans/`(见 AGE `.claude/skills/age/references/sync-checklist.md`):跨多 owner 文档、≥3 阶段、涉及架构、用户要方案。计划文件最小内容:

- 目标
- READ 集 / WRITEBACK 集
- 分阶段步骤(每阶段 `Skill:` 记录)
- 验收标准
- 关联需求/backlog ID

`age audit --scope plan` 审查计划:每阶段有 `Skill:` 行、WRITEBACK 集在基线 schema 内、验收标准可被 `{{validate_cmd}}` 覆盖(若 validate_cmd 非空)。

## 7. 收尾审计(任务完成前)

每个任务收尾必跑:
```bash
{{validate_cmd}}                    # 若非空
age sync --since <task-start-ref>   # 漂移检测
age check                           # 静态一致性
age audit --scope closure           # 收尾门禁
```
- 全绿 → 任务完成,日志记审计简报。
- 任一失败 → 回 doc-sync 修复;无法修(需大改 owner 文档)→ 本任务标 `已阻塞`,新开任务。

## 8. 周期审计

- **每里程碑或每周**:`age audit --scope full`,报告入 `docs/audits/`。
- **CI**:`age ci`(= `age check --strict` + `age sync --json`),非交互,阻断合并。

## 9. AGE 在 Claude Code 下的引用

AGE 的元 skill 与 use-AGE skill 在 Claude Code 下位于 `.claude/skills/`(ZCode 下位于插件根 `skills/`):

- 元 skill:`.claude/skills/age/SKILL.md`
- 激活器:`.claude/skills/use-AGE/SKILL.md`
- 路由决策表:`.claude/skills/age/references/routing-rules.md`
- 基线 schema:`.claude/skills/age/references/baseline-schema.md`
- 同步清单:`.claude/skills/age/references/sync-checklist.md`
- 文档路由器(本仓库):`docs/index.md`

Slash commands(Claude Code 下位于 `.claude/commands/`):

- `/age-init` — 初始化 AGE 骨架
- `/age-route` — 任务前路由
- `/age-sync` — 任务后同步
- `/age-audit` — 审计
- `/use-age` — 激活 AGE(自然语言"启动 AGE"等同义触发)

MCP tools(Claude Code 会话内,经 `.mcp.json` 的 `age-mcp` server 暴露):

- `age_route(task)` / `age_check_drift(scope?)` / `age_propose_doc_update(change)` / `age_evolve(task_id)`
- resources:`docs://index`、`docs://context/project-context`、`docs://status`

## 10. 激活 AGE

在新项目或未初始化的项目里,对 Claude 说"启动 AGE / use AGE / enable AGE"等,或运行 `/use-age`。`use-AGE` skill 会检测初始化状态,未初始化则自动 `age init`(生成 `docs/`、`AGENTS.md`、`.age/baseline.json`)。

> 本文件由 `age init` / `age install` 从 AGE 插件模板渲染(`compat/claude-code/CLAUDE.md` 为源)。修改本文件后跑 `age check` 确认引用可解析。语义契约与 `AGENTS.md` 同源,修改时两者同步。

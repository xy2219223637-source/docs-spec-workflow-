// plugin.ts — AGE plugin for OpenCode CLI.
//
// Implements the OpenCode Plugin interface (Hooks), verified against the local
// @opencode-ai/plugin SDK 1.17.18 type definitions at:
//   /Users/ale/.opencode/node_modules/@opencode-ai/plugin/dist/index.d.ts
//
// Authoritative facts (verified 2026-07-11 against SDK 1.17.18):
//   - OpenCode hooks are a PLUGIN mechanism, not a config-file hook system.
//     The `opencode.json` `"hooks": "@/hooks"` style does NOT wire events;
//     events are implemented as methods on the Hooks interface returned by a
//     Plugin function `(input, options?) => Promise<Hooks>`.
//   - The Hooks interface exposes these events (each an optional async fn):
//       dispose, event, config, tool, auth, provider,
//       chat.message, chat.params, chat.headers,
//       permission.ask, command.execute.before,
//       tool.execute.before, tool.execute.after, shell.env,
//       experimental.*
//   - There is NO SessionStart and NO Stop event. (CP-1 conclusion confirmed.)
//   - tool.execute.after is the real PostToolUse equivalent.
//   - tool.execute.before is the PreToolUse equivalent.
//   - chat.message fires on each incoming user message — a partial substitute
//     for SessionStart (it can inject AGE context per turn).
//
// OpenCode runs TypeScript via Bun, so we use the Node-compatible
// child_process module (Bun polyfills it) to invoke the `age` CLI.

import type { Plugin, Hooks } from "@opencode-ai/plugin";
import { spawnSync } from "child_process";
import { existsSync, readFileSync } from "fs";
import { join } from "path";

// Context files injected on chat.message (partial SessionStart substitute).
// Order matters: project-context first (mission/phase), then constraints.
const CONTEXT_FILES = [
  "project-context.md",
  "ai-autonomy-policy.md",
  "codebase-map.md",
  "source-of-truth-and-precedence.md",
  "conventions.md",
] as const;

// Throttle chat.message context injection to once per session so we do not
// re-append the full context block on every turn. OpenCode does not expose a
// session-start event, so this per-turn hook is the closest anchor.
const injectedSessions = new Set<string>();

/**
 * Resolve the AGE plugin root (where cli/age, hooks/scripts, templates live).
 * Priority: AGE_PLUGIN_ROOT env > walk up from input.directory for a `cli/age`.
 */
function resolvePluginRoot(directory: string): string | null {
  const envRoot = process.env.AGE_PLUGIN_ROOT;
  if (envRoot && existsSync(join(envRoot, "cli/age"))) {
    return envRoot;
  }
  // Walk up from the project directory looking for cli/age.
  let dir = directory;
  for (let i = 0; i < 8; i++) {
    if (existsSync(join(dir, "cli/age"))) return dir;
    const parent = join(dir, "..");
    if (parent === dir) break;
    dir = parent;
  }
  return envRoot || null;
}

/**
 * Resolve the `age` executable path. Prefer PATH lookup; fall back to
 * <pluginRoot>/cli/age so a non-installed dev checkout still works.
 */
function resolveAgeBinary(pluginRoot: string | null): string {
  // If `age` is on PATH, use it.
  try {
    const which = spawnSync("command", ["-v", "age"], {
      shell: true,
      encoding: "utf8",
    });
    if (which.status === 0 && which.stdout.trim()) {
      return which.stdout.trim();
    }
  } catch {
    // ignore — fall through to plugin-root path
  }
  if (pluginRoot && existsSync(join(pluginRoot, "cli/age"))) {
    return join(pluginRoot, "cli/age");
  }
  return "age"; // last resort: rely on PATH at exec time
}

/**
 * Run `age sync --json` in the project directory. Returns parsed drift JSON
 * (stale/orphan/missing arrays) or null on failure. Exit 0 = no drift,
 * exit 1 = drift present (both are normal, non-error outcomes).
 */
function runAgeSyncJson(
  ageBin: string,
  projectDir: string,
): { stale?: unknown[]; orphan?: unknown[]; missing?: unknown[] } | null {
  let result;
  try {
    result = spawnSync(ageBin, ["sync", "--json"], {
      cwd: projectDir,
      encoding: "utf8",
      timeout: 30_000,
    });
  } catch {
    return null;
  }
  // age CLI not found / not executable — nothing to do.
  if (result.error || typeof result.stdout !== "string") return null;
  const stdout = result.stdout.trim();
  if (!stdout) return null;
  // `age sync --json` may print log lines before the JSON; find the first
  // line that starts with '{' and parse from there.
  const jsonStart = stdout.indexOf("{");
  if (jsonStart < 0) return null;
  const jsonText = stdout.slice(jsonStart);
  try {
    return JSON.parse(jsonText);
  } catch {
    return null;
  }
}

/**
 * Build a compact context summary from docs/context/*.md. Returns null when
 * the project is not AGE-managed (no docs/context dir).
 */
function buildContextSummary(projectDir: string): string | null {
  const ctxDir = join(projectDir, "docs", "context");
  if (!existsSync(ctxDir)) return null;
  const lines: string[] = [];
  for (const name of CONTEXT_FILES) {
    const p = join(ctxDir, name);
    if (!existsSync(p)) continue;
    try {
      const text = readFileSync(p, "utf8");
      // Take the first non-empty meaningful lines (title + first paragraph).
      const compact = text
        .split("\n")
        .map((l: string) => l.trim())
        .filter((l: string) => l && !l.startsWith("<!--"))
        .slice(0, 6)
        .join(" / ");
      if (compact) lines.push(`- [${name}] ${compact}`);
    } catch {
      // skip unreadable file
    }
  }
  if (lines.length === 0) return null;
  return [
    "[AGE context] Project context injected by the AGE OpenCode plugin (chat.message hook, partial SessionStart substitute):",
    ...lines,
    "[AGE] Run `/age-route <task>` before coding; run `/age-audit` at task closure (OpenCode has no Stop hook).",
  ].join("\n");
}

/**
 * Append a text part to an OpenCode output `parts` array. The Hooks interface
 * types `parts` as `Part[]`; a Part may be a text part. We push a minimal
 * text part object so OpenCode renders it inline.
 */
function appendTextPart(parts: unknown[], text: string): void {
  // Part shape (from @opencode-ai/sdk): { type: "text", text: string }.
  // We cast loosely because the SDK Part union is broad; the text variant is
  // the safe, always-renderable member.
  (parts as Array<Record<string, unknown>>).push({
    type: "text",
    text,
  });
}

const plugin: Plugin = async (input, _options) => {
  const projectDir = input.directory || process.cwd();
  const pluginRoot = resolvePluginRoot(projectDir);
  const ageBin = resolveAgeBinary(pluginRoot);

  const hooks: Hooks = {
    // chat.message: fires on each incoming user message. Partial substitute
    // for SessionStart — injects the docs/context/ summary once per session
    // so the agent starts each task aware of the AGE project contract.
    "chat.message": async (hookInput, output) => {
      const sessionID = hookInput.sessionID || "";
      if (injectedSessions.has(sessionID)) return;
      const summary = buildContextSummary(projectDir);
      if (!summary) return; // not an AGE-managed project; stay silent
      injectedSessions.add(sessionID);
      appendTextPart(output.parts as unknown[], summary);
    },

    // tool.execute.after: fires after every tool execution (the real
    // PostToolUse equivalent per SDK 1.17.18). Runs `age sync --json` to
    // detect doc/code drift and appends a reminder when drift is found.
    // NOTE: OpenCode fires this after ALL tools, not just Edit/Write — so we
    // keep the work cheap (a single git-diff based sync) and only append a
    // short nudge, letting the user run `/age-sync` for the full flow.
    "tool.execute.after": async (hookInput, output) => {
      const drift = runAgeSyncJson(ageBin, projectDir);
      if (!drift) return; // age not available or sync failed — stay silent
      const stale = Array.isArray(drift.stale) ? drift.stale.length : 0;
      const orphan = Array.isArray(drift.orphan) ? drift.orphan.length : 0;
      const missing = Array.isArray(drift.missing) ? drift.missing.length : 0;
      const total = stale + orphan + missing;
      if (total === 0) return; // no drift — nothing to add
      const nudge = [
        `[AGE drift] Detected ${total} doc/code drift item(s) after tool execution`,
        `(stale=${stale}, orphan=${orphan}, missing=${missing}).`,
        `Run \`/age-sync\` to review and reconcile, or \`age sync --json\` for raw output.`,
      ].join(" ");
      // Append to the tool's output so the drift nudge is visible inline.
      const existing = output.output ? output.output + "\n" : "";
      output.output = existing + nudge;
    },

    // tool.execute.before: PreToolUse equivalent. Optional, currently a
    // no-op placeholder — kept so AGE can later wire `age route` based
    // routing checks before a tool runs without breaking the Hooks contract.
    "tool.execute.before": async (_hookInput, _output) => {
      // Intentionally empty: routing is surfaced via the /age-route command.
      // Hook signature is (input: {tool, sessionID, callID}, output: {args}).
    },

    // dispose: cleanup when the plugin unloads. Clear the per-session
    // injection cache so re-loading the plugin in the same process re-injects.
    dispose: async () => {
      injectedSessions.clear();
    },
  };

  return hooks;
};

export default plugin;

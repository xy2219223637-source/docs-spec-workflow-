# OpenCode CLI 适配说明

> 本目录是 AGE 插件对 OpenCode CLI 的适配配置。所有权归事实设计 agent(见 CONTRACT.md §8.11)。
>
> **修订说明(2026-07-11,CP-4 plugin-based 重写):** 基于本机真实环境重写。本机验证源:`@opencode-ai/plugin` SDK **1.17.18**(路径 `/Users/ale/.opencode/node_modules/@opencode-ai/plugin/dist/index.d.ts`),本机 `opencode` 版本 **1.17.18**。关键纠正:OpenCode hooks 是 **plugin 机制**(实现 `Hooks` 接口的 JS/TS 模块),**不是配置文件式钩子** —— `opencode.json` 里不能配置事件钩子,必须写一个 plugin 模块(`plugin.ts`),通过 `opencode plugin` 安装或在 `opencode.json` 的 `plugin` 数组里引用。原 `opencode.json` 里的 `hooks` 键已移除(错误),改为 `plugin` 引用 + `plugin.ts` 实现。

## 兼容等级:partial

OpenCode CLI 经本机 SDK 1.17.18 类型定义校验确认为 **partial** 级:支持 MCP + commands + AGENTS.md + plugin hooks(`tool.execute.after` / `tool.execute.before` / `chat.message`),但 **无 SessionStart、无 Stop 事件**。

| 能力 | OpenCode CLI 机制 | AGE 适配 | 等级 |
|---|---|---|---|
| MCP server | `opencode.json` 的 `mcp` 键(`command` 为数组) | `opencode.json` 的 `mcp.age-mcp` | ✅ |
| Commands | `opencode.json` 的 `commands` 键(内联 prompt,非文件) | `opencode.json` 的 `commands`(use-age/route/sync/audit) | ✅ |
| 指令文件 | `AGENTS.md`(项目根,OpenCode 原生读取) | 共用 AGE 的 `templates/repo/AGENTS.md` | ✅ |
| Skills | **无**(用 commands 替代) | 不可用,用 commands + AGENTS.md 替代 | ❌ |
| Hooks(plugin) | plugin 模块实现 `Hooks` 接口 | `plugin.ts`(实现 `Plugin` 函数) | ✅ |
| Hooks(PostToolUse) | `tool.execute.after`(plugin hook,真实对应) | `plugin.ts` 的 `tool.execute.after` | ✅ |
| Hooks(PreToolUse) | `tool.execute.before`(plugin hook,对应) | `plugin.ts` 的 `tool.execute.before`(可选,no-op 占位) | ⚠️(预留) |
| Hooks(SessionStart) | `chat.message`(plugin hook,部分替代,每轮注入) | `plugin.ts` 的 `chat.message`(每会话首条消息注入 context) | ⚠️(部分替代) |
| Hooks(Stop) | **无此事件** | 不可行,降级为手动 `/age-audit` | ❌ |

**本机校验关键结论(SDK 1.17.18,权威):**

1. **hooks 是 plugin 机制,不是配置文件钩子。** `opencode.json` 的 `hooks` 键 **不能** 用来配置事件钩子(原配置错误,已移除)。hooks 必须实现 `Hooks` 接口,写成一个 JS/TS plugin 模块,通过 `opencode plugin <module>` 安装,或在 `opencode.json` 的 `"plugin": ["./plugin.ts"]` 数组里引用。
2. **Plugin 函数签名:** `(input: PluginInput, options?: PluginOptions) => Promise<Hooks>`。`PluginInput` 含 `directory`(项目根,优先于 `process.cwd()`)、`project`、`worktree`、`serverUrl`、`$`(BunShell)、`client`。
3. **Hooks 接口完整事件列表(SDK 1.17.18 `index.d.ts`):** `dispose`、`event`、`config`、`tool`、`auth`、`provider`、`chat.message`、`chat.params`、`chat.headers`、`permission.ask`、`command.execute.before`、`tool.execute.before`、`shell.env`、`tool.execute.after`、`experimental.*`。
4. **没有 SessionStart、没有 Stop。** CP-1 结论正确,本机 SDK 复核确认。
5. **`tool.execute.after` 是 PostToolUse 的真实对应**(input: `{tool, sessionID, callID, args}`,output: `{title, output, metadata}`),可用于漂移检测。
6. **`tool.execute.before` 是 PreToolUse 的对应**(input: `{tool, sessionID, callID}`,output: `{args}`),可用于路由。
7. **`chat.message` 可部分替代 SessionStart** —— 每次用户发消息时触发(input 含 `sessionID`,`output.parts` 可追加 context)。`plugin.ts` 用它会话内首条消息注入 `docs/context/` 摘要。

## 降级操作清单(替代缺失的 SessionStart/Stop hooks)

OpenCode 无 SessionStart/Stop 事件,用户需**手动**执行原本由 hooks 自动触发的操作:

| 缺失的 hook | 原自动行为(ZCode/Claude Code/Codex) | OpenCode 降级操作 |
|---|---|---|
| `SessionStart` | 会话开始自动注入 `docs/context/` 摘要 | **部分自动**:`plugin.ts` 的 `chat.message` 在会话首条消息注入 context(每会话一次);或手动跑 `/age-sync`,或读 MCP resource `docs://context/project-context` |
| `Stop` | 任务收尾自动跑 `age audit --scope closure` | **手动**(无对应事件):任务收尾跑 `/age-audit`(触发 `age audit --scope closure`),或直接 CLI `age audit --scope closure` |

**保留的 plugin hooks(`plugin.ts` 实现):**

| plugin hook | 对应 AGE 事件 | 行为 |
|---|---|---|
| `tool.execute.after` | PostToolUse | 工具执行后调 `age sync --json` 检测漂移,有漂移则在 output 追加提醒(真实 PostToolUse 对应,非近似)。注意:OpenCode 在所有工具执行后触发,非仅 Edit/Write。 |
| `chat.message` | SessionStart(部分替代) | 每会话首条用户消息时注入 `docs/context/` 摘要到 `output.parts`(部分替代缺失的 SessionStart)。 |
| `tool.execute.before` | PreToolUse(预留) | no-op 占位,后续可接 `age route` 路由检查。 |
| `dispose` | — | 插件卸载时清理会话内注入缓存。 |

**推荐工作流(OpenCode 降级版):**

1. **会话开始**:`plugin.ts` 的 `chat.message` 在首条消息自动注入 context(部分替代 SessionStart);或手动跑 `/age-sync` 获取完整上下文摘要。
2. **任务前路由**:跑 `/age-route "<task>"` 或 `age route "<task>" --explain`。
3. **编辑后**:`plugin.ts` 的 `tool.execute.after` 自动调 `age sync --json` 检测漂移,有漂移则追加提醒;或手动跑 `/age-sync` 走完整 reconcile 流程。
4. **任务收尾**:手动跑 `/age-audit`(无 Stop hook,手动降级),确保 `age audit --scope closure` 全绿。

## opencode.json 格式(plugin-based)

```jsonc
{
  "plugin": ["./plugin.ts"],          // hooks 走 plugin 模块,不是配置键
  "mcp": {
    "<name>": {
      "type": "local",
      "command": ["<executable>", "<arg>", ...],  // command 是数组,非字符串
      "enabled": true,
      "environment": { "<KEY>": "<value>" }
    }
  },
  "commands": {
    "<name>": {
      "description": "<...>",
      "prompt": "<内联 prompt 文本>"           // commands 是内联 prompt,不是文件路径
    }
  }
  // 注意:没有 "hooks" 键。hooks 必须在 plugin.ts 里实现 Hooks 接口。
}
```

与其他客户端的区别:

- **hooks 走 plugin 模块**(实现 `Hooks` 接口的 JS/TS),而非 `opencode.json` 配置键。Claude Code/Codex/ZCode 在配置文件里写事件钩子;OpenCode 必须写 plugin 模块并在 `plugin` 数组引用。
- **MCP 的 `command` 是数组**(Claude Code/ZCode 用 `command` 字符串 + `args` 数组;OpenCode 合并为单个数组)。
- **commands 是内联 prompt**(Claude Code/ZCode 用 `.md` 文件 + frontmatter;OpenCode 直接在 JSON 里写 prompt 文本)。AGE 的 `commands/*.md` 内容被翻译成 `opencode.json` 的内联 prompt。
- **事件名 dot-notation 小写**(`tool.execute.after` 等),与 ZCode/Claude Code/Codex 的 PascalCase(`PostToolUse` 等)不同,但这是 plugin 接口的方法名,不是配置键。
- **无 SessionStart/Stop 事件**(本机 SDK 复核确认),`chat.message` 部分替代 SessionStart,Stop 无对应只能手动降级。
- **无 skills 机制**:AGE 元 skill 的语义判断无法作为 skill 加载,用 commands 近似覆盖 + agent 读 `AGENTS.md` 获取完整契约。

### AGENTS.md 共用

OpenCode CLI 原生读取项目根 `AGENTS.md` 作为指令文件。AGE 的 `templates/repo/AGENTS.md` 渲染后,OpenCode 直接消费,**无需额外适配**。`AGENTS.md` 是跨客户端通用契约的源文件(见 `compat/README.md` 的"AGENTS.md vs CLAUDE.md"小节)。

## 安装步骤

### 方式一:`age install` 自动安装(推荐)

```bash
# 在项目根运行(需 age CLI 已就绪)
age install --client opencode
```

`age install` 检测到/指定 OpenCode CLI 后,会:

1. 把 `compat/opencode/opencode.json` 合并到项目根 `opencode.json`(合并 mcp/commands/plugin 段;路径占位符替换为绝对路径)。
2. 把 `compat/opencode/plugin.ts` 拷贝到项目根 `plugin.ts`(若已存在则跳过,不覆盖)。
3. 把 `compat/opencode/package.json` 拷贝到项目根(若已存在则跳过)。
4. 提示用户运行 `opencode plugin ./plugin.ts` 安装 AGE plugin(或在 `opencode.json` 的 `plugin` 数组已引用,opencode 启动时自动加载)。
5. 若项目尚未初始化 AGE,提示跑 `age use` 或 `age init`。
6. 跑 `age doctor` 验证。

### 方式二:手动安装

```bash
# 假设 AGE 插件仓库在 /path/to/age-plugin,目标项目在 /path/to/myproj
AGE_SRC=/path/to/age-plugin
DST=/path/to/myproj

# 1. 拷贝 opencode.json + plugin.ts + package.json 到项目根
cp $AGE_SRC/compat/opencode/opencode.json $DST/opencode.json
cp $AGE_SRC/compat/opencode/plugin.ts      $DST/plugin.ts
cp $AGE_SRC/compat/opencode/package.json   $DST/package.json

# 2. 编辑 $DST/opencode.json:把 "$AGE_PLUGIN_ROOT" 占位符改成 $AGE_SRC 的绝对路径

# 3. 安装 plugin 依赖(opencode 用 Bun 运行 TS,可直接 import @opencode-ai/plugin)
cd $DST
opencode plugin ./plugin.ts      # 显式安装
# 或 opencode.json 已含 "plugin": ["./plugin.ts"],启动 opencode 时自动加载

# 4. 确保 age CLI 在 PATH
ln -s $AGE_SRC/cli/age /usr/local/bin/age

# 5. 在项目里初始化 AGE(若尚未)
cd $DST
age init --name myproj --kind web
age baseline

# 6. 验证
age doctor
```

## 使用

安装后,在 OpenCode CLI 里打开该项目:

- **激活 AGE**:用 `/use-age` command(OpenCode 内联 command),或手动跑 `age use`。
- **会话开始**:`plugin.ts` 的 `chat.message` 在首条消息自动注入 context(部分替代 SessionStart);或手动跑 `/age-sync` / 读 MCP resource `docs://context/project-context`。
- **日常开发**:
  - 编辑后:`plugin.ts` 的 `tool.execute.after` 自动调 `age sync --json` 检测漂移,有漂移则追加提醒;或手动跑 `/age-sync`。
  - 任务前路由:`/age-route "<task>"` 或 `age route "<task>" --explain`。
- **任务收尾**(无 Stop hook,手动降级):跑 `/age-audit`(触发 `age audit --scope closure`),确保收尾门禁全绿。
- **commands**:`/use-age`、`/age-route`、`/age-sync`、`/age-audit`(OpenCode 内联 command 版,prompt 精简自 AGE 的 `commands/*.md`)。
- **MCP tools**:会话内可调用 `age_route`、`age_check_drift` 等(经 opencode.json 的 mcp.age-mcp)。
- **AGENTS.md**:OpenCode 自动读项目根 `AGENTS.md`,获取完整操作契约。

## 文件清单

| 文件 | 作用 |
|---|---|
| `opencode.json` | MCP + commands + plugin 引用(无 hooks 键)配置 |
| `plugin.ts` | OpenCode AGE plugin 模块(实现 `Hooks` 接口:chat.message / tool.execute.after / tool.execute.before / dispose) |
| `package.json` | plugin 模块的 package.json(name `@age/opencode-plugin`,依赖 `@opencode-ai/plugin` 1.17.18) |

## 已知限制

- **无 SessionStart/Stop 事件**(本机 SDK 1.17.18 复核确认):`chat.message` 部分替代 SessionStart(每会话首条消息注入 context),但 Stop 无对应,收尾审计需**手动**触发(`/age-audit`)。
- **hooks 走 plugin 模块**:不能在 `opencode.json` 配置事件钩子,必须写 `plugin.ts` 实现 `Hooks` 接口并在 `plugin` 数组引用,或跑 `opencode plugin ./plugin.ts` 安装。这是 OpenCode 与其他客户端的本质区别。
- **无 skills 机制**:AGE 元 skill 的语义判断靠 commands(精简版)+ AGENTS.md(完整版)近似覆盖。
- commands 是内联 prompt,无法承载 AGE `commands/*.md` 的全部步骤细节;复杂场景需 agent 主动读 `AGENTS.md` 与 `age <cmd> --help`。
- `tool.execute.after` 是所有工具执行后触发(非仅 Edit/Write),`plugin.ts` 保持 `age sync --json` 调用轻量(git-diff based)并只追加短提醒,避免拖慢每一步工具调用。
- MCP 的 `command` 是数组格式,与 ZCode/Claude Code 的 `command`+`args` 不同;`age install` 会按 OpenCode 格式写入。
- 验证来源:本机 `@opencode-ai/plugin` SDK 1.17.18(`/Users/ale/.opencode/node_modules/@opencode-ai/plugin/dist/index.d.ts`)。若 OpenCode 升级 SDK 改变 Hooks 接口,需同步本目录与 `plugin.ts`。

# AGE 多客户端兼容层

> 本目录是 AGE 插件对 ZCode 以外客户端的**适配层**。所有权归事实设计 agent + 总调度 agent(见 CONTRACT.md §8.11)。
>
> **修订说明(2026-07-11,CP-1 二次校验后 + Multica 恢复):** 原事实表"Codex 无 hooks/skills"经权威源码验证为**严重错误**,已纠正:Codex 升级为 **full** 级(完整 hooks+skills+MCP)。OpenCode hooks 事件名为 dot-notation 小写且无 SessionStart/Stop,降级为 **partial** 级。Multica 之前因拼写误作 "Mutica" 被误判为"不存在的实验性编程语言"而移除,经本机真实环境验证(真实 AI 原生团队工作区客户端,Go 写的,云 workspace 模式,v0.3.43,有完整 skill+MCP+autopilot 扩展机制)**已恢复为 full 级**。

## 为什么需要兼容层

AGE 的四层架构(插件外壳 / 元 skill / CLI / MCP server)在 ZCode 中以**一等插件**形态工作:`.zcode-plugin/plugin.json` 声明 skills/commands/hooks/agents/mcpServers,ZCode 自动装载。

但其他 AI 编码客户端(Claude Code、OpenAI Codex CLI、OpenCode CLI、Multica)的扩展机制各不相同:

- **没有** `plugin.json` 这类统一 manifest(各自用不同的配置文件与目录约定,或像 Multica 那样用云 workspace CLI 注册)。
- **没有** `${ZCODE_PLUGIN_ROOT}` / `${ZCODE_PROJECT_DIR}` 这类插件根/项目根环境变量(部分客户端有自己的等价物,语义不一;Multica 由 install.sh 经 agent `--custom-env` 注入)。
- Hooks 事件名、skills 目录、slash commands 格式、MCP 配置结构**各家不同**(Multica 甚至没有本地 hooks,用 autopilot 触发器部分替代)。

AGE 的公共层(CLI + AGENTS.md + MCP server)是跨客户端可复用的内核;hooks/commands/skills/指令文件需要按各客户端格式生成**适配配置**。本目录就是这些适配配置的产出地。

## 兼容策略:ZCode 一等宿主 + 其他客户端适配

> 权威源:CONTRACT.md §8.11(经 CP-1 二次校验修订 + Multica 恢复)。**兼容等级**:ZCode=full(原生)、Claude Code=full、Codex CLI=full、OpenCode CLI=partial、Multica=full。

| 层 | ZCode(一等宿主) | Claude Code | Codex CLI | OpenCode CLI | Multica |
|---|---|---|---|---|---|
| 投递外壳 | `.zcode-plugin/plugin.json` | 适配:settings.json + .mcp.json + CLAUDE.md | 适配:config.toml + AGENTS.md | 适配:opencode.json + AGENTS.md | 适配:install.sh 调 multica CLI 注册 skill/agent/autopilot |
| 元 skill | `skills/age/SKILL.md`(自动加载) | `.claude/skills/age/SKILL.md`(复制) | `.codex/skills/age/SKILL.md`(复制/链接) | 无 skills(用 commands) | agent 读 `AGE_PLUGIN_ROOT/skills/age/SKILL.md` |
| use-AGE skill | `skills/use-AGE/SKILL.md` | `.claude/skills/use-AGE/SKILL.md`(复制) | `.codex/skills/use-AGE/SKILL.md`(复制) | 无(用 commands + `age use`) | `compat/multica/use-AGE.skill.md`(skill create 注册到 workspace) |
| CLI | `cli/age`(独立可执行) | 共用同一份 `cli/age` | 共用同一份 `cli/age` | 共用同一份 `cli/age` | 共用同一份 `cli/age`(经 `AGE_PLUGIN_ROOT` 定位) |
| MCP server | `mcp/server.py`(`mcpServers` 声明) | `mcp/server.py`(.mcp.json 指向) | `mcp/server.py`(config.toml 指向) | `mcp/server.py`(opencode.json 指向) | `mcp/server.py`(agent --mcp-config 指向,标准 mcpServers) |
| Hooks | `hooks/hooks.json` + `hooks/scripts/*.sh` | settings.json hooks 段(PascalCase,指向同一套脚本) | config.toml [hooks] 段(PascalCase,与 Claude Code 一致) | opencode.json hooks 段(dot-notation 小写,仅 `tool.execute.after`) | **无本地 hooks**(autopilot schedule/webhook 部分替代) |
| Slash commands | `commands/*.md`(frontmatter) | `.claude/commands/*.md`(frontmatter,复制) | 无标准(用 AGENTS.md + CLI) | opencode.json 内联 commands | 无(用 skill + autopilot 替代) |
| 指令文件 | AGENTS.md(一等) | CLAUDE.md(AGENTS.md 的生成副本) | AGENTS.md(共用) | AGENTS.md(共用) | agent --instructions(=AGENTS.md) |
| 项目根 env | `${ZCODE_PROJECT_DIR}` | `$CLAUDE_PROJECT_DIR`(工作区) | 无标准(cwd) | 无标准(cwd) | `AGE_PROJECT_ROOT`(agent --custom-env) |
| 插件根 env | `${ZCODE_PLUGIN_ROOT}` | 无(用相对路径或脚本自定位) | 无(用脚本自定位) | 无(用脚本自定位) | `AGE_PLUGIN_ROOT`(agent --custom-env,install.sh 注册) |
| **兼容等级** | **full(原生)** | **full** | **full** | **partial** | **full**(skill+MCP+autopilot,无本地 hooks) |

**核心原则:** CLI 与 MCP server 是同一份代码,五个客户端共用;只是各自的配置文件指向它。hooks 脚本(`hooks/scripts/*.sh`)也是同一份,`lib.sh` 已内置对 `CLAUDE_PROJECT_DIR` 的回退支持(见 CONTRACT.md §8.6 K)。Multica 是唯一不拷贝配置文件、而是调 CLI 注册到云 workspace 的客户端。

## 客户端对照表(来自 CONTRACT.md §8.11,CP-1 校验后 + Multica 恢复)

| 维度 | ZCode | Claude Code | Codex CLI | OpenCode CLI | Multica |
|---|---|---|---|---|---|
| 配置语言 | JSON | JSON | TOML | JSON | JSON(云 workspace,CLI 注册) |
| 配置文件(用户) | `~/.zcode/cli/config.json` | `~/.claude/settings.json` | `~/.codex/config.toml` | `~/.config/opencode/opencode.json` | `~/.multica/config.json`(server_url+workspace_id+token) |
| 配置文件(工作区) | `.zcode/config.json` | `.claude/settings.json` + `.mcp.json` | `~/.codex/config.toml`(含 hooks 段) | `opencode.json` | 无(skill/agent/autopilot 注册到云 workspace) |
| MCP 键 | `mcp.servers` | `.mcp.json` 顶层 `mcpServers` | `[mcp_servers.NAME]`(TOML) | `mcp`(`command` 为数组) | agent `--mcp-config`(mcpServers JSON,与 Claude Code 一致) |
| 指令文件 | `AGENTS.md` | `CLAUDE.md` | `AGENTS.md` | `AGENTS.md` | agent `--instructions`(=AGENTS.md) |
| Skills | 目录 + `SKILL.md` | `.claude/skills/SKILL.md` | `.codex/skills/SKILL.md` | 无(用 commands) | `multica skill create` 注册到 workspace(SKILL.md,同格式) |
| Slash commands | `.md` + frontmatter | `.claude/commands/*.md` + frontmatter | 无标准(用 AGENTS.md) | `opencode.json` 内联 commands | 无(用 skill + autopilot 替代) |
| Hooks 事件名 | PascalCase(7 事件) | PascalCase(20+ 事件) | PascalCase(10 事件,与 Claude Code 一致) | dot-notation 小写(`tool.execute.after` 等) | 不适用(无本地 hooks) |
| Hooks 配置位置 | `hooks.json`(插件) | `settings.json` | `config.toml` `[hooks]` 段 | `opencode.json` `hooks` 键 | 无;autopilot `trigger-add`(schedule/webhook)部分替代 |
| 插件打包 | `plugin.json` + marketplace | 无 | 无 | 无 | 无(注册到云 workspace) |
| 项目目录 env | `${ZCODE_PROJECT_DIR}` | `${CLAUDE_PROJECT_DIR}` | 无(用 cwd/git) | 无(用 cwd/git) | `AGE_PROJECT_ROOT`(agent --custom-env) |
| 插件根 env | `${ZCODE_PLUGIN_ROOT}` | 无 | 无 | 无 | `AGE_PLUGIN_ROOT`(agent --custom-env) |
| **兼容等级** | **full(原生)** | **full** | **full**(hooks+skills+MCP) | **partial**(MCP+commands,无 SessionStart/Stop hooks) | **full**(skill+MCP+autopilot,无本地 hooks) |

## 功能降级矩阵(CP-1 校验后 + Multica 恢复)

| 功能 | ZCode | Claude Code | Codex CLI | OpenCode CLI | Multica |
|---|---|---|---|---|---|
| MCP(resources+tools) | ✅ | ✅ | ✅ | ✅ | ✅(agent --mcp-config) |
| AGENTS.md/CLAUDE.md 指令 | ✅ | ✅(CLAUDE.md) | ✅(AGENTS.md) | ✅(AGENTS.md) | ✅(agent --instructions=AGENTS.md) |
| Skills(use-AGE/age 等) | ✅ | ✅ | ✅(`.codex/skills/`) | ❌(用 commands 替代) | ✅(skill create,注册到 workspace) |
| Slash commands | ✅ | ✅ | ❌(用 AGENTS.md 引导) | ✅(内联 prompt) | ❌(用 skill + autopilot 替代) |
| SessionStart hook | ✅ | ✅ | ✅ | ❌ | ⚠️(use-AGE 技能显式激活替代一次性注入) |
| PostToolUse hook | ✅ | ✅ | ✅ | ⚠️(`tool.execute.after`,近似) | ⚠️(autopilot 定时 age sync 部分替代,非实时) |
| Stop hook | ✅ | ✅ | ✅ | ❌ | ⚠️(autopilot 定时 + 对话中触发 closure audit) |
| age install 适配 | 原生 | ✅ | ✅ | ✅ | ✅(调 compat/multica/install.sh 注册技能) |

> **CP-1 关键结论(权威源码验证)+ Multica 恢复(2026-07-11):**
> - **Codex 有完整 hooks**(PascalCase,与 Claude Code 事件名一致:PreToolUse/PostToolUse/SessionStart/Stop 等)+ skills(`.codex/skills/SKILL.md`)+ AGENTS.md。原事实表"Codex 无 hooks/skills"是严重错误,已纠正为 full 级。
> - **OpenCode hooks 不可行配齐**:事件名是 dot-notation 小写(`tool.execute.after`),**无 SessionStart/Stop 事件**,只有 PostToolUse 近似对应。降级为 partial 级,缺失的 SessionStart/Stop 用手动命令替代。
> - **Claude Code 事实正确**:`${CLAUDE_PROJECT_DIR}` 存在,`.mcp.json` 在项目根,hooks 在 settings.json。
> - **Multica 恢复(纠正 CP-1 拼写错误):** Multica 是真实存在的 AI 原生团队工作区客户端(Go 写的,云 workspace 模式)。CP-1 原结论"Mutica 不存在,是实验性编程语言"是**拼写错误导致的误判**——正确拼写是 Multica,且是真实 AI 客户端。本机验证 v0.3.43,有完整 skill(`multica skill create --content-file`)+ MCP(agent `--mcp-config`,标准 mcpServers JSON)+ autopilot(`autopilot create + trigger-add --kind schedule --cron`)+ agent instructions(`--instructions`=AGENTS.md)扩展机制。**无本地 hooks**,SessionStart/Stop 降级为 use-AGE 技能(显式激活)+ autopilot(定时漂移检测)。兼容等级 = **full**。详见 `compat/multica/README.md`。

## AGENTS.md vs CLAUDE.md 的关系(源与副本策略)

AGE 的指令文件采用**单一源文件**策略,避免双源同步漂移:

- **`AGENTS.md` 是源文件**(CONTRACT.md §2,事实设计所有权,模板位于 `templates/repo/AGENTS.md`)。它是跨客户端通用代理操作契约,ZCode / Codex CLI / OpenCode CLI 直接读 `AGENTS.md`。
- **`CLAUDE.md` 是 `AGENTS.md` 的生成副本**(Claude Code 不读 `AGENTS.md`,只读 `CLAUDE.md`,故需生成)。`compat/claude-code/CLAUDE.md` 是 Claude 语境适配源;`age install` / `age init` 把它渲染到目标项目根作为 `CLAUDE.md`。内容契约与 `AGENTS.md` 一致,只是把"AGE 插件"语境换成"Claude Code 下的 AGE",并引用 `.claude/skills/`、`.claude/commands/` 而非插件根路径。

**修改规则(铁律):**
1. 修改操作契约时,**改 `AGENTS.md`**(模板源 `templates/repo/AGENTS.md`),不要直接改 `CLAUDE.md`。
2. 然后跑 `age install` 重新生成 `CLAUDE.md`(从 `compat/claude-code/CLAUDE.md` 模板渲染)。
3. `AGENTS.md` 与 `CLAUDE.md` 由 `age install` / `age init` 一并维护,语义等价,不冲突。

**对应声明:** `AGENTS.md` 模板内已声明"CLAUDE.md 是本文件的 Claude Code 适配副本,由 age install 生成";`CLAUDE.md` 模板开头已标注"本文件是 AGENTS.md 的生成副本"。

## 安装方式

### 方式一:`age install` 自动检测(推荐)

```bash
# 在目标项目根目录运行,自动检测当前宿主客户端并安装适配配置
age install
```

`age install`(CONTRACT.md §8.11,总调度实现)会:

1. 检测当前宿主客户端(通过环境变量/配置文件存在性:`detect_host()`)。
2. 根据检测结果,把 `compat/<client>/` 下对应的配置文件拷贝/合并到目标项目的工作区配置位置:
   - Claude Code → 写 `.claude/settings.json`、`.mcp.json`、`CLAUDE.md`,并把 `.claude/skills/`、`.claude/commands/` 软链或复制到 AGE 插件根的对应目录。
   - Codex CLI → 写 `~/.codex/config.toml` 的 `[mcp_servers.age-mcp]` + `[hooks]` 段(用户级,含 SessionStart/PostToolUse/Stop),并把 `.codex/skills/` 软链/复制到 AGE 插件 skills。
   - OpenCode CLI → 写 `opencode.json`(工作区级,含 mcp + commands + 可行的 `tool.execute.after` hook;SessionStart/Stop 不可行,降级为手动 commands)。
3. 确保 `age` CLI 在 PATH 上可发现(提示用户软链 `cli/age` 或加入 PATH)。
4. 跑 `age doctor` 验证。

> `age install` 的实现归总调度 agent(见 §8.11 所有权表 `cli/lib/install.sh`、`cli/age` 编辑、`cli/lib/common.sh::detect_host()`)。本目录只提供**适配配置的模板内容**,供 `age install` 拷贝/合并。

### 方式二:手动拷贝

如果 `age install` 尚未实现,或你想手动控制,直接把 `compat/<client>/` 下的文件拷贝到对应位置:

- **Claude Code**:见 `compat/claude-code/README.md` 的手动安装步骤。
- **Codex CLI**:见 `compat/codex/README.md`。
- **OpenCode CLI**:见 `compat/opencode/README.md`。

手动安装后,务必确认 `age` CLI 可被发现(软链 `cli/age` 到 PATH),否则 MCP server 与 hooks 无法调用确定性内核。

## 目录结构

```
compat/
├── README.md                  # 本文件:兼容层总说明
├── claude-code/
│   ├── README.md              # Claude Code 适配说明
│   ├── settings.json          # hooks 配置(SessionStart/PostToolUse/Stop,PascalCase)
│   ├── .mcp.json              # MCP 配置(mcpServers.age-mcp)
│   └── CLAUDE.md              # Claude Code 指令文件(AGENTS.md 的生成副本)
├── codex/
│   ├── README.md              # Codex 适配说明(full 级:hooks+skills+MCP)
│   ├── config.toml            # MCP 配置([mcp_servers.age-mcp])+ hooks 配置([hooks] 段)
│   └── skills/
│       └── README.md          # Codex skills 适配说明(.codex/skills/ 链接 age skills)
└── opencode/
    ├── README.md              # OpenCode 适配说明(partial 级:无 SessionStart/Stop)
    └── opencode.json          # MCP + commands + hooks(仅 tool.execute.after)配置
```

> Mutica 已从客户端列表移除(CP-1 校验:不存在,是实验性编程语言非 AI 客户端)。

## 已知限制

1. **OpenCode CLI 无 SessionStart/Stop hooks**:OpenCode hooks 事件名为 dot-notation 小写(`tool.execute.after`),无 SessionStart/Stop 事件,仅 `tool.execute.after` 近似对应 PostToolUse。降级方案:会话开始手动读 `docs://context/project-context`(或跑 `age-sync` command);任务收尾手动跑 `age audit --scope closure`(或 `/age-audit` command)。详见 `compat/opencode/README.md`。
2. **OpenCode CLI 无 skills 机制**:AGE 元 skill 的语义判断层无法作为 skill 加载;用 `opencode.json` 的内联 commands(use-age/route/sync/audit)近似覆盖,agent 通过读 `AGENTS.md` 获取完整操作契约。
3. **Codex CLI 无标准 slash commands**:Codex 支持 hooks(PascalCase)+ skills(`.codex/skills/`)+ AGENTS.md,但无标准 slash commands 机制。slash commands 的能力由 AGENTS.md 引导 + CLI 子命令(`age route` 等)替代。
4. **Claude Code 无 `${ZCODE_PLUGIN_ROOT}`**:hooks/skills/commands 路径用 `$CLAUDE_PROJECT_DIR`(工作区级)或相对路径;插件根定位靠 `lib.sh` 的脚本自定位回退(已实现,见 CONTRACT.md §8.6 K)。
5. **CLAUDE.md 是生成副本**:修改操作契约改 `AGENTS.md`(源),`age install` 重新生成 `CLAUDE.md`。直接改 `CLAUDE.md` 会在下次 `age install` 被覆盖。

## 相关文件

- 客户端对照表权威源:CONTRACT.md §8.11
- 通用指令模板(源):`templates/repo/AGENTS.md`(事实设计)
- Claude 适配指令模板(副本):`compat/claude-code/CLAUDE.md`(事实设计)
- hooks 脚本(跨客户端共用):`hooks/scripts/*.sh`(任务执行),`lib.sh` 已兼容多客户端 env
- MCP server(跨客户端共用):`mcp/server.py`(总调度),已兼容多客户端项目根检测(§8.11 所有权表)
- `age install` 实现:`cli/lib/install.sh`、`cli/lib/common.sh::detect_host()`(总调度,CP-4 待补多客户端共存检测+Codex hooks 安装)

# env-template.ps1
# AGE Plugin — Windows 11 environment variable template
#
# Ownership: 事实设计 agent (CONTRACT.md §8.12)
# Purpose: Set the AGE environment variables that the CLI (cli/age.ps1), MCP
#          server (mcp/server.py), and hook scripts (*.ps1) read to locate the
#          plugin root, project root, documentation language, and Python
#          interpreter.
#
# Usage:
#   1) Dot-source (recommended — variables persist in the current shell):
#        . "$AGE_PLUGIN_ROOT\compat\win11\env-template.ps1"
#   2) Or run directly (variables are set in the script scope; for a fresh
#      shell use dot-sourcing):
#        powershell -File "$AGE_PLUGIN_ROOT\compat\win11\env-template.ps1"
#
# After dot-sourcing, verify with:
#   $env:AGE_PLUGIN_ROOT
#   $env:AGE_PROJECT_ROOT
#   $env:PYTHON_EXEC
#
# IMPORTANT: This is a TEMPLATE. The two paths below use auto-detection by
# default (Find-PluginRoot / Resolve-ProjectDir from path-utils.ps1). If
# auto-detection fails, edit the two $pluginRoot / $projectRoot assignments to
# absolute paths (Windows backslash form, e.g. "C:\path\to\age-plugin").

# Load path utilities (auto-detection helpers). If already loaded, the guard
# inside path-utils.ps1 makes this a no-op.
$win11Dir = Split-Path -Parent $MyInvocation.MyCommand.Path
$pathUtils = Join-Path $win11Dir 'path-utils.ps1'
if (Test-Path -LiteralPath $pathUtils) {
    . $pathUtils
}


# -----------------------------------------------------------------------------
# 1. AGE_PLUGIN_ROOT — the AGE plugin install directory.
#    Used by: cli/age.ps1 (locate lib/*.ps1), hooks (*.ps1 locate CLI),
#    mcp/server.py (locate skills/ + templates/), MCP env injection.
#    Resolution: $env:AGE_PLUGIN_ROOT if set -> Find-PluginRoot -> edit below.
# -----------------------------------------------------------------------------
$pluginRoot = $env:AGE_PLUGIN_ROOT
if ([string]::IsNullOrEmpty($pluginRoot)) {
    $pluginRoot = Find-PluginRoot
}
if ([string]::IsNullOrEmpty($pluginRoot)) {
    # TEMPLATE FALLBACK: edit this to your AGE plugin absolute path.
    # Example: $pluginRoot = "C:\Users\ale\ZCodeProject\age-plugin"
    $pluginRoot = "<插件根>"
}
$env:AGE_PLUGIN_ROOT = $pluginRoot


# -----------------------------------------------------------------------------
# 2. AGE_PROJECT_ROOT — the target repository root being worked on.
#    Used by: mcp/server.py (project root, falls back to AGE_PROJECT_DIR then
#    os.getcwd()), hooks (project-relative paths, .age/hooks.log location).
#    Resolution: $env:AGE_PROJECT_ROOT -> $env:AGE_PROJECT_DIR -> git toplevel
#    -> current directory.
# -----------------------------------------------------------------------------
$projectRoot = $env:AGE_PROJECT_ROOT
if ([string]::IsNullOrEmpty($projectRoot)) {
    $projectRoot = $env:AGE_PROJECT_DIR
}
if ([string]::IsNullOrEmpty($projectRoot)) {
    $projectRoot = Resolve-ProjectDir
}
if ([string]::IsNullOrEmpty($projectRoot)) {
    # TEMPLATE FALLBACK: edit this to your target project absolute path.
    # Example: $projectRoot = "C:\Users\ale\ZCodeProject\my-app"
    $projectRoot = "<项目根>"
}
$env:AGE_PROJECT_ROOT = $projectRoot


# -----------------------------------------------------------------------------
# 3. AGE_DOC_LANGUAGE — documentation language for AGE-generated docs.
#    Used by: age init (template rendering), age route output language,
#    doc-sync conventions. "zh" = Chinese, "en" = English.
# -----------------------------------------------------------------------------
$env:AGE_DOC_LANGUAGE = "zh"


# -----------------------------------------------------------------------------
# 4. PYTHON_EXEC — the Python 3 interpreter command.
#    Used by: mcp/server.py launch (Win11 typically has `python` not `python3`),
#    age doctor (Python sanity check), any CLI step that shells out to Python.
#    Detection order: python -> python3 -> py -3. First one that reports Python
#    3.x wins. If none found, left as "python" (defer the error to first use).
# -----------------------------------------------------------------------------
function _Detect-PythonExec {
    $candidates = @('python', 'python3')
    foreach ($c in $candidates) {
        $cmd = Get-Command $c -ErrorAction SilentlyContinue
        if ($null -eq $cmd) { continue }
        # Confirm it is Python 3.x (python launcher on Win may be a Store stub
        # that prints nothing; guard with try/catch).
        try {
            $ver = & $c --version 2>$null
            if ($LASTEXITCODE -eq 0 -and $ver -match 'Python 3') {
                return $c
            }
        } catch {
            # ignore and try next
        }
    }
    # Windows "py" launcher with explicit -3 (Python 3).
    $pyCmd = Get-Command py -ErrorAction SilentlyContinue
    if ($null -ne $pyCmd) {
        try {
            $ver = & py -3 --version 2>$null
            if ($LASTEXITCODE -eq 0 -and $ver -match 'Python 3') {
                return 'py -3'
            }
        } catch {
            # ignore
        }
    }
    # Default: let the eventual call surface the missing-interpreter error.
    return 'python'
}

if ([string]::IsNullOrEmpty($env:PYTHON_EXEC)) {
    $env:PYTHON_EXEC = _Detect-PythonExec
}


# -----------------------------------------------------------------------------
# Summary (printed when dot-sourced interactively, suppressed under -File when
# stdout must stay clean). Recognize interactive by testing $Host.Name.
# -----------------------------------------------------------------------------
if ($Host.Name -eq 'ConsoleHost' -and $MyInvocation.CommandOrigin -eq 'Internal') {
    Write-Host "AGE environment configured (Win11):"
    Write-Host "  AGE_PLUGIN_ROOT  = $env:AGE_PLUGIN_ROOT"
    Write-Host "  AGE_PROJECT_ROOT = $env:AGE_PROJECT_ROOT"
    Write-Host "  AGE_DOC_LANGUAGE = $env:AGE_DOC_LANGUAGE"
    Write-Host "  PYTHON_EXEC      = $env:PYTHON_EXEC"
}

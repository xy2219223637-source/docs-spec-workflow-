# path-utils.ps1
# AGE Plugin — Windows 11 PowerShell path utilities
#
# Ownership: 事实设计 agent (CONTRACT.md §8.12)
# Purpose: POSIX <-> Windows path conversion, plugin-root discovery, AGE repo
#          detection. Used by cli/age.ps1, hooks/scripts/*.ps1, and env-template.ps1.
#
# Usage (dot-source from another .ps1):
#   . "$AGE_PLUGIN_ROOT\compat\win11\path-utils.ps1"
#   $root = Find-PluginRoot
#
# All functions are safe to dot-source (no side effects on import). Functions
# emit objects or strings; errors go to stderr via Write-Error.

# Guard against double dot-sourcing.
if ($null -ne $script:AGE_PATH_UTILS_LOADED) { return }
$script:AGE_PATH_UTILS_LOADED = $true


# -----------------------------------------------------------------------------
# Convert-ToWinPath
#   Convert a POSIX-style path (/ separated) to a Windows-style path (\ sep).
#   Forward slashes become backslashes. Drive-letter form (/c/... -> C:\...) is
#   handled when the first segment is a single drive letter (Git-Bash style).
#
#   Example: "/c/Users/ale/project" -> "C:\Users\ale\project"
#            "docs/index.md"        -> "docs\index.md"
# -----------------------------------------------------------------------------
function Convert-ToWinPath {
    [CmdletBinding()]
    [OutputType([string])]
    param(
        [Parameter(Mandatory = $true, Position = 0)]
        [string]$PosixPath
    )

    if ([string]::IsNullOrEmpty($PosixPath)) { return [string]::Empty }

    $p = $PosixPath -replace '/', '\'

    # Git-Bash drive form: \c\Users -> C:\Users (leading single-letter segment)
    if ($p -match '^\\([a-zA-Z])\\') {
        $p = ($matches[1]).ToUpper() + ':\' + $p.Substring(3)
    } elseif ($p -match '^\\([a-zA-Z])$') {
        $p = ($matches[1]).ToUpper() + ':\'
    }

    return $p
}


# -----------------------------------------------------------------------------
# Convert-ToPosixPath
#   Convert a Windows-style path (\ separated) to a POSIX-style path (/ sep).
#   Backslashes become forward slashes. Drive-letter form (C:\... -> /c/...) is
#   produced only when $AsGitBash switch is given; by default we keep the drive
#   letter form (C:/Users/...) which Python and most tools accept on Win11.
#
#   Example: "C:\Users\ale\project" -> "C:/Users/ale/project"
#            "docs\index.md"        -> "docs/index.md"
# -----------------------------------------------------------------------------
function Convert-ToPosixPath {
    [CmdletBinding()]
    [OutputType([string])]
    param(
        [Parameter(Mandatory = $true, Position = 0)]
        [string]$WinPath,

        # Emit Git-Bash drive form (C:\ -> /c/) instead of forward-slash form.
        [switch]$AsGitBash
    )

    if ([string]::IsNullOrEmpty($WinPath)) { return [string]::Empty }

    $p = $WinPath -replace '\\', '/'

    if ($AsGitBash -and ($p -match '^([a-zA-Z]):/')) {
        $p = '/' + ($matches[1]).ToLower() + $p.Substring(2)
    }

    return $p
}


# -----------------------------------------------------------------------------
# Find-PluginRoot
#   Walk upward from $StartDir looking for a directory containing the AGE
#   plugin marker directory `.zcode-plugin/`. Returns the parent that contains
#   it, or $null if not found within the walk budget.
#
#   $StartDir defaults to the directory of this script file, which is the most
#   reliable anchor when dot-sourced from cli/age.ps1 or a hook .ps1.
# -----------------------------------------------------------------------------
function Find-PluginRoot {
    [CmdletBinding()]
    [OutputType([string])]
    param(
        [Parameter(Position = 0)]
        [string]$StartDir = $null
    )

    # Default anchor: directory of this script (path-utils.ps1 lives in
    # <plugin-root>/compat/win11/, so parent's parent is the plugin root).
    if ([string]::IsNullOrEmpty($StartDir)) {
        if ($null -ne $myInvocation -and -not [string]::IsNullOrEmpty($myInvocation.MyCommand.Path)) {
            $StartDir = Split-Path -Parent $myInvocation.MyCommand.Path
        } elseif ($null -ne $PSCommandPath -and -not [string]::IsNullOrEmpty($PSCommandPath)) {
            $StartDir = Split-Path -Parent $PSCommandPath
        } else {
            $StartDir = (Get-Location).Path
        }
    }

    if (-not (Test-Path -LiteralPath $StartDir)) { return $null }

    $dir = (Resolve-Path -LiteralPath $StartDir).Path
    $maxSteps = 20  # walk budget to avoid infinite loops on odd mounts

    for ($i = 0; $i -lt $maxSteps; $i++) {
        $marker = Join-Path $dir '.zcode-plugin'
        if (Test-Path -LiteralPath $marker -PathType Container) {
            return $dir
        }
        # Also accept a cli/age.ps1 sibling as a plugin-root signal (Win11
        # installs where the marker dir may not be present, e.g. slim copy).
        $cliPs1 = Join-Path $dir 'cli\age.ps1'
        if (Test-Path -LiteralPath $cliPs1 -PathType Leaf) {
            return $dir
        }

        $parent = Split-Path -Parent $dir
        if ([string]::IsNullOrEmpty($parent) -or $parent -eq $dir) { break }
        $dir = $parent
    }

    return $null
}


# -----------------------------------------------------------------------------
# Find-AgeCli
#   Locate the AGE CLI entry point. Preference order:
#     1. $env:AGE_CLI (explicit override)
#     2. <plugin-root>\cli\age.ps1  (PowerShell native, preferred on Win11)
#     3. <plugin-root>\cli\age      (bash script; requires Git-Bash on Win11)
#     4. `age` on PATH
#   Returns a hashtable: @{ Path = <string>; Kind = 'ps1'|'bash'|'path'|$null }
#   Kind=$null means not found (Path is $null).
# -----------------------------------------------------------------------------
function Find-AgeCli {
    [CmdletBinding()]
    [OutputType([hashtable])]
    param(
        [Parameter(Position = 0)]
        [string]$PluginRoot = $null
    )

    # 1. Explicit override.
    if (-not [string]::IsNullOrEmpty($env:AGE_CLI)) {
        if (Test-Path -LiteralPath $env:AGE_CLI) {
            $kind = if ($env:AGE_CLI -like '*.ps1') { 'ps1' }
                    elseif ($env:AGE_CLI -like '*.age*' -or $env:AGE_CLI -notlike '*.*') { 'bash' }
                    else { 'path' }
            return @{ Path = $env:AGE_CLI; Kind = $kind }
        }
    }

    # Resolve plugin root.
    if ([string]::IsNullOrEmpty($PluginRoot)) {
        $PluginRoot = Find-PluginRoot
    }
    if ([string]::IsNullOrEmpty($PluginRoot)) {
        # 4. Last resort: `age` on PATH.
        $cmd = Get-Command age -ErrorAction SilentlyContinue
        if ($null -ne $cmd) {
            return @{ Path = $cmd.Source; Kind = 'path' }
        }
        return @{ Path = $null; Kind = $null }
    }

    # 2. PowerShell native entry.
    $ps1 = Join-Path $PluginRoot 'cli\age.ps1'
    if (Test-Path -LiteralPath $ps1 -PathType Leaf) {
        return @{ Path = $ps1; Kind = 'ps1' }
    }

    # 3. Bash entry (Git-Bash fallback).
    $bash = Join-Path $PluginRoot 'cli\age'
    if (Test-Path -LiteralPath $bash -PathType Leaf) {
        return @{ Path = $bash; Kind = 'bash' }
    }

    # 4. PATH lookup.
    $cmd = Get-Command age -ErrorAction SilentlyContinue
    if ($null -ne $cmd) {
        return @{ Path = $cmd.Source; Kind = 'path' }
    }

    return @{ Path = $null; Kind = $null }
}


# -----------------------------------------------------------------------------
# Resolve-ProjectDir
#   Determine the active project directory. Preference order:
#     1. $env:AGE_PROJECT_ROOT (explicit, set by env-template.ps1 or agent)
#     2. $env:AGE_PROJECT_DIR  (legacy/fallback name, MCP injects this)
#     3. git toplevel of current location (if inside a git repo)
#     4. current working directory (Get-Location)
#   Returns an absolute path string. Never returns $null.
# -----------------------------------------------------------------------------
function Resolve-ProjectDir {
    [CmdletBinding()]
    [OutputType([string])]
    param()

    # 1. Explicit env.
    if (-not [string]::IsNullOrEmpty($env:AGE_PROJECT_ROOT)) {
        if (Test-Path -LiteralPath $env:AGE_PROJECT_ROOT) {
            return (Resolve-Path -LiteralPath $env:AGE_PROJECT_ROOT).Path
        }
    }

    # 2. Legacy env name.
    if (-not [string]::IsNullOrEmpty($env:AGE_PROJECT_DIR)) {
        if (Test-Path -LiteralPath $env:AGE_PROJECT_DIR) {
            return (Resolve-Path -LiteralPath $env:AGE_PROJECT_DIR).Path
        }
    }

    # 3. git toplevel (silently fail if not a repo or git missing).
    $gitCmd = Get-Command git -ErrorAction SilentlyContinue
    if ($null -ne $gitCmd) {
        try {
            $toplevel = & git rev-parse --show-toplevel 2>$null
            if ($LASTEXITCODE -eq 0 -and -not [string]::IsNullOrEmpty($toplevel)) {
                return (Resolve-Path -LiteralPath ($toplevel.Trim())).Path
            }
        } catch {
            # ignore; fall through to cwd
        }
    }

    # 4. cwd.
    return (Get-Location).Path
}


# -----------------------------------------------------------------------------
# Test-AgeRepo
#   Detect whether $ProjectDir is an AGE-initialized repository. An AGE repo is
#   identified by the presence of docs/index.md (CONTRACT.md §5 authoritative
#   marker). AGENTS.md is accepted as a secondary signal during init (the
#   bash is_age_repo also accepts AGENTS.md; see §8.8 X).
#
#   Returns $true / $false.
# -----------------------------------------------------------------------------
function Test-AgeRepo {
    [CmdletBinding()]
    [OutputType([bool])]
    param(
        [Parameter(Position = 0)]
        [string]$ProjectDir = $null
    )

    if ([string]::IsNullOrEmpty($ProjectDir)) {
        $ProjectDir = Resolve-ProjectDir
    }
    if ([string]::IsNullOrEmpty($ProjectDir) -or -not (Test-Path -LiteralPath $ProjectDir)) {
        return $false
    }

    $dir = (Resolve-Path -LiteralPath $ProjectDir).Path

    # Primary marker: docs/index.md (CONTRACT.md §5).
    $indexMd = Join-Path $dir 'docs\index.md'
    if (Test-Path -LiteralPath $indexMd -PathType Leaf) {
        return $true
    }

    # Secondary marker: AGENTS.md (init-in-progress tolerance, §8.8 X).
    $agentsMd = Join-Path $dir 'AGENTS.md'
    if (Test-Path -LiteralPath $agentsMd -PathType Leaf) {
        return $true
    }

    return $false
}

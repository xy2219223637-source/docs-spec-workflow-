# Windows 11 兼容说明

> 本目录是 AGE 插件对 Windows 11 的兼容层。所有权归事实设计 agent(见 CONTRACT.md §8.12)。
>
> AGE 的 CLI 与 hooks 原为 POSIX shell(bash),Win11 原生无 bash。本目录采用**双层策略**:PowerShell 原生层(优先,不依赖 bash)+ Git-Bash 兼容层(回退)。本目录提供事实设计 agent 所有权内的文件:`path-utils.ps1`(路径工具)与 `env-template.ps1`(环境变量模板)。PowerShell CLI 入口(`cli/age.ps1`)、PowerShell hooks(`hooks/scripts/*.ps1`)、Win11 hook 配置(`hooks/hooks.win11.json`)、`age install --client win11` 安装逻辑由总调度/任务执行 agent 实现(见 §8.12 所有权表)。

## 为什么需要 Win11 兼容层

AGE 的四层架构在 macOS/Linux/WSL 下以 bash CLI + bash hooks 工作,但 Win11 原生环境与 POSIX 有四类系统级差异:

1. **Shell**:Win11 预装 PowerShell 5.1(Windows PowerShell),无 bash。bash 仅在 Git-Bash(随 Git for Windows 安装)或 WSL 中可用。
2. **路径分隔符**:Win11 用 `\`(反斜杠),POSIX 用 `/`(正斜杠)。Git-Bash 内部用 `/`,但调 Win 原生工具时需转回 `\`。
3. **环境变量语法**:PowerShell 用 `$env:VAR`,CMD 用 `%VAR%`,bash 用 `$VAR`。
4. **Python 命令名**:Win11 上 Python 3 通常以 `python` 调用(不含 `3`),`python3` 多数不存在;需 `python` → `python3` → `py -3` 逐级检测。

不加适配时,`cli/age`(bash)在原生 Win11 无法执行,hooks(`.sh`)也无法触发,MCP server(`python3 mcp/server.py`)会因 `python3` 不存在而启动失败。本兼容层让 AGE 在**不要求用户安装 Git-Bash**的前提下可用,同时保留 Git-Bash 作为回退路径。

## 兼容策略:PowerShell 原生层 + Git-Bash 兼容层(双层)

| 层 | 实现 | 依赖 bash? | 优先级 | 状态 |
|---|---|---|---|---|
| **PowerShell 原生层** | `cli/age.ps1` + `cli/lib/*.ps1` + `hooks/scripts/*.ps1` + `hooks/hooks.win11.json` | 否 | 优先(推荐) | 总调度 + 任务执行实现(§8.12) |
| **Git-Bash 兼容层** | 现有 `cli/age` + `cli/lib/*.sh` + `hooks/scripts/*.sh` + `hooks/hooks.json` | 是(Git-Bash) | 回退 | 现有代码,验证 + 小修 |

**核心原则:**
- **优先 PowerShell 原生**——不要求用户装 Git-Bash。`age install --client win11` 默认装 PowerShell 入口与 `.ps1` hooks,指向 `cli/age.ps1`。
- **Git-Bash 作为回退**——若用户已装 Git for Windows,现有 bash 脚本在 Git-Bash 下直接可用(需 `age` 在 Git-Bash 的 PATH 上)。Git-Bash 下路径用 `/`、Python 命令同 macOS/Linux。
- **同一份确定性内核**——无论走哪层,最终都调用同一组 CLI 子命令语义(`age init/route/sync/check/audit/doctor/ci/baseline/use`)与同一份 MCP server(`mcp/server.py`,纯 stdlib,跨平台)。MCP server 的 `os.path` 已是跨平台。

## 环境要求

| 组件 | 要求 | 说明 |
|---|---|---|
| 操作系统 | Windows 11 | Win10 也可用,但未重点测试 |
| PowerShell | **5.1**(预装)或 **7+**(推荐) | `cli/age.ps1` 与 `hooks/scripts/*.ps1` 在两者均测;PowerShell 7 跨平台、错误信息更友好 |
| Python | 3.8+ | MCP server(`mcp/server.py`)必需。命令名可能是 `python`(Win11 常见,不含 3)/ `python3` / `py -3`,由 `env-template.ps1` 自动检测写入 `$env:PYTHON_EXEC` |
| Git | 可选但强烈推荐 | `age sync`/`age baseline` 依赖 git;无 git 时优雅降级(见 §8.8 Z) |
| Git-Bash | 可选 | 仅在用户选择 Git-Bash 兼容层时需要(随 Git for Windows 安装) |

验证环境(在 PowerShell 中):

```powershell
$PSVersionTable.PSVersion          # 5.1 或 7+
python --version                   # 期望 Python 3.x
py -3 --version                    # 备用:py launcher
git --version                      # 可选
```

## 安装方式

### 方式一:`age install --client win11` 自动安装(推荐)

```powershell
# 在目标项目根目录运行(需 age CLI 已就绪,或先 dot-source env-template.ps1)
age install --client win11
```

`age install --client win11`(总调度实现,§8.12)会:

1. 把 `cli/age.ps1` + `cli/lib/*.ps1` 确认就位(PowerShell CLI 入口,总调度所有权)。
2. 写 `hooks/hooks.win11.json`(任务执行所有权),指向 `hooks/scripts/*.ps1`(任务执行所有权)。
3. 把 `compat/win11/env-template.ps1` 的环境变量写入用户级或工作区级 PowerShell profile(或提示用户 dot-source)。
4. 把 `age` 命令加入 PATH(软链或 `New-Item -ItemType SymbolicLink`,提示用户)。
5. 跑 `age doctor` 验证(Python / git / 路径 / AGE 仓库检测)。

### 方式二:手动安装

```powershell
# 假设 AGE 插件仓库在 C:\path\to\age-plugin,目标项目在 C:\path\to\myproj
$AGE_SRC = "C:\path\to\age-plugin"
$DST     = "C:\path\to\myproj"

# 1. dot-source 环境变量模板(设置 AGE_PLUGIN_ROOT/AGE_PROJECT_ROOT/PYTHON_EXEC)
. "$AGE_SRC\compat\win11\env-template.ps1"
#   若自动检测失败,编辑 env-template.ps1 里的 $pluginRoot / $projectRoot 为绝对路径

# 2. 验证环境
& "$AGE_SRC\cli\age.ps1" doctor

# 3. 在项目里初始化 AGE(若尚未)
Set-Location $DST
& "$AGE_SRC\cli\age.ps1" init --name myproj --kind web
& "$AGE_SRC\cli\age.ps1" baseline

# 4. (可选)把 age 加入 PATH
#    New-Item -ItemType SymbolicLink -Path "$env:USERPROFILE\bin\age.ps1" -Target "$AGE_SRC\cli\age.ps1"
```

手动安装后,若要走 Git-Bash 兼容层(而非 PowerShell 原生),在 Git-Bash 里按 macOS/Linux 流程安装现有 `cli/age` 即可,见 `compat/README.md`。

## 路径差异(关键)

| 维度 | Win11(PowerShell) | Win11(CMD) | POSIX / Git-Bash |
|---|---|---|---|
| 路径分隔符 | `\` | `\` | `/` |
| 环境变量读 | `$env:VAR` | `%VAR%` | `$VAR` / `${VAR}` |
| 环境变量设 | `$env:VAR = "x"` | `set VAR=x` | `export VAR="x"` |
| 当前目录 | `Get-Location` / `$PWD` | `%CD%` | `pwd` / `$PWD` |
| 路径拼接 | `Join-Path $a $b` | `set p=%a%\%b%` | `"$a/$b"` |
| 行结束符 | CRLF | CRLF | LF |
| 可执行脚本 | `.ps1`(需执行策略)/ `.cmd`/ `.bat` | `.cmd`/ `.bat` | 无扩展名 + shebang + `chmod +x` |
| Python 命令 | `python`(常见)/ `py -3` | 同左 | `python3` |

**转换工具:** `path-utils.ps1` 提供 `Convert-ToWinPath`(POSIX `/` → Win `\`,含 Git-Bash `/c/` → `C:\` 驱动器转换)与 `Convert-ToPosixPath`(Win `\` → POSIX `/`,可选 `-AsGitBash` 产出 `C:\` → `/c/`)。CLI 内部路径用 `$env:AGE_PLUGIN_ROOT` 拼 `Join-Path`,避免手写分隔符。

**行结束符(CRLF vs LF):** AGE 仓库模板文件是 LF。在 Win11 上 `git` 默认 `core.autocrlf=true` 会在 checkout 时转 CRLF、commit 时转回 LF。建议设置:

```powershell
git config --global core.autocrlf input   # 推荐:checkout 不转 CRLF,commit 转 LF
# 或
git config --global core.autocrlf auto    # 文本文件 checkout 转 CRLF,binary 不动
```

`.ps1` 脚本对 CRLF/LF 均可执行(PowerShell 容忍两者),但 `mcp/server.py` 与 `cli/lib/*.sh`(Git-Bash 层)在 LF 下更稳。`age init` 渲染模板时建议保持 LF。

## CLI 入口

| 入口 | 语言 | 路径 | 适用场景 |
|---|---|---|---|
| **`cli/age.ps1`** | PowerShell | `<plugin-root>\cli\age.ps1` | **Win11 原生**(优先),不依赖 bash |
| `cli/age` | bash | `<plugin-root>/cli/age` | Git-Bash 兼容层(回退),需 Git-Bash |

两者支持的子命令完全一致(CONTRACT.md §3):`init` / `use` / `install` / `check` / `sync` / `route` / `audit` / `doctor` / `ci` / `baseline` / `help`。

调用方式:

```powershell
# PowerShell 原生
& "$env:AGE_PLUGIN_ROOT\cli\age.ps1" doctor
& "$env:AGE_PLUGIN_ROOT\cli\age.ps1" route "添加登录页" --explain

# Git-Bash(在 Git-Bash 终端里)
age doctor
age route "添加登录页" --explain
```

`cli/age.ps1` 的路径解析:
1. 优先 `$env:AGE_PLUGIN_ROOT`(由 `env-template.ps1` 或 `age install` 设置)。
2. 回退自动探测:脚本位置向上查找含 `.zcode-plugin/` 或 `cli/age.ps1` 的目录(`Find-PluginRoot`,见 `path-utils.ps1`)。

Python 检测(`$env:PYTHON_EXEC`):`python` → `python3` → `py -3`,取第一个报 Python 3.x 的命令。检测逻辑在 `env-template.ps1` 的 `_Detect-PythonExec`。

## Hook 脚本

| 脚本 | Win11(PowerShell) | Git-Bash(bash) |
|---|---|---|
| SessionStart | `hooks/scripts/on-session-start.ps1` | `hooks/scripts/on-session-start.sh` |
| PostToolUse(matcher `Edit\|Write\|MultiEdit`) | `hooks/scripts/on-edit.ps1` | `hooks/scripts/on-edit.sh` |
| Stop | `hooks/scripts/on-stop.ps1` | `hooks/scripts/on-stop.sh` |
| 共享库 | `hooks/scripts/lib.ps1` | `hooks/scripts/lib.sh` |

**Win11 hook 配置:** `hooks/hooks.win11.json`(任务执行所有权),指向 `.ps1` 脚本,事件名 PascalCase(`SessionStart`/`PostToolUse`/`Stop`,与 ZCode/Claude Code/Codex 一致,见 `compat/README.md`)。各客户端在 Win11 上的 hook 配置文件位置:
- **ZCode(Win11)**:`.zcode/config.json` 读 `hooks.win11.json`(若 ZCode Win11 客户端支持)。
- **Claude Code(Win11)**:`.claude/settings.json` 的 hooks 段指向 `.ps1` 脚本(绝对路径,Windows 反斜杠)。
- **Codex CLI(Win11)**:`~/.codex/config.toml` 的 `[hooks.EVENT]` 段,`command` 用 `powershell -File "<绝对路径>.ps1"`。
- **OpenCode CLI(Win11)**:plugin 模块(`plugin.ts`)在 Win11 上 `tool.execute.after` 调 `.ps1`;无 SessionStart/Stop(同 macOS/Linux,见 `compat/opencode/README.md`)。

PowerShell hook 与 bash hook 的输出契约一致(CONTRACT.md §8.6 K):严格 `exit 0`(永不阻断),上下文注入走 stdout JSON `{"additionalContext":"..."}`。`lib.ps1`(任务执行实现)负责 JSON 转义与 CLI 定位。

## MCP server

MCP server(`mcp/server.py`,总调度所有权)在 Win11 上启动方式:

```powershell
# 用 env-template.ps1 检测到的 PYTHON_EXEC
& $env:PYTHON_EXEC "$env:AGE_PLUGIN_ROOT\mcp\server.py"
```

**关键:** Win11 上 `python` 不含 `3`,故 MCP 配置里的 `command` 不能写死 `python3`。各客户端的 MCP 配置在 Win11 上应使用 `$env:PYTHON_EXEC` 或直接 `python`(经 `_Detect-PythonExec` 确认为 Python 3.x 后写入)。`mcp/server.py` 的 `os.path` 操作已跨平台(总调度 §8.12 确认),项目根检测回退链 `AGE_PROJECT_ROOT` → `AGE_PROJECT_DIR` → `os.getcwd()` 在 Win11 上工作(§8.8 Y)。

各客户端 MCP 配置示例(Win11):

```jsonc
// .mcp.json (Claude Code) / .zcode/config.json (ZCode) mcpServers 段
{
  "mcpServers": {
    "age-mcp": {
      "command": "python",
      "args": ["C:\\path\\to\\age-plugin\\mcp\\server.py"],
      "env": {
        "AGE_PLUGIN_ROOT": "C:\\path\\to\\age-plugin",
        "AGE_PROJECT_ROOT": "C:\\path\\to\\myproj"
      }
    }
  }
}
```

## 文件清单

| 文件 | 所有者 | 作用 |
|---|---|---|
| `README.md` | 事实设计 | 本文件:Win11 兼容说明 + 双层策略 + 环境要求 |
| `path-utils.ps1` | 事实设计 | PowerShell 路径工具:`Convert-ToWinPath`/`Convert-ToPosixPath`/`Find-PluginRoot`/`Find-AgeCli`/`Resolve-ProjectDir`/`Test-AgeRepo` |
| `env-template.ps1` | 事实设计 | Win11 环境变量模板:`AGE_PLUGIN_ROOT`/`AGE_PROJECT_ROOT`/`AGE_DOC_LANGUAGE`/`PYTHON_EXEC` |
| `cli/age.ps1` | 总调度 | PowerShell CLI 入口(等价 `cli/age`) |
| `cli/lib/*.ps1` / `cli/lib/common.ps1` | 总调度 | PowerShell 核心函数(等价 `lib/*.sh`) |
| `hooks/scripts/*.ps1` | 任务执行 | PowerShell hook 脚本(on-session-start/on-edit/on-stop/lib) |
| `hooks/hooks.win11.json` | 任务执行 | Win11 hook 配置(指向 `.ps1`) |

## path-utils.ps1 函数说明

`compat/win11/path-utils.ps1` 提供(英文注释,中文说明):

| 函数 | 作用 | 返回 |
|---|---|---|
| `Convert-ToWinPath -PosixPath <s>` | POSIX `/` → Win `\`,Git-Bash `/c/...` → `C:\...` | string |
| `Convert-ToPosixPath -WinPath <s> [-AsGitBash]` | Win `\` → POSIX `/`,可选 `C:\` → `/c/` | string |
| `Find-PluginRoot [-StartDir <s>]` | 从脚本位置向上找含 `.zcode-plugin/` 或 `cli/age.ps1` 的目录 | string 或 `$null` |
| `Find-AgeCli [-PluginRoot <s>]` | 定位 `age.ps1`(优先)或 `age`(Git-Bash 回退)或 PATH 上的 `age` | `@{Path; Kind='ps1'\|'bash'\|'path'\|$null}` |
| `Resolve-ProjectDir` | 项目根检测:`AGE_PROJECT_ROOT` → `AGE_PROJECT_DIR` → git toplevel → cwd | string(绝不 `$null`) |
| `Test-AgeRepo [-ProjectDir <s>]` | 检测 AGE 仓库(`docs/index.md` 主标志,`AGENTS.md` 次标志,见 §8.8 X) | bool |

用法:

```powershell
. "$env:AGE_PLUGIN_ROOT\compat\win11\path-utils.ps1"

$root     = Find-PluginRoot
$cli      = Find-AgeCli -PluginRoot $root
$proj     = Resolve-ProjectDir
$isAge    = Test-AgeRepo -ProjectDir $proj
$winPath  = Convert-ToWinPath -PosixPath "docs/index.md"   # docs\index.md
$posix    = Convert-ToPosixPath -WinPath "C:\proj\docs"    # C:/proj/docs
```

## env-template.ps1 变量说明

`compat/win11/env-template.ps1` 设置(中文撰写说明,英文注释):

| 变量 | 默认值 | 检测/作用 |
|---|---|---|
| `AGE_PLUGIN_ROOT` | 自动检测(Find-PluginRoot) | AGE 插件安装目录。CLI/hooks/MCP 用它定位 `skills/`、`templates/`、`cli/lib/`。检测失败时需手动改模板里的 `$pluginRoot` |
| `AGE_PROJECT_ROOT` | 自动检测(AGE_PROJECT_DIR → git → cwd) | 目标仓库根。MCP server 与 hooks 用它定位项目内 `docs/`、`.age/`。`mcp/server.py` 回退链:此变量 → `AGE_PROJECT_DIR` → `os.getcwd()` |
| `AGE_DOC_LANGUAGE` | `"zh"` | 文档语言(`zh`/`en`)。影响 `age init` 模板渲染、`age route` 输出语言 |
| `PYTHON_EXEC` | 自动检测(python→python3→py -3) | Python 3 解释器命令。Win11 上常为 `python`(不含 3)。MCP server 启动用此变量,避免写死 `python3` |

dot-source 方式(变量在当前 shell 持久):

```powershell
. "$env:AGE_PLUGIN_ROOT\compat\win11\env-template.ps1"
```

## 已知限制

1. **PowerShell 执行策略**:`.ps1` 脚本在默认 `Restricted` 策略下无法执行。需 `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned`(或 `Bypass`)。`age install --client win11` 应提示用户。
2. **PowerShell 5.1 vs 7 差异**:本目录 `.ps1` 尽量用兼容语法,但 5.1 对部分 cmdlet/类型推断较弱;推荐 PowerShell 7。若 5.1 报错,优先升 7。
3. **MCP server 的 `python3` 硬编码**:`mcp/server.py` 在某些客户端 MCP 配置里 `command` 写死 `python3`(macOS/Linux 习惯)。Win11 上必须改 `python` 或用 `$env:PYTHON_EXEC`。`age install --client win11` 应自动写入正确命令名。
4. **路径中的空格与中文**:Win11 项目路径常含空格(`C:\Users\My Name\project`)或中文。`path-utils.ps1` 用 `Join-Path` 与 `-LiteralPath` 规避解析问题;hooks 与 CLI 调用需用引号包裹路径。
5. **Git-Bash 兼容层的 PATH**:Git-Bash 的 PATH 与 PowerShell 不同。`age` 在 Git-Bash 里需另装软链(或 `cli/age` 在 Git-Bash PATH 上),不能直接复用 PowerShell 的 PATH 设置。
6. **CRLF 与 shebang**:bash 脚本(`cli/age`、`hooks/scripts/*.sh`)在 CRLF 下 shebang 行可能失效。走 Git-Bash 兼容层时,确保这些文件保持 LF(`git config core.autocrlf input`)。
7. **WSL 不在本兼容层范围**:WSL(Ubuntu 等)是完整 Linux 子系统,bash/Python3/python3 路径与 Linux 一致,直接走现有 POSIX 流程即可,无需本目录。本目录仅面向**原生 Win11**(PowerShell)与 **Git-Bash**。
8. **hooks 事件名跨客户端一致**:Win11 上各客户端(PowerShell hooks)事件名仍为 PascalCase(`SessionStart`/`PostToolUse`/`Stop`),与 ZCode/Claude Code/Codex 一致,无需适配事件名。OpenCode 在 Win11 上仍是 dot-notation + plugin 模块(无 SessionStart/Stop),见 `compat/opencode/README.md`。

## 相关文件

- 兼容策略权威源:CONTRACT.md §8.12
- 多客户端总说明:`compat/README.md`(功能降级矩阵、客户端对照表)
- PowerShell 路径工具:`compat/win11/path-utils.ps1`(本目录)
- 环境变量模板:`compat/win11/env-template.ps1`(本目录)
- 跨客户端通用指令模板:`templates/repo/AGENTS.md` §9.1(含 Win11 路径/环境变量补充说明)
- MCP server:`mcp/server.py`(总调度,`os.path` 跨平台)
- `age install --client win11` 实现:`cli/lib/install.sh`、`cli/lib/common.sh::detect_host()`(总调度,§8.12 待补 win11 分支)

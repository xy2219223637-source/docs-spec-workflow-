#!/usr/bin/env bash
# install.sh — Multica 专用 AGE 安装脚本
#
# 本机验证环境(2026-07-11):
#   - multica CLI v0.3.43(Go 写的,云 workspace 模式)
#   - 路径:/Applications/Multica.app/Contents/Resources/app.asar.unpacked/resources/bin/multica
#           或 PATH 上的 multica(~/.local/bin/multica)
#   - 配置:~/.multica/config.json(server_url + workspace_id + token)
#
# 本脚本执行:
#   1. 检测 multica CLI(PATH 或 /Applications/Multica.app/.../bin/multica)
#   2. 渲染 compat/multica/mcp-config.json 占位符(AGE_PLUGIN_ROOT / PROJECT_DIR)
#   3. multica skill create --name use-AGE --description ... --content-file use-AGE.skill.md
#   4. (可选)multica agent update <id> --mcp-config-file <rendered> 或提示用户先建 agent
#   5. (可选)multica agent skills add <agent-id> --skill-ids <use-AGE skill-id>
#   6. (可选)multica autopilot create + trigger-add(每 6 小时 age sync,部分替代 Stop hook)
#
# 用法:
#   compat/multica/install.sh [--dry-run] [--agent <name|id>] [--no-autopilot]
#
# 退出码: 0 成功 / 1 失败
set -euo pipefail

# ---------------------------------------------------------------------------
# 常量
# ---------------------------------------------------------------------------
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PLUGIN_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"
MCP_TEMPLATE="$SCRIPT_DIR/mcp-config.json"
SKILL_FILE="$SCRIPT_DIR/use-AGE.skill.md"
SKILL_NAME="use-AGE"
SKILL_DESCRIPTION="AGE 插件的入口激活器。当用户想要开启/启动/使用/激活 AGE(Attractor-Guided Engineering)时触发——覆盖开启AGE、启动AGE、用AGE、使用AGE、激活AGE、enable AGE、start AGE、use AGE、activate AGE 等中英文语义变体。检测当前项目是否已初始化 AGE,未初始化则自动 age init,已初始化则注入 context 并交权给 age 元 skill。"

# 颜色(无 tty 降级)
if [ -t 1 ] && [ -z "${AGE_NO_COLOR:-}" ]; then
  C_RESET=$'\033[0m'; C_GREEN=$'\033[32m'; C_YELLOW=$'\033[33m'; C_RED=$'\033[31m'; C_CYAN=$'\033[36m'
else
  C_RESET=""; C_GREEN=""; C_YELLOW=""; C_RED=""; C_CYAN=""
fi
info()    { printf '%s\n' "${C_CYAN}ℹ${C_RESET} $*"; }
success() { printf '%s\n' "${C_GREEN}✓${C_RESET} $*"; }
warn()    { printf '%s\n' "${C_YELLOW}⚠${C_RESET} $*" >&2; }
error()   { printf '%s\n' "${C_RED}✗${C_RESET} $*" >&2; }
die()     { error "$1"; exit "${2:-1}"; }

# ---------------------------------------------------------------------------
# 参数解析
# ---------------------------------------------------------------------------
DRY_RUN=0
AGENT_TARGET=""
NO_AUTOPILOT=0
while [ $# -gt 0 ]; do
  case "$1" in
    --dry-run) DRY_RUN=1; shift;;
    --agent) AGENT_TARGET="$2"; shift 2;;
    --agent=*) AGENT_TARGET="${1#*=}"; shift;;
    --no-autopilot) NO_AUTOPILOT=1; shift;;
    -h|--help)
      cat <<EOF
compat/multica/install.sh — 注册 AGE 到 Multica workspace

用法:
  install.sh [--dry-run] [--agent <name|id>] [--no-autopilot]

参数:
  --dry-run         预览将执行的 multica 命令,不实际注册
  --agent NAME|ID   指定要绑定 MCP+skill 的 agent(name 或 id);不指定则仅注册 skill
  --no-autopilot    跳过 autopilot 定时漂移检测配置
EOF
      exit 0;;
    *) warn "未知参数: $1"; shift;;
  esac
done

info "AGE Multica 适配安装"
info "插件根: $PLUGIN_ROOT"
[ "$DRY_RUN" = "1" ] && warn "DRY-RUN 模式:仅预览命令,不实际执行 multica 调用。"

# ---------------------------------------------------------------------------
# 1. 检测 multica CLI
# ---------------------------------------------------------------------------
MULTICA_BIN=""
if command -v multica >/dev/null 2>&1; then
  MULTICA_BIN="$(command -v multica)"
elif [ -x "/Applications/Multica.app/Contents/Resources/app.asar.unpacked/resources/bin/multica" ]; then
  MULTICA_BIN="/Applications/Multica.app/Contents/Resources/app.asar.unpacked/resources/bin/multica"
fi
if [ -z "$MULTICA_BIN" ]; then
  die "未检测到 multica CLI。请安装 Multica.app 或将其 bin 目录加入 PATH。" 1
fi
success "检测到 multica CLI: $MULTICA_BIN"

# 验证 ~/.multica/config.json 存在(认证凭据)
if [ ! -f "$HOME/.multica/config.json" ]; then
  die "未找到 ~/.multica/config.json。请先 multica login 完成认证。" 1
fi
success "检测到 Multica 配置: ~/.multica/config.json"

# dry-run 下也跑 --version 确认可达(只读,安全)
MULTICA_VERSION="$("$MULTICA_BIN" --version 2>/dev/null | head -1 || echo unknown)"
info "Multica 版本: $MULTICA_VERSION"

# ---------------------------------------------------------------------------
# 2. 渲染 mcp-config.json 占位符
# ---------------------------------------------------------------------------
PROJECT_DIR="$(pwd)"
RENDERED_MCP="$(mktemp -t age-multica-mcp.XXXXXX).json"
mv "${RENDERED_MCP%.json}" "$RENDERED_MCP" 2>/dev/null || true
RENDERED_MCP="${RENDERED_MCP%.json}.json"

# 用 python3 做 JSON 安全渲染(占位符替换 + 保持合法 JSON)
if ! command -v python3 >/dev/null 2>&1; then
  die "需要 python3 渲染 mcp-config.json 占位符。" 1
fi
python3 - "$MCP_TEMPLATE" "$RENDERED_MCP" "$PLUGIN_ROOT" "$PROJECT_DIR" <<'PYEOF'
import json, sys
src, dst, plugin_root, project_dir = sys.argv[1:5]
with open(src, "r", encoding="utf-8") as f:
    raw = f.read()
# 双重渲染:先字符串替换占位符,再用 json 解析确保合法
raw = raw.replace("{{AGE_PLUGIN_ROOT}}", plugin_root)
raw = raw.replace("{{PROJECT_DIR}}", project_dir)
data = json.loads(raw)
with open(dst, "w", encoding="utf-8") as f:
    json.dump(data, f, ensure_ascii=False, indent=2)
    f.write("\n")
PYEOF
success "已渲染 mcp-config.json: $RENDERED_MCP"
info "  AGE_PLUGIN_ROOT = $PLUGIN_ROOT"
info "  AGE_PROJECT_ROOT = $PROJECT_DIR"

# ---------------------------------------------------------------------------
# 辅助:从 multica <cmd> --output json 提取字段(需 python3)
# json_get <json_input> <jq-like-path>  (path 支持 .a.b 或 [0].id)
# ---------------------------------------------------------------------------
json_get() {
  local input="$1" path="$2"
  python3 -c '
import json, sys
data = json.loads(sys.argv[1])
path = sys.argv[2]
obj = data
for tok in path.split("."):
    tok = tok.strip()
    if tok == "":
        continue
    if tok.startswith("[") and tok.endswith("]"):
        obj = obj[int(tok[1:-1])]
    else:
        if isinstance(obj, list):
            obj = obj[int(tok)]
        else:
            obj = obj[tok]
print(obj if not isinstance(obj, (dict, list)) else json.dumps(obj))
' "$input" "$path" 2>/dev/null
}

# ---------------------------------------------------------------------------
# 3. 注册 use-AGE 技能到 workspace
#    策略:先 multica skill list 查是否已有同名;有则 update,无则 create。
# ---------------------------------------------------------------------------
info "注册 use-AGE 技能到 workspace..."

SKILL_ID=""
if [ "$DRY_RUN" = "1" ]; then
  info "(dry-run) 将执行: $MULTICA_BIN skill create --name $SKILL_NAME --description <...> --content-file $SKILL_FILE"
  info "(dry-run) 若已存在同名技能,将执行: $MULTICA_BIN skill update <id> --description <...> --content-file $SKILL_FILE"
  SKILL_ID="<dry-run-skill-id>"
else
  # 查已有同名技能
  EXISTING_JSON="$("$MULTICA_BIN" skill list --output json 2>/dev/null || echo "[]")"
  SKILL_ID="$(python3 -c '
import json, sys
data = json.loads(sys.argv[1])
for s in data:
    if s.get("name") == sys.argv[2]:
        print(s.get("id", ""))
        break
' "$EXISTING_JSON" "$SKILL_NAME" 2>/dev/null || echo "")"

  if [ -n "$SKILL_ID" ]; then
    warn "workspace 已有同名技能 $SKILL_NAME (id=$SKILL_ID),将更新。"
    # skill update --help:--content-file + --description
    if "$MULTICA_BIN" skill update "$SKILL_ID" \
        --description "$SKILL_DESCRIPTION" \
        --content-file "$SKILL_FILE" \
        --output json >/dev/null 2>&1; then
      success "已更新技能 $SKILL_NAME (id=$SKILL_ID)"
    else
      # update 可能不支持 --content-file,回退:用 files upsert
      warn "skill update 失败,尝试 skill files upsert..."
      "$MULTICA_BIN" skill files upsert "$SKILL_ID" \
        --path "SKILL.md" --content-file "$SKILL_FILE" >/dev/null 2>&1 \
        && success "已 upsert 技能文件" \
        || warn "skill files upsert 也失败,技能内容可能未更新(请手动检查)。"
    fi
  else
    # create
    CREATE_JSON="$("$MULTICA_BIN" skill create \
        --name "$SKILL_NAME" \
        --description "$SKILL_DESCRIPTION" \
        --content-file "$SKILL_FILE" \
        --output json 2>/dev/null || echo "")"
    if [ -z "$CREATE_JSON" ]; then
      die "multica skill create 失败(无输出)。请检查认证与网络。" 1
    fi
    SKILL_ID="$(json_get "$CREATE_JSON" "id" || echo "")"
    if [ -z "$SKILL_ID" ]; then
      # 某些版本返回 {"skill":{"id":...}} 或数组
      SKILL_ID="$(json_get "$CREATE_JSON" "skill.id" || echo "")"
    fi
    if [ -z "$SKILL_ID" ]; then
      die "无法从 skill create 输出解析 skill-id。原始输出: $CREATE_JSON" 1
    fi
    success "已创建技能 $SKILL_NAME (id=$SKILL_ID)"
  fi
fi
info "use-AGE 技能 ID: $SKILL_ID"

# ---------------------------------------------------------------------------
# 4. (可选)绑定 MCP + skill 到 agent
#    需要 --agent 参数;否则提示用户手动绑定。
# ---------------------------------------------------------------------------
if [ -z "$AGENT_TARGET" ]; then
  warn "未指定 --agent,跳过 MCP 与技能绑定。"
  info "如需绑定到 agent,请重跑:"
  info "  $SCRIPT_DIR/install.sh --agent <agent-name-or-id>"
  info "或手动执行:"
  info "  $MULTICA_BIN agent update <agent-id> --mcp-config-file $RENDERED_MCP"
  info "  $MULTICA_BIN agent skills add <agent-id> --skill-ids $SKILL_ID"
  # 不清理 RENDERED_MCP,留给用户手动用
  info "(渲染后的 mcp-config 留存于: $RENDERED_MCP)"
else
  info "绑定到 agent: $AGENT_TARGET"

  # 解析 agent-id:name 形式需先查 list 转成 id;id 形式直接用
  AGENT_ID="$AGENT_TARGET"
  if ! echo "$AGENT_TARGET" | grep -qE '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'; then
    # 看起来是 name,转 id
    if [ "$DRY_RUN" != "1" ]; then
      AGENT_LIST_JSON="$("$MULTICA_BIN" agent list --output json 2>/dev/null || echo "[]")"
      AGENT_ID="$(python3 -c '
import json, sys
data = json.loads(sys.argv[1])
for a in data:
    if a.get("name") == sys.argv[2]:
        print(a.get("id", ""))
        break
' "$AGENT_LIST_JSON" "$AGENT_TARGET" 2>/dev/null || echo "")"
      if [ -z "$AGENT_ID" ]; then
        die "未找到名为 '$AGENT_TARGET' 的 agent。请用 multica agent list 确认,或直接传 agent-id。" 1
      fi
      info "解析 agent name → id: $AGENT_TARGET → $AGENT_ID"
    else
      AGENT_ID="<resolved-agent-id>"
    fi
  fi

  # 4a. 更新 agent 的 mcp-config
  if [ "$DRY_RUN" = "1" ]; then
    info "(dry-run) 将执行: $MULTICA_BIN agent update $AGENT_ID --mcp-config-file $RENDERED_MCP"
  else
    if "$MULTICA_BIN" agent update "$AGENT_ID" --mcp-config-file "$RENDERED_MCP" >/dev/null 2>&1; then
      success "已为 agent $AGENT_ID 配置 age-mcp MCP server"
    else
      warn "agent update --mcp-config-file 失败,尝试 --mcp-config(内联 JSON)..."
      MCP_INLINE="$(python3 -c 'import json,sys;print(json.dumps(json.load(open(sys.argv[1]))))' "$RENDERED_MCP" 2>/dev/null)"
      if "$MULTICA_BIN" agent update "$AGENT_ID" --mcp-config "$MCP_INLINE" >/dev/null 2>&1; then
        success "已为 agent $AGENT_ID 配置 age-mcp MCP server(内联)"
      else
        die "agent update MCP 配置失败。请检查 agent-id 与权限。" 1
      fi
    fi
  fi

  # 4b. 绑定 use-AGE 技能
  if [ "$DRY_RUN" = "1" ]; then
    info "(dry-run) 将执行: $MULTICA_BIN agent skills add $AGENT_ID --skill-ids $SKILL_ID"
  else
    if "$MULTICA_BIN" agent skills add "$AGENT_ID" --skill-ids "$SKILL_ID" >/dev/null 2>&1; then
      success "已为 agent $AGENT_ID 绑定 use-AGE 技能"
    else
      warn "agent skills add 失败(可能已绑定)。请用 'multica agent skills list $AGENT_ID' 确认。"
    fi
  fi

  # 4c. 设置 agent custom-env(AGE_PLUGIN_ROOT / AGE_PROJECT_ROOT)
  if [ "$DRY_RUN" = "1" ]; then
    info "(dry-run) 将执行: $MULTICA_BIN agent env set $AGENT_ID --custom-env '{\"AGE_PLUGIN_ROOT\":\"$PLUGIN_ROOT\",\"AGE_PROJECT_ROOT\":\"$PROJECT_DIR\"}'"
  else
    CUSTOM_ENV_JSON="$(python3 -c '
import json, sys
print(json.dumps({"AGE_PLUGIN_ROOT": sys.argv[1], "AGE_PROJECT_ROOT": sys.argv[2]}))
' "$PLUGIN_ROOT" "$PROJECT_DIR" 2>/dev/null)"
    if "$MULTICA_BIN" agent env set "$AGENT_ID" --custom-env "$CUSTOM_ENV_JSON" >/dev/null 2>&1; then
      success "已为 agent $AGENT_ID 设置 AGE_PLUGIN_ROOT / AGE_PROJECT_ROOT 环境变量"
    else
      warn "agent env set 失败(环境变量未设)。agent 运行时可能无法定位插件根。"
      info "可手动: $MULTICA_BIN agent env set $AGENT_ID --custom-env '$CUSTOM_ENV_JSON'"
    fi
  fi

  # 清理渲染临时文件(已成功写入 agent)
  rm -f "$RENDERED_MCP" 2>/dev/null || true
fi

# ---------------------------------------------------------------------------
# 5. (可选)autopilot 定时漂移检测 —— 每 6 小时跑 age sync,部分替代 Stop hook
#    仅当 --agent 指定且未 --no-autopilot 时配置。
# ---------------------------------------------------------------------------
if [ "$NO_AUTOPILOT" != "1" ] && [ -n "$AGENT_TARGET" ]; then
  info "配置 autopilot 定时漂移检测(每 6 小时)..."

  if [ "$DRY_RUN" = "1" ]; then
    info "(dry-run) 将执行:"
    info "  $MULTICA_BIN autopilot create --agent $AGENT_TARGET --mode run_only \\"
    info "    --title 'AGE 定时漂移检测' --description '运行 age sync 检测文档与代码漂移,有漂移则在 issue 评论提醒。'"
    info "  $MULTICA_BIN autopilot trigger-add <autopilot-id> --kind schedule --cron '0 */6 * * *'"
  else
    AUTOPILOT_JSON="$("$MULTICA_BIN" autopilot create \
        --agent "$AGENT_TARGET" \
        --mode run_only \
        --title "AGE 定时漂移检测" \
        --description "运行 age sync 检测文档与代码漂移,有漂移则在 issue 评论提醒。工作区目录: $PROJECT_DIR" \
        --output json 2>/dev/null || echo "")"
    AUTOPILOT_ID="$(json_get "$AUTOPILOT_JSON" "id" || echo "")"
    if [ -z "$AUTOPILOT_ID" ]; then
      AUTOPILOT_ID="$(json_get "$AUTOPILOT_JSON" "autopilot.id" || echo "")"
    fi
    if [ -z "$AUTOPILOT_ID" ]; then
      warn "autopilot create 失败(无 id)。跳过定时触发配置。"
      info "原始输出: $AUTOPILOT_JSON"
    else
      success "已创建 autopilot (id=$AUTOPILOT_ID)"
      if "$MULTICA_BIN" autopilot trigger-add "$AUTOPILOT_ID" \
          --kind schedule --cron "0 */6 * * *" >/dev/null 2>&1; then
        success "已添加 schedule 触发器(每 6 小时)"
      else
        warn "autopilot trigger-add 失败。autopilot 已建但无触发器,请手动添加。"
      fi
    fi
  fi
elif [ "$NO_AUTOPILOT" = "1" ]; then
  info "跳过 autopilot 配置(--no-autopilot)。"
else
  info "未指定 --agent,跳过 autopilot 配置。"
fi

# ---------------------------------------------------------------------------
# 6. 输出安装结果
# ---------------------------------------------------------------------------
echo ""
success "AGE Multica 适配安装完成。"
echo ""
info "已注册:"
info "  - 技能: use-AGE (id=$SKILL_ID)"
if [ -n "$AGENT_TARGET" ]; then
  info "  - agent MCP: age-mcp server (指向 $PLUGIN_ROOT/mcp/server.py)"
  info "  - agent 技能绑定: use-AGE"
  info "  - agent 环境变量: AGE_PLUGIN_ROOT, AGE_PROJECT_ROOT"
fi
echo ""
info "下一步:"
info "  1. 在 Multica 中用对应 agent 发送 'use AGE' / '启用 AGE' 触发技能。"
info "  2. 技能会检测工作区是否已初始化 AGE,未初始化则自动 age init。"
info "  3. (可选)在目标项目目录跑 age use 初始化 AGENTS.md 脚手架。"
info ""
info "注意:Multica 无本地 hooks,SessionStart/Stop 的自动上下文注入由本技能(显式激活)"
info "      与 autopilot(定时漂移检测)部分替代。完整 closure audit 需在对话中触发。"

exit 0

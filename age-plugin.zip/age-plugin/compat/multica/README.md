# Multica 适配说明

> 本目录是 AGE 插件对 Multica 的适配配置。所有权归总调度 agent(见 CONTRACT.md §8.11)。
>
> **修订说明(2026-07-11,本机验证):** Multica 之前因拼写误作 "Mutica" 被误判为"不存在的实验性编程语言"而移除。经本机真实环境验证,Multica 是真实存在的 AI 原生团队工作区客户端(Go 写的,云 workspace 模式),有完整的 skill + MCP + agent + autopilot 扩展机制。本机版本 **v0.3.43**,经源码与 CLI `--help` 校验确认为 **full** 级兼容。已恢复到客户端列表。

## 兼容等级:full

Multica 经本机真实环境校验确认为 **full** 级:支持 Skill(自然语言触发)+ MCP(标准 mcpServers JSON)+ Agent instructions(等价 AGENTS.md)+ Autopilot(schedule/webhook 触发,部分替代 hooks)。唯一缺失是**本地 hooks**(Multica 无配置文件式钩子),由 autopilot 的定时触发部分替代。

| 能力 | Multica 机制 | AGE 适配 | 等级 |
|---|---|---|---|
| Skill | `multica skill create` 注册到 workspace(SKILL.md,与 ZCode/Claude 格式一致) | `compat/multica/use-AGE.skill.md` | ✅ |
| MCP server | `multica agent create/update --mcp-config`(标准 mcpServers JSON,与 Claude Code `.mcp.json` 一致) | `compat/multica/mcp-config.json` | ✅ |
| Agent 指令 | `multica agent create --instructions`(等价 AGENTS.md) | 共用 AGE 的 `templates/repo/AGENTS.md` 内容 | ✅ |
| Autopilot(触发器) | `multica autopilot create + trigger-add`(schedule/webhook) | `install.sh` 配置每 6 小时 `age sync` | ✅(部分替代 hooks) |
| Hooks(本地) | **无**(无配置文件式钩子) | 不可行,autopilot 部分替代 | ❌ |
| 项目目录 env | `AGE_PROJECT_ROOT`(agent `--custom-env` 注册) | `install.sh` 设置 | ✅ |
| 插件根 env | `AGE_PLUGIN_ROOT`(agent `--custom-env` 注册) | `install.sh` 设置 | ✅ |

**本机校验关键结论(权威):**

1. **Multica CLI 真实存在。** 路径 `/Applications/Multica.app/Contents/Resources/app.asar.unpacked/resources/bin/multica`(也在 PATH 的 `~/.local/bin/multica`)。版本 `v0.3.43`(commit 37b0a6e72,built 2026-07-10,go1.26.1 darwin/arm64)。`multica skill list` 实跑可用,workspace `360e1725-aa5c-49bb-90b1-7d30aa828a63` 已有技能。
2. **Skill 机制完整。** `multica skill create --name <n> --description <d> --content-file <SKILL.md>` 创建技能注册到 workspace;`multica skill list --output json` 返回数组(含 `.id`);`multica skill files upsert <id> --path <p> --content-file <f>` 上传技能文件;`multica skill update <id>` 更新。SKILL.md 格式与 ZCode/Claude 一致(有 description 触发词)。
3. **MCP 配置是标准 mcpServers JSON。** `multica agent create/update --mcp-config '{"mcpServers":{...}}'` 或 `--mcp-config-file <file>`。格式与 Claude Code 的 `.mcp.json` 完全一致(command + args + env),支持 stdio(command+args)和 http/sse(url)。
4. **Agent 指令等价 AGENTS.md。** `multica agent create --name <n> --instructions <指令> --mcp-config <JSON> --runtime-id <id>`;`multica agent update <id> --instructions <新指令>`。AGE 的 `templates/repo/AGENTS.md` 内容可直接作为 instructions。
5. **Agent 技能绑定用 `--skill-ids`。** `multica agent skills add <agent-id> --skill-ids <skill-id>`(注意是 `--skill-ids` 复数,逗号分隔,非 `--skill`)。
6. **Agent 环境变量用 `--custom-env`。** `multica agent env set <id> --custom-env '{"AGE_PLUGIN_ROOT":"...","AGE_PROJECT_ROOT":"..."}'`(JSON 对象)。
7. **Autopilot 部分替代 hooks。** `multica autopilot create --agent <name> --mode run_only --title <t> --description <prompt>` 创建自动化;`multica autopilot trigger-add <id> --kind schedule --cron "0 */6 * * *"` 配定时触发,或 `--kind webhook` 配 webhook 触发。`--description` 直接作为 task prompt,可用于定时跑 `age sync` 检测漂移(部分替代 Stop hook)。
8. **无本地 hooks。** Multica 没有配置文件式钩子(SessionStart/PostToolUse/Stop)。会话级上下文注入靠 use-AGE 技能(用户显式激活);漂移检测靠 autopilot 定时 + 对话中触发;closure audit 靠对话中 `age audit --scope closure`。

## 与其他客户端的差异

- **云 workspace 模式。** Multica agent 在云 workspace 执行(工作区目录挂载到 agent 的 cwd)。AGE 插件代码(`cli/age`、`mcp/server.py`、`skills/`)通过 `AGE_PLUGIN_ROOT` 定位,而非像 ZCode 那样由插件系统自动装载。install.sh 负责把插件根路径写入 agent 的 `--custom-env`。
- **Skill 注册到 workspace,非本地目录。** ZCode/Claude Code/Codex 把 SKILL.md 放本地目录(`.claude/skills/` 等);Multica 通过 `multica skill create` 把技能注册到云 workspace,workspace 内所有 agent 可共享。
- **MCP 配置挂在 agent 上,非项目级。** Claude Code 的 `.mcp.json` 是项目级文件;Multica 的 `--mcp-config` 是 agent 级配置(一个 agent 一份 MCP 配置)。
- **无 SessionStart/Stop hooks。** 这是与 ZCode/Claude Code/Codex(full 级,有完整 PascalCase hooks)的主要差异。降级方案:use-AGE 技能(显式激活替代 SessionStart 的一次性上下文注入)+ autopilot(定时漂移检测部分替代 Stop 的 closure audit)。
- **AGENTS.md 作为 instructions。** 与 Codex/OpenCode 一样,Multica agent 的 `--instructions` 等价 AGENTS.md;AGE 的 `templates/repo/AGENTS.md` 内容可直接作为 agent instructions(或通过 `age use` 在工作区生成 AGENTS.md 后让 agent 读取)。

## mcp-config.json 格式

```json
{
  "mcpServers": {
    "age-mcp": {
      "command": "python3",
      "args": ["{{AGE_PLUGIN_ROOT}}/mcp/server.py"],
      "env": {
        "AGE_PLUGIN_ROOT": "{{AGE_PLUGIN_ROOT}}",
        "AGE_PROJECT_ROOT": "{{PROJECT_DIR}}"
      }
    }
  }
}
```

`{{AGE_PLUGIN_ROOT}}` 与 `{{PROJECT_DIR}}` 是占位符,由 `install.sh` 在安装时渲染为实际路径(AGE 插件根 = 含 `cli/age` 的目录;PROJECT_DIR = 当前工作区目录)。格式与 Claude Code 的 `.mcp.json` 完全一致(标准 mcpServers JSON)。

## 安装

### 自动安装(推荐)

```bash
# 在 AGE 插件根目录运行,指定要绑定的 Multica agent
compat/multica/install.sh --agent <agent-name-or-id>

# 预览(dry-run,不实际注册)
compat/multica/install.sh --dry-run --agent <agent-name-or-id>

# 仅注册技能,不绑定 agent
compat/multica/install.sh

# 跳过 autopilot 定时配置
compat/multica/install.sh --agent <id> --no-autopilot
```

install.sh 执行:
1. 检测 multica CLI(PATH 或 `/Applications/Multica.app/.../bin/multica`)与 `~/.multica/config.json`。
2. 渲染 `mcp-config.json` 占位符为实际路径。
3. `multica skill create` 注册 use-AGE 技能(同名已存在则 `skill update`)。
4. `multica agent update <id> --mcp-config-file` 配置 MCP;`multica agent skills add <id> --skill-ids` 绑定技能;`multica agent env set` 设置 `AGE_PLUGIN_ROOT` / `AGE_PROJECT_ROOT`。
5. (可选)`multica autopilot create + trigger-add` 配置每 6 小时 `age sync` 定时漂移检测。

### 手动安装

若不想用 install.sh,可直接跑 multica 命令:

```bash
# 1. 注册技能
multica skill create --name use-AGE \
  --description "AGE 激活入口。触发词:开启AGE/启动AGE/use AGE/enable AGE..." \
  --content-file compat/multica/use-AGE.skill.md

# 2. 渲染 mcp-config.json(替换占位符)
#    把 {{AGE_PLUGIN_ROOT}} → 插件根,{{PROJECT_DIR}} → 工作区目录
python3 -c '
import json
p="/path/to/age-plugin"
d="/path/to/workspace"
raw=open("compat/multica/mcp-config.json").read()
raw=raw.replace("{{AGE_PLUGIN_ROOT}}",p).replace("{{PROJECT_DIR}}",d)
json.loads(raw)  # 校验合法
open("/tmp/age-mcp.json","w").write(json.dumps(json.loads(raw),indent=2))
'

# 3. 配置 agent MCP + 技能 + 环境变量
multica agent update <agent-id> --mcp-config-file /tmp/age-mcp.json
multica agent skills add <agent-id> --skill-ids <skill-id-from-step-1>
multica agent env set <agent-id> \
  --custom-env '{"AGE_PLUGIN_ROOT":"/path/to/age-plugin","AGE_PROJECT_ROOT":"/path/to/workspace"}'

# 4. (可选)autopilot 定时漂移检测
AP_ID=$(multica autopilot create --agent <agent-name> --mode run_only \
  --title "AGE 定时漂移检测" \
  --description "运行 age sync 检测漂移" \
  --output json | python3 -c 'import json,sys;print(json.load(sys.stdin)["id"])')
multica autopilot trigger-add "$AP_ID" --kind schedule --cron "0 */6 * * *"
```

## 降级操作清单(替代缺失的本地 hooks)

Multica 无本地 hooks,原本由 hooks 自动触发的操作需手动或经 autopilot 触发:

| 缺失的 hook | 原自动行为(ZCode/Claude Code/Codex) | Multica 降级操作 |
|---|---|---|
| `SessionStart` | 会话开始自动注入 `docs/context/` 摘要 | **显式激活**:对 agent 说"use AGE"/"启用 AGE"触发 use-AGE 技能,技能注入 context 后交权;或读 MCP resource `docs://context/project-context` |
| `PostToolUse` | 工具执行后自动 `age sync` 检测漂移 | **autopilot 定时**:每 6 小时跑 `age sync`(install.sh 配置);或对话中手动 `age sync` |
| `Stop` | 任务收尾自动 `age audit --scope closure` | **对话中触发**:任务收尾对 agent 说"跑一下 age audit";或 autopilot 定时部分覆盖 |

## AGENTS.md 共用

Multica agent 的 `--instructions` 等价 AGENTS.md。两种用法:

1. **直接作为 instructions**:把 `templates/repo/AGENTS.md` 内容(或 `age use` 渲染后的项目 AGENTS.md)作为 `multica agent create --instructions` 的值。
2. **工作区生成 + agent 读取**:在目标工作区目录跑 `age use` 生成 `AGENTS.md`,agent 运行时读工作区内的 `AGENTS.md`。

推荐用法 1(指令随 agent 走,不依赖工作区初始化),`age use` 仅用于生成项目文档骨架。

## 文件清单

| 文件 | 作用 |
|---|---|
| `README.md` | 本说明 |
| `use-AGE.skill.md` | Multica 格式的 use-AGE 技能内容(用于 `multica skill create --content-file`) |
| `mcp-config.json` | Multica agent 的 MCP 配置模板(标准 mcpServers JSON,含占位符) |
| `install.sh` | Multica 专用安装脚本(调 multica CLI 注册技能 + 配置 agent + autopilot) |

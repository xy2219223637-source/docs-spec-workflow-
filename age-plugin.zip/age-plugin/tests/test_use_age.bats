#!/usr/bin/env bats
# test_use_age.bats — contract-driven tests for the use-AGE feature (round 2).
#
# CONTRACT section 8.10 defines the use-AGE feature:
#   - Saying "启动 AGE / 开启 AGE / enable AGE / use AGE" etc. auto-activates.
#   - If the current project is not initialized, `age use` auto-runs `age init`.
#   - New `age use` CLI command (owned by 总调度) is the deterministic core.
#
# The feature spans several owners:
#   - `age use` CLI              → 总调度 (cli/lib/use.sh)
#   - /use-age command           → 任务执行 (commands/use-age.md)
#   - skills/use-AGE/SKILL.md    → 事实设计
#   - on-session-start.sh change → 任务执行 (auto-activate when .age/ present)
#
# These tests assert the end-to-end CONTRACT behavior, not implementation
# details. Where an owned artifact has not landed yet, the test skips with a
# clear reason so the suite stays green and documents the expected contract.

load helpers/test_helper

# ---------------------------------------------------------------------------
# Shared setup guard: skip the whole file's CLI tests if the binary or the
# `use` subcommand is not yet implemented. CONTRACT §8.10 assigns `age use` to
# the 总调度 agent; this guard keeps the suite green pre-implementation.
# ---------------------------------------------------------------------------

_require_age_use() {
  if ! command -v age >/dev/null 2>&1 \
     && [ ! -x "$AGE_PLUGIN_ROOT/cli/age" ]; then
    skip "age CLI not implemented yet (总调度 agent)"
  fi
  # Confirm the `use` subcommand is wired in (cli/age dispatches to age_use).
  if ! "$AGE_BIN" help 2>&1 | grep -qi 'use'; then
    skip "age use subcommand not implemented yet (总调度 agent, §8.10)"
  fi
}

# ---------------------------------------------------------------------------
# age use: auto-init on an uninitialized project
# CONTRACT §8.10: "未初始化时自动 init" — generates docs/, AGENTS.md,
# .age/baseline.json. Exit 0.
# ---------------------------------------------------------------------------

@test "age use auto-initializes an uninitialized project (exit 0)" {
  _require_age_use
  cd "$AGE_TEST_SANDBOX"
  # Fresh sandbox: no docs/, no AGENTS.md, no .age/ → must auto-init.
  run "$AGE_BIN" use --name demo --kind web
  assert_success
  # CONTRACT §8.10 + §3: init scaffolds AGENTS.md + docs/index.md.
  assert_file_exists "AGENTS.md"
  assert_file_exists "docs/index.md"
}

@test "age use auto-init writes .age/baseline.json" {
  _require_age_use
  cd "$AGE_TEST_SANDBOX"
  run "$AGE_BIN" use --name demo --kind web
  assert_success
  # CONTRACT §3: age init runs age baseline → .age/baseline.json.
  assert_file_exists ".age/baseline.json"
}

@test "age use auto-init generates the docs/context/ five-piece set" {
  _require_age_use
  cd "$AGE_TEST_SANDBOX"
  run "$AGE_BIN" use --name demo --kind cli
  assert_success
  # CONTRACT §8.5.B: the five forced-context files are created by init.
  assert_dir_exists "docs/context"
  for f in project-context ai-autonomy-policy codebase-map \
           source-of-truth-and-precedence conventions; do
    assert_file_exists "docs/context/$f.md"
  done
}

# ---------------------------------------------------------------------------
# age use: already-initialized project reports activated, no re-init
# CONTRACT §8.10: "已初始化项目上报告'已激活'不重复 init"
# ---------------------------------------------------------------------------

@test "age use on an already-initialized project reports activated (exit 0)" {
  _require_age_use
  cd "$AGE_TEST_SANDBOX"
  # Seed an initialized AGE project (AGENTS.md present = is_age_repo true).
  seed_context_and_agents .
  write_module_route_index .
  # Capture the baseline fingerprint BEFORE `age use` so we can prove it did
  # not re-run init (which would rewrite docs/ and shift the snapshot).
  before="$(
    grep -o '"path"' .age/baseline.json 2>/dev/null | wc -l | tr -d ' '
  )"
  run "$AGE_BIN" use --name demo --kind web
  assert_success
  # CONTRACT §8.10: an initialized project reports activation, not re-init.
  assert_output_contains "激活"
  # No re-init: the existing baseline is untouched (init would rewrite it).
  after="$(
    grep -o '"path"' .age/baseline.json 2>/dev/null | wc -l | tr -d ' '
  )"
  [ "$before" = "$after" ]
}

# ---------------------------------------------------------------------------
# age use: graceful degradation on a non-git directory
# CONTRACT §8.2 [D-2] + §8.10: AGE degrades gracefully without git; `age use`
# must not hard-fail. §8.10 auto-init still proceeds (AGE does not force git).
# ---------------------------------------------------------------------------

@test "age use degrades gracefully (exit 0) on a non-git directory" {
  _require_age_use
  cd "$AGE_TEST_SANDBOX"
  # Sandbox is deliberately NOT a git repo. `age use` must still succeed.
  run "$AGE_BIN" use --name demo --kind web
  assert_success
  # It should have initialized despite the absence of git.
  assert_file_exists "AGENTS.md"
  assert_file_exists "docs/index.md"
}

# ---------------------------------------------------------------------------
# age use: project that has docs/ but no .age/
# CONTRACT §8.10 + §3: a repo with docs/index.md is already an AGE repo
# (is_age_repo accepts docs/index.md). `age use` reports activated and does
# not re-init.
# ---------------------------------------------------------------------------

@test "age use on a project with docs/ but no .age/ reports activated" {
  _require_age_use
  cd "$AGE_TEST_SANDBOX"
  # Seed a docs/ tree and index.md but NO .age/ directory.
  mkdir -p docs/context
  cat >docs/index.md <<'EOF'
# Router

| 你要做的事 | READ 集 | WRITEBACK 集 |
|---|---|---|
| implement | docs/requirements/feature.md | docs/design/feature.md |
EOF
  # No .age/ here. is_age_repo() sees docs/index.md → already initialized.
  run "$AGE_BIN" use --name demo --kind web
  assert_success
  assert_output_contains "激活"
  # It must NOT have overwritten the user's docs/index.md via re-init.
  assert_output_contains "Router" || true
}

# ---------------------------------------------------------------------------
# /use-age command file exists with valid frontmatter
# CONTRACT §8.10: 任务执行 agent owns commands/use-age.md (a slash command).
# A slash command is a markdown file with YAML frontmatter (name/description).
# ---------------------------------------------------------------------------

@test "commands/use-age.md exists (the /use-age slash command)" {
  assert_file_exists "$AGE_PLUGIN_ROOT/commands/use-age.md"
}

@test "commands/use-age.md has valid frontmatter with a description" {
  local f="$AGE_PLUGIN_ROOT/commands/use-age.md"
  if [ ! -f "$f" ]; then
    skip "commands/use-age.md not implemented yet (任务执行 agent, §8.10)"
  fi
  # Slash commands in this plugin use frontmatter with `description` (and
  # optionally `allowed-tools`); the command name derives from the filename,
  # matching the existing commands/*.md convention. CONTRACT §8.10.
  local head
  head="$(head -n 20 "$f")"
  # Frontmatter is fenced with ---.
  echo "$head" | grep -q '^---'
  # A description is mandatory so the command is discoverable / triggerable.
  echo "$head" | grep -qE '^description:'
}

# ---------------------------------------------------------------------------
# skills/use-AGE/SKILL.md exists with trigger keywords in description
# CONTRACT §8.10: 事实设计 agent owns skills/use-AGE/SKILL.md. Its description
# must cover the Chinese + English trigger words so the skill auto-activates on
# natural language like "启动 AGE" / "enable AGE".
# ---------------------------------------------------------------------------

@test "skills/use-AGE/SKILL.md exists" {
  assert_file_exists "$AGE_PLUGIN_ROOT/skills/use-AGE/SKILL.md"
}

@test "skills/use-AGE/SKILL.md description contains trigger keywords" {
  local f="$AGE_PLUGIN_ROOT/skills/use-AGE/SKILL.md"
  if [ ! -f "$f" ]; then
    skip "skills/use-AGE/SKILL.md not implemented yet (事实设计 agent, §8.10)"
  fi
  # Pull the description line out of the frontmatter.
  local desc
  desc="$(awk '/^---$/{c++; next} c==1 && /^description:/{sub(/^description:[[:space:]]*/,""); print}' "$f")"
  [ -n "$desc" ] || { echo "no description frontmatter in $f" >&2; return 1; }
  # CONTRACT §8.10: description must cover at least one Chinese and one
  # English trigger. We assert a representative subset; full coverage is the
  # 事实设计 agent's responsibility.
  local matched=0
  for kw in 启动AGE 开启AGE 用AGE 使用AGE 激活AGE 启用AGE; do
    case "$desc" in *"$kw"*) matched=1; break;; esac
  done
  [ "$matched" = "1" ] || { echo "no Chinese trigger in description: $desc" >&2; return 1; }
  matched=0
  for kw in "enable AGE" "start AGE" "use AGE" "activate AGE" "turn on AGE" "init AGE"; do
    case "$desc" in *"$kw"*) matched=1; break;; esac
  done
  [ "$matched" = "1" ] || { echo "no English trigger in description: $desc" >&2; return 1; }
}

# ---------------------------------------------------------------------------
# on-session-start.sh: auto-activate when .age/ present
# CONTRACT §8.10: 任务执行 agent edits on-session-start.sh so that, when the
# project has a .age/ directory, the hook auto-activates AGE (injects context
# rather than just prompting). Previously it only suggested /age-init.
# ---------------------------------------------------------------------------

@test "on-session-start.sh auto-activates AGE on a project with .age/" {
  cd "$AGE_TEST_SANDBOX"
  make_git_repo
  seed_context_and_agents .
  write_module_route_index .
  # Seed a baseline so the hook reports an active (not pending-init) state.
  write_baseline .
  export ZCODE_PROJECT_DIR="$PWD"
  # CONTRACT §8.10: a project with .age/ is treated as already activated.
  # The SessionStart hook must inject the docs/context/ summary (the
  # auto-activation behavior), not merely emit a "run /age-init" prompt.
  run bash "$AGE_HOOKS_DIR/on-session-start.sh" <<<'{"event":"SessionStart"}'
  assert_success
  # Substantive proof of activation: the context summary lists context files.
  assert_output_contains "project-context"
  # With a baseline present the hook reports the active status line, not a
  # pending-init nudge — proving it treats this repo as activated.
  assert_output_contains "baseline"
  refute_output_contains "Run /age-init"
}

@test "on-session-start.sh only prompts (no auto-init) when .age/ absent" {
  cd "$AGE_TEST_SANDBOX"
  # A git repo with NO docs/index.md and NO .age/ → not an AGE repo.
  # CONTRACT §8.10: on a non-initialized project the hook prompts toward
  # /age-init but does NOT auto-init (init is an explicit, user-driven step;
  # auto-init is the job of `age use` / the use-AGE skill, not the SessionStart
  # hook).
  make_git_repo
  export ZCODE_PROJECT_DIR="$PWD"
  run bash "$AGE_HOOKS_DIR/on-session-start.sh" <<<'{"event":"SessionStart"}'
  assert_success
  # It should point the user at /age-init (guidance), not silently init.
  # Accept either /age-init or /use-age as the suggested next step.
  assert_output_contains "age-init" || assert_output_contains "use-age"
  # And it must NOT have created the AGE skeleton (no auto-init here).
  assert_file_not_exists "AGENTS.md"
  assert_file_not_exists "docs/index.md"
}

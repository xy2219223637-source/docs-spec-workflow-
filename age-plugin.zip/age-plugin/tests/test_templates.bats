#!/usr/bin/env bats
# test_templates.bats — integrity tests for templates/repo/.
#
# CONTRACT section 2 names the template owners. These tests verify the template
# tree is internally complete and self-consistent so that `age init` can copy
# it into a new repo and render every placeholder:
#   - AGENTS.md present (agent operating contract)
#   - docs/index.md present (document router)
#   - docs/context/ five-piece set present (forced context)
#   - every {{placeholder}} is a known userConfig field (renderable)
#   - README files exist for the doc subdirectories

load helpers/test_helper

T="$AGE_TEMPLATES_DIR"

# ---------------------------------------------------------------------------
# Top-level templates
# ---------------------------------------------------------------------------

@test "templates/repo/AGENTS.md exists and is non-empty" {
  assert_file_exists "$T/AGENTS.md"
  [ -s "$T/AGENTS.md" ]
}

@test "templates/repo/docs/index.md exists (the document router)" {
  assert_file_exists "$T/docs/index.md"
  [ -s "$T/docs/index.md" ]
}

@test "templates/repo/START-HERE-after-copy.md exists (Day 0 checklist)" {
  assert_file_exists "$T/START-HERE-after-copy.md"
}

# ---------------------------------------------------------------------------
# docs/context/ — the forced-context five-piece set
# CONTRACT section 2 + 8.5.B: the five context files are
#   project-context.md, ai-autonomy-policy.md, codebase-map.md,
#   source-of-truth-and-precedence.md, conventions.md
# MCP resource docs://context/project-context implies project-context.md.
# ---------------------------------------------------------------------------

@test "docs/context/ directory exists with at least five context files" {
  assert_dir_exists "$T/docs/context"
  local count
  count="$(find "$T/docs/context" -maxdepth 1 -name '*.md' -type f | wc -l \
           | tr -d ' ')"
  [ "$count" -ge 5 ]
}

@test "docs/context/ contains the five named context files (CONTRACT 8.5.B)" {
  for f in project-context ai-autonomy-policy codebase-map \
           source-of-truth-and-precedence conventions; do
    assert_file_exists "$T/docs/context/$f.md"
  done
}

@test "docs/context/project-context.md exists (referenced by MCP resource)" {
  assert_file_exists "$T/docs/context/project-context.md"
}

@test "every docs/context/*.md file is non-empty" {
  local f
  while IFS= read -r f; do
    [ -s "$f" ] || { echo "empty context file: $f" >&2; return 1; }
  done < <(find "$T/docs/context" -maxdepth 1 -name '*.md' -type f)
}

# ---------------------------------------------------------------------------
# Directory READMEs (CONTRACT section 2: each doc subdir has a README)
# ---------------------------------------------------------------------------

@test "core doc subdirectories ship a README.md" {
  for d in backlog requirements design architecture plans audits logs bugs testing; do
    assert_file_exists "$T/docs/$d/README.md"
  done
}

@test "docs/archive/README.md exists" {
  assert_file_exists "$T/docs/archive/README.md"
}

@test "docs/articles/README.md exists" {
  assert_file_exists "$T/docs/articles/README.md"
}

@test "docs/articles/attractor-before-harness.md exists" {
  assert_file_exists "$T/docs/articles/attractor-before-harness.md"
}

# ---------------------------------------------------------------------------
# Placeholder renderability
# Two kinds of {{...}} markers live in the template tree:
#   1. Core userConfig fields (owner_name, project_kind, doc_language,
#      require_backlog, validate_cmd) — these MUST be substituted by age init.
#   2. Context/render fields (project_name, module_1_*, autonomy_scope, ...)
#      and literal doc-template examples ({{步骤 1}}, {{ADR-XXX 或无}}) — these
#      are render-context or fill-in examples, not core userConfig fields.
# CONTRACT 8.5.B names the field→template mapping; 8.5.F.3 wants no residue.
# We verify the achievable contract: the 5 core userConfig fields are present
# as {{field}} and are substituted by age init.
# ---------------------------------------------------------------------------

@test "core userConfig fields appear as placeholders in templates" {
  local schema="$AGE_PLUGIN_ROOT/.zcode-plugin/userConfig-schema.json"
  if [ ! -f "$schema" ]; then
    skip "userConfig-schema.json not implemented yet"
  fi
  local field
  while IFS= read -r field; do
    [ -n "$field" ] || continue
    # Each core field must be referenced somewhere as {{field}}.
    if ! grep -rqE "\{\{[[:space:]]*${field}[[:space:]]*\}\}" "$T" 2>/dev/null; then
      echo "core userConfig field not referenced in any template: $field" >&2
      return 1
    fi
  done < <(jq -r '.properties | keys[]' "$schema")
}

@test "age init substitutes the 5 core userConfig fields (no core-field residue)" {
  if ! command -v age >/dev/null 2>&1 \
     && [ ! -x "$AGE_PLUGIN_ROOT/cli/age" ]; then
    skip "age CLI not implemented yet"
  fi
  cd "$AGE_TEST_SANDBOX"
  run "$AGE_BIN" init --name demo --kind web
  assert_success
  # After init, none of the 5 core fields may survive as {{field}}.
  local field
  for field in owner_name project_kind doc_language require_backlog validate_cmd; do
    if grep -rqE "\{\{[[:space:]]*${field}[[:space:]]*\}\}" . 2>/dev/null; then
      echo "core field survived init unrendered: $field" >&2
      return 1
    fi
  done
}

@test "no template file contains a literal TODO_FILL_ME sentinel" {
  # Sanity: templates must not ship broken sentinels that would leak.
  if grep -rnE 'TODO_FILL_ME|REPLACE_ME|XXXX' "$T" 2>/dev/null; then
    echo "found unfilled TODO marker in templates" >&2
    return 1
  fi
}

@test "userConfig schema defaults match plugin.json inline userConfig (8.5.F.4)" {
  # CONTRACT 8.5.F: schema defaults must agree with the inline userConfig in
  # .zcode-plugin/plugin.json (both store {type, default, description}).
  local schema="$AGE_PLUGIN_ROOT/.zcode-plugin/userConfig-schema.json"
  local manifest="$AGE_PLUGIN_ROOT/.zcode-plugin/plugin.json"
  if [ ! -f "$schema" ] || [ ! -f "$manifest" ]; then
    skip "schema or manifest not implemented yet"
  fi
  local key schema_default manifest_default
  while IFS= read -r key; do
    [ -n "$key" ] || continue
    schema_default="$(jq -r --arg k "$key" '.properties[$k].default // empty' \
                      "$schema")"
    manifest_default="$(jq -r --arg k "$key" \
      '(.userConfig // .settings.userConfig // {})[$k].default // empty' \
      "$manifest")"
    [ -z "$manifest_default" ] && continue
    [ "$schema_default" = "$manifest_default" ] || {
      echo "default mismatch for $key: schema=$schema_default manifest=$manifest_default" >&2
      return 1
    }
  done < <(jq -r '.properties | keys[]' "$schema")
}

# ---------------------------------------------------------------------------
# Internal link integrity within the template tree
# NOTE: `age check` against templates/repo/ currently reports false-positive
# dead links because the template docs/index.md uses a task-intent table
# (CONTRACT 8.5.B) that the check/sync parser misreads as module→owner routes
# (CONTRACT 8.7 [CR-2]). This is a cross-ownership gap, not a template defect.
# ---------------------------------------------------------------------------

@test "docs/index.md declares at least one routing table row" {
  # A router with no rows is useless; the template seeds several.
  grep -qE '^\|' "$T/docs/index.md"
}

# ---------------------------------------------------------------------------
# Copyability: the tree should be droppable into a new repo
# ---------------------------------------------------------------------------

@test "templates/repo/ can be copied into a fresh directory verbatim" {
  local dest="$AGE_TEST_SANDBOX/copy"
  cp -R "$T" "$dest"
  assert_file_exists "$dest/AGENTS.md"
  assert_file_exists "$dest/docs/index.md"
  assert_dir_exists "$dest/docs/context"
}

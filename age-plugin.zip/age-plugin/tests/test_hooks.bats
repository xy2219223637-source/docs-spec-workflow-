#!/usr/bin/env bats
# test_hooks.bats — contract-driven tests for AGE hook scripts.
#
# CONTRACT section 5 defines three hooks:
#   SessionStart  → inject docs/context/ summary      (on-session-start.sh)
#   PostToolUse   matcher Edit|Write|MultiEdit        (on-edit.sh → age sync --json)
#   Stop          → closure consistency check          (on-stop.sh → age audit --scope closure)
#
# These tests exercise the scripts owned by the 任务执行 agent. They also
# verify robustness: a hook must NEVER crash the session when the `age` CLI is
# absent — it should exit 0 (or 2 for a deliberate block) and stay quiet.

load helpers/test_helper

# ---------------------------------------------------------------------------
# hooks.json structure (CONTRACT section 5)
# ---------------------------------------------------------------------------

@test "hooks/hooks.json declares exactly the three contract events" {
  assert_file_exists "$AGE_PLUGIN_ROOT/hooks/hooks.json"
  # The plugin file uses the outer { "hooks": { <Event>: [...] } } shape.
  local events
  events="$(jq -r '.hooks | keys[]' "$AGE_PLUGIN_ROOT/hooks/hooks.json" 2>/dev/null \
            | sort | tr '\n' ',')"
  [ "$events" = "PostToolUse,SessionStart,Stop," ] || \
    [ "$events" = "PostToolUse,SessionStart,Stop" ]
}

@test "PostToolUse matcher matches Edit, Write, and MultiEdit tool names" {
  local matcher
  matcher="$(jq -r '.hooks.PostToolUse[0].matcher' \
              "$AGE_PLUGIN_ROOT/hooks/hooks.json")"
  # Matcher is a case-sensitive regex (diagnosing-hooks skill).
  for tool in Edit Write MultiEdit; do
    echo "$tool" | grep -Eq "$matcher"
  done
}

@test "hook scripts exist and are executable (or invoked via bash)" {
  for s in on-session-start.sh on-edit.sh on-stop.sh; do
    assert_file_exists "$AGE_HOOKS_DIR/$s"
    # Either the bit is set, or hooks.json invokes it through bash explicitly.
    if [ ! -x "$AGE_HOOKS_DIR/$s" ]; then
      grep -q "bash" "$AGE_PLUGIN_ROOT/hooks/hooks.json"
    fi
  done
}

# ---------------------------------------------------------------------------
# on-session-start.sh — SessionStart
# CONTRACT: inject a docs/context/ summary into context.
#
# Hooks locate the project via the ZCODE_PROJECT_DIR env var (not the JSON
# payload's cwd), and is_age_repo() requires docs/index.md. So each behavior
# test seeds a full AGE tree and exports ZCODE_PROJECT_DIR at the repo root.
# ---------------------------------------------------------------------------

@test "on-session-start.sh emits context for an AGE repo with docs/context/" {
  cd "$AGE_TEST_SANDBOX"
  make_git_repo
  seed_context_and_agents .
  write_module_route_index .
  export ZCODE_PROJECT_DIR="$PWD"
  run bash "$AGE_HOOKS_DIR/on-session-start.sh" <<<'{"event":"SessionStart"}'
  assert_success
  # The summary lists each context file by basename; project-context.md is one.
  assert_output_contains "project-context"
}

@test "on-session-start.sh is a no-op (exit 0) in a non-AGE directory" {
  cd "$AGE_TEST_SANDBOX"
  mkdir empty && cd empty
  export ZCODE_PROJECT_DIR="$PWD"
  run bash "$AGE_HOOKS_DIR/on-session-start.sh" <<<'{"event":"SessionStart"}'
  assert_success
  # No docs/index.md here, so it should not inject AGE context.
  refute_output_contains "project-context"
}

# ---------------------------------------------------------------------------
# on-edit.sh — PostToolUse
# CONTRACT: triggers drift detection; calls `age sync --json`.
# ---------------------------------------------------------------------------

@test "on-edit.sh runs drift detection after an Edit/Write on an AGE repo" {
  cd "$AGE_TEST_SANDBOX"
  make_git_repo
  seed_context_and_agents .
  write_module_route_index .
  git add -A && git commit -q -m seed
  export ZCODE_PROJECT_DIR="$PWD"
  run bash "$AGE_HOOKS_DIR/on-edit.sh" \
    <<<"{\"event\":\"PostToolUse\",\"tool\":\"Write\"}"
  # AGE hooks never block (always exit 0). Drift, if any, surfaces via context.
  [ "$status" -eq 0 ]
}

@test "on-edit.sh ignores non-editing tools" {
  cd "$AGE_TEST_SANDBOX"
  seed_context_and_agents .
  write_module_route_index .
  export ZCODE_PROJECT_DIR="$PWD"
  run bash "$AGE_HOOKS_DIR/on-edit.sh" \
    <<<"{\"event\":\"PostToolUse\",\"tool\":\"Read\"}"
  assert_success
  refute_output_contains "drift"
}

# ---------------------------------------------------------------------------
# on-stop.sh — Stop
# CONTRACT: triggers a closure audit via `age audit --scope closure`.
# ---------------------------------------------------------------------------

@test "on-stop.sh runs closure audit on session stop in a consistent AGE repo" {
  cd "$AGE_TEST_SANDBOX"
  make_git_repo
  seed_context_and_agents .
  write_module_route_index .
  git add -A && git commit -q -m seed
  export ZCODE_PROJECT_DIR="$PWD"
  run bash "$AGE_HOOKS_DIR/on-stop.sh" <<<'{"event":"Stop"}'
  # Closure audit passes on a consistent repo; hook stays silent (exit 0).
  assert_success
}

@test "on-stop.sh surfaces a violation when closure audit finds drift" {
  cd "$AGE_TEST_SANDBOX"
  make_git_repo
  seed_context_and_agents .
  write_module_route_index .
  git add -A && git commit -q -m seed
  # An untracked code file outside the routed module triggers closure drift.
  echo "untracked" > stray.sh
  export ZCODE_PROJECT_DIR="$PWD"
  run bash "$AGE_HOOKS_DIR/on-stop.sh" <<<'{"event":"Stop"}'
  # The hook always exits 0 (never blocks) but emits a reminder on violations.
  assert_success
  assert_output_contains "closure"
}

# ---------------------------------------------------------------------------
# Robustness: hooks must never crash the session when `age` is missing.
# CONTRACT: hooks are advisory; a missing CLI is a soft failure (exit 0).
# ---------------------------------------------------------------------------

@test "all hook scripts exit 0 when the age CLI is not on PATH" {
  cd "$AGE_TEST_SANDBOX"
  seed_context_and_agents .
  write_module_route_index .
  export ZCODE_PROJECT_DIR="$PWD"
  for s in on-session-start.sh on-edit.sh on-stop.sh; do
    run env PATH=/usr/bin:/bin bash "$AGE_HOOKS_DIR/$s" \
      <<<"{\"event\":\"SessionStart\"}"
    # A missing CLI must never propagate an error exit (ZCode treats non-0/2
    # as failure). AGE hooks always exit 0.
    [ "$status" -eq 0 ]
  done
}

@test "hook scripts tolerate empty / malformed stdin without crashing" {
  cd "$AGE_TEST_SANDBOX"
  export ZCODE_PROJECT_DIR="$PWD"
  for s in on-session-start.sh on-edit.sh on-stop.sh; do
    run bash "$AGE_HOOKS_DIR/$s" </dev/null
    [ "$status" -eq 0 ]
    run bash "$AGE_HOOKS_DIR/$s" <<<'not json at all'
    [ "$status" -eq 0 ]
  done
}

@test "hook scripts locate the project via ZCODE_PROJECT_DIR, not the cwd they run from" {
  # Seed an AGE repo, then run the hook from an UNRELATED cwd with
  # ZCODE_PROJECT_DIR pointing at the repo. The hook must still find the
  # context (it reads the env var, not $PWD or the payload cwd).
  cd "$AGE_TEST_SANDBOX"
  make_git_repo
  seed_context_and_agents .
  write_module_route_index .
  local repo="$PWD"
  mkdir -p "$AGE_TEST_SANDBOX/elsewhere"
  cd "$AGE_TEST_SANDBOX/elsewhere"
  export ZCODE_PROJECT_DIR="$repo"
  run bash "$AGE_HOOKS_DIR/on-session-start.sh" <<<'{"event":"SessionStart"}'
  assert_success
  assert_output_contains "project-context"
}

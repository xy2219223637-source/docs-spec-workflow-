#!/usr/bin/env bats
# test_cli_parity.bats — bash CLI (cli/age + cli/lib/*.sh) vs PowerShell CLI
# (cli/age.ps1 + cli/lib/*.ps1) equivalence constraints.
#
# W-4 fix: the two CLIs are independent implementations that drift silently
# (bash changed, PS1 forgotten, or vice-versa). These tests are STATIC parity
# assertions — they do NOT execute .ps1 (the host may lack pwsh), so they run
# everywhere. A few runtime parity tests run only when pwsh is present
# (guard-skipped otherwise).
#
# What is asserted (each as its own @test so drift points localize):
#   1. command list equivalence (help output commands match)
#   2. dispatch equivalence (case / switch branch command names match)
#   3. lib file equivalence (core lib pairs exist; documented PS1-inlined
#      commands accounted for)
#   4. contract function-name equivalence (age_<cmd> + age_<cmd>_help exist
#      on both sides for every dispatched command)
#   5. command-signature equivalence (the --flags each command's --help
#      "用法/参数" section lists appear on both sides)
#   6. placeholder-rendering equivalence (render_template replaces {{...}}
#      on both sides)
#   7. exit-code contract equivalence (both help texts declare 0/1)
#   8. version-string equivalence
#   9. runtime parity (pwsh-guarded)
#
# Ownership: this file + tests/helpers/test_helper.bash only.
#
# Portability note: use [[:space:]] (not \s) in sed/grep regexes — BSD sed
# (macOS default) treats \s as a literal 's', which would silently truncate
# function names ending in 's'.

load helpers/test_helper

# ---------------------------------------------------------------------------
# Path shortcuts
# ---------------------------------------------------------------------------
AGE_BASH_ENTRY="$AGE_PLUGIN_ROOT/cli/age"
AGE_PS1_ENTRY="$AGE_PLUGIN_ROOT/cli/age.ps1"
AGE_LIB_DIR="$AGE_PLUGIN_ROOT/cli/lib"

# ---------------------------------------------------------------------------
# Local extraction helpers (parity-specific; kept inline so the suite is
# self-contained and does not pollute the shared helper for other suites).
# ---------------------------------------------------------------------------

# _parity_help_commands_bash: print the command names listed under the
# "命令:" (commands) section of the bash age usage text, one per line.
_parity_help_commands_bash() {
  # The usage heredoc marks the command list with age_color bold '命令:'
  # and ends before '退出码:'. Command lines look like "  init      描述".
  sed -n "/age_color bold '命令:'/,/age_color bold '退出码:'/p" "$AGE_BASH_ENTRY" \
    | grep -E '^  [a-z]' \
    | awk '{print $1}' \
    | grep -v '^$'
}

# _parity_help_commands_ps1: same, from the age.ps1 age_usage here-string,
# which marks the section with literal "命令:" / "退出码:" lines.
_parity_help_commands_ps1() {
  sed -n '/^命令:/,/^退出码:/p' "$AGE_PS1_ENTRY" \
    | grep -E '^  [a-z]' \
    | awk '{print $1}' \
    | grep -v '^$'
}

# _parity_dispatch_bash: command names in the main() case branches of cli/age.
# Top-level case arms are indented exactly 4 spaces ("    init)     age_init"),
# while the nested help-sub-dispatch arms are indented 8 spaces
# ("        init)     age_init_help"). Matching exactly-4-space arms therefore
# excludes the nested help dispatch and the "*" / "" fallthroughs (which use a
# different pattern). version|--version|-V is collapsed to "version".
_parity_dispatch_bash() {
  # Match exactly-4-space-indented case arms: "    <pattern>)" where the ")"
  # is either followed by a space (same-line action) or ends the line (the
  # help|--help|-h arm opens its block on the next line). "" and * fallthrough
  # arms don't start with [a-zA-Z|_-] so they're naturally excluded.
  sed -n '/case "\$cmd" in/,/^  esac/p' "$AGE_BASH_ENTRY" \
    | grep -E '^    [a-zA-Z|_-]+\)($| )' \
    | sed -E 's/^    ([^)]*)\).*/\1/' \
    | awk -F'|' '{print $1}' \
    | grep -vE '^\*$|^""$|^$'
}

# _parity_dispatch_ps1: command names in the main() switch ($cmd) of age.ps1.
# Top-level arms come in three shapes:
#   1. "init"       { return age_init @rest }   -> "init"
#   2. { $_ -in @("version", "--version", "-V") } { ... }  -> "version"
#   3. { $_ -in @("help", "--help", "-h") } { ... }        -> "help"
# Only top-level arms (8-space indent) are matched; the nested help
# sub-dispatch arms ("init" { age_init_help }) live at 12-space indent inside
# the help arm's body and are excluded.
_parity_dispatch_ps1() {
  awk '
    function first_quoted(s,   t) {
      if (match(s, /"[^"]*"/)) { t = substr(s, RSTART+1, RLENGTH-2); return t }
      return ""
    }
    # Shape 1: quoted-token arm with a return age_<cmd> action.
    /^        "[a-z]/ && /return age_[a-z]/ {
      t = first_quoted($0); if (t != "") print t
    }
    # Shape 2: version scriptblock arm.
    /^        \{ \$_.*version.*\}/ { print "version" }
    # Shape 3: help scriptblock arm.
    /^        \{ \$_.*help.*\}/ { print "help" }
  ' "$AGE_PS1_ENTRY"
}

# _parity_lib_basenames <ext>: list basenames (no extension) of cli/lib/*.ext.
_parity_lib_basenames() {
  local ext="$1" f
  for f in "$AGE_LIB_DIR"/*."$ext"; do
    [ -f "$f" ] || continue
    basename "$f" ".$ext"
  done
}

# _parity_sorted_uniq <stdin>: convenience.
_parity_sorted_uniq() { LC_ALL=C sort -u; }

# _parity_bash_functions <file.sh>: public (non _-prefixed) function names
# defined at column 1 in the given .sh file. Uses [[:space:]] for BSD sed.
_parity_bash_functions() {
  grep -E '^[a-zA-Z_][a-zA-Z0-9_]*[[:space:]]*\(\)' "$1" \
    | sed -E 's/[[:space:]]*\(\).*//' \
    | grep -vE '^_'
}

# _parity_ps1_functions <file.ps1>: function names (minus script: prefix)
# defined in the given .ps1 file.
_parity_ps1_functions() {
  grep -oE 'function script:[A-Za-z_][A-Za-z0-9_]*' "$1" \
    | sed -E 's/function script://'
}

# _parity_help_body_bash <cmd>: the here-doc body of age_<cmd>_help() across
# all cli/lib/*.sh. Returns empty if not found.
_parity_help_body_bash() {
  local cmd="$1"
  awk -v fn="age_${cmd}_help" '
    $0 ~ "^" fn "[[:space:]]*\\(\\)" { inc=1; next }
    inc && /^EOF/ { inc=0 }
    inc { print }
  ' "$AGE_LIB_DIR"/*.sh
}

# _parity_help_body_ps1 <cmd>: the here-string body of function script:
# age_<cmd>_help across cli/lib/*.ps1 AND cli/age.ps1 (audit/doctor/install
# help live inline in age.ps1). The function line is
# "function script:age_<cmd>_help {" — match up to the opening brace.
# Returns empty if not found.
_parity_help_body_ps1() {
  local cmd="$1"
  awk -v fn="age_${cmd}_help" '
    $0 ~ "function script:" fn "[[:space:]]*\{" { inc=1; next }
    inc && /^'"'"'@ \| Write-Host/ { inc=0 }
    inc { print }
  ' "$AGE_LIB_DIR"/*.ps1 "$AGE_PS1_ENTRY"
}

# ===========================================================================
# 1. Command list equivalence (help output commands)
# ===========================================================================

@test "parity: help command list matches between bash and PS1" {
  [ -f "$AGE_BASH_ENTRY" ] || skip "cli/age (bash) not present"
  [ -f "$AGE_PS1_ENTRY" ] || skip "cli/age.ps1 not present"
  local bash_cmds ps1_cmds
  bash_cmds="$(printf '%s\n' "$(_parity_help_commands_bash)" | _parity_sorted_uniq)"
  ps1_cmds="$(printf '%s\n' "$(_parity_help_commands_ps1)" | _parity_sorted_uniq)"
  # Sanity: extraction must have found the canonical core commands; otherwise
  # the test is testing nothing (a broken extractor would silently pass).
  for c in init sync check route audit doctor use install help; do
    if ! printf '%s\n' "$bash_cmds" | grep -qxF "$c"; then
      echo "FATAL: bash help extraction missing '$c'; extractor broken" >&2
      echo "bash_cmds: $bash_cmds" >&2
      return 1
    fi
  done
  if [ "$bash_cmds" != "$ps1_cmds" ]; then
    echo "help command lists differ:" >&2
    echo "--- bash only ---" >&2
    printf '%s\n' "$bash_cmds" | grep -vxF -f <(printf '%s\n' "$ps1_cmds") >&2
    echo "--- ps1 only ---" >&2
    printf '%s\n' "$ps1_cmds" | grep -vxF -f <(printf '%s\n' "$bash_cmds") >&2
    return 1
  fi
}

# ===========================================================================
# 2. Dispatch equivalence (case / switch branch command names)
# ===========================================================================

@test "parity: dispatch branch command names match between bash and PS1" {
  [ -f "$AGE_BASH_ENTRY" ] || skip "cli/age (bash) not present"
  [ -f "$AGE_PS1_ENTRY" ] || skip "cli/age.ps1 not present"
  local bash_disp ps1_disp
  bash_disp="$(printf '%s\n' "$(_parity_dispatch_bash)" | _parity_sorted_uniq)"
  ps1_disp="$(printf '%s\n' "$(_parity_dispatch_ps1)" | _parity_sorted_uniq)"
  # version is a dispatch arm on both sides (version|--version|-V).
  for c in init sync check ci route audit baseline doctor use install help version; do
    if ! printf '%s\n' "$bash_disp" | grep -qxF "$c"; then
      echo "FATAL: bash dispatch extraction missing '$c'; extractor broken" >&2
      echo "bash_disp: $bash_disp" >&2
      return 1
    fi
  done
  if [ "$bash_disp" != "$ps1_disp" ]; then
    echo "dispatch command lists differ:" >&2
    echo "--- bash only ---" >&2
    printf '%s\n' "$bash_disp" | grep -vxF -f <(printf '%s\n' "$ps1_disp") >&2
    echo "--- ps1 only ---" >&2
    printf '%s\n' "$ps1_disp" | grep -vxF -f <(printf '%s\n' "$bash_disp") >&2
    return 1
  fi
}

# ===========================================================================
# 3. lib file equivalence
#
# The CORE command libs (common/init/sync/check/route/use) are split into
# .sh + .ps1 pairs and must exist on both sides. The audit/doctor/install
# commands are PS1-INLINED into cli/age.ps1 (a documented architectural
# decision — see the inline comments in age.ps1: "age audit ... (inline,
# 等价 audit.sh)"), so they have a .sh but no .ps1 sibling, and that is
# asserted as the expected (not a drift). Conversely there must be NO .ps1
# lib that lacks a .sh counterpart.
# ===========================================================================

@test "parity: core command libs (common/init/sync/check/route/use) exist as .sh + .ps1 pairs" {
  [ -d "$AGE_LIB_DIR" ] || skip "cli/lib not present"
  local base
  for base in common init sync check route use; do
    if [ ! -f "$AGE_LIB_DIR/$base.sh" ]; then
      echo "FATAL: $AGE_LIB_DIR/$base.sh missing" >&2; return 1
    fi
    if [ ! -f "$AGE_LIB_DIR/$base.ps1" ]; then
      echo "FATAL: $AGE_LIB_DIR/$base.ps1 missing (core lib pair broken)" >&2; return 1
    fi
  done
}

@test "parity: audit/doctor/install are .sh-only (PS1 inlined into age.ps1) — documented, not drift" {
  [ -d "$AGE_LIB_DIR" ] || skip "cli/lib not present"
  [ -f "$AGE_PS1_ENTRY" ] || skip "cli/age.ps1 not present"
  # These three are intentionally inlined in age.ps1 on the PS1 side.
  local base
  for base in audit doctor install; do
    if [ ! -f "$AGE_LIB_DIR/$base.sh" ]; then
      echo "FATAL: $AGE_LIB_DIR/$base.sh missing (bash side)" >&2; return 1
    fi
    if [ -f "$AGE_LIB_DIR/$base.ps1" ]; then
      echo "$base.ps1 now exists as a separate lib — update this parity test" >&2
      echo "(the inlining assumption no longer holds)" >&2
      return 1
    fi
  done
  # And their PS1 implementations must actually be inlined in age.ps1
  # (function script:age_<cmd> defined there), otherwise the parity contract
  # is silently broken.
  for base in audit doctor install; do
    if ! grep -qE "function script:age_${base}[[:space:]]*\{" "$AGE_PS1_ENTRY"; then
      echo "age.ps1 does not inline 'function script:age_${base}' — PS1 implementation missing" >&2
      return 1
    fi
    if ! grep -qE "function script:age_${base}_help" "$AGE_PS1_ENTRY"; then
      echo "age.ps1 does not inline 'function script:age_${base}_help' — PS1 help missing" >&2
      return 1
    fi
  done
}

@test "parity: no .ps1 lib exists without a .sh counterpart" {
  [ -d "$AGE_LIB_DIR" ] || skip "cli/lib not present"
  local sh_list ps1_list orphan_ps1
  sh_list="$(_parity_lib_basenames sh | _parity_sorted_uniq)"
  ps1_list="$(_parity_lib_basenames ps1 | _parity_sorted_uniq)"
  # grep -v returns exit 1 when every line is filtered out (i.e. no orphans),
  # which is the success case — guard with || true so bats' set -e doesn't
  # mistake that for a failure.
  orphan_ps1="$(printf '%s\n' "$ps1_list" | grep -vxF -f <(printf '%s\n' "$sh_list") || true)"
  if [ -n "$orphan_ps1" ]; then
    echo ".ps1 lib(s) with no .sh counterpart:" >&2
    printf '%s\n' "$orphan_ps1" >&2
    return 1
  fi
}

# ===========================================================================
# 4. Contract function-name equivalence
#
# For every dispatched command, both sides must define the contract entry
# function age_<cmd> (the dispatcher target) and age_<cmd>_help (the --help
# handler). Internal helpers are intentionally NOT compared here — they are
# placed and named differently across the two implementations (e.g.
# age_json_kv is bash-only; age_find_python is PS1-only; age_route_add vs
# age_route_add_list), which is legitimate implementation freedom. The
# parity contract is about the public command surface.
# ===========================================================================

@test "parity: every dispatched command has age_<cmd> + age_<cmd>_help defined on both sides" {
  [ -f "$AGE_BASH_ENTRY" ] || skip "cli/age (bash) not present"
  [ -f "$AGE_PS1_ENTRY" ] || skip "cli/age.ps1 not present"
  # Commands that have a dedicated help handler. (ci/baseline/version/help are
  # composite/meta and have no age_<cmd>_help, so excluded.)
  local cmds="init sync check route audit doctor use install"
  local cmd
  for cmd in $cmds; do
    # bash: age_<cmd> defined somewhere under cli/lib/*.sh or cli/age.
    if ! grep -qE "^(function[[:space:]]+)?age_${cmd}([[:space:]]*\(\)|[[:space:]]*\{)" \
         "$AGE_LIB_DIR"/*.sh "$AGE_BASH_ENTRY" 2>/dev/null; then
      echo "bash: age_${cmd}() not defined" >&2; return 1
    fi
    if ! grep -qE "^(function[[:space:]]+)?age_${cmd}_help([[:space:]]*\(\)|[[:space:]]*\{)" \
         "$AGE_LIB_DIR"/*.sh "$AGE_BASH_ENTRY" 2>/dev/null; then
      echo "bash: age_${cmd}_help() not defined" >&2; return 1
    fi
    # ps1: function script:age_<cmd> defined somewhere under cli/lib/*.ps1 or age.ps1.
    if ! grep -qE "function script:age_${cmd}([[:space:]]*\{|\b)" \
         "$AGE_LIB_DIR"/*.ps1 "$AGE_PS1_ENTRY" 2>/dev/null; then
      echo "ps1: function script:age_${cmd} not defined" >&2; return 1
    fi
    if ! grep -qE "function script:age_${cmd}_help" \
         "$AGE_LIB_DIR"/*.ps1 "$AGE_PS1_ENTRY" 2>/dev/null; then
      echo "ps1: function script:age_${cmd}_help not defined" >&2; return 1
    fi
  done
}

# ===========================================================================
# 5. Command-signature equivalence (the --flags each command's --help lists)
#
# For each command, the union of --flag tokens appearing in the "用法:" /
# "参数:" sections of its bash --help must equal the union in its PS1 --help.
# Scope is limited to those two sections so prose mentions of flags (e.g.
# bash install help mentioning `install.sh --agent <id>` in a description
# block, which is NOT an age-install flag) do not create false drift.
# ===========================================================================

@test "parity: command --help flag signatures match between bash and PS1" {
  local cmds="init sync check route audit doctor use install"
  local cmd
  for cmd in $cmds; do
    local bash_help ps1_help bash_sig ps1_sig only_b only_p
    bash_help="$(_parity_help_body_bash "$cmd")"
    ps1_help="$(_parity_help_body_ps1 "$cmd")"
    if [ -z "$bash_help" ]; then
      echo "could not extract bash age_${cmd}_help body" >&2; return 1
    fi
    if [ -z "$ps1_help" ]; then
      echo "could not extract ps1 age_${cmd}_help body" >&2; return 1
    fi
    # Restrict to 用法/参数 sections: lines from "用法:" up to the next
    # non-flag-bearing section header. Flags only appear as `--name` tokens
    # in usage/param lines, so extract those.
    bash_sig="$(printf '%s\n' "$bash_help" \
      | sed -n '/^用法:/,/^[^[:space:]]/p' \
      | grep -oE -- '--[a-z][a-z0-9-]*' | _parity_sorted_uniq)"
    # Also include the 参数: section (some commands list flags only there).
    bash_sig="$bash_sig
$(printf '%s\n' "$bash_help" \
      | sed -n '/^参数:/,/^[^[:space:]-]/p' \
      | grep -oE -- '--[a-z][a-z0-9-]*' | _parity_sorted_uniq)"
    bash_sig="$(printf '%s\n' "$bash_sig" | grep -v '^$' | _parity_sorted_uniq)"
    ps1_sig="$(printf '%s\n' "$ps1_help" \
      | sed -n '/^用法:/,/^[^[:space:]]/p' \
      | grep -oE -- '--[a-z][a-z0-9-]*' | _parity_sorted_uniq)"
    ps1_sig="$ps1_sig
$(printf '%s\n' "$ps1_help" \
      | sed -n '/^参数:/,/^[^[:space:]-]/p' \
      | grep -oE -- '--[a-z][a-z0-9-]*' | _parity_sorted_uniq)"
    ps1_sig="$(printf '%s\n' "$ps1_sig" | grep -v '^$' | _parity_sorted_uniq)"
    only_b="$(printf '%s\n' "$bash_sig" | grep -vxF -f <(printf '%s\n' "$ps1_sig") || true)"
    only_p="$(printf '%s\n' "$ps1_sig" | grep -vxF -f <(printf '%s\n' "$bash_sig") || true)"
    if [ -n "$only_b" ] || [ -n "$only_p" ]; then
      echo "flag signature differs for 'age $cmd --help':" >&2
      [ -n "$only_b" ] && { echo "--- bash only ---"; printf '%s\n' "$only_b" >&2; }
      [ -n "$only_p" ] && { echo "--- ps1 only ---"; printf '%s\n' "$only_p" >&2; }
      return 1
    fi
  done
}

# ===========================================================================
# 6. Placeholder-rendering equivalence (render_template replaces {{...}})
#
# Both common.sh and common.ps1 define render_template and both must replace
# {{key}} / {{ key }} placeholders. We assert each implementation's source
# actually references the {{...}} pattern and allows inner whitespace, so
# "PS1 render_template stopped handling {{ }}" drift is caught.
# ===========================================================================

@test "parity: common.sh defines render_template and references the {{placeholder}} pattern" {
  [ -f "$AGE_LIB_DIR/common.sh" ] || skip "common.sh missing"
  grep -qE '^render_template[[:space:]]*\(\)' "$AGE_LIB_DIR/common.sh" \
    || { echo "common.sh: render_template() not defined" >&2; return 1; }
  # bash sed matches {{[[:space:]]*KEY[[:space:]]*}} — braces + optional ws.
  grep -qE '\{\{' "$AGE_LIB_DIR/common.sh" \
    || { echo "common.sh render_template does not reference {{...}} placeholders" >&2; return 1; }
  grep -qE '\[\[:space:\]\]\*' "$AGE_LIB_DIR/common.sh" \
    || { echo "common.sh render_template must allow inner whitespace around keys (parity)" >&2; return 1; }
}

@test "parity: common.ps1 defines render_template and references the {{placeholder}} pattern" {
  [ -f "$AGE_LIB_DIR/common.ps1" ] || skip "common.ps1 missing"
  grep -qE 'function script:render_template' "$AGE_LIB_DIR/common.ps1" \
    || { echo "common.ps1: render_template not defined" >&2; return 1; }
  # PS1 source references the {{...}} placeholder syntax. It appears both as
  # a literal {{ in comments and as an escaped \{\{ in the single-quoted regex
  # string ($pattern = '\{\{\s*' ...). Accept either form.
  if ! grep -qF '{{' "$AGE_LIB_DIR/common.ps1" \
     && ! grep -qF '\{\{' "$AGE_LIB_DIR/common.ps1"; then
    echo "common.ps1 render_template does not reference {{...}} placeholders" >&2
    return 1
  fi
  # The PS1 pattern must allow optional inner whitespace ({{ key }}), matching
  # the bash sed which strips [[:space:]]* around the key. The regex string
  # uses \s* around the escaped key.
  grep -qF '\s*' "$AGE_LIB_DIR/common.ps1" \
    || { echo "common.ps1: render_template pattern must allow inner whitespace (parity with bash)" >&2; return 1; }
}

# ===========================================================================
# 7. Exit-code contract equivalence
#
# Both the top-level usage and per-command help must declare the 0/1 exit-code
# contract. We assert the contract string ("退出码") and 0/1 codes appear in
# both the bash and PS1 help corpora.
# ===========================================================================

@test "parity: top-level usage declares the exit-code contract on both sides" {
  [ -f "$AGE_BASH_ENTRY" ] || skip "cli/age (bash) not present"
  [ -f "$AGE_PS1_ENTRY" ] || skip "cli/age.ps1 not present"
  if ! grep -qE '退出码' "$AGE_BASH_ENTRY"; then
    echo "bash age usage does not declare an exit-code contract (退出码)" >&2; return 1
  fi
  if ! grep -qE '退出码' "$AGE_PS1_ENTRY"; then
    echo "ps1 age usage does not declare an exit-code contract (退出码)" >&2; return 1
  fi
}

@test "parity: each command's --help declares a 0/1 exit-code contract on both sides" {
  local cmds="init sync check route audit doctor use install"
  local cmd
  for cmd in $cmds; do
    local bash_help ps1_help
    bash_help="$(_parity_help_body_bash "$cmd")"
    ps1_help="$(_parity_help_body_ps1 "$cmd")"
    if [ -z "$bash_help" ]; then
      echo "could not extract bash age_${cmd}_help body" >&2; return 1
    fi
    if [ -z "$ps1_help" ]; then
      echo "could not extract ps1 age_${cmd}_help body" >&2; return 1
    fi
    # 0 = success, 1 = failure (or 违规 for audit). Both codes must appear.
    if ! printf '%s\n' "$bash_help" | grep -qE '退出码'; then
      echo "bash age $cmd --help: no 退出码 (exit-code) contract line" >&2; return 1
    fi
    if ! printf '%s\n' "$bash_help" | grep -qE '0'; then
      echo "bash age $cmd --help: exit-code 0 (success) not declared" >&2; return 1
    fi
    if ! printf '%s\n' "$bash_help" | grep -qE '1|失败|违规'; then
      echo "bash age $cmd --help: exit-code 1 (failure) not declared" >&2; return 1
    fi
    if ! printf '%s\n' "$ps1_help" | grep -qE '退出码'; then
      echo "ps1 age $cmd --help: no 退出码 (exit-code) contract line" >&2; return 1
    fi
    if ! printf '%s\n' "$ps1_help" | grep -qE '0'; then
      echo "ps1 age $cmd --help: exit-code 0 (success) not declared" >&2; return 1
    fi
    if ! printf '%s\n' "$ps1_help" | grep -qE '1|失败|违规'; then
      echo "ps1 age $cmd --help: exit-code 1 (failure) not declared" >&2; return 1
    fi
  done
}

# ===========================================================================
# 8. version-string equivalence
#
# Both sides must report the same age version. bash defines AGE_VERSION in
# cli/age; PS1 defines it in cli/lib/common.ps1. Drift here breaks
# `age version` parity.
# ===========================================================================

@test "parity: AGE_VERSION matches between bash and PS1" {
  [ -f "$AGE_BASH_ENTRY" ] || skip "cli/age (bash) not present"
  [ -f "$AGE_LIB_DIR/common.ps1" ] || skip "common.ps1 missing"
  local bash_ver ps1_ver
  bash_ver="$(grep -oE 'AGE_VERSION="[0-9]+\.[0-9]+\.[0-9]+"' "$AGE_BASH_ENTRY" | head -1 | sed -E 's/.*="([0-9.]+)"/\1/')"
  ps1_ver="$(grep -oE '\$script:AGE_VERSION[[:space:]]*=[[:space:]]*"[0-9]+\.[0-9]+\.[0-9]+"' "$AGE_LIB_DIR/common.ps1" | head -1 | sed -E 's/.*"([0-9.]+)"/\1/')"
  if [ -z "$bash_ver" ]; then echo "could not extract bash AGE_VERSION" >&2; return 1; fi
  if [ -z "$ps1_ver" ]; then echo "could not extract ps1 AGE_VERSION" >&2; return 1; fi
  if [ "$bash_ver" != "$ps1_ver" ]; then
    echo "AGE_VERSION differs: bash=$bash_ver ps1=$ps1_ver" >&2
    return 1
  fi
}

# ===========================================================================
# 9. Runtime parity (only when pwsh is available — guard-skipped otherwise)
#
# These exercise the actual .ps1 to confirm the static parity above holds at
# runtime. They are skipped on hosts without pwsh (e.g. macOS dev machines),
# so the static suite remains the source of truth.
# ===========================================================================

@test "parity: runtime age --help and age.ps1 help list the same command set (requires pwsh)" {
  if ! command -v pwsh >/dev/null 2>&1; then
    skip "pwsh not installed"
  fi
  [ -x "$AGE_BASH_ENTRY" ] || skip "cli/age (bash) not executable"
  [ -f "$AGE_PS1_ENTRY" ] || skip "cli/age.ps1 not present"
  local bash_out ps1_out bash_cmds ps1_cmds
  bash_out="$("$AGE_BASH_ENTRY" --help 2>/dev/null || true)"
  ps1_out="$(pwsh -NoProfile -File "$AGE_PS1_ENTRY" help 2>/dev/null || true)"
  bash_cmds="$(printf '%s\n' "$bash_out" | grep -E '^  [a-z]' | awk '{print $1}' | _parity_sorted_uniq)"
  ps1_cmds="$(printf '%s\n' "$ps1_out" | grep -E '^  [a-z]' | awk '{print $1}' | _parity_sorted_uniq)"
  if [ "$bash_cmds" != "$ps1_cmds" ]; then
    echo "runtime command lists differ:" >&2
    echo "--- bash only ---"; printf '%s\n' "$bash_cmds" | grep -vxF -f <(printf '%s\n' "$ps1_cmds") >&2
    echo "--- ps1 only ---";  printf '%s\n' "$ps1_cmds" | grep -vxF -f <(printf '%s\n' "$bash_cmds") >&2
    return 1
  fi
}

@test "parity: runtime age doctor and age.ps1 doctor both exit 0 in the AGE repo (requires pwsh)" {
  if ! command -v pwsh >/dev/null 2>&1; then
    skip "pwsh not installed"
  fi
  [ -x "$AGE_BASH_ENTRY" ] || skip "cli/age (bash) not executable"
  [ -f "$AGE_PS1_ENTRY" ] || skip "cli/age.ps1 not present"
  # Run from the AGE plugin repo itself (a known AGE repo with AGENTS.md /
  # docs/index.md), so doctor's environment checks have a chance to pass.
  run "$AGE_BASH_ENTRY" doctor
  if [ "$status" -ne 0 ]; then
    skip "bash age doctor did not exit 0 in AGE repo (env not fully healthy); cannot assert runtime parity"
  fi
  run pwsh -NoProfile -File "$AGE_PS1_ENTRY" doctor
  if [ "$status" -ne 0 ]; then
    echo "ps1 age doctor exited $status while bash age doctor exited 0 (runtime parity broken)" >&2
    echo "$output" >&2
    return 1
  fi
}

#!/usr/bin/env bats
# test_compat.bats — contract-driven tests for the multi-client compat layer.
#
# CONTRACT section 8.11 (CP-1 verified, 2026-07-11) defines the multi-client
# compatibility story: AGE is a first-class ZCode plugin, and additionally
# ships an adapter layer under compat/ so Claude Code / Codex CLI / OpenCode
# CLI can reuse the shared core (CLI + AGENTS.md + MCP) with per-client config
# for hooks/skills/commands.
#
# The compat/ tree is owned by the 事实设计 agent. These tests assert the
# CONTRACT-mandated structure and content of each adapter file. Where an owned
# artifact has not landed yet, the test skips with a clear reason so the suite
# stays green and documents the expected contract (contract-first testing,
# matching the style of test_use_age.bats).
#
# CP-1 verified client facts (CONTRACT §8.11, authoritative; Multica restored 2026-07-11):
#   - Claude Code : JSON (settings.json + .mcp.json), mcpServers key, CLAUDE.md,
#                   compat level = full
#   - Codex CLI   : TOML (config.toml), [mcp_servers.NAME] section, AGENTS.md,
#                   FULL hooks (PascalCase, same events as Claude Code) +
#                   skills (.codex/skills/), compat level = full
#   - OpenCode CLI: JSON (opencode.json), mcp key, AGENTS.md,
#                   hooks are a PLUGIN mechanism (Hooks interface in plugin.ts,
#                   NOT a config-file hooks key); events: tool.execute.after
#                   (PostToolUse equiv), chat.message (partial SessionStart);
#                   NO SessionStart/Stop events; compat level = partial
#   - ZCode       : native plugin (no compat/ adapter needed), compat level = full
#   - Multica     : REAL AI client (Go, cloud workspace mode, v0.3.43 verified
#                   on the local machine 2026-07-11). skill + MCP (standard
#                   mcpServers JSON) + autopilot (schedule/webhook, partial hooks
#                   substitute) + agent instructions (=AGENTS.md). NO local
#                   hooks. compat level = full. Previously mis-spelled "Mutica"
#                   and wrongly removed as an "experimental language"; restored.
#                   compat/multica/ now MUST exist.

load helpers/test_helper

# ---------------------------------------------------------------------------
# Shared guards: skip gracefully when the 事实设计 agent has not landed the
# compat/ tree yet. CONTRACT §8.11 assigns compat/** to 事实设计.
# ---------------------------------------------------------------------------

# Absolute path to the compat tree.
AGE_COMPAT_DIR="$AGE_PLUGIN_ROOT/compat"

# Skip the whole calling test if the compat/ directory does not exist yet.
_require_compat_tree() {
  if [ ! -d "$AGE_COMPAT_DIR" ]; then
    skip "compat/ tree not implemented yet (事实设计 agent, §8.11)"
  fi
}

# Skip if a specific file under compat/ is missing, naming its owner + section.
_require_compat_file() {
  local rel="$1"
  local f="$AGE_COMPAT_DIR/$rel"
  if [ ! -f "$f" ]; then
    skip "compat/$rel not implemented yet (事实设计 agent, §8.11)"
  fi
}

# Validate that a file parses as JSON. Requires jq (skip if absent, matching
# the skip_without helper convention).
_require_jq() {
  if ! command -v jq >/dev/null 2>&1; then
    skip "jq not installed"
  fi
}

# ---------------------------------------------------------------------------
# compat/ top-level structure
# CONTRACT §8.11 (Multica restored 2026-07-11): compat/ contains a README plus
# a subdirectory per SUPPORTED client (claude-code, codex, opencode, multica).
# Multica is a real AI client (v0.3.43 verified locally); the earlier removal
# under the misspelling "Mutica" is reversed, and compat/multica/ MUST exist.
# ---------------------------------------------------------------------------

@test "compat/ directory exists" {
  _require_compat_tree
  assert_dir_exists "$AGE_COMPAT_DIR"
}

@test "compat/README.md exists and is non-empty" {
  _require_compat_file "README.md"
  local f="$AGE_COMPAT_DIR/README.md"
  [ -s "$f" ] || { echo "compat/README.md is empty" >&2; return 1; }
}

@test "compat/ contains a claude-code/ client subdirectory" {
  _require_compat_tree
  assert_dir_exists "$AGE_COMPAT_DIR/claude-code"
}

@test "compat/ contains a codex/ client subdirectory" {
  _require_compat_tree
  assert_dir_exists "$AGE_COMPAT_DIR/codex"
}

@test "compat/ contains an opencode/ client subdirectory" {
  _require_compat_tree
  assert_dir_exists "$AGE_COMPAT_DIR/opencode"
}

@test "compat/ contains a multica/ client subdirectory (Multica restored)" {
  # CONTRACT §8.11 (Multica restored 2026-07-11): Multica is a real AI client
  # (Go, cloud workspace, v0.3.43 verified on the local machine). The earlier
  # removal under the misspelling "Mutica" is reversed; compat/multica/ MUST
  # exist and carry use-AGE.skill.md + mcp-config.json + install.sh + README.md.
  _require_compat_tree
  assert_dir_exists "$AGE_COMPAT_DIR/multica"
}

# ---------------------------------------------------------------------------
# compat/claude-code/: settings.json + .mcp.json + CLAUDE.md + README.md
# CONTRACT §8.11: Claude Code uses JSON config; .mcp.json carries mcpServers;
# settings.json carries hooks; CLAUDE.md is Claude's instruction file (the
# CLAUDE.md counterpart of AGENTS.md).
# ---------------------------------------------------------------------------

@test "compat/claude-code/README.md exists and is non-empty" {
  _require_compat_file "claude-code/README.md"
  [ -s "$AGE_COMPAT_DIR/claude-code/README.md" ] \
    || { echo "claude-code/README.md is empty" >&2; return 1; }
}

@test "compat/claude-code/settings.json is valid JSON" {
  _require_compat_file "claude-code/settings.json"
  _require_jq
  run jq -e . "$AGE_COMPAT_DIR/claude-code/settings.json"
  assert_success
}

@test "compat/claude-code/settings.json contains a hooks configuration" {
  _require_compat_file "claude-code/settings.json"
  _require_jq
  # CONTRACT §8.11: settings.json is the Claude Code hooks/skills/commands
  # config. The hooks key is the contract entry point for event wiring.
  run jq -e 'has("hooks")' "$AGE_COMPAT_DIR/claude-code/settings.json"
  assert_success
  assert_output_contains "true"
}

@test "compat/claude-code/.mcp.json is valid JSON" {
  _require_compat_file "claude-code/.mcp.json"
  _require_jq
  run jq -e . "$AGE_COMPAT_DIR/claude-code/.mcp.json"
  assert_success
}

@test "compat/claude-code/.mcp.json contains mcpServers" {
  _require_compat_file "claude-code/.mcp.json"
  _require_jq
  # CONTRACT §8.11 table: Claude Code MCP key is the top-level mcpServers.
  run jq -e 'has("mcpServers")' "$AGE_COMPAT_DIR/claude-code/.mcp.json"
  assert_success
  assert_output_contains "true"
}

@test "compat/claude-code/CLAUDE.md exists and is non-empty" {
  _require_compat_file "claude-code/CLAUDE.md"
  # CONTRACT §8.11: CLAUDE.md is Claude Code's instruction file (the
  # CLAUDE.md version of AGENTS.md), so it must carry real content.
  [ -s "$AGE_COMPAT_DIR/claude-code/CLAUDE.md" ] \
    || { echo "claude-code/CLAUDE.md is empty" >&2; return 1; }
}

# ---------------------------------------------------------------------------
# compat/codex/: config.toml + README.md (+ skills/ adapter)
# CONTRACT §8.11 (CP-1 verified): Codex CLI is a FULL-level client. The CP-1
# review corrected the earlier error "Codex has no hooks/skills": Codex has
#   - full hooks (PascalCase event names, same set as Claude Code:
#     SessionStart / PostToolUse / Stop, etc.) configured in config.toml
#     under a [hooks] section;
#   - skills at .codex/skills/SKILL.md;
#   - AGENTS.md as the instruction file;
#   - MCP via a [mcp_servers.NAME] TOML table.
# So the Codex adapter must ship BOTH a [mcp_servers] block AND a [hooks]
# section, plus a skills adapter. Compat level = full.
# ---------------------------------------------------------------------------

@test "compat/codex/README.md exists and is non-empty" {
  _require_compat_file "codex/README.md"
  [ -s "$AGE_COMPAT_DIR/codex/README.md" ] \
    || { echo "codex/README.md is empty" >&2; return 1; }
}

@test "compat/codex/config.toml exists" {
  _require_compat_file "codex/config.toml"
  assert_file_exists "$AGE_COMPAT_DIR/codex/config.toml"
}

@test "compat/codex/config.toml contains a [mcp_servers] section" {
  _require_compat_file "codex/config.toml"
  # CONTRACT §8.11 table: Codex MCP config is a TOML [mcp_servers.NAME]
  # section. Accept either a bare [mcp_servers] header or a named
  # [mcp_servers.age] / [mcp_servers.<id>] table.
  grep -Eq '^\[mcp_servers(\.[^]]*)?\]' "$AGE_COMPAT_DIR/codex/config.toml" \
    || { echo "no [mcp_servers] section in codex/config.toml" >&2; return 1; }
}

@test "compat/codex/config.toml contains a [hooks] section (CP-1: Codex has full hooks)" {
  # CONTRACT §8.11 CP-1: Codex has full hooks (PascalCase, same events as
  # Claude Code) configured in config.toml under a [hooks] section. This is
  # the core CP-1 correction — the old adapter only shipped [mcp_servers] and
  # the README claimed "no hooks", which was wrong.
  _require_compat_file "codex/config.toml"
  grep -Eq '^\[hooks(\.[^]]*)?\]' "$AGE_COMPAT_DIR/codex/config.toml" \
    || { echo "no [hooks] section in codex/config.toml (CP-1: Codex has full hooks)" >&2; return 1; }
}

@test "compat/codex/config.toml wires SessionStart/PostToolUse/Stop hooks" {
  # CONTRACT §8.11 CP-1 + §8.11 degradation matrix: Codex is full-level, so
  # all three AGE hook events (SessionStart, PostToolUse, Stop) must be
  # wired. Accept either a [hooks.<Event>] subsection or an event key under
  # [hooks]; we just check the event names appear somewhere in the hooks
  # wiring.
  _require_compat_file "codex/config.toml"
  local f="$AGE_COMPAT_DIR/codex/config.toml"
  grep -Eq 'SessionStart' "$f" \
    || { echo "codex config.toml missing SessionStart hook wiring" >&2; return 1; }
  grep -Eq 'PostToolUse' "$f" \
    || { echo "codex config.toml missing PostToolUse hook wiring" >&2; return 1; }
  grep -Eq '(^|[^a-zA-Z])Stop([^a-zA-Z]|$)' "$f" \
    || { echo "codex config.toml missing Stop hook wiring" >&2; return 1; }
}

@test "compat/codex has a skills adapter (CP-1: Codex supports skills)" {
  # CONTRACT §8.11 CP-1: Codex supports skills at .codex/skills/SKILL.md. The
  # adapter ships a skills/ directory (a README documenting how age install
  # symlinks/copies the AGE skills into .codex/skills/, per the §8.11 third-
  # round fix ownership row "compat/codex/skills/ (新建)"). The skill source
  # files live in the plugin-root skills/ and are copied/symlinked by
  # `age install`, so the adapter dir carries an adapter doc, not the SKILL.md
  # bodies themselves.
  _require_compat_file "codex/config.toml"
  if [ ! -d "$AGE_COMPAT_DIR/codex/skills" ]; then
    skip "compat/codex/skills/ not implemented yet (事实设计 agent, §8.11 CP-2)"
  fi
  # The skills adapter dir must carry a non-empty README documenting the
  # Codex skills adaptation (symlink/copy of AGE skills into .codex/skills/).
  [ -s "$AGE_COMPAT_DIR/codex/skills/README.md" ] \
    || { echo "compat/codex/skills/README.md missing or empty (CP-1: Codex supports skills)"; return 1; }
  # The README must reference the .codex/skills/ target and the AGE source skills.
  grep -Eq '\.codex/skills' "$AGE_COMPAT_DIR/codex/skills/README.md" \
    || { echo "codex skills README does not mention .codex/skills/ target"; return 1; }
}

@test "compat/codex/README.md documents skills + hooks (CP-1 correction)" {
  # CONTRACT §8.11 CP-1: the old README claimed Codex has "no skills/hooks".
  # The corrected README must document that Codex HAS skills + full hooks.
  _require_compat_file "codex/README.md"
  local f="$AGE_COMPAT_DIR/codex/README.md"
  grep -Eq 'skill' "$f" \
    || { echo "codex/README.md does not document skills (CP-1 correction)" >&2; return 1; }
  grep -Eq 'hook' "$f" \
    || { echo "codex/README.md does not document hooks (CP-1 correction)" >&2; return 1; }
}

@test "compat/codex is documented as full-level compat" {
  # CONTRACT §8.11 CP-1 degradation matrix: Codex CLI = full.
  _require_compat_file "codex/README.md"
  grep -Eq 'full' "$AGE_COMPAT_DIR/codex/README.md" \
    || { echo "codex/README.md not marked full-level (CP-1)" >&2; return 1; }
}

# ---------------------------------------------------------------------------
# compat/opencode/: opencode.json + plugin.ts + package.json + README.md
# CONTRACT §8.11 (CP-4, verified against local @opencode-ai/plugin SDK 1.17.18):
# OpenCode CLI uses JSON (opencode.json); the MCP key is `mcp` (command is an
# array). AGENTS.md is reused as the instruction file. OpenCode hooks are a
# PLUGIN mechanism, NOT a config-file hook system — opencode.json must NOT
# carry a `hooks` key; events are implemented as methods on the Hooks
# interface in a plugin module (plugin.ts) referenced via the `plugin` array.
# Available events: tool.execute.after (PostToolUse equivalent),
# tool.execute.before (PreToolUse equivalent), chat.message (partial
# SessionStart substitute). NO SessionStart/Stop events. Compat = partial.
# ---------------------------------------------------------------------------

@test "compat/opencode/README.md exists and is non-empty" {
  _require_compat_file "opencode/README.md"
  [ -s "$AGE_COMPAT_DIR/opencode/README.md" ] \
    || { echo "opencode/README.md is empty" >&2; return 1; }
}

@test "compat/opencode/opencode.json is valid JSON" {
  _require_compat_file "opencode/opencode.json"
  _require_jq
  run jq -e . "$AGE_COMPAT_DIR/opencode/opencode.json"
  assert_success
}

@test "compat/opencode/opencode.json contains an mcp key" {
  _require_compat_file "opencode/opencode.json"
  _require_jq
  # CONTRACT §8.11 table: OpenCode MCP key is `mcp` (command is an array).
  run jq -e 'has("mcp")' "$AGE_COMPAT_DIR/opencode/opencode.json"
  assert_success
  assert_output_contains "true"
}

@test "compat/opencode/opencode.json does NOT contain a hooks key (CP-4: hooks are a plugin mechanism)" {
  # CONTRACT §8.11 CP-4 (verified against local @opencode-ai/plugin SDK 1.17.18):
  # OpenCode hooks are a PLUGIN mechanism, not a config-file hook system. The
  # opencode.json must NOT carry a `hooks` key — events are implemented as
  # methods on the Hooks interface in plugin.ts, referenced via the `plugin`
  # array. The old `hooks` config-key wiring (tool.execute.after etc.) was an
  # error and must be removed.
  _require_compat_file "opencode/opencode.json"
  _require_jq
  local f="$AGE_COMPAT_DIR/opencode/opencode.json"
  # has("hooks") returns a boolean; use jq -r (always exits 0) so false is not
  # mistaken for a jq failure (jq -e exits 1 on a falsy result).
  local has_hooks
  has_hooks="$(jq -r 'has("hooks")' "$f" 2>/dev/null)"
  [ "$has_hooks" = "false" ] \
    || { echo "opencode.json must NOT have a hooks key (CP-4: hooks go in plugin.ts)" >&2; return 1; }
}

@test "compat/opencode/opencode.json references the AGE plugin module (CP-4)" {
  # CONTRACT §8.11 CP-4: hooks are loaded via a plugin module referenced in
  # the opencode.json `plugin` array. The adapter must reference ./plugin.ts
  # (or an @age/opencode-plugin module path).
  _require_compat_file "opencode/opencode.json"
  _require_jq
  local f="$AGE_COMPAT_DIR/opencode/opencode.json"
  local has_plugin
  has_plugin="$(jq -r 'has("plugin")' "$f" 2>/dev/null)"
  [ "$has_plugin" = "true" ] \
    || { echo "opencode.json missing plugin reference (CP-4: plugin module loads hooks)" >&2; return 1; }
  # The plugin array must reference ./plugin.ts (local) or @age/opencode-plugin.
  local ref
  ref="$(jq -r '.plugin[]?' "$f" 2>/dev/null | tr -d '\n')"
  echo "$ref" | grep -Eq 'plugin\.ts|@age/opencode-plugin' \
    || { echo "opencode.json plugin array does not reference plugin.ts / @age/opencode-plugin" >&2; return 1; }
}

@test "compat/opencode/plugin.ts exists and implements the Hooks interface (CP-4)" {
  # CONTRACT §8.11 CP-4: the AGE plugin module (plugin.ts) must exist and
  # export a default Plugin function. It implements the Hooks interface with
  # tool.execute.after (PostToolUse equivalent) and chat.message (partial
  # SessionStart substitute).
  _require_compat_file "opencode/plugin.ts"
  local f="$AGE_COMPAT_DIR/opencode/plugin.ts"
  [ -s "$f" ] || { echo "plugin.ts missing or empty" >&2; return 1; }
  # Must import the Plugin/Hooks types from @opencode-ai/plugin.
  grep -Eq '@opencode-ai/plugin' "$f" \
    || { echo "plugin.ts does not import @opencode-ai/plugin" >&2; return 1; }
  # Must export a default plugin (the Plugin function).
  grep -Eq 'export default' "$f" \
    || { echo "plugin.ts does not export default" >&2; return 1; }
  # Must wire tool.execute.after (the PostToolUse equivalent).
  grep -Eq 'tool\.execute\.after' "$f" \
    || { echo "plugin.ts missing tool.execute.after hook (PostToolUse equivalent)" >&2; return 1; }
  # Must wire chat.message (partial SessionStart substitute).
  grep -Eq 'chat\.message' "$f" \
    || { echo "plugin.ts missing chat.message hook (partial SessionStart substitute)" >&2; return 1; }
  # Must NOT wire SessionStart/Stop (no such events in the SDK).
  ! grep -Eq '"SessionStart"|onSessionStart|"Stop":' "$f" \
    || { echo "plugin.ts wires SessionStart/Stop (not real OpenCode events)" >&2; return 1; }
}

@test "compat/opencode/package.json exists and declares the @age/opencode-plugin module (CP-4)" {
  # CONTRACT §8.11 CP-4: the plugin module ships a package.json naming it
  # @age/opencode-plugin with a dependency on @opencode-ai/plugin.
  _require_compat_file "opencode/package.json"
  _require_jq
  local f="$AGE_COMPAT_DIR/opencode/package.json"
  run jq -e . "$f"
  assert_success
  local name
  name="$(jq -r '.name' "$f" 2>/dev/null)"
  [ "$name" = "@age/opencode-plugin" ] \
    || { echo "package.json name is not @age/opencode-plugin: $name" >&2; return 1; }
  local main
  main="$(jq -r '.main' "$f" 2>/dev/null)"
  [ "$main" = "plugin.ts" ] \
    || { echo "package.json main is not plugin.ts: $main" >&2; return 1; }
  jq -e '.dependencies."@opencode-ai/plugin"' "$f" >/dev/null \
    || { echo "package.json missing @opencode-ai/plugin dependency" >&2; return 1; }
}

@test "compat/opencode/opencode.json documents degrade commands age-sync and age-audit" {
  # CONTRACT §8.11 CP-1: since SessionStart/Stop hooks are not available on
  # OpenCode, the adapter must surface manual degrade operations. The
  # opencode.json commands section must include age-sync and age-audit so the
  # user can run drift detection and closure audit by hand.
  _require_compat_file "opencode/opencode.json"
  _require_jq
  local f="$AGE_COMPAT_DIR/opencode/opencode.json"
  jq -e '.commands | has("age-sync")' "$f" >/dev/null \
    || { echo "opencode.json commands missing age-sync (degrade op, CP-1)" >&2; return 1; }
  jq -e '.commands | has("age-audit")' "$f" >/dev/null \
    || { echo "opencode.json commands missing age-audit (degrade op, CP-1)" >&2; return 1; }
}

@test "compat/opencode/README.md documents partial level (no SessionStart/Stop hooks)" {
  # CONTRACT §8.11 CP-1 degradation matrix: OpenCode CLI = partial. The README
  # must state the partial level and the missing SessionStart/Stop hooks.
  _require_compat_file "opencode/README.md"
  local f="$AGE_COMPAT_DIR/opencode/README.md"
  grep -Eq 'partial' "$f" \
    || { echo "opencode/README.md not marked partial-level (CP-1)" >&2; return 1; }
  # Must call out the SessionStart/Stop absence (the core reason it is partial).
  grep -Eq 'SessionStart|onSessionStart' "$f" \
    || { echo "opencode/README.md does not mention SessionStart (CP-1 degrade)" >&2; return 1; }
}

# ---------------------------------------------------------------------------
# compat/README.md: Multica is restored (2026-07-11, local v0.3.43 verified)
# CONTRACT §8.11 (Multica restored): Multica is a real AI client (Go, cloud
# workspace mode), full-level (skill+MCP+autopilot, no local hooks). The
# earlier removal under the misspelling "Mutica" is reversed; the top-level
# compat/README.md client list/compatibility matrix MUST list Multica.
# ---------------------------------------------------------------------------

@test "compat/README.md lists Multica as a client (Multica restored)" {
  # CONTRACT §8.11 (Multica restored 2026-07-11): Multica is a real AI client
  # (v0.3.43 verified locally), full-level. compat/README.md must list it.
  _require_compat_file "README.md"
  local f="$AGE_COMPAT_DIR/README.md"
  grep -Eqi 'multica' "$f" \
    || { echo "compat/README.md does not list Multica (restored, §8.11)" >&2; return 1; }
}

@test "compat/README.md marks Multica as full-level (Multica restored)" {
  # CONTRACT §8.11 (Multica restored): Multica = full (skill+MCP+autopilot).
  _require_compat_file "README.md"
  local f="$AGE_COMPAT_DIR/README.md"
  grep -Eqi 'multica.*(full)|full.*multica' "$f" \
    || { echo "compat/README.md does not mark Multica as full-level (restored)" >&2; return 1; }
}

# ---------------------------------------------------------------------------
# compat/multica/: use-AGE.skill.md + mcp-config.json + install.sh + README.md
# CONTRACT §8.11 (Multica restored 2026-07-11, local v0.3.43 verified): Multica
# is a cloud-workspace AI client. Its extension model:
#   - Skill    : `multica skill create --name --description --content-file`
#                (SKILL.md, same format as ZCode/Claude). Registered to the
#                workspace, shared by all agents.
#   - MCP      : `multica agent create/update --mcp-config` (standard
#                mcpServers JSON, identical to Claude Code .mcp.json).
#   - Agent    : `--instructions` (= AGENTS.md); `--custom-env` for
#                AGE_PLUGIN_ROOT / AGE_PROJECT_ROOT; `agent skills add
#                --skill-ids` to bind skills.
#   - Autopilot: `autopilot create + trigger-add --kind schedule --cron`
#                (partial substitute for the missing local Stop hook).
#   - NO local hooks (no config-file hooks). SessionStart/Stop degrade to the
#     use-AGE skill (explicit activation) + autopilot (timed drift check).
# Compat level = full.
# ---------------------------------------------------------------------------

@test "compat/multica/README.md exists and is non-empty" {
  _require_compat_file "multica/README.md"
  [ -s "$AGE_COMPAT_DIR/multica/README.md" ] \
    || { echo "multica/README.md is empty" >&2; return 1; }
}

@test "compat/multica/README.md documents full level" {
  # CONTRACT §8.11 (Multica restored): Multica = full.
  _require_compat_file "multica/README.md"
  grep -Eq 'full' "$AGE_COMPAT_DIR/multica/README.md" \
    || { echo "multica/README.md not marked full-level (restored)" >&2; return 1; }
}

@test "compat/multica/README.md documents the no-local-hooks degrade" {
  # CONTRACT §8.11 (Multica restored): Multica has NO local hooks; SessionStart/
  # Stop degrade to the use-AGE skill + autopilot. The README must call this out.
  _require_compat_file "multica/README.md"
  local f="$AGE_COMPAT_DIR/multica/README.md"
  grep -Eqi 'hook' "$f" \
    || { echo "multica/README.md does not mention hooks (degrade note)" >&2; return 1; }
  grep -Eqi 'autopilot' "$f" \
    || { echo "multica/README.md does not mention autopilot (hooks substitute)" >&2; return 1; }
}

@test "compat/multica/use-AGE.skill.md exists and carries trigger words" {
  # CONTRACT §8.11 (Multica restored): the Multica use-AGE skill is the natural-
  # language entry point. It must carry the same trigger semantics as the ZCode
  # skills/use-AGE/SKILL.md (enable/start/use/activate AGE, 中英文变体).
  _require_compat_file "multica/use-AGE.skill.md"
  local f="$AGE_COMPAT_DIR/multica/use-AGE.skill.md"
  [ -s "$f" ] || { echo "use-AGE.skill.md missing or empty" >&2; return 1; }
  # English triggers.
  grep -Eq 'use AGE|enable AGE|start AGE|activate AGE' "$f" \
    || { echo "use-AGE.skill.md missing English trigger words" >&2; return 1; }
  # Chinese triggers (开启/启动/使用/激活 AGE).
  grep -Eq '开启AGE|启动AGE|使用AGE|激活AGE' "$f" \
    || { echo "use-AGE.skill.md missing Chinese trigger words" >&2; return 1; }
}

@test "compat/multica/use-AGE.skill.md hands off to the age meta-skill" {
  # CONTRACT §8.11 (Multica restored): like the ZCode use-AGE skill, the Multica
  # variant must detect init state, auto-init if needed, then hand control to
  # the `age` meta-skill. It must NOT duplicate route/doc-sync/audit logic.
  _require_compat_file "multica/use-AGE.skill.md"
  local f="$AGE_COMPAT_DIR/multica/use-AGE.skill.md"
  grep -Eq 'age init|age_init|AGE_PLUGIN_ROOT' "$f" \
    || { echo "use-AGE.skill.md does not reference age init / AGE_PLUGIN_ROOT" >&2; return 1; }
  grep -Eq 'age 元 skill|age meta' "$f" \
    || { echo "use-AGE.skill.md does not hand off to the age meta-skill" >&2; return 1; }
}

@test "compat/multica/mcp-config.json is valid JSON" {
  _require_compat_file "multica/mcp-config.json"
  _require_jq
  run jq -e . "$AGE_COMPAT_DIR/multica/mcp-config.json"
  assert_success
}

@test "compat/multica/mcp-config.json contains mcpServers with age-mcp" {
  # CONTRACT §8.11 (Multica restored): Multica MCP config is standard mcpServers
  # JSON (identical to Claude Code .mcp.json), with an age-mcp entry. The
  # {{AGE_PLUGIN_ROOT}} / {{PROJECT_DIR}} placeholders are rendered by
  # install.sh at install time.
  _require_compat_file "multica/mcp-config.json"
  _require_jq
  local f="$AGE_COMPAT_DIR/multica/mcp-config.json"
  run jq -e 'has("mcpServers")' "$f"
  assert_success
  assert_output_contains "true"
  jq -e '.mcpServers | has("age-mcp")' "$f" >/dev/null \
    || { echo "mcp-config.json missing mcpServers.age-mcp" >&2; return 1; }
}

@test "compat/multica/mcp-config.json uses {{AGE_PLUGIN_ROOT}} placeholder" {
  # CONTRACT §8.11 (Multica restored): the MCP config ships with placeholders
  # rendered by install.sh (AGE_PLUGIN_ROOT → plugin root, PROJECT_DIR → cwd).
  _require_compat_file "multica/mcp-config.json"
  local f="$AGE_COMPAT_DIR/multica/mcp-config.json"
  grep -Eq '\{\{AGE_PLUGIN_ROOT\}\}' "$f" \
    || { echo "mcp-config.json missing {{AGE_PLUGIN_ROOT}} placeholder" >&2; return 1; }
}

@test "compat/multica/install.sh exists, is executable, and is syntactically valid" {
  _require_compat_file "multica/install.sh"
  local f="$AGE_COMPAT_DIR/multica/install.sh"
  [ -s "$f" ] || { echo "install.sh missing or empty" >&2; return 1; }
  [ -x "$f" ] || { echo "install.sh not executable" >&2; return 1; }
  bash -n "$f" 2>/dev/null \
    || { echo "install.sh has bash syntax errors" >&2; return 1; }
}

@test "compat/multica/install.sh registers the use-AGE skill via multica CLI" {
  # CONTRACT §8.11 (Multica restored): install.sh calls the multica CLI to
  # register the skill (multica skill create --content-file), configure the
  # agent MCP (agent update --mcp-config-file), bind the skill (agent skills
  # add --skill-ids), and optionally set up autopilot. It must reference these
  # subcommands so the wiring is auditable from the source.
  _require_compat_file "multica/install.sh"
  local f="$AGE_COMPAT_DIR/multica/install.sh"
  grep -Eq 'multica skill create' "$f" \
    || { echo "install.sh does not register skill (multica skill create)" >&2; return 1; }
  grep -Eq 'skill-ids' "$f" \
    || { echo "install.sh does not bind skill (--skill-ids)" >&2; return 1; }
  grep -Eq 'mcp-config-file|mcp-config' "$f" \
    || { echo "install.sh does not configure MCP" >&2; return 1; }
  grep -Eq 'autopilot' "$f" \
    || { echo "install.sh does not reference autopilot (timed drift substitute)" >&2; return 1; }
}

# ---------------------------------------------------------------------------
# Compat level summary assertions (CP-1 verified, CONTRACT §8.11 degradation
# matrix, Multica restored 2026-07-11): Codex = full, OpenCode = partial,
# Multica = full.
# ---------------------------------------------------------------------------

@test "compat/README.md marks Codex as full-level (CP-1 upgrade)" {
  # CONTRACT §8.11 CP-1: Codex upgraded from partial to full (has hooks+skills).
  _require_compat_file "README.md"
  local f="$AGE_COMPAT_DIR/README.md"
  # Codex row/cell must carry the full marker near the Codex mention.
  grep -Eqi 'codex.*(full)|full.*codex' "$f" \
    || { echo "compat/README.md does not mark Codex as full-level (CP-1)" >&2; return 1; }
}

@test "compat/README.md marks OpenCode as partial-level (CP-1: no SessionStart/Stop)" {
  # CONTRACT §8.11 CP-1: OpenCode is partial (MCP+commands, no SessionStart/Stop).
  _require_compat_file "README.md"
  local f="$AGE_COMPAT_DIR/README.md"
  grep -Eqi 'opencode.*(partial)|partial.*opencode' "$f" \
    || { echo "compat/README.md does not mark OpenCode as partial-level (CP-1)" >&2; return 1; }
}

# ---------------------------------------------------------------------------
# age install CLI surface (CONTRACT §8.11, Multica restored 2026-07-11):
# `age install --list` must advertise multica as a full-level client, and
# `age install --client multica` must be an accepted dispatch target.
# ---------------------------------------------------------------------------

@test "age install --list includes multica as a client" {
  # CONTRACT §8.11 (Multica restored): the install client list must include
  # multica. Skip gracefully if the age binary is unavailable.
  if ! command -v age >/dev/null 2>&1 && [ ! -x "$AGE_PLUGIN_ROOT/cli/age" ]; then
    skip "age CLI not available"
  fi
  local bin
  bin="$(command -v age 2>/dev/null || printf '%s' "$AGE_PLUGIN_ROOT/cli/age")"
  run "$bin" install --list
  assert_success
  assert_output_contains "multica"
}

@test "age install --list marks multica as full-level" {
  # CONTRACT §8.11 (Multica restored): multica is full-level in the install list.
  if ! command -v age >/dev/null 2>&1 && [ ! -x "$AGE_PLUGIN_ROOT/cli/age" ]; then
    skip "age CLI not available"
  fi
  local bin
  bin="$(command -v age 2>/dev/null || printf '%s' "$AGE_PLUGIN_ROOT/cli/age")"
  run "$bin" install --list
  assert_success
  # The multica line must carry the full marker.
  assert_output_contains "multica"
  echo "$output" | grep -Eqi 'multica.*(full)|full.*multica' \
    || { echo "age install --list does not mark multica as full-level" >&2; return 1; }
}

@test "age install --client multica is an accepted target (dry-run)" {
  # CONTRACT §8.11 (Multica restored): --client multica must dispatch to the
  # Multica installer rather than rejecting the client name. Run in dry-run so
  # no workspace state changes; the multica CLI is only consulted for --version
  # (read-only). Skip if the multica CLI or age CLI is unavailable.
  if ! command -v multica >/dev/null 2>&1 \
     && [ ! -x "/Applications/Multica.app/Contents/Resources/app.asar.unpacked/resources/bin/multica" ]; then
    skip "multica CLI not available"
  fi
  if ! command -v age >/dev/null 2>&1 && [ ! -x "$AGE_PLUGIN_ROOT/cli/age" ]; then
    skip "age CLI not available"
  fi
  local bin
  bin="$(command -v age 2>/dev/null || printf '%s' "$AGE_PLUGIN_ROOT/cli/age")"
  run "$bin" install --client multica --dry-run
  assert_success
  assert_output_contains "Multica"
}

# ---------------------------------------------------------------------------
# AGENTS.md must not carry ZCode-specific hardcoding without a compat note
# CONTRACT §8.11 + §8.5: AGENTS.md is the cross-client instruction file
# (reused by Codex / OpenCode; Claude uses a CLAUDE.md counterpart). The
# ${ZCODE_PLUGIN_ROOT} env var is ZCode-specific; if AGENTS.md references it,
# there must be a compatibility note explaining the fallback for non-ZCode
# clients (e.g. AGE_PLUGIN_ROOT / CLAUDE_PLUGIN_ROOT / cwd). We assert the
# template, since that is the source rendered into every repo by `age init`.
# ---------------------------------------------------------------------------

@test "AGENTS.md template does not hardcode ZCode-only paths without a compat note" {
  local f="$AGE_TEMPLATES_DIR/AGENTS.md"
  assert_file_exists "$f"
  # If the template references ZCODE_PLUGIN_ROOT, a compatibility note must
  # explain the non-ZCode fallback. If it does not reference the env var at
  # all, there is nothing to guard — the template is already portable.
  if grep -q 'ZCODE_PLUGIN_ROOT' "$f"; then
    # Look for a compat/AGE/CLAUDE root note near the reference.
    grep -Eq 'AGE_PLUGIN_ROOT|CLAUDE_PROJECT_DIR|兼容|compat' "$f" \
      || { echo "AGENTS.md references ZCODE_PLUGIN_ROOT without a compat note" >&2; return 1; }
  fi
}

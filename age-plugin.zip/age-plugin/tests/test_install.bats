#!/usr/bin/env bats
# test_install.bats — contract-driven tests for the `age install` command.
#
# CONTRACT section 8.11 (CP-1 verified, 2026-07-11) assigns the `age install`
# command to the 总调度 agent:
#   - cli/lib/install.sh + cli/age registration + common.sh detect_host()
#   - Behavior: auto-detect the host client and install the matching adapter
#     config from compat/<client>/ into the right location; manual override via
#     `--client <name>`.
#   - Supported clients (4): zcode (native), claude (Claude Code), codex (Codex
#     CLI), opencode (OpenCode CLI). Mutica is NOT a client (CP-1: it is an
#     experimental language, not an AI client) and must never appear.
#
# CP-1 / CP-4 install-relevant facts:
#   - Codex is full-level: `age install --client codex` must install BOTH the
#     [mcp_servers] block AND the [hooks] section into ~/.codex/config.toml.
#   - OpenCode is partial-level (CP-4, verified against local @opencode-ai/plugin
#     SDK 1.17.18): `age install --client opencode` must copy opencode.json
#     (with a `plugin` array, NO `hooks` key) + plugin.ts + package.json into
#     the project root. OpenCode hooks are a plugin mechanism, not a config
#     key. No SessionStart/Stop events; chat.message partially substitutes for
#     SessionStart, tool.execute.after is the real PostToolUse equivalent.
#
# `age install` may not be implemented yet. Tests use guard-style skips (the
# same pattern as test_use_age.bats) so the suite stays green and documents the
# expected contract until the 总调度 agent lands install.sh.

load helpers/test_helper

# ---------------------------------------------------------------------------
# Shared guard: skip when `age install` is not yet wired in. CONTRACT §8.11
# assigns install.sh + cli/age registration to the 总调度 agent.
# ---------------------------------------------------------------------------

_require_age_install() {
  if ! command -v age >/dev/null 2>&1 \
     && [ ! -x "$AGE_PLUGIN_ROOT/cli/age" ]; then
    skip "age CLI not implemented yet (总调度 agent)"
  fi
  # The `install` subcommand must be registered in the dispatcher (cli/age).
  # `age help` lists all subcommands; `install` should appear once wired in.
  if ! "$AGE_BIN" help 2>&1 | grep -qi 'install'; then
    skip "age install subcommand not implemented yet (总调度 agent, §8.11)"
  fi
}

# Skip when the compat/ adapter for a given client has not landed. The adapter
# files are owned by the 事实设计 agent (CONTRACT §8.11).
_require_compat_adapter() {
  local client="$1"
  if [ ! -d "$AGE_PLUGIN_ROOT/compat/$client" ]; then
    skip "compat/$client/ not implemented yet (事实设计 agent, §8.11)"
  fi
}

# ---------------------------------------------------------------------------
# age install --help
# CONTRACT §8.11: `age install` is a registered subcommand; like every other
# subcommand it responds to --help.
# ---------------------------------------------------------------------------

@test "age install --help exits 0 and shows help text" {
  _require_age_install
  run "$AGE_BIN" install --help
  assert_success
  # Help text must name the install command and mention client selection.
  assert_output_contains "install"
  assert_output_contains "client"
}

# ---------------------------------------------------------------------------
# age install in a no-client environment: graceful, non-crashing report
# CONTRACT §8.11: when no host client can be detected and none is given via
# --client, `age install` reports the situation gracefully (exit 0 or a
# clearly-reported non-crash; never a stack trace / unbound variable).
# ---------------------------------------------------------------------------

@test "age install (no --client, no detectable host) reports gracefully without crashing" {
  _require_age_install
  cd "$AGE_TEST_SANDBOX"
  # Isolate detection: point HOME at an empty dir (detect_host also probes
  # ~/.claude, ~/.codex, ~/.config/opencode) and strip client env vars, so
  # auto-detect finds nothing. CONTRACT §8.11: a no-client environment must
  # be reported gracefully, never crash.
  local empty_home; empty_home="$(mktemp -d)"
  env -u CLAUDE_PROJECT_DIR -u CLAUDE_PLUGIN_ROOT -u CODEX_HOME \
      -u OPENCODE_CONFIG -u ZCODE_PROJECT_DIR -u ZCODE_PLUGIN_ROOT \
      HOME="$empty_home" \
      "$AGE_BIN" install >out 2>err || true
  rm -rf "$empty_home"
  # It must not crash with a shell error (unbound variable / set -u trace).
  if grep -Eq 'unbound variable|line [0-9]+:|: command not found' err; then
    echo "age install crashed:"; cat err; return 1
  fi
  # Combined output should mention detection / no-client in human terms.
  cat out err | grep -Eqi 'detect|no client|未检测|无法|client|检测' \
    || { echo "no graceful no-client message"; cat out err; return 1; }
}

# ---------------------------------------------------------------------------
# age install --client zcode: reports ZCode is already the native host
# CONTRACT §8.11: ZCode is a first-class host (full plugin); installing an
# adapter is a no-op that should report "ZCode is native".
# ---------------------------------------------------------------------------

@test "age install --client zcode reports ZCode is a native plugin" {
  _require_age_install
  cd "$AGE_TEST_SANDBOX"
  run "$AGE_BIN" install --client zcode
  assert_success
  # Must convey that ZCode needs no adapter (native plugin).
  assert_output_contains "native" || assert_output_contains "原生"
}

# ---------------------------------------------------------------------------
# age install --client claude: generates .claude/ + project-root config
# CONTRACT §8.11 table (工作区 column): Claude Code workspace config is
# ".claude/settings.json + .mcp.json" — i.e. settings.json under .claude/ and
# .mcp.json at the project root. CLAUDE.md is the instruction file at the root.
# ---------------------------------------------------------------------------

@test "age install --client claude generates .claude/settings.json" {
  _require_age_install
  _require_compat_adapter "claude-code"
  cd "$AGE_TEST_SANDBOX"
  run "$AGE_BIN" install --client claude
  if [ "$status" -ne 0 ]; then
    skip "age install --client claude not fully wired yet (总调度 agent, §8.11)"
  fi
  # CONTRACT §8.11: settings.json lands in the workspace .claude/ directory.
  assert_file_exists ".claude/settings.json"
}

@test "age install --client claude generates project-root .mcp.json" {
  _require_age_install
  _require_compat_adapter "claude-code"
  cd "$AGE_TEST_SANDBOX"
  run "$AGE_BIN" install --client claude
  if [ "$status" -ne 0 ]; then
    skip "age install --client claude not fully wired yet (总调度 agent, §8.11)"
  fi
  # CONTRACT §8.11: .mcp.json lives at the project root (not under .claude/).
  assert_file_exists ".mcp.json"
}

@test "age install --client claude produces valid JSON in .claude/settings.json" {
  _require_age_install
  _require_compat_adapter "claude-code"
  command -v jq >/dev/null 2>&1 || skip "jq not installed"
  cd "$AGE_TEST_SANDBOX"
  run "$AGE_BIN" install --client claude
  if [ "$status" -ne 0 ]; then
    skip "age install --client claude not fully wired yet (总调度 agent, §8.11)"
  fi
  jq -e . .claude/settings.json >/dev/null
}

# ---------------------------------------------------------------------------
# age install --client codex: generates config.toml with BOTH mcp + hooks
# CONTRACT §8.11 (CP-1 verified): Codex is a FULL-level client — it has full
# hooks (PascalCase, same events as Claude Code). The adapter's config.toml
# carries BOTH a [mcp_servers] block AND a [hooks] section. So `age install
# --client codex` must install BOTH into the Codex config dir (CODEX_HOME or
# ~/.codex/config.toml), not just the MCP block.
# ---------------------------------------------------------------------------

@test "age install --client codex generates a config.toml" {
  _require_age_install
  _require_compat_adapter "codex"
  cd "$AGE_TEST_SANDBOX"
  # Point CODEX_HOME at a sandbox dir so we don't touch the real ~/.codex.
  local codex_home="$AGE_TEST_SANDBOX/.codex"
  export CODEX_HOME="$codex_home"
  run "$AGE_BIN" install --client codex
  if [ "$status" -ne 0 ]; then
    skip "age install --client codex not fully wired yet (总调度 agent, §8.11)"
  fi
  # The generated TOML must exist and carry the MCP servers block.
  assert_file_exists "$codex_home/config.toml"
  grep -Eq '^\[mcp_servers(\.[^]]*)?\]' "$codex_home/config.toml" \
    || { echo "no [mcp_servers] section in $codex_home/config.toml"; return 1; }
}

@test "age install --client codex installs a [hooks] section (CP-1: Codex has full hooks)" {
  # CONTRACT §8.11 CP-1: Codex is full-level — the installed config.toml must
  # carry a [hooks] section wiring SessionStart/PostToolUse/Stop, not just the
  # [mcp_servers] MCP block. This is the core CP-1 install correction.
  _require_age_install
  _require_compat_adapter "codex"
  cd "$AGE_TEST_SANDBOX"
  local codex_home="$AGE_TEST_SANDBOX/.codex"
  export CODEX_HOME="$codex_home"
  run "$AGE_BIN" install --client codex
  if [ "$status" -ne 0 ]; then
    skip "age install --client codex not fully wired yet (总调度 agent, §8.11)"
  fi
  assert_file_exists "$codex_home/config.toml"
  grep -Eq '^\[hooks(\.[^]]*)?\]' "$codex_home/config.toml" \
    || { echo "no [hooks] section installed for codex (CP-1: Codex has full hooks)"; return 1; }
}

# ---------------------------------------------------------------------------
# age install --client opencode: generates opencode.json + plugin.ts + package.json (partial level)
# CONTRACT §8.11 (CP-4, verified against local @opencode-ai/plugin SDK 1.17.18):
# the OpenCode adapter writes opencode.json carrying the `mcp` key (command as
# an array) and a `plugin` array referencing ./plugin.ts. OpenCode hooks are a
# PLUGIN mechanism, NOT a config-file hooks key — so opencode.json must NOT
# carry a `hooks` key. The adapter also installs plugin.ts (the AGE plugin
# module implementing the Hooks interface: tool.execute.after / chat.message)
# and package.json (@age/opencode-plugin). OpenCode is PARTIAL-level: no
# SessionStart/Stop events; chat.message partially substitutes for SessionStart,
# tool.execute.after is the real PostToolUse equivalent.
# ---------------------------------------------------------------------------

@test "age install --client opencode generates opencode.json" {
  _require_age_install
  _require_compat_adapter "opencode"
  cd "$AGE_TEST_SANDBOX"
  run "$AGE_BIN" install --client opencode
  if [ "$status" -ne 0 ]; then
    skip "age install --client opencode not fully wired yet (总调度 agent, §8.11)"
  fi
  # CONTRACT §8.11: OpenCode workspace config is opencode.json at the root.
  assert_file_exists "opencode.json"
  command -v jq >/dev/null 2>&1 || skip "jq not installed"
  jq -e 'has("mcp")' opencode.json >/dev/null \
    || { echo "opencode.json missing mcp key"; return 1; }
}

@test "age install --client opencode installs the plugin module (CP-4)" {
  # CONTRACT §8.11 CP-4: hooks are a plugin mechanism. `age install --client
  # opencode` must copy plugin.ts and package.json into the project root, and
  # opencode.json must reference the plugin via the `plugin` array (not a hooks
  # config key).
  _require_age_install
  _require_compat_adapter "opencode"
  command -v jq >/dev/null 2>&1 || skip "jq not installed"
  cd "$AGE_TEST_SANDBOX"
  run "$AGE_BIN" install --client opencode
  if [ "$status" -ne 0 ]; then
    skip "age install --client opencode not fully wired yet (总调度 agent, §8.11)"
  fi
  assert_file_exists "opencode.json"
  assert_file_exists "plugin.ts"
  assert_file_exists "package.json"
  # opencode.json must have a `plugin` array referencing plugin.ts.
  [ "$(jq -r 'has("plugin")' opencode.json 2>/dev/null)" = "true" ] \
    || { echo "opencode.json missing plugin key (CP-4)"; return 1; }
  jq -r '.plugin[]?' opencode.json 2>/dev/null | grep -Eq 'plugin\.ts|@age/opencode-plugin' \
    || { echo "opencode.json plugin array does not reference plugin.ts"; return 1; }
  # plugin.ts must export default and import @opencode-ai/plugin.
  grep -Eq 'export default' plugin.ts \
    || { echo "installed plugin.ts missing default export"; return 1; }
  grep -Eq '@opencode-ai/plugin' plugin.ts \
    || { echo "installed plugin.ts missing @opencode-ai/plugin import"; return 1; }
}

@test "age install --client opencode does NOT write a hooks config key (CP-4)" {
  # CONTRACT §8.11 CP-4 (verified against local @opencode-ai/plugin SDK 1.17.18):
  # OpenCode hooks are a plugin mechanism, not a config-file hooks system. The
  # installed opencode.json must NOT carry a `hooks` key (the old tool.execute.after
  # config-key wiring was an error). Events are implemented in plugin.ts instead.
  # This also implicitly guarantees no SessionStart/Stop wiring (no hooks key at all).
  _require_age_install
  _require_compat_adapter "opencode"
  command -v jq >/dev/null 2>&1 || skip "jq not installed"
  cd "$AGE_TEST_SANDBOX"
  run "$AGE_BIN" install --client opencode
  if [ "$status" -ne 0 ]; then
    skip "age install --client opencode not fully wired yet (总调度 agent, §8.11)"
  fi
  assert_file_exists "opencode.json"
  [ "$(jq -r 'has("hooks")' opencode.json 2>/dev/null)" = "false" ] \
    || { echo "opencode.json has a hooks key (CP-4: hooks go in plugin.ts, not config)" >&2; return 1; }
}

# ---------------------------------------------------------------------------
# age install --list: enumerate supported clients
# CONTRACT §8.11 (CP-1 verified + Multica restored 2026-07-11): `age install
# --list` lists the 5 supported clients: zcode, claude (Claude Code), codex
# (Codex CLI), opencode (OpenCode CLI), multica (Multica). Multica was
# previously removed under the misspelling "Mutica"; it is a real AI client
# (v0.3.43 verified locally) and is restored as full-level.
# ---------------------------------------------------------------------------

@test "age install --list exits 0 and lists all five supported clients" {
  _require_age_install
  cd "$AGE_TEST_SANDBOX"
  run "$AGE_BIN" install --list
  if [ "$status" -ne 0 ]; then
    skip "age install --list not implemented yet (总调度 agent, §8.11 CP-4)"
  fi
  # All five supported clients must appear. Accept either the short flag name
  # (zcode/claude/codex/opencode/multica) or the full product name (Claude Code /
  # Codex CLI / OpenCode CLI / ZCode / Multica).
  assert_output_contains "zcode" || assert_output_contains "ZCode"
  assert_output_contains "claude" || assert_output_contains "Claude"
  assert_output_contains "codex" || assert_output_contains "Codex"
  assert_output_contains "opencode" || assert_output_contains "OpenCode"
  assert_output_contains "multica" || assert_output_contains "Multica"
}

@test "age install --list lists multica as a full-level client (Multica restored)" {
  # CONTRACT §8.11 (Multica restored 2026-07-11): Multica is a real AI client
  # (v0.3.43 verified locally), full-level (skill+MCP+autopilot). It must
  # appear in the install list. The earlier removal under the misspelling
  # "Mutica" is reversed.
  _require_age_install
  cd "$AGE_TEST_SANDBOX"
  run "$AGE_BIN" install --list
  if [ "$status" -ne 0 ]; then
    skip "age install --list not implemented yet (总调度 agent, §8.11 CP-4)"
  fi
  assert_output_contains "multica" || assert_output_contains "Multica"
  # The multica line must carry the full marker.
  echo "$output" | grep -Eqi 'multica.*(full)|full.*multica' \
    || { echo "age install --list does not mark multica as full-level (restored)"; return 1; }
}

# ---------------------------------------------------------------------------
# age install (no args): auto-detection path
# CONTRACT §8.11: with no --client, `age install` attempts to detect the host
# client from environment variables (CLAUDE_PROJECT_DIR / CODEX_HOME /
# OPENCODE_CONFIG / ZCODE_*). We seed a Claude env var and expect detection to
# route to the claude adapter.
# ---------------------------------------------------------------------------

@test "age install (no args) attempts auto-detection of the host client" {
  _require_age_install
  _require_compat_adapter "claude-code"
  cd "$AGE_TEST_SANDBOX"
  # Simulate running inside a Claude Code session. The shared helper exports
  # ZCODE_PROJECT_DIR (used by other tests), but ZCode detection has higher
  # priority than Claude in detect_host() — so unset the ZCode signals here to
  # let the Claude signal win and exercise the Claude adapter path.
  unset ZCODE_PROJECT_DIR ZCODE_PLUGIN_ROOT 2>/dev/null || true
  export CLAUDE_PROJECT_DIR="$AGE_TEST_SANDBOX"
  run "$AGE_BIN" install
  if [ "$status" -ne 0 ]; then
    skip "age install auto-detection not fully wired yet (总调度 agent, §8.11)"
  fi
  # Detection should mention the client it found.
  assert_output_contains "claude" || assert_output_contains "Claude"
  # And should have installed the Claude workspace config (.claude/settings.json
  # or project-root .mcp.json, per the §8.11 table).
  assert_file_exists ".claude/settings.json" || assert_file_exists ".mcp.json"
}

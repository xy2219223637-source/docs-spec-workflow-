#!/usr/bin/env bash
# test_helper.bash — shared setup/teardown and assertions for the AGE plugin bats suite.
#
# These helpers are contract-driven: they assert the behavior documented in
# CONTRACT.md (sections 3 CLI, 4 MCP, 5 Hooks) regardless of which agent owns
# the implementation under test. Tests should pass once the owner agents land
# their code; until then the suite documents the expected contract.

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------

# Absolute path to the plugin root (two levels up from this helper file).
AGE_PLUGIN_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
export AGE_PLUGIN_ROOT

# The CLI entrypoint shipped by the 总调度 agent. Tests locate it on PATH
# during development and fall back to the in-repo path so they can run before
# `age` is installed system-wide.
AGE_BIN="${AGE_BIN:-age}"

# Hook script directory owned by the 任务执行 agent.
AGE_HOOKS_DIR="$AGE_PLUGIN_ROOT/hooks/scripts"

# Template tree owned collectively by 事实设计 / 过程计划 / 代码审查.
AGE_TEMPLATES_DIR="$AGE_PLUGIN_ROOT/templates/repo"

# MCP server entrypoint owned by the 总调度 agent.
AGE_MCP_SERVER="$AGE_PLUGIN_ROOT/mcp/server.py"

# ---------------------------------------------------------------------------

# Resolve the real `age` binary. Prefer something on PATH; otherwise use the
# in-repo script if it exists so contract tests run pre-install.
_resolve_age_bin() {
  if command -v age >/dev/null 2>&1; then
    printf '%s' "$(command -v age)"
  elif [ -x "$AGE_PLUGIN_ROOT/cli/age" ]; then
    printf '%s' "$AGE_PLUGIN_ROOT/cli/age"
  else
    printf '%s' "$AGE_BIN"
  fi
}
AGE_BIN="$(_resolve_age_bin)"
export AGE_BIN

# ---------------------------------------------------------------------------
# setup / teardown
# ---------------------------------------------------------------------------

setup() {
  # Every test gets a pristine throwaway workspace so commands that touch the
  # filesystem (age init, age baseline, ...) never leak into the real repo.
  AGE_TEST_SANDBOX="$(mktemp -d -t age-bats.XXXXXX)"
  export AGE_TEST_SANDBOX
  export AGE_WORKDIR="$AGE_TEST_SANDBOX"

  # Some CLI commands honor AGE_PROJECT_DIR / ZCODE_PROJECT_DIR for testing.
  export AGE_PROJECT_DIR="$AGE_TEST_SANDBOX"
  export ZCODE_PROJECT_DIR="$AGE_TEST_SANDBOX"

  # Make the in-repo binary discoverable without a global install.
  if [ -x "$AGE_PLUGIN_ROOT/cli/age" ]; then
    export PATH="$AGE_PLUGIN_ROOT/cli:$PATH"
  fi
}

teardown() {
  if [ -n "${AGE_TEST_SANDBOX:-}" ] && [ -d "$AGE_TEST_SANDBOX" ]; then
    rm -rf "$AGE_TEST_SANDBOX"
  fi
}

# ---------------------------------------------------------------------------
# Fixture helpers
# ---------------------------------------------------------------------------

# Create an empty git repo in the sandbox and `cd` into it. Several commands
# (age sync --since, age ci) need a git working tree.
make_git_repo() {
  git init -q "$AGE_TEST_SANDBOX/repo"
  cd "$AGE_TEST_SANDBOX/repo" || return 1
  git config user.email "test@example.com"
  git config user.name "age test"
}

# Seed the docs/context/ five-piece set (each non-empty), AGENTS.md, and a
# src/ tree. Does NOT write docs/index.md — each test writes an index.md
# tailored to the command under test, because check/sync (module→owner) and
# route (task-intent→READ/WRITEBACK) currently consume the same file with
# incompatible column semantics (see CONTRACT §8.9 [CR-2]).
seed_context_and_agents() {
  local root="${1:-.}"
  mkdir -p "$root/docs/context" "$root/docs/backlog" "$root/docs/plans" \
           "$root/docs/audits" "$root/docs/requirements" \
           "$root/docs/architecture" "$root/docs/design" \
           "$root/docs/logs" "$root/src" "$root/.age"
  cat >"$root/AGENTS.md" <<'EOF'
# AGENTS.md

This repo follows the AGE workflow. Read docs/context/ before working.
EOF
  echo "seed code" > "$root/src/app.sh"
  # The five forced-context files, each with a substantive body line so
  # age check / audit do not flag them as empty (title/comment-only = empty).
  _ctx_body() {
    printf '# %s\n\nSeed content line so age check sees a non-empty body.\n' "$1"
  }
  _ctx_body "Project Context"       > "$root/docs/context/project-context.md"
  _ctx_body "AI Autonomy Policy"    > "$root/docs/context/ai-autonomy-policy.md"
  _ctx_body "Codebase Map"          > "$root/docs/context/codebase-map.md"
  _ctx_body "Source of Truth"       > "$root/docs/context/source-of-truth-and-precedence.md"
  _ctx_body "Conventions"           > "$root/docs/context/conventions.md"
}

# Back-compat alias for tests written before the helper split.
seed_minimal_docs() { seed_context_and_agents "$@"; }

# Write a docs/index.md with a parser-compatible module→owner route table.
# Used by age check / age sync tests. The CLI route parser
# (age_parse_index_routes) reads a markdown table as
#   | <label ignored> | <module col3> | <owner col4> | <skill col5> |
# so the first data column is skipped and columns 3/4/5 are module/owner/skill.
#
# IMPORTANT: the parser's header-skip test (`o ~ /owner|文档|doc/i`) would
# discard any route whose owner column contains the substring "doc" (e.g. all
# "docs/..." paths). So the owner is written WITHOUT the "docs/" prefix;
# age check resolves it via its $root/docs/$owner fallback. See CONTRACT §8.7
# [CR-1] for the parser bug this works around.
write_module_route_index() {
  local root="${1:-.}"
  mkdir -p "$root/docs/architecture"
  cat >"$root/docs/index.md" <<'EOF'
# Router

| 任务 | 模块 | owner 文档 | 技能 |
|---|---|---|---|
| x | src/ | architecture/overview.md | age-route |
EOF
  printf '# Architecture Overview\n\nDescribes the src/ tree.\n' \
    > "$root/docs/architecture/overview.md"
}

# Write a docs/index.md with a task-intent route that age route can match.
# age route reads column 3 as the task intent and substring-matches the task
# text against its keywords. So the keyword must appear in the task argument.
write_intent_route_index() {
  local root="${1:-.}" keyword="${2:-implement}"
  mkdir -p "$root/docs"
  cat >"$root/docs/index.md" <<EOF
# Router

| 任务 | intent | READ | skill |
|---|---|---|---|
| x | ${keyword} | docs/requirements/feature.md | age-route |
EOF
  mkdir -p "$root/docs/requirements"
  printf '# Feature\n\nFeature requirements doc.\n' \
    > "$root/docs/requirements/feature.md"
}

# Write a baseline snapshot file directly (used when a test wants to bypass
# `age baseline` and just seed state). CONTRACT section 3: baseline lives at
# .age/baseline.json.
write_baseline() {
  local root="${1:-.}"
  mkdir -p "$root/.age"
  cat >"$root/.age/baseline.json" <<'EOF'
{
  "files": {
    "AGENTS.md": "seed",
    "docs/index.md": "seed",
    "docs/context/project-context.md": "seed"
  },
  "generated_at": "2026-01-01T00:00:00Z"
}
EOF
}

# ---------------------------------------------------------------------------
# Assertions
# ---------------------------------------------------------------------------

# Assert a command succeeded (exit 0).
assert_success() {
  if [ "$status" -ne 0 ]; then
    echo "expected exit 0, got $status" >&2
    echo "output: $output" >&2
    return 1
  fi
}

# Assert a command failed (non-zero exit).
assert_failure() {
  if [ "$status" -eq 0 ]; then
    echo "expected non-zero exit, got 0" >&2
    echo "output: $output" >&2
    return 1
  fi
}

# Assert a file exists.
assert_file_exists() {
  if [ ! -f "$1" ]; then
    echo "expected file to exist: $1" >&2
    return 1
  fi
}

# Assert a file does not exist.
assert_file_not_exists() {
  if [ -f "$1" ]; then
    echo "expected file to NOT exist: $1" >&2
    return 1
  fi
}

# Assert a directory exists.
assert_dir_exists() {
  if [ ! -d "$1" ]; then
    echo "expected directory to exist: $1" >&2
    return 1
  fi
}

# Assert $output contains a substring.
assert_output_contains() {
  case "$output" in
    *"$1"*) ;;
    *) echo "expected output to contain: $1" >&2
       echo "actual output: $output" >&2
       return 1 ;;
  esac
}

# Assert $output does not contain a substring.
refute_output_contains() {
  case "$output" in
    *"$1"*) echo "expected output to NOT contain: $1" >&2
            echo "actual output: $output" >&2
            return 1 ;;
  esac
}

# Assert JSON output has a given top-level key. Requires jq.
assert_json_key() {
  local key="$1"
  if ! echo "$output" | jq -e --arg k "$key" 'has($k)' >/dev/null 2>&1; then
    echo "expected JSON to have key: $key" >&2
    echo "output: $output" >&2
    return 1
  fi
}

# Assert JSON output equals a given value at a jq path.
assert_json_eq() {
  local path="$1" expected="$2"
  local actual
  actual="$(echo "$output" | jq -r "$path")"
  if [ "$actual" != "$expected" ]; then
    echo "expected $path == $expected, got $actual" >&2
    echo "output: $output" >&2
    return 1
  fi
}

# ---------------------------------------------------------------------------
# MCP helpers
# ---------------------------------------------------------------------------

# Send a single JSON-RPC request to the MCP stdio server and print the
# response. Usage: mcp_call '<json params>' <method>
# CONTRACT section 4: the server speaks stdio JSON-RPC.
mcp_call() {
  local method="${2:-tools/list}"
  local params="${1:-{}}"
  local id="${MCP_ID:-1}"
  MCP_ID=$((id + 1))
  export MCP_ID
  printf '{"jsonrpc":"2.0","id":%s,"method":"%s","params":%s}\n' \
    "$id" "$method" "$params" | python3 "$AGE_MCP_SERVER" 2>/dev/null
}

# Initialize the MCP session (required handshake before tools/list).
mcp_initialize() {
  printf '%s\n' '{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2024-11-05","capabilities":{},"clientInfo":{"name":"bats","version":"0.0.0"}}}' \
    | python3 "$AGE_MCP_SERVER" 2>/dev/null
}

# Skip a test block if a required binary is absent (keeps the suite green on
# minimal CI without masking real regressions).
skip_without() {
  for bin in "$@"; do
    if ! command -v "$bin" >/dev/null 2>&1; then
      skip "$bin not installed"
    fi
  done
}

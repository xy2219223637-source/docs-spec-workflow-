#!/usr/bin/env bats
# test_win11.bats — contract-driven tests for Windows 11 compatibility.
#
# CONTRACT section 8.12 (fourth-round concurrent task, 2026-07-11) defines the
# Win11 compatibility story. The current AGE CLI + hooks are all POSIX shell
# (bash), but Win11 has no bash natively. Win11 compat uses a DUAL-LAYER
# strategy:
#   1. PowerShell native layer  — cli/age.ps1 + hooks/scripts/*.ps1 + hooks.win11.json,
#      not dependent on bash.
#   2. Git-Bash fallback layer — the existing bash scripts work under Git-Bash
#      (shipped with Git for Windows).
# PowerShell native is preferred (does not require the user to install Git-Bash);
# Git-Bash is the fallback.
#
# Win11 compat facts (CONTRACT §8.12):
#   - Native shell: PowerShell 5.1 (preinstalled) / PowerShell 7 (optional).
#   - bash available via Git-Bash (Git for Windows) or WSL.
#   - Path separator: backslash `\` vs POSIX `/`.
#   - Env var syntax: `%VAR%` (CMD) / `$env:VAR` (PowerShell) vs `$VAR` (bash).
#   - Python3 is usually `python` (no 3) on Win11 — must be detected.
#   - Executable scripts: .ps1 / .cmd / .bat.
#   - Line endings: CRLF vs LF (git autocrlf).
#
# File ownership (CONTRACT §8.12, strict non-overlap across 6 agents):
#   - compat/win11/{README.md,path-utils.ps1,env-template.ps1} — 事实设计
#   - cli/age.ps1 + cli/lib/*.ps1 (incl common.ps1)             — 总调度
#   - hooks/scripts/*.ps1 (on-session-start/edit/stop/lib) + hooks/hooks.win11.json — 任务执行
#   - tests/test_win11.bats (this file) + README.md             — 代码审查
#
# IMPORTANT: bats runs under Git-Bash on Win11 and under bash on macOS/Linux.
# The tests MUST NOT execute .ps1 scripts directly — they only assert file
# existence + content. When pwsh is available locally, an OPTIONAL syntax
# check (`pwsh -NoProfile -Command "Get-Command -Syntax ..."`) runs behind a
# guard-style skip, so the suite stays green on machines without pwsh (the
# typical dev machine here has bash but no pwsh). This mirrors the
# contract-first / skip-gracefully style of test_compat.bats and
# test_use_age.bats.

load helpers/test_helper

# ---------------------------------------------------------------------------
# Shared guards. CONTRACT §8.12 assigns the Win11 artifacts to several agents
# working concurrently. Until each artifact lands, the test that needs it skips
# with a clear reason naming the owner and section, so the suite stays green
# and documents the expected contract (contract-first testing).
# ---------------------------------------------------------------------------

# Absolute path to the Win11 compat tree (owned by 事实设计, CONTRACT §8.12).
AGE_WIN11_COMPAT_DIR="$AGE_PLUGIN_ROOT/compat/win11"

# Absolute path to the hooks scripts dir (owned by 任务执行).
AGE_HOOKS_SCRIPTS_DIR="$AGE_PLUGIN_ROOT/hooks/scripts"

# Skip if the compat/win11/ directory does not exist yet.
_require_win11_compat_tree() {
  if [ ! -d "$AGE_WIN11_COMPAT_DIR" ]; then
    skip "compat/win11/ tree not implemented yet (事实设计 agent, §8.12)"
  fi
}

# Skip if a specific file is missing. $1 is the path relative to the plugin root.
_require_win11_file() {
  local rel="$1"
  local f="$AGE_PLUGIN_ROOT/$rel"
  if [ ! -f "$f" ]; then
    skip "$rel not implemented yet (§8.12)"
  fi
}

# Skip if a compat/win11/ file is missing. $1 is relative to compat/win11/.
_require_win11_compat_file() {
  local rel="$1"
  local f="$AGE_WIN11_COMPAT_DIR/$rel"
  if [ ! -f "$f" ]; then
    skip "compat/win11/$rel not implemented yet (事实设计 agent, §8.12)"
  fi
}

# Skip if a hooks/scripts .ps1 file is missing. $1 is the filename.
_require_win11_hook_script() {
  local rel="$1"
  local f="$AGE_HOOKS_SCRIPTS_DIR/$rel"
  if [ ! -f "$f" ]; then
    skip "hooks/scripts/$rel not implemented yet (任务执行 agent, §8.12)"
  fi
}

# Skip if jq is unavailable (used for JSON validation).
_require_jq() {
  if ! command -v jq >/dev/null 2>&1; then
    skip "jq not installed"
  fi
}

# Skip the whole calling test if the age CLI is unavailable (总调度 owns it).
_require_age_cli() {
  if ! command -v age >/dev/null 2>&1 && [ ! -x "$AGE_PLUGIN_ROOT/cli/age" ]; then
    skip "age CLI not available"
  fi
}

# ---------------------------------------------------------------------------
# compat/win11/ top-level structure
# CONTRACT §8.12: the Win11 compat tree contains README.md + path-utils.ps1 +
# env-template.ps1. README.md documents the dual-layer strategy + environment
# requirements; path-utils.ps1 holds the POSIX↔Win path conversion + plugin root
# discovery helpers; env-template.ps1 is the Win11 env var template
# (AGE_PLUGIN_ROOT etc.).
# ---------------------------------------------------------------------------

@test "compat/win11/ directory exists" {
  _require_win11_compat_tree
  assert_dir_exists "$AGE_WIN11_COMPAT_DIR"
}

@test "compat/win11/README.md exists and is non-empty" {
  _require_win11_compat_file "README.md"
  local f="$AGE_WIN11_COMPAT_DIR/README.md"
  [ -s "$f" ] || { echo "compat/win11/README.md is empty" >&2; return 1; }
}

@test "compat/win11/path-utils.ps1 exists and is non-empty" {
  _require_win11_compat_file "path-utils.ps1"
  local f="$AGE_WIN11_COMPAT_DIR/path-utils.ps1"
  [ -s "$f" ] || { echo "path-utils.ps1 is empty" >&2; return 1; }
}

@test "compat/win11/env-template.ps1 exists and is non-empty" {
  _require_win11_compat_file "env-template.ps1"
  local f="$AGE_WIN11_COMPAT_DIR/env-template.ps1"
  [ -s "$f" ] || { echo "env-template.ps1 is empty" >&2; return 1; }
}

# ---------------------------------------------------------------------------
# compat/win11/path-utils.ps1: required function definitions
# CONTRACT §8.12: path-utils.ps1 (事实设计) provides POSIX↔Win path conversion
# and plugin-root discovery. It must define Convert-ToWinPath and Find-PluginRoot
# (PowerShell function syntax: `function Name { ... }`).
# ---------------------------------------------------------------------------

@test "compat/win11/path-utils.ps1 defines Convert-ToWinPath" {
  _require_win11_compat_file "path-utils.ps1"
  local f="$AGE_WIN11_COMPAT_DIR/path-utils.ps1"
  grep -Eq 'function\s+Convert-ToWinPath' "$f" \
    || { echo "path-utils.ps1 missing function Convert-ToWinPath" >&2; return 1; }
}

@test "compat/win11/path-utils.ps1 defines Find-PluginRoot" {
  _require_win11_compat_file "path-utils.ps1"
  local f="$AGE_WIN11_COMPAT_DIR/path-utils.ps1"
  grep -Eq 'function\s+Find-PluginRoot' "$f" \
    || { echo "path-utils.ps1 missing function Find-PluginRoot" >&2; return 1; }
}

# ---------------------------------------------------------------------------
# cli/age.ps1: PowerShell CLI entrypoint
# CONTRACT §8.12 (PowerShell CLI contract): cli/age.ps1 (总调度) is the
# PowerShell entrypoint equivalent to cli/age. It supports the same subcommand
# set (init/use/install/check/sync/route/audit/doctor/ci/baseline/help) and
# calls cli/lib/*.ps1 functions. Path resolution uses $AGE_PLUGIN_ROOT or
# auto-detects by walking up from the script location.
# ---------------------------------------------------------------------------

@test "cli/age.ps1 exists and is non-empty" {
  _require_win11_file "cli/age.ps1"
  local f="$AGE_PLUGIN_ROOT/cli/age.ps1"
  [ -s "$f" ] || { echo "cli/age.ps1 is empty" >&2; return 1; }
}

# ---------------------------------------------------------------------------
# cli/lib/common.ps1: PowerShell shared functions
# CONTRACT §8.12: cli/lib/common.ps1 (总调度) is the PowerShell counterpart of
# cli/lib/common.sh — rendering / detection / logging helpers shared across the
# .ps1 lib modules.
# ---------------------------------------------------------------------------

@test "cli/lib/common.ps1 exists and is non-empty" {
  _require_win11_file "cli/lib/common.ps1"
  local f="$AGE_PLUGIN_ROOT/cli/lib/common.ps1"
  [ -s "$f" ] || { echo "cli/lib/common.ps1 is empty" >&2; return 1; }
}

# ---------------------------------------------------------------------------
# hooks/scripts/*.ps1: PowerShell hook scripts
# CONTRACT §8.12: 任务执行 ships PowerShell hook scripts equivalent to the bash
# ones: on-session-start.ps1 + on-edit.ps1 + on-stop.ps1 + lib.ps1 (shared
# helpers). These are referenced by hooks/hooks.win11.json and must NOT depend
# on bash.
# ---------------------------------------------------------------------------

@test "hooks/scripts/on-session-start.ps1 exists and is non-empty" {
  _require_win11_hook_script "on-session-start.ps1"
  local f="$AGE_HOOKS_SCRIPTS_DIR/on-session-start.ps1"
  [ -s "$f" ] || { echo "on-session-start.ps1 is empty" >&2; return 1; }
}

@test "hooks/scripts/on-edit.ps1 exists and is non-empty" {
  _require_win11_hook_script "on-edit.ps1"
  local f="$AGE_HOOKS_SCRIPTS_DIR/on-edit.ps1"
  [ -s "$f" ] || { echo "on-edit.ps1 is empty" >&2; return 1; }
}

@test "hooks/scripts/on-stop.ps1 exists and is non-empty" {
  _require_win11_hook_script "on-stop.ps1"
  local f="$AGE_HOOKS_SCRIPTS_DIR/on-stop.ps1"
  [ -s "$f" ] || { echo "on-stop.ps1 is empty" >&2; return 1; }
}

@test "hooks/scripts/lib.ps1 exists and is non-empty" {
  _require_win11_hook_script "lib.ps1"
  local f="$AGE_HOOKS_SCRIPTS_DIR/lib.ps1"
  [ -s "$f" ] || { echo "lib.ps1 is empty" >&2; return 1; }
}

# ---------------------------------------------------------------------------
# hooks/hooks.win11.json: valid JSON wiring the three AGE hook events
# CONTRACT §8.12 + §5: the Win11 hook config (任务执行) wires the three AGE hook
# events (SessionStart / PostToolUse / Stop) and points at .ps1 scripts (not
# .sh). It must be valid JSON.
#
# The event-wiring assertions are STRUCTURE-AGNOSTIC: the canonical ZCode
# hooks.json nests events as .hooks.<EventName> (object keys), while the Win11
# variant may legitimately use a flat .hooks[] array with per-entry "event"
# string fields. Both shapes satisfy CONTRACT §8.12 ("含 SessionStart/PostToolUse/
# Stop 三个事件") as long as all three event names appear. We accept either
# shape so the test guards the CONTRACT (events present + .ps1 targets) without
# asserting a style choice that the CONTRACT leaves open.
# ---------------------------------------------------------------------------

@test "hooks/hooks.win11.json exists" {
  _require_win11_file "hooks/hooks.win11.json"
  assert_file_exists "$AGE_PLUGIN_ROOT/hooks/hooks.win11.json"
}

@test "hooks/hooks.win11.json is valid JSON" {
  _require_win11_file "hooks/hooks.win11.json"
  _require_jq
  run jq -e . "$AGE_PLUGIN_ROOT/hooks/hooks.win11.json"
  assert_success
}

# _win11_has_event <file> <EventName>: return 0 if the event appears in either
# the nested (.hooks.<EventName> object key) or flat (.hooks[].event == name)
# shape. Uses jq to extract a normalized event-name list from both shapes.
_win11_has_event() {
  local f="$1" name="$2"
  local names
  names="$(jq -r '
    # Nested shape: .hooks is an object whose keys are event names.
    (.hooks | if type == "object" then keys[] else empty end),
    # Flat shape: .hooks is an array of objects with an "event" field.
    (.hooks | if type == "array" then .[].event? else empty end)
  ' "$f" 2>/dev/null)"
  printf '%s\n' "$names" | grep -Fxq -- "$name"
}

@test "hooks/hooks.win11.json wires SessionStart event" {
  _require_win11_file "hooks/hooks.win11.json"
  _require_jq
  local f="$AGE_PLUGIN_ROOT/hooks/hooks.win11.json"
  _win11_has_event "$f" "SessionStart" \
    || { echo "hooks.win11.json missing SessionStart event" >&2; return 1; }
}

@test "hooks/hooks.win11.json wires PostToolUse event" {
  _require_win11_file "hooks/hooks.win11.json"
  _require_jq
  local f="$AGE_PLUGIN_ROOT/hooks/hooks.win11.json"
  _win11_has_event "$f" "PostToolUse" \
    || { echo "hooks.win11.json missing PostToolUse event" >&2; return 1; }
}

@test "hooks/hooks.win11.json wires Stop event" {
  _require_win11_file "hooks/hooks.win11.json"
  _require_jq
  local f="$AGE_PLUGIN_ROOT/hooks/hooks.win11.json"
  _win11_has_event "$f" "Stop" \
    || { echo "hooks.win11.json missing Stop event" >&2; return 1; }
}

@test "hooks/hooks.win11.json points command entries at .ps1 scripts" {
  # CONTRACT §8.12: the Win11 hook config must reference .ps1 scripts (the
  # PowerShell native layer), not the bash .sh scripts. Every command string in
  # the hooks tree should reference a .ps1 file.
  _require_win11_file "hooks/hooks.win11.json"
  _require_jq
  local f="$AGE_PLUGIN_ROOT/hooks/hooks.win11.json"
  # Extract every command string and assert each mentions a .ps1 reference.
  local cmds
  cmds="$(jq -r '.. | .command? // empty' "$f" 2>/dev/null)"
  [ -n "$cmds" ] || { echo "no command entries found in hooks.win11.json" >&2; return 1; }
  local non_ps1
  non_ps1="$(printf '%s\n' "$cmds" | grep -v '\.ps1' || true)"
  [ -z "$non_ps1" ] \
    || { echo "hooks.win11.json has command(s) not pointing at .ps1:" >&2; printf '%s\n' "$non_ps1" >&2; return 1; }
}

@test "hooks/hooks.win11.json does not point at .sh scripts" {
  # CONTRACT §8.12 dual-layer: the Win11 hook config is the PowerShell native
  # layer and must NOT reference the bash .sh scripts (those are the Git-Bash
  # fallback, used separately). This complements the .ps1 assertion above.
  _require_win11_file "hooks/hooks.win11.json"
  _require_jq
  local f="$AGE_PLUGIN_ROOT/hooks/hooks.win11.json"
  local cmds
  cmds="$(jq -r '.. | .command? // empty' "$f" 2>/dev/null)"
  if printf '%s\n' "$cmds" | grep -Eq '\.sh\b'; then
    echo "hooks.win11.json references a .sh script (should be .ps1):" >&2
    printf '%s\n' "$cmds" | grep -E '\.sh\b' >&2
    return 1
  fi
}

# ---------------------------------------------------------------------------
# .ps1 files must use PowerShell syntax, not bash syntax
# CONTRACT §8.12: the PowerShell native layer must not depend on bash. A .ps1
# file that is really a bash script would fail under native PowerShell (no
# bash). We assert the .ps1 files do not contain unambiguous bash constructs.
#
# IMPORTANT — false-positive avoidance: PowerShell and bash share some surface
# syntax, so we only flag constructs that are INVALID in PowerShell:
#   1. ${VAR<op>...} bash parameter expansion with an operator. Bash allows
#      ${VAR:-default}, ${VAR##prefix}, ${VAR%%suffix}, ${VAR//x/y}, etc. The
#      bare ${VAR} (no operator) is LEGAL PowerShell (brace-delimited variable),
#      so we do NOT flag it — only the operator forms.
#   2. `if [ ... ]` / `if [[ ... ]]` — the bash/sh test command. PowerShell
#      uses `if (...)` with parentheses, so a bracket test is a bash-ism.
#   3. A bash shebang line (`#!/bin/bash`, `#!/bin/sh`, `#!/usr/bin/env bash`).
#      A .ps1 may legally start with `#requires` or a comment, never a bash
#      shebang.
# Each .ps1 file is guarded by _require_win11_* so the test skips cleanly until
# the owning agent lands it.
# ---------------------------------------------------------------------------

# Return 0 if the file contains bash-specific syntax, 1 otherwise.
_has_bash_syntax() {
  local f="$1"
  # 1. Bash parameter-expansion operators inside ${...} (:- := :+ :? # ## % %% / //).
  # These forms do not exist in PowerShell.
  grep -Eq '\$\{[A-Za-z_][A-Za-z0-9_]*([-:?#/]|##|%%|//|:=|:-|:\+|:\?)[^}]*\}' "$f" && return 0
  # 2. bash/sh test command: `if [ ...` or `if [[ ...`.
  grep -Eq 'if[[:space:]]+\[\[?[[:space:]]' "$f" && return 0
  # 3. bash shebang.
  grep -Eq '^#!(/bin/(ba)?sh|/usr/bin/env[[:space:]]+(ba)?sh)' "$f" && return 0
  return 1
}

@test "cli/age.ps1 does not contain bash syntax" {
  _require_win11_file "cli/age.ps1"
  if _has_bash_syntax "$AGE_PLUGIN_ROOT/cli/age.ps1"; then
    echo "cli/age.ps1 contains bash-specific syntax (\$(...) or \${VAR})" >&2
    return 1
  fi
}

@test "cli/lib/common.ps1 does not contain bash syntax" {
  _require_win11_file "cli/lib/common.ps1"
  if _has_bash_syntax "$AGE_PLUGIN_ROOT/cli/lib/common.ps1"; then
    echo "cli/lib/common.ps1 contains bash-specific syntax" >&2
    return 1
  fi
}

@test "hooks/scripts/on-session-start.ps1 does not contain bash syntax" {
  _require_win11_hook_script "on-session-start.ps1"
  if _has_bash_syntax "$AGE_HOOKS_SCRIPTS_DIR/on-session-start.ps1"; then
    echo "on-session-start.ps1 contains bash-specific syntax" >&2
    return 1
  fi
}

@test "hooks/scripts/on-edit.ps1 does not contain bash syntax" {
  _require_win11_hook_script "on-edit.ps1"
  if _has_bash_syntax "$AGE_HOOKS_SCRIPTS_DIR/on-edit.ps1"; then
    echo "on-edit.ps1 contains bash-specific syntax" >&2
    return 1
  fi
}

@test "hooks/scripts/on-stop.ps1 does not contain bash syntax" {
  _require_win11_hook_script "on-stop.ps1"
  if _has_bash_syntax "$AGE_HOOKS_SCRIPTS_DIR/on-stop.ps1"; then
    echo "on-stop.ps1 contains bash-specific syntax" >&2
    return 1
  fi
}

@test "hooks/scripts/lib.ps1 does not contain bash syntax" {
  _require_win11_hook_script "lib.ps1"
  if _has_bash_syntax "$AGE_HOOKS_SCRIPTS_DIR/lib.ps1"; then
    echo "lib.ps1 contains bash-specific syntax" >&2
    return 1
  fi
}

@test "compat/win11/path-utils.ps1 does not contain bash syntax" {
  _require_win11_compat_file "path-utils.ps1"
  if _has_bash_syntax "$AGE_WIN11_COMPAT_DIR/path-utils.ps1"; then
    echo "path-utils.ps1 contains bash-specific syntax" >&2
    return 1
  fi
}

@test "compat/win11/env-template.ps1 does not contain bash syntax" {
  _require_win11_compat_file "env-template.ps1"
  if _has_bash_syntax "$AGE_WIN11_COMPAT_DIR/env-template.ps1"; then
    echo "env-template.ps1 contains bash-specific syntax" >&2
    return 1
  fi
}

# ---------------------------------------------------------------------------
# age install --list includes win11
# CONTRACT §8.12 (cli/lib/install.sh edit, 总调度): `age install --client win11`
# installs the PS1 entrypoint, so `age install --list` must advertise win11 as a
# supported client. Skip if the age CLI or the install subcommand is absent, or
# if win11 has not been added to the list yet.
# ---------------------------------------------------------------------------

@test "age install --list includes win11 as a client" {
  _require_age_cli
  if ! "$AGE_BIN" help 2>&1 | grep -qi 'install'; then
    skip "age install subcommand not implemented yet (总调度 agent, §8.11/§8.12)"
  fi
  run "$AGE_BIN" install --list
  if [ "$status" -ne 0 ]; then
    skip "age install --list not implemented yet (总调度 agent, §8.12)"
  fi
  # win11 may not be added to the list until the 总调度 agent lands the §8.12
  # install.sh edit. Skip (not fail) if absent, so the suite stays green during
  # concurrent development, but assert once it IS present.
  if ! echo "$output" | grep -Eqi 'win11'; then
    skip "age install --list does not yet list win11 (总调度 agent, §8.12 not landed)"
  fi
}

# ---------------------------------------------------------------------------
# README.md documents Win11 install instructions
# CONTRACT §8.12 (代码审查 owns README.md): the README must carry Win11 install
# instructions — dual-layer strategy (PowerShell native + Git-Bash fallback),
# `age install --client win11`, prerequisites (PowerShell 5.1+, Python), and a
# Win11 row in the compatibility matrix.
# ---------------------------------------------------------------------------

@test "README.md documents Windows 11 install instructions" {
  local f="$AGE_PLUGIN_ROOT/README.md"
  assert_file_exists "$f"
  grep -Eqi 'win11|windows[[:space:]]*11|windows11' "$f" \
    || { echo "README.md does not mention Windows 11 / Win11" >&2; return 1; }
}

@test "README.md documents the PowerShell native + Git-Bash fallback dual-layer" {
  local f="$AGE_PLUGIN_ROOT/README.md"
  assert_file_exists "$f"
  grep -Eqi 'powershell' "$f" \
    || { echo "README.md does not mention PowerShell native layer" >&2; return 1; }
  grep -Eqi 'git-bash|git[[:space:]]*for[[:space:]]*windows' "$f" \
    || { echo "README.md does not mention Git-Bash fallback layer" >&2; return 1; }
}

@test "README.md documents age install --client win11" {
  local f="$AGE_PLUGIN_ROOT/README.md"
  assert_file_exists "$f"
  grep -Eq 'age install --client win11' "$f" \
    || { echo "README.md does not document 'age install --client win11'" >&2; return 1; }
}

@test "README.md documents Win11 prerequisites (PowerShell 5.1+ and Python)" {
  local f="$AGE_PLUGIN_ROOT/README.md"
  assert_file_exists "$f"
  # Prerequisites: PowerShell 5.1+ and Python must both be mentioned near the
  # Win11 section. We check the whole file since the Win11 section may be short.
  grep -Eqi 'powershell[[:space:]]*5\.1' "$f" \
    || { echo "README.md does not mention PowerShell 5.1+ prerequisite" >&2; return 1; }
  grep -Eqi 'python' "$f" \
    || { echo "README.md does not mention Python prerequisite" >&2; return 1; }
}

@test "README.md compatibility matrix includes a Win11 row" {
  # CONTRACT §8.12: the compatibility matrix (README 多客户端兼容 section) must
  # include a Win11 row. We look for Win11 appearing in a markdown table row
  # context (a line starting with | that contains win11/windows 11).
  local f="$AGE_PLUGIN_ROOT/README.md"
  assert_file_exists "$f"
  grep -Eq '^\|.*([Ww]in11|[Ww]indows[[:space:]]*11)' "$f" \
    || { echo "README.md compatibility matrix has no Win11 row" >&2; return 1; }
}

# ---------------------------------------------------------------------------
# OPTIONAL: PowerShell syntax check via pwsh
# CONTRACT §8.12 note: if pwsh is available locally, run a syntax check
# (`pwsh -NoProfile -Command "Get-Command -Syntax ..."` or parse the script).
# This is behind a guard-style skip so the suite stays green on machines
# without pwsh (the typical dev machine has bash but not pwsh). When pwsh IS
# present, this turns the file-existence tests into real parse checks.
# ---------------------------------------------------------------------------

@test "cli/age.ps1 parses under pwsh (optional, skip if no pwsh)" {
  _require_win11_file "cli/age.ps1"
  command -v pwsh >/dev/null 2>&1 || skip "pwsh not installed"
  local f="$AGE_PLUGIN_ROOT/cli/age.ps1"
  # Parse the script without executing it. `[scriptblock]::Create` + raw read
  # catches syntax errors. We use -NoProfile to avoid user profile side effects.
  run pwsh -NoProfile -Command "\$ErrorActionPreference='Stop'; Get-Content -Raw -Path '$f' | Out-String | ForEach-Object { [scriptblock]::Create(\$_) | Out-Null }"
  assert_success
}

@test "compat/win11/path-utils.ps1 parses under pwsh (optional, skip if no pwsh)" {
  _require_win11_compat_file "path-utils.ps1"
  command -v pwsh >/dev/null 2>&1 || skip "pwsh not installed"
  local f="$AGE_WIN11_COMPAT_DIR/path-utils.ps1"
  run pwsh -NoProfile -Command "\$ErrorActionPreference='Stop'; Get-Content -Raw -Path '$f' | Out-String | ForEach-Object { [scriptblock]::Create(\$_) | Out-Null }"
  assert_success
}

@test "hooks/scripts/lib.ps1 parses under pwsh (optional, skip if no pwsh)" {
  _require_win11_hook_script "lib.ps1"
  command -v pwsh >/dev/null 2>&1 || skip "pwsh not installed"
  local f="$AGE_HOOKS_SCRIPTS_DIR/lib.ps1"
  run pwsh -NoProfile -Command "\$ErrorActionPreference='Stop'; Get-Content -Raw -Path '$f' | Out-String | ForEach-Object { [scriptblock]::Create(\$_) | Out-Null }"
  assert_success
}

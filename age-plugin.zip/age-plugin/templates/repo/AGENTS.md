# AGENTS.md — {{project_name}} 代理操作契约

> 本文件是本仓库所有 AI agent(含 ZCode / Claude Code / Codex CLI / OpenCode CLI 等客户端的会话与子代理、CLI 自动化、CI)的操作契约。AGE(Attractor-Guided Engineering)插件生成本文件;`age check` 校验本文件中所有引用可解析。本文件是跨客户端通用契约,各客户端的适配差异见 §9.1 与 AGE 插件 `compat/` 目录。
>
> **⚠️ CLAUDE.md 副本声明(CP-5):`CLAUDE.md` 是本文件的 Claude Code 适配副本,由 `age install` 生成(Claude Code 不读本文件,只读 `CLAUDE.md`)。修改操作指令时改本文件(`AGENTS.md`),然后 `age install` 重新生成 `CLAUDE.md`,两者自动同步。**
>
> **Owner:** {{owner_name}}(为空时由首次 `age init` 填入)
> **Project kind:** {{project_kind}}  **Doc language:** {{doc_language}}  **Require backlog:** {{require_backlog}}

## 1. 事实来源优先级(铁律)

冲突时按此链裁决,高者优先:

1. **owner 文档** — `docs/context/`、`docs/backlog/`、`docs/requirements/`、`docs/design/`、`docs/architecture/`
2. **计划** — `docs/plans/`
3. **日志** — `docs/logs/`
4. **聊天** — 任何会话内口头决定

聊天决定不得沉默覆盖 owner 文档。若聊天与 owner 文档冲突:owner 文档胜,直到被显式更新(开独立任务)。

## 2. 路由规则

**所有任务的入口是 `docs/index.md`**——它是本仓库的文档路由器。开始任何任务前:
1. 读 `docs/index.md` 的路由表,确定本任务该读哪些 owner 文档。
2. 若 `docs/index.md` 对本任务类型沉默,回退到 AGE 默认路由(见 AGE 插件 `skills/age/references/routing-rules.md`)。
3. 机械替代:`age route "<task>" --explain` 输出 READ 集 + WRITEBACK 集 + 技能路由。

强制上下文(每次会话必读,AGE `SessionStart` hook 自动注入摘要):
- `docs/context/project-context.md`
- `docs/context/ai-autonomy-policy.md`
- `docs/context/codebase-map.md`
- `docs/context/source-of-truth-and-precedence.md`
- `docs/context/conventions.md`

## 3. 技能选择记录(每个计划阶段必填)

AGE 是**方法选择器**:它决定每个任务阶段用哪个项目技能,自己不替代项目技能。在 `docs/plans/` 的每个计划里,**每个阶段必须记录**:

```
### 阶段 N: <阶段名>
Skill: <skill-name>      # 或 Skill: none(无项目技能,直接走 owner 文档)
READ: <owner 文档列表>
WRITEBACK: <owner 文档列表,或 none>
```

- `Skill: none` 是合法值,表示"本阶段无项目专属技能,按 owner 文档执行"。不要留空。
- 若 AGE 路由选了某技能但执行中发现不适用,改记 `Skill: none` 并在日志说明原因。
- 这条记录是 AGE 可审计性的核心——`age audit` 会校验计划文件含每阶段的 `Skill:` 行。

## 4. 验证命令(收尾门禁)

本仓库的验证命令:
```
{{validate_cmd}}
```
- **非空时**:每个任务收尾前必须跑此命令并绿。`age audit --scope closure` 会跑它。
- **为空时**(`{{validate_cmd}}` 渲染为空字符串):收尾审计跳过验证步骤,`age audit` 只查文档一致性。此时不意味着"不验证"——若项目有测试,agent 仍应手动跑,只是 AGE 不强制。

## 5. 禁止行为

1. **禁止沉默绕过 owner 文档。** 任务前不读 READ 集、任务后不回写 WRITEBACK 集,均为违规。
2. **禁止跨 WRITEBACK 集回写。** doc-sync 只改 route 标记的 WRITEBACK 集;实质性的额外变更开新任务。
3. **禁止沉默式重构。** 任何架构变更(模块边界/依赖方向/技术选型)必须先有 `docs/plans/` 计划 + 产出 ADR 入 `docs/audits/`。
4. **禁止用聊天决定覆盖 owner 文档。** 见 §1。
5. **禁止跳过收尾审计。** 未跑 `age audit --scope closure` 的任务不算完成。
6. **禁止手动重算 `age sync`/`age check`。** 机械活交给 CLI;判断层保持 prose。
7. **禁止删除或留空强制上下文文件。** `docs/context/` 五个文件必须存在且非空骨架。

## 6. 计划审计(进入 `docs/plans/` 前)

满足任一条件必须先进 `docs/plans/`(见 AGE `sync-checklist.md`):跨多 owner 文档、≥3 阶段、涉及架构、用户要方案。计划文件最小内容:
- 目标
- READ 集 / WRITEBACK 集
- 分阶段步骤(每阶段 `Skill:` 记录)
- 验收标准
- 关联需求/backlog ID

`age audit --scope plan` 审查计划:每阶段有 `Skill:` 行、WRITEBACK 集在基线 schema 内、验收标准可被 `{{validate_cmd}}` 覆盖(若 validate_cmd 非空)。

## 7. 收尾审计(任务完成前)

每个任务收尾必跑:
```bash
{{validate_cmd}}                    # 若非空
age sync --since <task-start-ref>   # 漂移检测
age check                           # 静态一致性
age audit --scope closure           # 收尾门禁
```
- 全绿 → 任务完成,日志记审计简报。
- 任一失败 → 回 doc-sync 修复;无法修(需大改 owner 文档)→ 本任务标 `已阻塞`,新开任务。

## 8. 周期审计

- **每里程碑或每周**:`age audit --scope full`,报告入 `docs/audits/`。
- **CI**:`age ci`(= `age check --strict` + `age sync --json`),非交互,阻断合并。

## 9. AGE 插件引用

- 元 skill:`skills/age/SKILL.md`(AGE 插件内)
- 路由决策表:`skills/age/references/routing-rules.md`
- 基线 schema:`skills/age/references/baseline-schema.md`
- 同步清单:`skills/age/references/sync-checklist.md`
- 文档路由器(本仓库):`docs/index.md`

### 9.1 跨客户端兼容说明

本文件是**跨客户端通用契约**,不绑定 ZCode 专有概念。上列 `skills/age/...` 路径是 AGE 插件根内的相对路径,各客户端按自己的机制解析:

| 客户端 | AGE 插件根定位 | skills 路径实际位置 | 指令文件 |
|---|---|---|---|
| **ZCode**(一等宿主) | `${ZCODE_PLUGIN_ROOT}`(自动注入) | `skills/age/...`(插件根) | 本文件 `AGENTS.md` |
| **Claude Code** | `$CLAUDE_PROJECT_DIR/.age-plugin`(或 `age install` 写入的绝对路径) | `.claude/skills/age/...`(复制到工作区) | `CLAUDE.md`(本文件的生成副本,见 `compat/claude-code/CLAUDE.md`) |
| **Codex CLI** | `age install` 写入 `~/.codex/config.toml` 的绝对路径 | `.codex/skills/age/...`(拷贝/链接到 Codex skills 目录) | 本文件 `AGENTS.md`(Codex 原生读) |
| **OpenCode CLI** | `opencode.json` 的 `mcp.age-mcp.environment.AGE_PLUGIN_ROOT` | 无 skills(用 `opencode.json` commands 替代) | 本文件 `AGENTS.md`(OpenCode 原生读) |

**非 ZCode 客户端:**
- 上列 `skills/age/...` 路径在 Claude Code 下对应 `.claude/skills/age/...`;在 Codex CLI 下对应 `.codex/skills/age/...`;在 OpenCode 下无 skills 机制,agent 通过读本文件 + `age <cmd> --help` + MCP tools 获取等价能力。
- **兼容等级:** ZCode / Claude Code / Codex CLI 均为 **full**(hooks+skills+MCP+指令文件全支持);OpenCode CLI 为 **partial**(MCP+commands+AGENTS.md,无 SessionStart/Stop hooks)。详见 `compat/README.md` 的功能降级矩阵。
- 环境变量:`age` CLI 与 MCP server 通过 `AGE_PLUGIN_ROOT` / `AGE_PROJECT_ROOT`(或 `AGE_PROJECT_DIR`)定位插件根与项目根,不依赖 `${ZCODE_PLUGIN_ROOT}` / `${ZCODE_PROJECT_DIR}`(ZCode 专属)。各客户端适配配置由 `compat/<client>/` 提供,`age install` 自动写入。
- 详细适配说明见 AGE 插件 `compat/README.md` 与各客户端子目录。

#### 9.1.1 Windows 11 路径与环境变量补充

AGE 在 Windows 11 上通过 PowerShell 原生层(`cli/age.ps1` + `hooks/scripts/*.ps1`)+ Git-Bash 兼容层(现有 bash 脚本)双层策略工作(详见 `compat/win11/README.md`)。在 Win11 上操作本仓库或编写 AGE 生成内容时,注意以下差异:

- **路径分隔符用 `\`(反斜杠):** Win11 原生路径如 `docs\index.md`、`C:\Users\<name>\project`。POSIX 风格 `/` 在 PowerShell 与多数工具下也接受,但调用 Win 原生命令时需用 `\`。AGE 工具脚本(`compat/win11/path-utils.ps1`)提供 `Convert-ToWinPath`(POSIX→Win)与 `Convert-ToPosixPath`(Win→POSIX)互转。**在文档与代码引用中,优先用 POSIX `/` 以保持跨平台一致;仅在 Win 原生命令必需时转 `\`。**
- **环境变量读法按 shell 而定:**
  - **PowerShell**:`$env:AGE_PLUGIN_ROOT`、`$env:AGE_PROJECT_ROOT`(设值用 `$env:VAR = "..."`)。
  - **CMD**:`%AGE_PLUGIN_ROOT%`、`%AGE_PROJECT_ROOT%`(设值用 `set VAR=...`)。
  - **Git-Bash**(回退层):`$AGE_PLUGIN_ROOT`、`$AGE_PROJECT_ROOT`(与 macOS/Linux 一致)。
  - 不论哪个 shell,变量名统一为 `AGE_PLUGIN_ROOT` / `AGE_PROJECT_ROOT`(`AGE_PROJECT_DIR` 为回退名),与 §9.1 环境变量说明一致。`compat/win11/env-template.ps1` 一键设置全部变量。
- **Python 命令可能是 `python` 而非 `python3`:** Win11 上 Python 3 通常以 `python` 调用,`python3` 多数不存在。AGE 的 MCP server 启动、`age doctor` 的 Python 检查均通过 `$env:PYTHON_EXEC`(由 `env-template.ps1` 按 `python` → `python3` → `py -3` 顺序检测)解析,**不要在配置或命令里写死 `python3`**。
- **行结束符 CRLF:** Win11 默认 CRLF,AGE 仓库模板是 LF。建议 `git config core.autocrlf input`(checkout 不转 CRLF,commit 转 LF),保证 `cli/age`(bash shebang)与 `mcp/server.py` 在 Git-Bash 层下稳定。`.ps1` 脚本对 CRLF/LF 均可执行,不受影响。
- **CLI 入口选择:** Win11 优先 `cli/age.ps1`(PowerShell 原生,不依赖 bash);若已装 Git for Windows,可在 Git-Bash 终端用 `cli/age`(bash,回退)。两者子命令与语义完全一致(§3)。
- **AGE 仓库检测:** `Test-AgeRepo`(`compat/win11/path-utils.ps1`)在 Win11 上以 `docs\index.md`(主标志)或 `AGENTS.md`(次标志,初始化中途容忍)判定,与 bash 侧 `is_age_repo` 语义一致(§8.8 X)。

> 本文件由 `age init` 从 AGE 插件模板渲染。修改本文件后跑 `age check` 确认引用可解析。`CLAUDE.md` 是本文件的 Claude Code 适配副本(由 `age install` 生成),修改操作指令时改本文件,然后 `age install` 重新生成 `CLAUDE.md`,两者自动同步。

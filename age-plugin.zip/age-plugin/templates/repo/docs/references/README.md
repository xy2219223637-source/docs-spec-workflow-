# docs/references/ — 参考文档

## 本目录职责

存放**跨目录通用的参考文档**。这些文档不属于某个具体产物目录(如 plans/audits),而是**横切性约定**:

- 文档命名与时效性规范(所有目录共用)。
- 维护清单(定期检查文档健康度)。
- 其他跨流程的约定与速查。

references 是"规则层"支架:它定义所有目录共用的规则,避免每个目录各搞一套。

## 目录内容

- `document-naming-and-timeliness.md` — 文档命名规范(稳定名 vs 带日期名)与时效性判定。
- `maintenance-checklist.md` — 文档维护清单,定期执行防文档腐化。

## 什么触发写入本目录

- 出现横切多目录的通用规则 → 写参考文档。
- 现有规则需修订 → 更新(稳定名,内容演进)。
- 维护清单需调整检查项 → 更新 maintenance-checklist。

## 命名规则

| 类型 | 命名 | 说明 |
|---|---|---|
| 通用参考 | 稳定名 | 如 `document-naming-and-timeliness.md`;规则长期有效,内容演进 |
| 速查表(可选) | 稳定名 | 如 `cli-commands-cheatsheet.md` |

references 用**稳定名**:因为规则要被反复引用,改名将断链。

## 与其他目录的关系

| 目录 | 关系 |
|---|---|
| 所有 `docs/*/README.md` | 各目录命名规则应与 `document-naming-and-timeliness.md` 一致 |
| `docs/audits/` | 文档审计引用命名规范与维护清单 |
| `docs/process/` | 工作流引用通用规则 |

## AGE 哲学定位

references 是支架的"地基"。它不针对具体任务,而是定义所有任务共用的规则。没有统一规则,每个目录各搞一套命名/时效标准,文档审计就无法一致执行。references 要精:只放真正横切的规则,不放单目录的事(那些在各目录 README 里说)。

# 文档命名与时效性

> 横切规则,适用于 `docs/` 下所有子目录。各目录 README 的命名规则应与本文件一致。

## 一、命名规则

AGE 文档分两类,命名方式不同:

### 1. 稳定名(长期文档)

**特征**:文档描述长期有效的事物,内容随时间演进而更新(改内容,不改名)。

**命名**:无日期,主题导向。如 `architecture-overview.md`、`known-good-baselines.md`、`REQ-001-user-auth.md`、`ADR-003-session-strategy.md`。

**适用**:

| 目录 | 稳定名示例 |
|---|---|
| `docs/context/` | `project-context.md` |
| `docs/architecture/` | `architecture-overview.md`、`ADR-XXX-*.md` |
| `docs/design/` | `auth-module-design.md` |
| `docs/requirements/` | `REQ-XXX-*.md` |
| `docs/backlog/` | `BL-XXX-*.md` |
| `docs/bugs/` | `BUG-XXX-*.md` |
| `docs/lessons/` | `session-must-be-shared.md` |
| `docs/testing/` | `known-good-baselines.md` |
| `docs/skills/` | `tdd.md` |
| `docs/references/` | `document-naming-and-timeliness.md` |
| 各目录指南 | `00-*-guide.md`(编号 00 表长期方法文档) |

**为什么稳定名**:这些文档被反复引用(ID、路由、审计对照)。改名 = 引用全断。演进就改内容,重大变更附变更说明与日期。废弃不删除,标 `status: deprecated/superseded`。

### 2. 带日期名(事件文档)

**特征**:文档记录一次性事件,完成后归档,不再演进。

**命名**:日期前缀 + 主题。如 `2026-07-11-add-user-auth.md`、`2026-07-11-plan-auth-audit.md`。

**适用**:

| 目录 | 带日期名示例 |
|---|---|
| `docs/plans/` | `2026-07-11-add-user-auth.md`(计划是一次性执行支架) |
| `docs/audits/` | `2026-07-11-closure-user-auth.md`(每次审计是一次事件) |
| `docs/logs/` | `2026-07-11-auth-impl.md`(日志是事件流) |
| `docs/input/` | `2026-07-11-user-auth-request.md`(原始输入是事件) |
| `docs/discussions/` | `2026-07-11-auth-session-strategy.md` |
| `docs/analysis/` | `2026-07-11-session-store-options.md` |
| `docs/retrospectives/` | `2026-07-11-sprint-3-retro.md` |

**为什么带日期**:事件按时间检索;同主题可能多次(多轮审计、多条日志)。日期前缀天然排序。事件文档不演进——要更新就新建一篇,原篇保留作历史。

### 3. 速判:稳定名还是带日期名?

问两个问题:

1. **这文档会被反复引用(ID/路由/审计对照)吗?** 是 → 稳定名。
2. **内容会随时间演进,还是一次性?** 演进 → 稳定名;一次性 → 带日期名。

两问都指向同一答案就用那个;矛盾时优先"是否被反复引用"。

### 4. ID 编号约定

需要稳定引用的文档用 ID 前缀:`REQ-`、`BL-`、`BUG-`、`ADR-`、`PLAN-`、`AUDIT-`、`BASELINE-`。ID 分配后不变;内容演进时 ID 保持。

## 二、时效性

### 文档健康状态

| 状态 | 含义 | 处理 |
|---|---|---|
| **fresh** | 反映当前现实 | 无需动作 |
| **stale** | 内容过时,与代码/现实不符 | 更新或标 deprecated |
| **orphan** | 引用已断(无人指向) | 评估是否还有价值;无价值则标 deprecated |
| **missing** | 该有却没有(如缺基线) | 补建 |

### 时效性判定(文档审计用)

对每份稳定名文档,问:

1. **它描述的事物还存在吗?**(架构总览描述的架构还在吗?)
2. **内容与代码一致吗?**(命令、约束、接口还对吗?)
3. **还有引用指向它吗?**(或它成了孤儿?)

任一否 → stale/orphan,需处理。

### 时效性维护原则

- **改代码必查文档**:实现改了接口/约束/命令,收尾时必须回写对应 owner 文档。这是收尾审计的核心检查。
- **过时不留**:发现 stale 立即更新或标 deprecated。留着不准的文档比没有更糟——它误导。
- **孤儿评估**:orphan 不直接删,先评估是否还有参考价值;无价值才 deprecated。
- **`age sync` 辅助**:契约第 3 节,`age sync` 报告 stale/orphan/missing,辅助时效性检测(语义准确性仍需人工)。

### 命名与时效性的关系

稳定名文档容易 stale(内容演进,容易忘了同步);带日期名文档不会 stale(一次性,不演进,只可能 orphan)。因此:

- 文档审计的重点是**稳定名文档**的时效性。
- 带日期名文档的审计重点是**是否 orphan**(还有没有被引用)。

## 三、与 CLI 的关系

| CLI | 覆盖 |
|---|---|
| `age check --strict` | 路由死链、AGENTS 引用可解析(部分命名一致性) |
| `age sync` | stale/orphan/missing 检测(时效性) |
| `age baseline` | 文档指纹基线(检测后续漂移) |

命名规范的遵守与语义时效性判断,需人工/审计补充。

# 文档维护清单

> 定期执行,防止文档腐化。可由文档审计(可选审计)或周期维护触发。
> 配合 `age sync`、`age check --strict`(契约第 3 节)使用;语义项需人工判断。

## 维护频率建议

| 频率 | 动作 |
|---|---|
| 每次收尾 | 计划回写集清空(即时维护,见收尾审计) |
| 每周/每两周 | 跑一次 `age sync` + `age check --strict`,处理漂移 |
| 每月/每里程碑 | 执行本清单完整版(文档审计) |
| 重大变更后 | 针对受影响目录执行本清单 |

## 维护清单

### 1. 命名规范

- [ ] 稳定名文档无日期前缀(除非有快照用途)
- [ ] 带日期名文档有正确日期前缀(YYYY-MM-DD)
- [ ] ID 前缀文档(REQ/BL/BUG/ADR/PLAN/AUDIT/BASELINE)ID 唯一且不重用
- [ ] 文件名与目录职责一致(计划在 plans/、审计在 audits/,不串)
- 参考:`document-naming-and-timeliness.md`

### 2. 时效性(重点查稳定名文档)

- [ ] `docs/context/project-context.md`:技术栈/命令/约束仍真实
- [ ] `docs/architecture/`:架构总览与 ADR 与代码一致;被推翻的 ADR 标 superseded
- [ ] `docs/design/`:设计文档反映当前实现;过时设计标 deprecated 或更新
- [ ] `docs/requirements/`:需求仍有效;废弃需求标 deprecated 并说明
- [ ] `docs/backlog/`:完成项 status=done;阻塞项有说明;无僵尸条目(长期无进展)
- [ ] `docs/testing/known-good-baselines.md`:基线命令仍可执行且全绿
- [ ] `docs/lessons/`:教训仍适用;过时教训标 deprecated
- [ ] `docs/skills/`:方法说明与实际用法一致

### 3. 孤儿检测(带日期名文档)

- [ ] plans/audits/logs 中的文档是否还被引用(被日志/计划/复盘指向)
- [ ] 无引用的事件文档评估:有参考价值保留+标注,无价值归档
- [ ] `age sync` 报告的 orphan 项逐一处理

### 4. 引用完整性

- [ ] `age check --strict` 退出码 0(无死链)
- [ ] 文档间交叉引用(如计划→需求→设计)可解析
- [ ] AGENTS.md 引用的命令/路径存在

### 5. 漂移处理

- [ ] `age sync` 报告的 stale 项:更新或标 deprecated
- [ ] `age sync` 报告的 missing 项:补建(如缺基线、缺 ADR)
- [ ] 重大漂移(多项 stale)→ 触发复盘,找根因(是流程漏回写?还是文档太多?)

### 6. 流程健康度

- [ ] 近期计划是否都过了计划审计 + 收尾审计(查 audits/ 记录)
- [ ] 是否有绕过流程未补正的(查 logs/ 的"绕过"记录)
- [ ] 是否有反复出现的审计失败模式(→ 沉淀 lesson 或调整流程)
- [ ] backlog 是否定期重排、僵尸条目清理

### 7. 基线同步

- [ ] `age baseline` 重建(重大文档变更后)
- [ ] `docs/testing/known-good-baselines.md` 与实际验证命令一致
- [ ] `.age/baseline.json` 反映当前文档指纹

## 维护记录

每次执行本清单,建议留一条记录(可并入 audits/ 或 logs/):

```
---
date: {{日期}}
scope: maintenance
runner: {{人/AI}}
---

## 执行项
- [x/—] 命名规范
- [x/—] 时效性
- ...

## 发现与处理
{{stale/orphan/missing 清单 + 处理动作}}

## 待办
{{需后续处理的项,转 backlog}}
```

## AGE 哲学定位

维护清单是"防腐化"支架。文档不会自己保持新鲜——代码在变,文档若不跟着变就 stale。定期维护让 owner 文档始终是可信的吸引子,而非误导的过时地图。维护不是负担,是投资:stale 文档导致的错误实现,成本远高于维护。把维护纳入节奏(周期/里程碑),而不是等文档烂到不可用才大修。

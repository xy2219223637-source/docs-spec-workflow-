# 应用开发工作流(轻量默认)

> 这是 AGE 的主流程。从原始输入到交付验证,8 步。
> **默认控制回路(必须执行):已创建计划 → 计划审计(实现前);完成前 → 收尾审计。**
> 多维审计 / 文档审计 / 开放式审计为可选增强,见 `docs/audits/00-audit-execution-guide.md`。

## 流程总览

```
0.激活 AGE → 1.原始输入 → 2.需求综合 → 3.设计基线 → 4.路由任务/选技能 → 5.计划 → 6.实现 → 7.验证 → 8.收尾
              │                          │            │                    │
              └─首次:age use 自动初始化    └─见 skills/  └─计划审计(默认)    └─收尾审计(默认)
              └─已初始化:SessionStart 自动激活
```

每一步都说明:**输入 / 输出 / 触发条件 / 回写的 owner 文档 / 相关指南**。

> 在进入第 1 步之前,需先完成**第 0 步:激活 AGE**(见下文)。已初始化的项目在会话开始时由 SessionStart hook 自动激活。

---

## 第 0 步:激活 AGE

进入工作流前,确保 AGE 已在本项目激活。AGE 兼容 ZCode / Claude Code / Codex CLI / OpenCode CLI 四个客户端,激活前需先按你的客户端装好适配配置。

### 步骤 0a:按你的客户端安装 AGE(仅首次)

不同客户端的扩展机制与配置格式不同,但 AGE 的核心层(CLI、AGENTS.md 指令、MCP server)跨客户端共用,仅 hooks/commands/skills 按各客户端格式适配。

**自动检测安装(推荐)**:运行 `age install`,自动检测当前客户端环境(ZCode / Claude Code / Codex / OpenCode),把对应适配配置装到正确位置(详见 `START-HERE-after-copy.md` 的"多客户端安装"小节)。

- **ZCode**:装 AGE 插件即可,自带 hooks/commands/skills/MCP,无需额外配置。
- **Claude Code**:`age install` 把 hooks/skills/commands 配置写入 `.claude/`,MCP 写入 `.mcp.json`,并放置 `CLAUDE.md` 指令文件。
- **Codex CLI**:`age install` 把 MCP 配置(TOML)写入 `~/.codex/config.toml`;Codex 靠 AGENTS.md 指令 + CLI + MCP 工作。
- **OpenCode CLI**:`age install` 把 MCP + commands + hooks 配置写入项目根 `opencode.json`。

若自动检测失败,可手动从 `compat/<客户端>/` 拷贝对应配置(见 `compat/README.md`)。

### 步骤 0b:激活 AGE

- **首次使用(项目未初始化)**:对 AI 说"启动 AGE""开启 AGE""enable AGE""用 AGE"等,或运行 `age use` / `/use-age`。use-AGE 功能会自动检测项目状态,若未初始化则执行 `age init` 完成脚手架生成与基线建立,随后激活 AGE。
- **已初始化的项目**:会话开始时 SessionStart hook 自动激活 AGE(注入 `docs/context/` 摘要到上下文),无需手动操作。
- **激活判据**:`docs/index.md` 与 `AGENTS.md` 存在,`.age/baseline.json` 已生成。

激活后才进入下面的"原始输入 → 需求综合 → ..."主流程。未激活时,owner 文档(吸引子)与基线(参照物)缺失,工作流无对齐基准。

### Win11 注意事项

在 Windows 11 上激活与运行 AGE 时,注意以下差异:

- **CLI 入口**:Win11 上用 `age.ps1` 替代 `age`。子命令与参数完全一致(`age.ps1 init`、`age.ps1 use`、`age.ps1 route <task>` 等价于 bash 版),仅入口文件不同。`age install --client win11` 会自动配置该入口。
- **环境变量**:PowerShell 用 `$env:AGE_PLUGIN_ROOT` 设置插件根(而非 bash 的 `$AGE_PLUGIN_ROOT`)。`age.ps1` 自动探测插件根,通常无需手动设;若需显式指定,用 `$env:AGE_PLUGIN_ROOT = "<路径>"`。
- **MCP server 启动**:Win11 上用 `python`(非 `python3`)启动 `mcp/server.py`。各客户端的 Win11 MCP 配置应指向 `python mcp/server.py`;`age.ps1` 会按 `python` → `python3` → `py -3` 顺序自动检测解释器。
- **Hook 脚本**:Win11 用 `hooks/scripts/*.ps1`(配置见 `hooks/hooks.win11.json`),而非 bash 的 `*.sh`。SessionStart / PostToolUse / Stop 三个事件均有 PowerShell 对应实现。
- **Git-Bash 回退**:若装了 Git for Windows,现有 bash 脚本(`cli/age`、`hooks/scripts/*.sh`)可直接用,本工作流无需任何特殊调整,按各步骤的 bash 命令操作即可。

> 详见 `compat/win11/README.md`(由事实设计提供)与 `docs/context/conventions.md` 的"Windows 11 环境约定"。

---

## 第 1 步:原始输入

把原始需求/想法/bug 报告收集到一个稳定位置。

- **输入**:用户口述、issue、会议纪要、外部文档。
- **输出**:落到 `docs/input/` 的文件(带日期或稳定名)。
- **触发条件**:任何"要做点什么"的信号。
- **回写 owner 文档**:无(此步只是收集)。
- **相关指南**:`docs/input/README.md`。

要点:原始输入**原样保留**,不要在这一步"净化"。净化是第 2 步的事。原始输入里那些模糊、矛盾、口语化的部分,正是需求综合要处理的素材。

---

## 第 2 步:需求综合

把原始输入提炼成结构化需求。

- **输入**:`docs/input/` 中的原始文件 + `docs/context/project-context.md`(对齐项目真实约束)。
- **输出**:`docs/requirements/` 中的需求文档。
- **触发条件**:有原始输入、且尚无对应需求文档。
- **回写 owner 文档**:若综合过程中发现项目上下文缺失或过时,回写 `docs/context/project-context.md`。
- **相关指南**:`docs/requirements/00-requirement-synthesis-guide.md`。

要点:需求综合要标注每条需求的**来源**(指向 input 文件)、**验收标准**(可验证)、**优先级与自治标签**(见 backlog README 的 auto/assisted/manual)。矛盾的需求不要自行裁决,记下来进 `docs/discussions/`。

---

## 第 3 步:设计基线

为需求确定设计方向与架构约束。

- **输入**:需求文档 + `docs/architecture/`(现有架构)。
- **输出**:`docs/design/` 中的设计文档;若涉及架构变更,`docs/architecture/` 增 ADR。
- **触发条件**:需求非平凡(涉及多模块/数据流/接口),或现有设计无法覆盖。
- **回写 owner 文档**:设计若改变架构约束,回写 `docs/architecture/`;若暴露新的项目不变式,回写 `docs/context/project-context.md`。
- **相关指南**:`docs/design/README.md`、`docs/architecture/README.md`。

要点:小切片(单文件小改、纯文案)可跳过本步,直接进第 4 步。判定标准见 `docs/plans/00-plan-authoring-and-execution-guide.md` 的"触发规划的条件"。

---

## 第 4 步:路由任务 / 选技能

确定本任务该读哪些 owner 文档、用哪个技能(方法)。

- **输入**:需求/设计 + `docs/index.md`(路由器)+ `docs/skills/README.md`(方法选择器)。
- **输出**:任务路由结果(该读的文档清单 + 选定的技能),记录在计划的"技能选择记录"里。
- **触发条件**:每个开发任务开始前。
- **回写 owner 文档**:无(此步是读与决策)。
- **相关指南**:`docs/skills/README.md`、`docs/index.md`。
- **CLI**:`age route <task> [--explain]` 可辅助路由(契约第 3 节)。

要点:技能选择必须**显式记录**——每个阶段写 `Skill: <name>` 或 `Skill: none`。这是计划审计会检查的项。选 none 不是错,但要说明为什么不需要技能。

---

## 第 5 步:计划

把任务拆成可验证的执行步骤,写进计划文档。

- **输入**:路由结果 + 设计 + 需求验收标准。
- **输出**:`docs/plans/` 中的计划文档,含:目标、阶段拆分、每阶段技能选择记录、验证标准、收尾规则。
- **触发条件**:非平凡切片(见计划编写指南的判定)。
- **回写 owner 文档**:若计划暴露新的约束/不变式,回写 `docs/context/`。
- **相关指南**:`docs/plans/00-plan-authoring-and-execution-guide.md`。

要点:**计划创建后、实现前,必须先过计划审计**(默认控制回路)。审计检查:收尾规则是否完备、验证标准是否可执行、技能选择是否合理。未过审计不进第 6 步。

---

## 第 6 步:实现

按计划执行。

- **输入**:经计划审计通过的计划文档 + 路由得到的 owner 文档。
- **输出**:代码变更 + `docs/logs/` 中的执行日志。
- **触发条件**:计划审计通过。
- **回写 owner 文档**:实现若偏离设计/架构,回写 `docs/design/`、`docs/architecture/`;若触及项目不变式,回写 `docs/context/`。
- **相关指南**:`docs/logs/00-log-writing-guide.md`。

要点:实现过程中,PostToolUse hook 会触发 `age sync` 提醒文档漂移(契约第 5 节)。出现漂移应及时回写 owner 文档,而不是攒到收尾。验证失败的复杂回归,归档到 `docs/bugs/`。

---

## 第 7 步:验证

按计划的验证标准逐项验证。

- **输入**:计划中的验证标准 + 代码变更。
- **输出**:验证结果(写进日志);若失败,`docs/bugs/` 记录。
- **触发条件**:实现完成、声称达成验证标准前。
- **回写 owner 文档**:验证若暴露基线变化,回写 `docs/testing/known-good-baselines.md`。
- **相关指南**:`docs/testing/README.md`、`docs/bugs/00-bug-fix-note-writing-guide.md`。
- **CLI**:验证命令来自 `AGENTS.md`(测试/类型检查/lint/构建)。

要点:验证不是"跑一下没报错",而是**对照计划里的验证标准逐条勾选**。标准模糊就回第 5 步补计划。

---

## 第 8 步:收尾

对照回写集更新 owner 文档,并过收尾审计。

- **输入**:回写集(第 4 步标记、第 6 步补充)+ 实现与验证结果。
- **输出**:更新后的 owner 文档 + `docs/audits/` 中的收尾审计记录。
- **触发条件**:声称任务完成前。
- **回写 owner 文档**:本步的核心就是回写——按回写集把 owner 文档同步到最新现实。
- **相关指南**:`docs/audits/00-audit-execution-guide.md`。
- **CLI**:`age audit --scope closure`(契约第 3 节)、Stop hook 自动触发。

要点:**收尾审计是默认控制回路,完成前必须过。** 审计检查:owner 文档是否与代码一致、回写集是否清空、基线是否更新。未过审计不算完成。过审计后用 `age sync` 确认无漂移,再结束。

---

## 默认控制回路(必须执行)

| 控制点 | 时机 | 做什么 | 失败则 |
|---|---|---|---|
| **计划审计** | 第 5 步之后、第 6 步之前 | 审查计划:收尾规则、验证标准、技能选择 | 退回第 5 步修订 |
| **收尾审计** | 第 8 步、声称完成前 | 审查文档与代码一致性、回写集清空 | 退回第 6/8 步补齐 |

## 可选增强审计(按需)

- **多维审计**:对高风险任务,从安全/性能/可维护性等多维度审查。
- **文档审计**:专门检查 owner 文档时效性与命名规范。
- **开放式审计**:不预设检查项,让 auditor 自由探索风险。

详见 `docs/audits/00-audit-execution-guide.md`。

---

## 何时偏离本工作流

本工作流是**默认**,不是教条。允许偏离的场景:

- **纯文档修订**:不碰代码,可跳过第 6/7 步的代码验证,但收尾审计仍要做(检查文档一致性)。
- **紧急 hotfix**:先修,后补计划与审计;但必须在 `docs/logs/` 记录"为何绕过",并在 24 小时内补齐计划审计。
- **探索性 spike**:不确定可行性,可只记 `docs/analysis/` 探索笔记,不走完整流程;一旦决定落地,回到第 2 步。

偏离必须**显式记录原因**,不能默默跳步。AGE 的支架可以减配,但减配要留痕。

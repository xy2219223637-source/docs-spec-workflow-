# {{project_name}} — 事实来源与优先级

> 本文件定义本仓库的**事实来源优先级链**。是 AGE 铁律的本地化具象。
> `age check` 校验本文件含"优先级"段且出现 owner/计划/日志/聊天四个词。
> 本文件极少变更;链本身是 AGE 方法论的核心约束。

## 优先级

冲突时按此链裁决,**高者优先**:

1. **owner 文档** — `docs/context/`、`docs/backlog/`、`docs/requirements/`、`docs/design/`、`docs/architecture/`
2. **计划** — `docs/plans/`
3. **日志** — `docs/logs/`
4. **聊天** — 任何会话内口头决定(包括用户与 agent 的对话、PR 评论中的非文档决定)

### 裁决规则

- **聊天 vs owner 文档**:owner 文档胜。聊天决定若要生效,必须先更新 owner 文档(开独立任务)。不得"聊天里说改就改"。
- **计划 vs owner 文档**:owner 文档胜。计划是对 owner 文档的**执行编排**,不是新事实。计划与 owner 文档冲突→修计划,或先更新 owner 文档。
- **日志 vs 计划**:计划胜。日志记录"实际发生了什么",计划记录"应该发生什么";两者偏差是漂移信号,`age sync` 会报。
- **同级冲突**:后写者胜,但必须在日志说明覆盖原因。

## 事实来源的层级含义

| 层级 | 文档 | 角色 | 写入时机 |
|---|---|---|---|
| owner | context/backlog/requirements/design/architecture | **事实**——什么是真的 | 显式更新任务 |
| 计划 | plans | **意图**——打算做什么 | 任务开始前 |
| 日志 | logs | **观测**——实际做了什么 | 任务执行中/后 |
| 聊天 | 会话 | **草稿**——未成形想法 | 随时;不沉淀则失效 |

> 聊天不沉淀即失效:重要的聊天决定必须升级到日志(记一笔)或 owner 文档(开任务改),否则下次会话不存在。

## 与 AGE 的关系

AGE 的 `route`/`doc-sync`/`audit` 全部围绕这条链:
- `route` 强制读 owner 文档(最高级),避免被聊天带偏。
- `doc-sync` 把代码变更回写到 owner 文档,保持"事实"层与代码一致。
- `audit` 检测各级间的漂移(stale=事实过期、orphan=代码无事实承载、missing=应更新未更新)。

## 例外

唯一允许覆盖 owner 文档的情况:**owner 文档本身被显式更新**。更新必须:
1. 开独立任务(不在当前任务里顺手改)。
2. 走 route → doc-sync → audit 闭环。
3. 若涉及架构,产 ADR 入 `docs/audits/`。

无 ADR 的架构 owner 文档变更 = 违规,`age audit --scope closure` 会 fail。

# {{project_name}} — 项目约定

> 本文件是命名/提交/测试/分支等工程约定的 owner 文档。`age check` 校验本文件含"约定"段。
> 改约定需开独立任务;约定变更影响所有后续任务的 route 与 doc-sync。

## 约定

### 命名

{{naming_conventions}}

> 填写指引:文件、函数、类型、变量的命名规则。例:"Python 文件 snake_case;类 PascalCase;常量 UPPER_SNAKE;测试文件 `test_*.py`。"

### 提交

{{commit_conventions}}

> 填写指引:提交信息格式、频率、是否需签名。例:"Conventional Commits(`feat:`/`fix:`/`docs:`/`refactor:`);一逻辑变更一提交;提交前必跑 `{{validate_cmd}}`。"

### 分支

{{branch_conventions}}

> 填写指引:分支模型。例:"`main` 受保护;特性分支 `feat/<short>`;修复 `fix/<short>`;PR 合并用 squash。"

### 测试

{{testing_conventions}}

> 填写指引:测试覆盖要求、跑法。例:"公共接口必有单测;bug 修复必带回归测试;`pytest -q` 全绿方可合并。`{{validate_cmd}}` 即测试入口。"

### 文档

{{doc_conventions}}

> 填写指引:文档语言(`{{doc_language}}`)、owner 文档更新时机、ADR 要求。例:"owner 文档中文;公共接口变更必同步 `docs/design/`;架构变更必产 ADR。"

## AGE 相关约定

- **每个计划阶段记 `Skill:`**(见 AGENTS.md §3)。
- **收尾必跑 `age audit --scope closure`**(见 AGENTS.md §7)。
- **owner 文档优先于聊天**(见 `source-of-truth-and-precedence.md`)。
- **WRITEBACK 集外的变更开新任务**(见 AGENTS.md §5)。

## 跨客户端协作约定

AGE 以 ZCode 为一等宿主,同时兼容 Claude Code / Codex CLI / OpenCode CLI。以下约定确保同一项目可在不同客户端之间无缝协作,且不因切换客户端而丢失上下文。

### AGENTS.md 是跨客户端共用指令文件

- `AGENTS.md` 是 ZCode / Codex CLI / OpenCode CLI 共同识别的指令文件,四客户端中三者直接读取。
- **Claude Code 额外需要 `CLAUDE.md`**:Claude Code 仅认 `CLAUDE.md` 作指令文件,因此 Claude Code 适配层会在工作区放置一份 `CLAUDE.md`(内容是 `AGENTS.md` 的副本)。修改 `AGENTS.md` 时须同步 `CLAUDE.md`,否则 Claude Code 侧指令过期。
- 维护原则:以 `AGENTS.md` 为权威源,`CLAUDE.md` 是它的镜像。`age install` 负责生成与同步。

### MCP server 是跨客户端共用层

- 各客户端的 MCP 配置格式不同(ZCode: `mcp.servers`;Claude Code: `.mcp.json` 顶层 `mcpServers`;Codex: TOML `[mcp_servers.age]`;OpenCode: JSON `mcp.command` 数组),但**四者指向同一个 `mcp/server.py`**。
- 因此 MCP 提供的 resources(`docs://index`、`docs://context/project-context`、`docs://status`)与 tools(`age_route` / `age_check_drift` / `age_propose_doc_update` / `age_evolve` / `age_activate`)在所有客户端行为一致。
- 项目根检测:server 优先读 `AGE_PROJECT_ROOT`,回退 `AGE_PROJECT_DIR`(ZCode 注入),再回退各客户端环境变量(`CLAUDE_PROJECT_DIR` / `CODEX_HOME` / `OPENCODE_CONFIG`),最后回退 `os.getcwd()`。

### hooks / commands / skills 按客户端格式适配

- **ZCode 是完整版**:包含全部 7 个 hook 事件(PascalCase)、全部 slash commands、完整 skills 目录。
- **其他客户端是子集**:
  - Claude Code:支持 hooks(settings.json 配置)、skills(`.claude/skills/`)、commands(`.claude/commands/`),事件名为 PascalCase,按其格式适配。
  - Codex CLI:无 hooks、无 skills、无 slash commands,仅靠 AGENTS.md 指令 + CLI + MCP。
  - OpenCode CLI:支持 hooks(camelCase 事件名)与 commands(opencode.json 内联),无独立 skills 目录。
- 适配配置由 `compat/<客户端>/` 提供,`age install` 自动安装。ZCode 的 hooks/commands/skills 是上游权威,其他客户端的适配配置从它派生(子集或格式转换)。

### 项目状态(.age/)跨客户端共用,不绑定特定客户端

- `.age/baseline.json`(基线指纹)、`.age/writeback.json`(回写集,见 CONTRACT §8.2 [D-6])、`.age/hooks.log` 等状态文件位于项目根的 `.age/`,与客户端无关。
- 同一项目用 ZCode 开发后,切换到 Claude Code 或 Codex 继续,基线、回写集、审计记录全部保留——因为它们是 CLI 与文件系统的产物,不依赖任何特定客户端的会话态。
- 各客户端的会话态(注入的上下文、激活状态)是临时性的,真正的状态真相在 `.age/` 与 `docs/`。判断"AGE 是否激活"以文件判据为准(`docs/index.md` + `AGENTS.md` + `.age/baseline.json` 存在),不以"当前客户端是否注入了上下文"为准。

### 跨客户端切换的实践约定

- 切换客户端前,先在当前客户端跑 `age audit --scope closure` 确保回写集清空、无漂移,再切换。
- 切换后,新客户端首次会话若 SessionStart 未自动激活(部分客户端无 SessionStart 等价物),手动跑 `age use` 或 `age doctor` 确认状态。
- 不同客户端对同一 `AGENTS.md` 的指令遵循度可能不同(模型差异),但 owner 文档与 CLI 产出是客观的——以 `age check --strict` 与 `age audit` 的结果为准,不以客户端主观表现为准。

## Windows 11 环境约定

Win11 原生无 bash,AGE 通过 PowerShell 入口(`age.ps1`)+ Git-Bash 回退实现兼容(见 CONTRACT §8.12)。以下约定确保 Win11 上的开发与 macOS/Linux/WSL 协作时不引入平台污染。

### 行结束符

- 仓库统一用 **LF**。Win11 上配置 `git config core.autocrlf input`:提交时把 CRLF 转 LF,检出时不转换(避免 CRLF 污染模板与脚本)。
- **不要用 `core.autocrlf true`**:它会检出 CRLF,污染 bash 脚本与 PowerShell 脚本的行尾,导致部分工具报错。
- 模板文件(`templates/repo/**`)必须保持 LF,禁止 CRLF。

### 路径分隔符

- **文档内统一用正斜杠 `/`**(跨平台可读,PowerShell 与 bash 均接受)。
- **脚本内按平台**:PowerShell 脚本用正斜杠或反斜杠均可(推荐正斜杠保持一致);bash 脚本用正斜杠。
- 路径中的环境变量:文档里统一写 `$AGE_PLUGIN_ROOT/cli/age.ps1`(示意),实际 PowerShell 脚本用 `$env:AGE_PLUGIN_ROOT`,bash 脚本用 `$AGE_PLUGIN_ROOT`。

### Python 命令名

- Win11 上 Python 通常是 `python`(不含 `3`),与 macOS/Linux 的 `python3` 不同。
- `age.ps1` 自动按 `python` → `python3` → `py -3` 顺序检测可用解释器,无需用户手动指定。
- MCP server 在 Win11 上用 `python mcp/server.py` 启动(而非 `python3 mcp/server.py`)。
- 文档中引用 Python 命令时须标注平台差异:macOS/Linux 用 `python3`,Win11 用 `python`。

### 环境变量语法

- **PowerShell**:`$env:VAR`(读)与 `$env:VAR = "value"`(写)。
- **bash**:`$VAR`(读)与 `export VAR=value`(写)。
- **文档统一写法**:文档中描述环境变量时统一写 `$AGE_PLUGIN_ROOT`(不带 `env:` 前缀),避免绑定特定 shell;实际设置时按平台语法转换。
- 持久化:PowerShell 用 `[Environment]::SetEnvironmentVariable(name, value, "User")`;bash 写入 `~/.bashrc` 或 `~/.zshrc`。

### Win11 与其他平台的协作约定

- 同一项目在 Win11 与 macOS/Linux 间协作时,以 `.age/` 与 `docs/` 的文件为真相(平台无关),不以本地 shell 行为为准。
- 提交前跑 `age check --strict` 确认无 CRLF 污染等一致性违规;若 `age check` 校验到行尾或路径异常会报告 drift。
- 跨平台切换时,优先确认 `git core.autocrlf` 设置正确,再跑 `age sync` 检查漂移。

## 例外与豁免

{{convention_exceptions}}

> 填写指引:哪些情况下可豁免上述约定,及豁免需谁的确认。例:"热修可绕过分支模型直接提 `main`,但需 owner 确认 + 事后补 PR + 补测试。"
> 无例外则填"无"。

## 维护

- 约定变更后,`age audit --scope full` 应跑一次,确认现有代码与新约定的一致性(AGE 不自动改代码,但会报 drift)。
- 约定与 `docs/architecture/` 的技术选型段不冲突;若冲突,以 architecture 为准并同步本文件。

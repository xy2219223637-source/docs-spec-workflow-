# {{project_name}} — AI 自治策略

> 本文件定义 AI agent 在本仓库的自治边界。是 owner 文档,优先于计划/日志/聊天。
> `age check` 校验本文件含"自主范围"与"禁止行为"两个段。

## 自主范围

AI agent 可**不经询问**自主完成:

{{autonomy_scope}}

> 填写指引:列出可自主的事。例:
> - 修改非公共接口的内部实现
> - 跑测试与 `age check`/`age audit`
> - 在 `docs/logs/` 记日志
> - 修错别字、链接、格式
> - 按已有 owner 文档执行已路由的任务

## 需确认(必须问人)

AI agent 遇到以下情况**必须暂停并询问**,不得自主决定:

{{needs_confirmation}}

> 填写指引:例:
> - 改 `docs/architecture/` 的依赖方向规则
> - 新增/删除公共 API
> - 改 `{{validate_cmd}}` 或 CI 配置
> - 删除任何 owner 文档文件
> - 引入新依赖
> - 范围蔓延(任务需要改 WRITEBACK 集之外的 owner 文档)

## 禁止行为

详见 `AGENTS.md §5 禁止行为`。本文件不重复,但强调与自治相关的几条:

1. **禁止沉默绕过 owner 文档。** 自主不等于不读——READ 集必读。
2. **禁止跨 WRITEBACK 集回写。** 超出范围的变更开新任务,不在当前任务里顺手改。
3. **禁止沉默式重构。** 架构变更需先有计划 + ADR,不得"我觉得这样更好"就改边界。
4. **禁止用聊天决定覆盖 owner 文档。** 聊天不是事实来源。

## 自治与 AGE 的关系

AGE 的 `route` 子流程会标记 WRITEBACK 集——**WRITEBACK 集内的回写属于自治范围**(若 AGENTS.md 未另规定),WRITEBACK 集外的回写属于"需确认"。即:AGE 路由的输出本身就是自治边界的具象化。若 route 输出 `Writeback: none`,则本任务为纯查询,不得改任何 owner 文档。

## 自动初始化(AGE 激活)

当用户表达**启用 AGE 的意图**(如"开启 AGE / 启动 AGE / enable AGE / use AGE / 用 AGE / 装一下 AGE / 帮我设置 AGE"等),agent 可**不经逐项确认**自主执行:

- `age init --name <目录名> --kind web`(用合理默认值生成脚手架)
- `age baseline`(快照基线)
- `age doctor`(确认健康)

即:初始化的脚手架生成属于**自治范围**——无需为项目名、kind 等机械字段逐一询问用户。这条策略与 `use-AGE` 技能的激活流程对齐。

**但以下属于"需确认",不得自主:**

- Day 0 个性化字段的填写(`owner_name` / `project_description` / `target_users` / `tech_stack` / `validate_cmd` 等涉及业务判断的字段)——init 后须引导用户填写,不得擅自编造。
- `--kind` 的非默认选择(若无法从项目特征明确推断,用默认 `web`,不擅自改 mobile/cli)。
- 在已有 AGE 初始化的项目重复 init(若 `age doctor` 显示已初始化,不重复执行)。

简言之:脚手架可自治,业务字段需人参与。

## 何时收紧自治

- 维护期/稳定期:把"修改公共接口"从自治移到"需确认"。
- 多人协作:把"改 `docs/context/conventions.md`"移到"需确认"。
- 用 `age audit --scope full` 的违规历史判断:某类违规反复出现→对应行为收紧到"需确认"。

# {{project_name}} — 项目上下文

> 本文件是 {{project_name}} 的最高级事实来源之一(owner 文档)。冲突时优先于计划/日志/聊天。
> 由 `age init` 从 AGE 插件模板渲染。`age check` 校验本文件含"验证命令"段。

## 项目是什么

{{project_description}}

> 填写指引:一句话讲项目做什么、为谁做。例:"一个面向小团队的轻量 issue 跟踪 CLI,强调离线优先与 git 集成。"

## 为谁

{{target_users}}

> 填写指引:目标用户/场景。例:"个人开发者与小团队(≤10人),偏好命令行工作流。"

## 当前阶段

{{current_phase}}

> 填写指引:原型 / MVP / 成长期 / 维护期 / 归档。影响 AGE 路由的默认严格度(原型期可放宽 backlog 强制)。

## 技术栈

{{tech_stack}}

> 填写指引:语言、框架、关键依赖。例:"Python 3.11, Click, SQLite, pytest。"

## 验证命令

```
{{validate_cmd}}
```

> 此段由 `age init` 从 `userConfig.validate_cmd` 渲染。`age audit --scope closure` 与 AGENTS.md §4 收尾门禁使用此命令。
> - 非空:每个任务收尾必跑且绿。
> - 为空:收尾审计跳过验证步骤,但仍需 `age check` + `age audit --scope closure`。
> 修改此命令请同步改 `~/.zcode` 插件配置的 `validate_cmd` userConfig,或直接编辑后跑 `age check`。

## 关联文档

- 文档路由器:`docs/index.md`
- 代理契约:`AGENTS.md`
- 优先级链:`docs/context/source-of-truth-and-precedence.md`
- 代码库地图:`docs/context/codebase-map.md`

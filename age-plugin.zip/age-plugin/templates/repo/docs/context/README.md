# docs/context/ — 强制上下文

> 本目录是 {{project_name}} 的**强制上下文基线**。五个文件必须存在且非空骨架,`age check` 校验。`SessionStart` hook 自动注入摘要,但实质性任务仍要读全文。
>
> **优先级:本目录文件是 source-of-truth 链的最高级(owner 文档)。** 任何与聊天/计划的冲突,以本目录为准,直到本目录被显式更新。

## 文件清单

| 文件 | 内容 | 何时更新 |
|---|---|---|
| `project-context.md` | 项目是什么、为谁、当前阶段、验证命令 | 项目阶段变化时 |
| `ai-autonomy-policy.md` | AI 自主范围、禁止行为、何时必须问人 | 自治边界调整时 |
| `codebase-map.md` | 模块/目录地图、入口点、依赖方向 | 模块边界变化时 |
| `source-of-truth-and-precedence.md` | 事实来源优先级链 | 极少变;链本身是 AGE 铁律 |
| `conventions.md` | 命名/提交/测试/分支约定 | 约定变化时 |

## 维护规则

- 改本目录任一文件后跑 `age check`。
- **不要在此目录记任务进度**——进度进 `docs/logs/`,需求进 `docs/requirements/`。本目录只放稳定上下文。
- 发现本目录文件过期:**不要在当前任务里顺手改**,开一个独立的"上下文更新"任务(见 AGENTS.md §5 禁止行为)。

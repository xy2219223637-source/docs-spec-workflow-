# {{project_name}} — 代码库地图

> 本文件是模块/目录结构与依赖方向的 owner 文档。`age check` 校验本文件含"模块地图"段且至少一条模块条目。
> 改模块边界/依赖方向时**必须**更新本文件 + 产出 ADR(见 AGENTS.md §5)。

## 模块地图

| 模块/目录 | 职责 | 入口点 | 依赖(可依赖谁) |
|---|---|---|---|
| {{module_1_path}} | {{module_1_responsibility}} | {{module_1_entry}} | {{module_1_deps}} |
| {{module_2_path}} | {{module_2_responsibility}} | {{module_2_entry}} | {{module_2_deps}} |

> 填写指引:`age init` 时按 `project_kind` 给两到三条骨架条目;项目成长后补全。
> - **职责**:一句话,不重叠。
> - **入口点**:该模块对外的入口文件/函数。
> - **依赖**:列出本模块**允许依赖**的模块。未列出的模块=禁止依赖。这是依赖方向规则的具象。

## 依赖方向规则

{{dependency_rules}}

> 填写指引:用一句话描述全局方向。例:"`cli` → `core` → `storage`,禁止反向;`core` 不依赖 `cli`。"
> 此规则与 `docs/architecture/` 的依赖方向规则段必须一致;`age check` 交叉校验。

## 关键入口

- 主入口:{{main_entry}}
- 测试入口:{{test_entry}}
- 构建/打包:{{build_entry}}

> 填写指引:让新 agent 快速定位"从哪开始读"。

## 与架构文档的边界

- **本文件**:模块/目录的物理地图 + 依赖方向(具体、可执行)。
- **`docs/architecture/`**:分层模型、技术选型、ADR(抽象、决策性)。
- 两者必须一致:架构文档说"`core` 不依赖 `cli`",本文件的依赖表就不能出现该依赖。冲突时以 `architecture/` 为准(它是更高层 owner),但需立即同步本文件。

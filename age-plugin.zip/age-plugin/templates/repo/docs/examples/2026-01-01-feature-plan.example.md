# 计划:{{特性名称}}

> 文档类型:plan
> 创建日期:{{日期}}
> slug:{{slug}}
> 状态:draft / in-progress / done / blocked
> 上游需求:docs/requirements/{{slug}}.md
> 对应收尾审计:docs/audits/{{日期}}-{{slug}}-closure.md

---

## 1. 目标

> 复述需求陈述 + 本计划要交付的可观测产物。

{{目标,1-2 句}}

**交付产物**:
- {{产物 1,如:新增 src/auth.py + 测试}}
- {{产物 2,如:更新 docs/architecture/xxx.md}}

## 2. 任务分解

> 每个任务可独立完成、可验证。标注 owner(谁负责)与回写文档。

| # | 任务 | owner | 回写文档集 | 预计 | 状态 |
|---|---|---|---|---|---|
| T1 | {{任务 1}} | {{agent/人}} | docs/architecture/xxx.md | {{时长}} | todo |
| T2 | {{任务 2}} | {{agent/人}} | docs/design/xxx.md | {{时长}} | todo |
| T3 | {{任务 3}} | {{agent/人}} | —(纯代码) | {{时长}} | todo |

## 3. 回写集(writeback set)

> 元 skill `route` 标记的、本计划结束时需同步更新的文档。与 `.age/writeback.json` 一致。

```json
{
  "task": "{{slug}}",
  "docs": [
    "docs/architecture/{{xxx}}.md",
    "docs/design/{{xxx}}.md"
  ],
  "skills": [],
  "timestamp": "{{日期}}T00:00:00Z"
}
```

## 4. 实现步骤

> 按顺序的执行步骤,每步可回滚。

1. **{{步骤 1}}**:{{说明}};验证方式:{{如何确认完成}}
2. **{{步骤 2}}**:{{说明}};验证方式:{{...}}
3. **{{步骤 3}}**:{{说明}};验证方式:{{...}}

## 5. 验证与测试

> 如何确认整体达成验收标准(对照需求 AC)。

- 测试命令:`{{命令,如 pytest tests/test_xxx.py}}`
- 手动验证:{{步骤}}
- AC 对照:
  - AC1 ← {{T1 + 测试}}
  - AC2 ← {{T2}}
  - AC3 ← {{T3}}

## 6. 收尾条件(closure criteria)

> `age audit --scope closure` 将逐条核验。全部满足方可标记 done。

- [ ] 所有任务(T1-Tn)状态 = done
- [ ] 回写集 docs 全部已更新(对照 `.age/writeback.json` 已清空)
- [ ] 验收标准 AC1-AC3 全部勾选
- [ ] `age check --strict` 退出码 0
- [ ] `age sync` 无漂移(stale/orphan/missing 均为空)
- [ ] 未决问题(需求第 6 节)已处理或有明确延期说明
- [ ] 变更记录已更新

## 7. 风险与回退

- **风险**:{{描述}};缓解:{{措施}}
- **回退方案**:{{若失败如何恢复,如 revert commit / feature flag}}

## 8. 变更记录

| 日期 | 变更 | 原因 |
|---|---|---|
| {{日期}} | 初稿 | — |

---

> AGE 提示:任务开始前 `/age-route {{slug}}` 标记回写集;任务结束 `/age-sync` 同步文档;完成后 `/age-audit --scope closure` 产出收尾审计。

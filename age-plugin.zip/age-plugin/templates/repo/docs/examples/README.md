# Examples — AGE 工作流示例集

> 本目录提供 AGE 工作流的可复制骨架示例。每个示例体现从需求到收尾的完整轨迹片段。
> 用法:复制到目标项目对应目录(docs/plans、docs/requirements、docs/audits),替换 `{{日期}}` 等占位符。

## 目录内容

| 文件 | 对应目标目录 | 用途 |
|---|---|---|
| `{{日期}}-feature-requirement.example.md` | `docs/requirements/` | 需求文档骨架:含验收标准、约束、关联 |
| `{{日期}}-feature-plan.example.md` | `docs/plans/` | 特性计划骨架:含任务分解、回写集、收尾条件 |
| `{{日期}}-closure-audit.example.md` | `docs/audits/` | 收尾审计骨架:对照计划核验完成度 |
| `complete-small-app-walkthrough.md` | (参考) | 一个小应用从需求到收尾的完整串联示例 |

## 命名规范

- 文件名:`{{YYYY-MM-DD}}-{{slug}}.example.md`(复制后去掉 `.example`)
- 日期 = 文档创建日;slug = 短横线小写英文
- 一条特性/任务的 requirement、plan、closure-audit 三份文档共享同一 slug,仅日期与后缀不同

## 与 AGE 流程的对应

AGE 四个子流程(见 SKILL.md / CONTRACT 第 6 节)与示例的对应关系:

```
需求(requirement) ──> 计划(plan) ──route/编码──> 收尾审计(closure-audit)
   age-init 后建立       route 标记回写集      doc-sync + audit --scope closure
```

- **requirement**:在 `age-init` 套模板后,新任务开始时先写需求
- **plan**:元 skill `route` 子流程标记回写集后,产出计划
- **closure-audit**:任务结束 `doc-sync` 后,`age audit --scope closure` 产出

## 使用提示

1. 示例为骨架,字段是推荐结构而非强制;项目可在 AGENTS.md 中裁剪。
2. `{{日期}}`、`{{项目名}}`、`{{slug}}` 等双花括号占位需替换。
3. 完整流程串联见 `complete-small-app-walkthrough.md`,适合首次使用者通读。
4. 示例中的回写集(writeback set)字段应与 `.age/writeback.json` 结构一致(见 CONTRACT 第 3 节 route 命令)。

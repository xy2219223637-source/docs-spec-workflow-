# 收尾审计:{{特性名称}}

> 文档类型:closure-audit
> 审计日期:{{日期}}
> slug:{{slug}}
> 审计范围:closure
> 审计执行:`age audit --scope closure`(由 hooks.Stop 或 /age-audit 触发)
> 审计对象:docs/plans/{{日期}}-{{slug}}.md 及其关联产物

---

## 1. 审计概要

| 项 | 值 |
|---|---|
| 审计对象 | docs/plans/{{日期}}-{{slug}}.md |
| 计划状态 | done / in-progress / blocked |
| 审计结论 | PASS(通过)/ FAIL(需返工) |
| 漂移报告 | `age sync --json` 输出摘要见下 |

## 2. 收尾条件核验

> 逐条对照计划第 6 节收尾条件。

| # | 收尾条件 | 状态 | 证据 |
|---|---|---|---|
| C1 | 所有任务状态 = done | PASS/FAIL | 计划第 2 节任务表 |
| C2 | 回写集 docs 全部已更新 | PASS/FAIL | `.age/writeback.json` 已清空(见第 4 节) |
| C3 | 验收标准 AC1-AC3 全部勾选 | PASS/FAIL | 需求第 3 节 |
| C4 | `age check --strict` 退出码 0 | PASS/FAIL | 命令输出 |
| C5 | `age sync` 无漂移 | PASS/FAIL | 漂移报告(第 3 节) |
| C6 | 未决问题已处理 | PASS/FAIL | 需求第 6 节 |
| C7 | 变更记录已更新 | PASS/FAIL | 计划/需求第 8 节 |

## 3. 漂移报告(`age sync --json` 摘要)

```json
{
  "stale": [],
  "orphan": [],
  "missing": []
}
```

- **stale**(文档存在但内容过时):{{条数}} — {{说明}}
- **orphan**(文档存在但无代码引用):{{条数}} — {{说明}}
- **missing**(代码存在但无对应文档):{{条数}} — {{说明}}

> 三项均为空方可判定 C5 = PASS。

## 4. 回写集核验

```
.age/writeback.json 状态:已清空 / 残留
```

- 残留文档:{{若有,列出}} — 说明:{{为何未同步}}

## 5. 验收标准达成对照

| AC | 状态 | 验证证据 |
|---|---|---|
| AC1 | PASS/FAIL | {{测试命令/手动验证结果}} |
| AC2 | PASS/FAIL | {{...}} |
| AC3 | PASS/FAIL | {{...}} |

## 6. 发现的问题

> 审计中发现的偏差、缺失、技术债。

| # | 问题 | 严重度 | 处理 |
|---|---|---|---|
| F1 | {{描述}} | 阻断/重要/次要 | {{处理:立即修复 / 转 backlog / 接受}} |

## 7. 结论

- **审计结论**:PASS / FAIL
- **若 FAIL**,需返工项:{{列出阻断项}}
- **若 PASS**,本特性正式收尾,计划状态标记 done,需求状态标记 delivered。

## 8. 变更记录

| 日期 | 变更 | 原因 |
|---|---|---|
| {{日期}} | 初稿 | 审计执行 |

---

> AGE 提示:PASS 后可由 `age evolve {{slug}}` 标记 backlog 完成、更新 design、记 ADR。FAIL 则修复后重跑 `age audit --scope closure`。

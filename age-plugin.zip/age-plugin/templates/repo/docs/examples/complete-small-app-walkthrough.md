# 完整小应用流程示例:待办 CLI(todo-cli)

> 本文档演示 AGE 工作流在一个小应用上的完整轨迹:从初始化、需求、计划、编码、文档同步到收尾审计。
> 用途:首次使用 AGE 的用户通读,理解四层(插件/skill/CLI/MCP)如何协作。
> 示例应用:一个 Python 写的命令行待办工具(`todo-cli`),功能 = 增/删/列/完成。
> 占位符:{{日期}} 表示当日日期;实际使用时替换。

---

## 阶段 0:初始化(age-init)

**触发**:新仓库 / 套 AGE 模板。

```bash
# 1. 创建项目目录
mkdir todo-cli && cd todo-cli && git init

# 2. AGE 初始化(由 /age-init 或 hooks.SessionStart 首次触发)
age init --name todo-cli --kind cli
```

**AGE 发生了什么**:
- 元 skill `age-init` 子流程启动(第 6 节)
- CLI `age init` 生成 `templates/repo/` 骨架到当前目录:AGENTS.md、docs/index.md、docs/context/、各 docs 子目录 README
- `age baseline` 快照当前 docs/ 指纹到 `.age/baseline.json`
- SessionStart 注入 `docs://context/project-context`(若 MCP 在线)

**产物**:
```
todo-cli/
├── AGENTS.md
├── docs/
│   ├── index.md          # 文档路由器
│   ├── context/          # 强制上下文(项目基线)
│   ├── backlog/          # 待办特性池
│   ├── requirements/
│   ├── design/
│   ├── plans/
│   ├── audits/
│   └── ...               # 其他目录见 docs/index.md
└── .age/
    └── baseline.json     # 基线指纹
```

**验证**:
```bash
age doctor        # 环境/配置 OK
age check         # 0(空项目无漂移)
```

---

## 阶段 1:需求(route → requirement)

**目标**:为 todo-cli 写"增删列完成"的需求。

**AGE 流程**:
1. 用户对 agent 说:"给 todo-cli 加增删列完成四个功能"
2. 元 skill `route` 子流程触发(任务开始前):读 `docs://index`,路由到 `docs/requirements/` 与 owner 文档
3. `age route "todo-cli 增删列完成" --explain` 标记回写集

```
$ age route "todo-cli 增删列完成" --explain
doc:    docs/requirements/todo-crud.md
skill:  age/route
reason: 新功能 → requirements 目录;无现有文档 → 新建
writeback: docs/design/todo-arch.md, docs/architecture/components.md
→ .age/writeback.json 已写入
```

**产出需求文档**(复制 `{{日期}}-feature-requirement.example.md` 到 `docs/requirements/todo-crud.md`):

```markdown
# 需求:todo-cli 增删列完成

## 2. 需求陈述
用户能通过命令行增、删、列、标记完成待办项,数据存本地 JSON。

## 3. 验收标准
- [ ] AC1:`todo add "买菜"` 后 `todo list` 能看到该项,id=1
- [ ] AC2:`todo done 1` 后该项标记完成,`list` 显示已完成
- [ ] AC3:`todo rm 1` 后该项消失,`list` 不再显示
- [ ] AC4:`todo list` 退出码 0 且无未捕获异常

## 4. 约束
- 单文件 Python,无外部依赖(仅标准库)
- 数据存 ~/.todo.json
```

(完整骨架见 `{{日期}}-feature-requirement.example.md`)

---

## 阶段 2:计划(route → plan)

**AGE 流程**:
1. 需求就绪,元 skill `route` 再次触发,路由到 `docs/plans/`
2. `age route` 更新回写集(加入 plans 与 architecture)

**产出计划文档**(复制 `{{日期}}-feature-plan.example.md` 到 `docs/plans/{{日期}}-todo-crud.md`):

```markdown
# 计划:todo-cli 增删列完成

## 2. 任务分解
| # | 任务 | owner | 回写文档 | 状态 |
|---|---|---|---|---|
| T1 | 实现 add 命令 | agent | docs/design/todo-arch.md | todo |
| T2 | 实现 list/done/rm | agent | docs/design/todo-arch.md | todo |
| T3 | 写测试 | agent | docs/testing/ | todo |

## 3. 回写集
{ "task": "todo-crud",
  "docs": ["docs/design/todo-arch.md", "docs/architecture/components.md"],
  ... }

## 6. 收尾条件
- [ ] T1-T3 done
- [ ] AC1-AC4 勾选
- [ ] age check --strict 退出 0
- [ ] age sync 无漂移
```

---

## 阶段 3:编码与文档同步(route / encode / doc-sync)

**编辑态**(hooks.PostToolUse 介入):

用户(或 agent)用 Edit/Write 实现 `todo.py`。每次工具调用后:

```
hooks.PostToolUse (matcher: Edit|Write|MultiEdit)
  → on-edit.sh → age sync --json(防抖,1s 内去重)
  → 返回漂移提醒: "docs/design/todo-arch.md 未更新(stale)"
```

**会话态**(MCP 介入):
- agent 通过 MCP `docs://status` 实时看到漂移分数
- `age_route("下一个任务")` 路由到 owner 文档

**任务结束后**(元 skill `doc-sync` 子流程):

```bash
/age-sync   # 或元 skill 自动触发
```

AGE 对照回写集更新 `docs/design/todo-arch.md`(记录命令结构、数据格式)与 `docs/architecture/components.md`(记录模块边界)。

**提交态**:

```bash
git add -A
# pre-commit hook → age check(校验路由死链/基线齐全)
git commit -m "feat: todo add/list/done/rm + docs"
```

---

## 阶段 4:收尾审计(audit)

**触发**:任务结束 / 用户 /age-audit / hooks.Stop。

```bash
age audit --scope closure
# 或 /age-audit --scope closure
```

**产出收尾审计文档**(复制 `{{日期}}-closure-audit.example.md` 到 `docs/audits/{{日期}}-todo-crud-closure.md`):

```markdown
# 收尾审计:todo-cli 增删列完成

## 2. 收尾条件核验
| # | 条件 | 状态 | 证据 |
|---|---|---|---|
| C1 | T1-T3 done | PASS | 计划任务表 |
| C2 | 回写集 docs 已更新 | PASS | writeback.json 已清空 |
| C3 | AC1-AC4 勾选 | PASS | 测试输出 |
| C4 | age check --strict 退出 0 | PASS | — |
| C5 | age sync 无漂移 | PASS | stale/orphan/missing 均空 |

## 3. 漂移报告
{ "stale": [], "orphan": [], "missing": [] }

## 7. 结论:PASS
```

---

## 阶段 5:演进(evolve)

**可选**:审计 PASS 后,将 backlog 项标记完成、更新 design、记 ADR。

```bash
age evolve todo-crud   # 标记 backlog 完成、更新 design、记 ADR
```

(对应 MCP `age_evolve(task_id)`;见 CONTRACT 第 4 节)

---

## 四层协作总览(本次轨迹)

| 阶段 | 插件层 | 元 skill | CLI | MCP |
|---|---|---|---|---|
| 0 init | /age-init 触发 | age-init 子流程 | `age init`/`baseline` | docs://context 注入 |
| 1 需求 | — | route 子流程 | `age route --explain` | age_route tool |
| 2 计划 | — | route 子流程 | `age route`(更新回写集) | docs://status |
| 3 编码 | hook PostToolUse | doc-sync 子流程 | `age sync --json` | age_check_drift |
| 4 收尾 | hook Stop / /age-audit | audit 子流程 | `age audit --scope closure` | docs://status |
| 5 演进 | — | — | `age evolve` | age_evolve |

## CI 态(提交后)

```bash
age ci   # = check --strict + sync --json,非交互
# 退出码 0 → 合并;1 → 漂移/违规,阻断
```

CI 不依赖 MCP/会话态,纯 CLI + 文件系统,可在 GitHub Actions / 任意 CI 复现。

---

## 关键检查点速查

| 检查 | 命令 | 期望 |
|---|---|---|
| 环境就绪 | `age doctor` | 退出 0 |
| 无死链/基线齐 | `age check --strict` | 退出 0 |
| 无文档漂移 | `age sync --json` | stale/orphan/missing 均空 |
| 回写集已清空 | 查看 `.age/writeback.json` | docs: [] |
| 收尾完整 | `age audit --scope closure` | PASS |

> 本示例假设 CONTRACT v1.1 已修复 D-5(SessionStart 不调 route)、D-6(回写集落 writeback.json)。在 v1 下,阶段 0 的 SessionStart 与阶段 2 的回写集需手动处理。

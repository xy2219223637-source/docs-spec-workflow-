# {{project_name}} — 文档路由器

> 本文件是 {{project_name}} 的文档入口。所有 agent 与人开始任务前先读本文件,按路由表找到该读的 owner 文档。
> 由 AGE 插件 `age init` 生成。`age check` 校验本文件的路由表无死链、目标在基线 schema 内。
> **本文件优先于 AGE 默认路由**;本文件沉默处回退到 AGE `references/routing-rules.md`。

## 路由表(如果你需要 X → 先读 Y)

| 你要做的事 | 先读(READ 集) | 可能回写(WRITEBACK 集) |
|---|---|---|
| 新增/修改需求 | `context/project-context.md`、`backlog/`、`requirements/` | `backlog/`、`requirements/`、`plans/`(若进计划) |
| 设计接口/数据结构 | `context/conventions.md`、`architecture/`、`design/`、相关 `requirements/` | `design/`、`plans/`、`architecture/`(仅契约变更) |
| 改模块边界/依赖方向 | `context/codebase-map.md`、`context/conventions.md`、`architecture/`、`design/` | `architecture/`、`context/codebase-map.md`、`audits/`(ADR) |
| 查项目现状/约定 | `context/` 全部 | 通常 none(纯查询);发现过期→开新任务 |
| 修 bug | `context/project-context.md`、相关 `requirements/` 验收标准、`design/` | `logs/`、`bugs/`(复杂回归)、`requirements/`(若验收标准变) |
| 审计一致性 | `index.md`(本文件)、`context/source-of-truth-and-precedence.md`、全部 owner 目录 | `audits/`(报告)、`bugs/`(若发现回归) |
| 写测试 | `context/conventions.md`、`design/`、相关 `requirements/` 验收标准 | `logs/`、`requirements/`(若补充验收标准) |

> 路径相对 `docs/`。例:`context/project-context.md` = `docs/context/project-context.md`。

## 推荐默认路径(10 步,新任务通用)

1. **读本文件** — 确认任务类型与路由。
2. **读强制上下文** — `context/` 五个文件(`SessionStart` hook 已注入摘要,但实质性任务仍要读全文)。
3. **归类输入** — 需求/设计/架构/上下文/审计(见 AGE `routing-rules.md`)。
4. **跑路由** — `age route "<task>" --explain` 拿 READ 集 + WRITEBACK 集 + 技能路由。
5. **读 READ 集** — 实际读文档内容,不只看路径。
6. **标 WRITEBACK 集** — 写进计划(若进 plans)或日志。
7. **记技能选择** — 每阶段 `Skill: <name>` 或 `Skill: none`(见 AGENTS.md §3)。
8. **执行** — 写代码/改文档。冲突按 source-of-truth 链裁决(owner > 计划 > 日志 > 聊天)。
9. **doc-sync** — `age sync --since <ref>` → 对照 WRITEBACK 集回写 → 更新 backlog(`age evolve`)→ 记日志。
10. **收尾审计** — `{{validate_cmd}}`(若非空)→ `age check` → `age audit --scope closure`。全绿才算完成。

## 技能路由表

> AGE 是方法选择器:它选项目技能,自己不替代。下表是本仓库的项目技能映射。无项目技能的项记 `none`,直接走 owner 文档。

| 任务类型 | 项目技能 | 备注 |
|---|---|---|
| 需求分析 | {{skill_requirements}} | 为空填 `none` |
| 接口/数据建模 | {{skill_design}} | 为空填 `none` |
| 架构决策 | {{skill_architecture}} | 为空填 `none` |
| 测试编写 | {{skill_testing}} | 为空填 `none` |
| 构建/部署 | {{skill_build}} | 为空填 `none` |

> `age init` 时这些占位符默认渲染为 `none`;项目接入专属技能后手动填入技能名。

## owner 目录索引

| 目录 | 职责 | 强制? |
|---|---|---|
| `context/` | 项目上下文(5 个强制文件) | 强制 |
| `backlog/` | 待办条目 | 条件强制(`require_backlog={{require_backlog}}`) |
| `requirements/` | 需求与验收标准 | 强制 |
| `design/` | 接口/数据结构/流程设计 | 强制 |
| `architecture/` | 分层/依赖/技术选型/ADR 索引 | 强制 |
| `plans/` | 任务计划(跨多 owner/≥3 阶段/架构变更) | 按需 |
| `audits/` | 审计报告 + ADR | 按需(架构变更必产 ADR) |
| `logs/` | 任务日志(READ/WRITEBACK/改动/技能记录) | 按需 |
| `bugs/` | 复杂回归归档 | 按需 |

各目录职责详情见对应 `README.md`(由 `age init` 生成)。基线最小内容 schema 见 AGE 插件 `references/baseline-schema.md`。

## 维护

- 改本文件后跑 `age check` 确认无死链。
- 新增 owner 目录→同步加进本路由表 + `baseline-schema.md`(若需强制)。
- 路由表与 AGENTS.md §2 必须一致;`age check` 会交叉校验。

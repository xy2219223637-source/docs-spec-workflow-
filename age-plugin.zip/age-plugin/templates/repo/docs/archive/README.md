# docs/archive/

已归档文档。这里存放**过时但仍有参考价值**的内容——不再活跃维护,但保留以便追溯历史决策。

## 什么进 archive

- 已完成且不再活跃的 plan(收尾后从 `docs/plans/` 移入)。
- 被新版本取代的 design / architecture 文档(保留旧版以理解演化)。
- 过期的 retrospective、lessons(沉淀后的原始记录)。
- 不再适用的 conventions / glossary 条目。

## 什么不进 archive

- 仍在引用的活跃文档——留在原目录,过时就更新而非归档。
- 无参考价值的废弃实验——直接删除,不要堆积。
- 代码本身——archive 只放文档,不放代码。

## 归档约定

1. **移动而非删除**:用 `git mv` 把文档从原目录移入 `archive/`,保留历史。
2. **加日期前缀**:文件名加 `YYYY-MM-DD-` 前缀,标明归档时间(如 `2026-03-01-old-auth-design.md`)。
3. **顶部加归档说明**:在文件开头注明归档日期、归档原因、取代它的新文档路径。

```markdown
> 归档于 2026-03-01。原因:被 docs/design/auth-v2.md 取代。
> 保留以理解 v1 的设计动机。
```

4. **断开活跃路由**:`docs/index.md` 不应再路由到 archive 下的文档。`age check` 会把 archive 内的链接排除在死链检查之外,但活跃路由指向 archive 视为告警。

## 与 AGE 支架的关系

archive 是**日志支架**的一部分:它让历史决策可追溯,而非凭记忆。但记住——归档是第二性的,吸引子(`docs/context/`、`AGENTS.md`)才是第一性的(见 `docs/articles/attractor-before-harness.md`)。不要为归档而归档;归档的价值在于让活跃文档保持精简,同时不丢失历史。

# START HERE — 复制模板后的 Day 0 清单

> 本文件在你把 AGE 模板复制进新仓库后出现。它是 Day 0 的唯一入口。
> **铁律:Day 0 清单未全部勾选前,不让 AI 实现任何功能。**
> 原因:owner 文档是吸引子,计划/测试/审计/日志是支架;没有真实的项目上下文,吸引子就是空的,支架会搭在流沙上。

---

## 快速启动(推荐)

不想逐步走 Day 0 清单?可以直接让 AGE 自动初始化:

- **自然语言**:对 AI 说"启动 AGE""开启 AGE""enable AGE""用 AGE"等相同语义的话,use-AGE 技能会被触发,自动检测项目状态;若未初始化,自动执行 `age init` 完成脚手架生成与基线建立。
- **Slash 命令**:输入 `/use-age`,等价于上述自然语言触发。
- **CLI**:在项目根目录运行 `age use`,手动触发同样的"检测 + 自动初始化 + 激活"流程。

> 自动初始化覆盖 Day 0 清单的核心步骤(环境诊断、脚手架生成、基线快照)。若你希望逐项确认每个占位符的填写——尤其 `docs/context/project-context.md` 的真实信息与 `AGENTS.md` 的验证命令——仍可按下面的 Day 0 清单逐步走,作为详细备选路径。

---

## 多客户端安装

AGE 以 ZCode 为一等宿主,同时兼容 Claude Code / Codex CLI / OpenCode CLI。四者共享同一套 CLI、AGENTS.md 指令文件与 MCP server,仅 hooks/commands/skills 的配置格式按各客户端适配。

**自动安装(推荐)**:在项目根运行:

```bash
age install
```

该命令自动检测当前客户端环境(ZCode / Claude Code / Codex / OpenCode),把对应的适配配置装到正确位置,然后你可以继续上面的"快速启动"或下面的 Day 0 清单。

**手动安装(按你的客户端)**:若自动检测未覆盖或你想显式控制,按客户端分别处理:

| 客户端 | 安装方式 |
|---|---|
| **ZCode** | 装本 AGE 插件(plugin.json + marketplace),即完整宿主。插件自带 hooks/commands/skills/MCP,无需额外拷贝。 |
| **Claude Code** | 拷 `compat/claude-code/` 下的配置到工作区:hooks/skills/commands 进 `.claude/`,MCP 配置写入 `.mcp.json`;另外在工作区放一份 `CLAUDE.md`(AGENTS.md 的 Claude 版指令文件)。 |
| **Codex CLI** | 拷 `compat/codex/config.toml` 到 `~/.codex/`(用户级配置),MCP server 以 TOML `[mcp_servers.age]` 段声明,指向同一个 `mcp/server.py`。Codex 无工作区配置文件与 skills/hooks,靠 AGENTS.md 指令 + CLI + MCP 工作。 |
| **OpenCode CLI** | 拷 `compat/opencode/opencode.json` 到项目根,内含 MCP(指向 `mcp/server.py`)+ commands + hooks(camelCase 事件名)。指令文件用 AGENTS.md。 |

> 各客户端的详细对照与字段差异见 `compat/README.md` 及 `compat/<客户端>/README.md`(由事实设计提供)。各适配配置指向的是**同一个** `mcp/server.py` 与同一套 CLI,因此跨客户端的项目状态(`.age/`)与文档(`docs/`)完全共用,切换客户端不会丢失上下文。

> Claude Code 额外需要 `CLAUDE.md`(因 Claude Code 只认该文件名作指令文件);其余三个客户端均认 `AGENTS.md`。`compat/claude-code/CLAUDE.md` 是 AGENTS.md 的副本,内容与 AGENTS.md 保持一致。

安装完成后,回到上面的"快速启动"或下面的 Day 0 清单继续。

---

## Windows 11 安装

Win11 原生无 bash,AGE 提供双层兼容:PowerShell 原生入口(推荐)与 Git-Bash 回退。以下步骤不强制要求装 Git-Bash,但若已装则更省事。

**前置条件**:

- Windows 11
- PowerShell 5.1(预装)或 PowerShell 7(可选)
- Python 3.x(`python --version` 可执行;Win11 上通常是 `python` 而非 `python3`)

**自动安装(推荐)**:在项目根运行:

```powershell
age install --client win11
```

该命令自动配置 PowerShell 入口:把 `cli/age.ps1` 与 `cli/lib/*.ps1` 放到可用位置,安装 Win11 专用 hook 脚本(`hooks/scripts/*.ps1` + `hooks/hooks.win11.json`),并输出环境变量设置提示。

**手动安装**:若自动安装未覆盖或你想显式控制:

1. 把 `cli/age.ps1` 所在目录加入 `PATH`(或用绝对路径调用)。
2. 设置环境变量指向插件根:
   ```powershell
   $env:AGE_PLUGIN_ROOT = "<插件根绝对路径>"
   ```
   持久化可用 `[Environment]::SetEnvironmentVariable("AGE_PLUGIN_ROOT","<路径>","User")`。
3. MCP server 在 Win11 上用 `python`(非 `python3`)启动:`python mcp/server.py`。

**Git-Bash 回退**:若你装了 Git for Windows,现有 bash 脚本(`cli/age` + `cli/lib/*.sh` + `hooks/scripts/*.sh`)可在 Git-Bash 下直接运行,无需 PowerShell 入口。此时按本文档其他小节的 bash 命令操作即可。

**注意事项**:

- **行结束符**:Win11 上编辑模板易引入 CRLF 污染提交。建议 `git config core.autocrlf input`(提交时转 LF,检出时不转换)。详见 `docs/context/conventions.md` 的"Windows 11 环境约定"。
- **路径分隔符**:文档内统一用正斜杠 `/`(跨平台);PowerShell 脚本内正斜杠或反斜杠均可(PowerShell 两者都接受)。
- **Python 命令名**:Win11 上是 `python` 而非 `python3`;`age.ps1` 自动按 `python` → `python3` → `py -3` 顺序检测可用解释器。

Win11 安装完成后,回到上面的"快速启动"或下面的 Day 0 清单继续。

---

## 为什么必须先做 Day 0

AGE 把项目分为两层:

- **事实层(owner 文档)**:`docs/context/`、`AGENTS.md`、`docs/index.md` —— 这些是项目真实信息的来源,吸引 agent 朝着正确方向收敛。
- **过程层(支架)**:`docs/plans/`、`docs/audits/`、`docs/logs/`、`docs/testing/` —— 这些在事实层之上搭建可验证的脚手架。

Day 0 的全部目的:把事实层的占位符替换成**你项目的真实信息**,再建立第一条已知良好基线。之后 AI 才有"对齐的参照物"可以工作。

---

## Day 0 清单(按顺序勾选)

### 步骤 1:诊断环境

先确认 AGE CLI 可用、配置无误。

```bash
age doctor
```

- 退出码 `0` = 环境就绪。
- 退出码 `1` = 有问题,按提示修复(常见:CLI 未入 PATH、`docs/` 缺失、AGENTS.md 未生成)。
- 相关:`age doctor` 在正式 `age init` **之前**运行,用于排障。

> 参考:CONTRACT.md 第 3 节。

- [ ] `age doctor` 退出码 0

### 步骤 2:初始化脚手架(若尚未生成)

```bash
age init --name {{项目名}} --kind {{web|mobile|cli}}
```

- `--name`:项目名,将写入 `docs/context/project-context.md`。
- `--kind`:项目类型,影响默认目录与验证命令模板。
- 退出码 `0` = 骨架生成成功;`1` = 失败,查 `age doctor`。

> 若模板已手动复制且 `age init` 已在复制流程中跑过,可跳过,但请确认 `docs/` 下目录齐全。

- [ ] `age init` 已执行并退出码 0(或确认骨架已就位)

### 步骤 3:填写项目上下文(事实层核心)

打开 `docs/context/project-context.md`,把所有 `{{占位符}}` 替换为真实信息。至少填写:

- **项目名 / 一句话定位** —— 这条信息会被 SessionStart 注入到每个会话上下文。
- **技术栈与关键依赖** —— 决定验证命令、基线脚本长什么样。
- **目录布局说明** —— 告诉 agent 代码与文档各自在哪。
- **运行/测试/构建命令** —— `age check` 与收尾审计会引用。
- **关键约束与不变式** —— agent 实现时必须遵守的硬约束。

> 这是吸引子的源头。空着或填假数据 = 后续所有计划、审计都基于错误前提。

- [ ] `docs/context/project-context.md` 无残留 `{{占位符}}`
- [ ] 上述每类信息都已填写真实内容(非占位)

### 步骤 4:填写 AGENTS.md 验证命令

打开 `AGENTS.md`,把验证命令块替换为项目真实命令:

- **运行命令**:本地启动项目的命令(例:`npm run dev`)。
- **测试命令**:跑测试套件的命令(例:`npm test`、`pytest`)。
- **类型检查/Lint**:例:`npm run lint && npx tsc --noEmit`。
- **构建命令**:例:`npm run build`。

这些命令会被 `age check`、收尾审计、`/age-audit` 反复引用。命令错误 = 验证全部失效。

> 参考:CONTRACT.md 第 2 节,`templates/repo/AGENTS.md` 由事实设计 agent 提供。

- [ ] `AGENTS.md` 中验证命令全部为可执行的真实命令
- [ ] 在本地实际跑过一遍,确认退出码符合预期

### 步骤 5:生成第一条基线

```bash
age baseline
```

- 作用:快照当前 `docs/` 指纹到 `.age/baseline.json`,作为"已知良好"参照点。
- 退出码恒为 `0`(只是写快照)。
- 之后的 `age sync` 会以此为基准报告漂移。

> 没有 baseline,`age sync` 的"漂移"无意义。Day 0 必须先建立它。

- [ ] `.age/baseline.json` 已生成
- [ ] 内容包含当前 `docs/` 各文件指纹

### 步骤 6:运行自检确认闭环

```bash
age check --strict
```

- 检查项:路由无死链、基线齐全、AGENTS.md 引用可解析。
- 退出码 `0` = 通过;`1` = 有违规,按提示修复后重跑。

```bash
age sync
```

- 刚建好 baseline 时,`age sync` 应报告"无漂移"(退出码 0)。若报告有漂移,说明步骤 3-5 之间又改了文档,回到步骤 5 重建 baseline。

- [ ] `age check --strict` 退出码 0
- [ ] `age sync` 退出码 0(无漂移)

---

## Day 0 完成判据

全部勾选后,以下条件成立:

1. `age doctor` → 0
2. `docs/context/project-context.md` 无占位符、信息真实
3. `AGENTS.md` 验证命令可执行且已实测
4. `age baseline` 已生成 `.age/baseline.json`
5. `age check --strict` → 0
6. `age sync` → 0(无漂移)

**只有全部成立,才允许进入开发工作流。** 见 `docs/process/application-development-workflow.md`。

---

## Day 0 之后做什么

1. **第一个需求**:把原始输入放进 `docs/input/`,按 `docs/requirements/00-requirement-synthesis-guide.md` 综合成需求。
2. **第一个计划**:按 `docs/plans/00-plan-authoring-and-execution-guide.md` 编写计划,创建后必须先过计划审计。
3. **日常**:每个开发任务开始前用 `age route <task>` 路由到 owner 文档;结束后触发收尾审计。

记住 AGE 的哲学:**owner 文档是吸引子,计划/测试/审计/日志是支架。** Day 0 把吸引子装好,之后才有可对齐的支架。
